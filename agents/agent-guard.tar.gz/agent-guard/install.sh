#!/usr/bin/env bash
# Install agent-guard into a repository.
#   ./install.sh /path/to/repo
# Copies the control plane in, makes hooks executable, wires .gitignore,
# and prints the one-time manual steps. Re-running overwrites hook scripts
# but never your allowed-hosts, checks, AGENTS.md or CLAUDE.md.
set -euo pipefail
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="${1:?usage: install.sh /path/to/repo}"
[[ -d "$DEST/.git" ]] || { echo "not a git repo: $DEST" >&2; exit 1; }

copy_if_missing() { [[ -e "$DEST/$1" ]] && echo "  keep   $1" || { mkdir -p "$(dirname "$DEST/$1")"; cp -R "$SRC/$1" "$DEST/$1"; echo "  add    $1"; }; }
copy_always()     { mkdir -p "$(dirname "$DEST/$1")"; cp -R "$SRC/$1" "$DEST/$1"; echo "  update $1"; }

echo "Installing agent-guard into $DEST"
copy_always     .guard/hooks
copy_always     .guard/.gitignore
copy_if_missing .guard/checks/on-edit
copy_if_missing .guard/checks/on-stop
copy_if_missing .guard/allowed-hosts
copy_always     .claude/settings.json
copy_always     .codex/hooks.json
copy_if_missing .codex/config.toml
copy_if_missing AGENTS.md
copy_if_missing CLAUDE.md
copy_if_missing .github/workflows/agent-guard.yml
copy_if_missing .pre-commit-config.yaml
chmod +x "$DEST"/.guard/hooks/*.sh "$DEST"/.guard/checks/*

grep -qx '.guard/logs/' "$DEST/.gitignore" 2>/dev/null || echo '.guard/logs/' >> "$DEST/.gitignore"

cat <<TXT

Done. One-time steps you have to do yourself:
  1. Edit .guard/allowed-hosts for this project's registries and APIs.
  2. Edit .guard/checks/on-edit and on-stop so they match the stack (they skip missing tools).
  3. Tools the hooks expect on the machine/sandbox: jq (required), gitleaks, shellcheck, your linters.
  4. pip install pre-commit && (cd "$DEST" && pre-commit install)
  5. Codex: run /hooks in the TUI once to review and activate the repo hooks.
  6. Commit all of this. The control plane only works when it travels with the repo.
TXT
