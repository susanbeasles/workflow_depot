// src/deployment-authority-worker.mjs
import { DurableObject, WorkerEntrypoint } from "cloudflare:workers";

// src/shared/oidc.mjs
var encoder = new TextEncoder();
var issuer = "https://token.actions.githubusercontent.com";
var reject = (message) => {
  throw new Error(message);
};
function decode(value) {
  if (typeof value !== "string" || !value.length || !/^[A-Za-z0-9_-]+$/.test(value)) reject("Invalid OIDC encoding");
  return Uint8Array.from(atob(value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4)), (c) => c.charCodeAt(0));
}
function json(value) {
  return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(decode(value)));
}
async function githubJWKS(fetcher = fetch) {
  const response = await fetcher(`${issuer}/.well-known/jwks`, { redirect: "manual", signal: AbortSignal.timeout(1e4) });
  if (!response.ok) reject("OIDC trust-key retrieval failed");
  const raw = await response.text();
  if (raw.length > 128e3) reject("OIDC trust-key inventory too large");
  const data = JSON.parse(raw);
  if (!Array.isArray(data.keys) || data.keys.length > 32) reject("Invalid OIDC trust-key inventory");
  return data;
}
async function verifyExecutorOIDC(token2, trust, { operationID, runID, runAttempt }, jwks, now = Math.floor(Date.now() / 1e3)) {
  if (typeof token2 !== "string" || token2.length > 2e4) reject("Invalid OIDC token size");
  const parts = token2.split(".");
  if (parts.length !== 3) reject("Invalid OIDC token");
  const header = json(parts[0]);
  if (header.alg !== "RS256" || typeof header.kid !== "string" || header.jku || header.jwk || header.x5u || header.crit) reject("Unsupported OIDC signature header");
  const keys = jwks?.keys?.filter((k) => k.kid === header.kid && k.kty === "RSA" && (k.alg === void 0 || k.alg === "RS256") && (k.use === void 0 || k.use === "sig") && !k.d);
  if (keys?.length !== 1) reject("Unknown or ambiguous OIDC signing key");
  const key = await crypto.subtle.importKey("jwk", keys[0], { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
  if (!await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, decode(parts[2]), encoder.encode(`${parts[0]}.${parts[1]}`))) reject("Invalid OIDC signature");
  const c = json(parts[1]);
  if (c.iss !== issuer || c.aud !== `${trust.audiencePrefix}:${operationID}`) reject("Wrong OIDC issuer/audience");
  if (![c.exp, c.iat, c.nbf].every(Number.isSafeInteger) || c.exp <= now || c.iat > now + 30 || c.nbf > now + 30 || c.exp <= c.iat || c.exp - c.iat > 600 || c.iat < now - 600) reject("Expired or invalid OIDC lifetime");
  const exact3 = { repository: trust.repository, repository_id: String(trust.repositoryID), repository_owner_id: String(trust.ownerID), ref: trust.ref, workflow_ref: trust.workflowRef, workflow_sha: trust.workflowSHA, job_workflow_ref: trust.jobWorkflowRef, job_workflow_sha: trust.jobWorkflowSHA, runner_environment: "github-hosted", run_id: String(runID), run_attempt: String(runAttempt) };
  for (const [name, value] of Object.entries(exact3)) if (typeof value !== "string" || !value.length || c[name] !== value) reject(`Untrusted executor claim: ${name}`);
  if (!trust.eventNames?.includes(c.event_name) || !trust.actorIDs?.includes(Number(c.actor_id))) reject("Untrusted executor event/actor");
  if (typeof c.jti !== "string" || c.jti.length < 8 || c.jti.length > 200) reject("Missing OIDC replay identity");
  return { jti: c.jti, runID: String(runID), runAttempt: String(runAttempt), expiresAt: c.exp, workflowSHA: c.job_workflow_sha };
}
function validateTrust(t) {
  const fields = ["audiencePrefix", "repository", "repositoryID", "ownerID", "ref", "workflowRef", "workflowSHA", "jobWorkflowRef", "jobWorkflowSHA", "eventNames", "actorIDs"];
  const positive2 = (v) => Number.isSafeInteger(v) && v > 0, sha2 = /^[a-f0-9]{40}$/;
  if (!t || Object.getPrototypeOf(t) !== Object.prototype || Object.keys(t).sort().join() !== fields.sort().join()) reject("Invalid executor trust schema");
  if (!["audiencePrefix", "repository", "ref", "workflowRef", "workflowSHA", "jobWorkflowRef", "jobWorkflowSHA"].every((k) => typeof t[k] === "string")) reject("Invalid executor trust field type");
  if (typeof t.audiencePrefix !== "string" || !/^[A-Za-z0-9_.:-]{1,200}$/.test(t.audiencePrefix) || !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(t.repository) || !positive2(t.repositoryID) || !positive2(t.ownerID) || !/^refs\/heads\/[A-Za-z0-9_.\/-]+$/.test(t.ref) || ![t.workflowSHA, t.jobWorkflowSHA].every((v) => sha2.test(v))) reject("Invalid executor trust identity");
  const workflow2 = /^([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+)\/\.github\/workflows\/[A-Za-z0-9_.-]+\.ya?ml@(refs\/heads\/[A-Za-z0-9_.\/-]+|[a-f0-9]{40})$/;
  const caller = typeof t.workflowRef === "string" && t.workflowRef.match(workflow2), job = typeof t.jobWorkflowRef === "string" && t.jobWorkflowRef.match(workflow2);
  if (!caller || caller[1] !== t.repository || caller[2] !== t.ref || !job || sha2.test(job[2]) && job[2] !== t.jobWorkflowSHA) reject("Invalid pinned workflow identity");
  if (!Array.isArray(t.eventNames) || !t.eventNames.length || t.eventNames.length > 20 || !t.eventNames.every((v) => typeof v === "string" && /^[a-z][a-z0-9_]{0,63}$/.test(v)) || new Set(t.eventNames).size !== t.eventNames.length || !Array.isArray(t.actorIDs) || !t.actorIDs.length || t.actorIDs.length > 100 || !t.actorIDs.every(positive2) || new Set(t.actorIDs).size !== t.actorIDs.length) reject("Invalid executor event or actor policy");
  return t;
}
async function verifyOIDC(token2, trust, binding, jwks, now = Math.floor(Date.now() / 1e3)) {
  validateTrust(trust);
  if (!binding || Object.keys(binding).sort().join() !== ["operationID", "runID", "runAttempt"].sort().join() || typeof binding.operationID !== "string" || !/^[a-f0-9]{64}$/.test(binding.operationID) || ![binding.runID, binding.runAttempt, now].every((v) => Number.isSafeInteger(v) && v > 0)) reject("Invalid execution binding");
  return verifyExecutorOIDC(token2, trust, binding, jwks, now);
}

// src/shared/contract.mjs
var encoder2 = new TextEncoder();
var hex = /^[a-f0-9]{64}$/;
var id = /^[a-f0-9]{32}$/;
var sha = /^[a-f0-9]{40}$/;
var uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
var repository = /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/;
var script = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
var matches = (pattern, value) => typeof value === "string" && pattern.test(value);
var signerKey = (value) => matches(hex, value) && value.length === 64 || matches(/^SHA256:[A-Za-z0-9+/]{42}[AEIMQUYcgkosw048]$/, value) && value.length === 50;
var positive = (v) => Number.isSafeInteger(v) && v > 0;
var object = (v) => v !== null && typeof v === "object" && Object.getPrototypeOf(v) === Object.prototype;
var exact = (v, keys) => object(v) && Object.keys(v).sort().join() === keys.slice().sort().join();
var fail = () => {
  throw Error("Cloudflare deployment contract denied");
};
var require2 = (v) => {
  if (!v) fail();
};
function canonical(value) {
  if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number" && Number.isSafeInteger(value)) return String(value);
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  if (object(value)) return "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonical(value[k])).join(",") + "}";
  fail();
}
function byteView(value) {
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  fail();
}
async function sha256(bytes) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", byteView(bytes)))].map((v) => v.toString(16).padStart(2, "0")).join("");
}
async function digest(value) {
  return sha256(encoder2.encode(canonical(value)));
}
function hostname(value) {
  return typeof value === "string" && value.length <= 253 && value.includes(".") && value.split(".").every((p) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(p)) && /^[a-z][a-z0-9-]*$/.test(value.split(".").at(-1));
}
function workflow(value) {
  return typeof value === "string" && /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/\.github\/workflows\/[A-Za-z0-9_.-]+\.ya?ml@(?:refs\/heads\/[A-Za-z0-9_.\/-]+|[a-f0-9]{40})$/.test(value);
}
function validateIngress(target) {
  if (!Object.hasOwn(target, "ingress")) {
    require2(matches(id, target.zoneID) && hostname(target.hostname));
    return { type: "custom-domain" };
  }
  const value = target.ingress;
  require2(object(value) && ["routes", "service-only"].includes(value.type) && exact(value, value.type === "routes" ? ["type", "zoneIDs", "routes"] : ["type", "zoneIDs"]));
  require2(Array.isArray(value.zoneIDs) && value.zoneIDs.length > 0 && value.zoneIDs.length <= 100 && value.zoneIDs.every((v) => matches(id, v)) && new Set(value.zoneIDs).size === value.zoneIDs.length && canonical(value.zoneIDs) === canonical([...value.zoneIDs].sort()));
  if (value.type === "service-only") {
    require2(target.zoneID === null && target.hostname === null);
    return value;
  }
  require2(matches(id, target.zoneID) && hostname(target.hostname) && value.zoneIDs.includes(target.zoneID) && Array.isArray(value.routes) && value.routes.length > 0 && value.routes.length <= 100);
  const ids = [];
  for (const route of value.routes) {
    require2(exact(route, ["id", "zoneID", "pattern"]) && matches(id, route.id) && route.zoneID === target.zoneID && typeof route.pattern === "string" && route.pattern.length <= 1024 && route.pattern.startsWith(target.hostname + "/"));
    require2(/^[A-Za-z0-9._~!$&'()+,;=:@\/-]*\*?$/.test(route.pattern.slice(target.hostname.length + 1)));
    ids.push(route.id);
  }
  require2(new Set(ids).size === ids.length && canonical(ids) === canonical([...ids].sort()) && new Set(value.routes.map((r) => r.pattern)).size === value.routes.length);
  return value;
}
function validatePolicy(policy2, { requireDeploymentTarget = true } = {}) {
  require2(typeof requireDeploymentTarget === "boolean");
  require2(exact(policy2, ["schema", "revision", "enabled", "authorizer", "executor", "targets", "maxArtifactBytes", "verification"]));
  require2(policy2.schema === "workflow-depot-cloudflare-policy/v1" && positive(policy2.revision) && typeof policy2.enabled === "boolean" && positive(policy2.maxArtifactBytes) && policy2.maxArtifactBytes <= 5 * 1024 * 1024);
  for (const trust of [policy2.authorizer, policy2.executor]) if (policy2.enabled || !exact(trust, [])) validateTrust(trust);
  require2(Array.isArray(policy2.targets) && policy2.targets.length <= 100 && (!policy2.enabled || !requireDeploymentTarget || policy2.targets.length > 0));
  const targets = /* @__PURE__ */ new Set();
  for (const t of policy2.targets) {
    require2(exact(t, ["accountID", "scriptName", "zoneID", "hostname", "metadataDigest", "sourceRepository", "sourceRepositoryID", ...Object.hasOwn(t, "ingress") ? ["ingress"] : []]));
    require2(matches(id, t.accountID) && matches(script, t.scriptName) && matches(hex, t.metadataDigest) && matches(repository, t.sourceRepository) && positive(t.sourceRepositoryID));
    validateIngress(t);
    const key = t.accountID + "/" + t.scriptName;
    require2(!targets.has(key));
    targets.add(key);
  }
  const v = policy2.verification;
  if (policy2.enabled || !exact(v, [])) {
    require2(exact(v, ["signerKeyIDs", "ciWorkflowRef", "ciWorkflowSHA", "requiredJobs"]) && Array.isArray(v.signerKeyIDs) && v.signerKeyIDs.length > 0 && v.signerKeyIDs.length <= 20 && v.signerKeyIDs.every(signerKey) && new Set(v.signerKeyIDs).size === v.signerKeyIDs.length && workflow(v.ciWorkflowRef) && matches(sha, v.ciWorkflowSHA));
    require2(Array.isArray(v.requiredJobs) && v.requiredJobs.length > 0 && v.requiredJobs.length <= 20 && v.requiredJobs.every((n) => typeof n === "string" && n.length > 0 && n.length <= 150 && n.trim() === n && !/[\u0000-\u001f\u007f]/.test(n)) && new Set(v.requiredJobs).size === v.requiredJobs.length);
    const ref = v.ciWorkflowRef.split("@")[1];
    if (matches(sha, ref)) require2(ref === v.ciWorkflowSHA);
  }
  return policy2;
}
function operationTarget(op, policy2) {
  require2(exact(op, ["schema", "operationID", "nonce", "policyDigest", "artifactDigest", "metadataDigest", "accountID", "scriptName", "zoneID", "hostname", "expectedDeploymentID", "source", "execution", "expiresAt", ...Object.hasOwn(op, "ingress") ? ["ingress"] : []]));
  require2(op.schema === "workflow-depot-cloudflare-deploy/v1" && ["operationID", "nonce", "policyDigest", "artifactDigest", "metadataDigest"].every((k) => matches(hex, op[k])) && matches(uuid, op.expectedDeploymentID) && positive(op.expiresAt));
  require2(exact(op.source, ["repository", "repositoryID", "commitSHA", "signerKeyID", "signingReceiptDigest", "ciRunID", "ciRunAttempt"]) && matches(repository, op.source.repository) && positive(op.source.repositoryID) && matches(sha, op.source.commitSHA) && signerKey(op.source.signerKeyID) && matches(hex, op.source.signingReceiptDigest) && positive(op.source.ciRunID) && positive(op.source.ciRunAttempt));
  require2(exact(op.execution, ["runID", "runAttempt"]) && positive(op.execution.runID) && positive(op.execution.runAttempt));
  require2(policy2.verification.signerKeyIDs.includes(op.source.signerKeyID));
  const target = policy2.targets.find((t) => t.accountID === op.accountID && t.scriptName === op.scriptName && t.zoneID === op.zoneID && t.hostname === op.hostname && t.metadataDigest === op.metadataDigest && t.sourceRepository === op.source.repository && t.sourceRepositoryID === op.source.repositoryID);
  require2(target && Object.hasOwn(target, "ingress") === Object.hasOwn(op, "ingress") && canonical(validateIngress(target)) === canonical(validateIngress(op)));
  return target;
}
async function validateOperation(op, policy2, now = Math.floor(Date.now() / 1e3)) {
  validatePolicy(policy2);
  require2(policy2.enabled && positive(now));
  operationTarget(op, policy2);
  require2(op.expiresAt > now && op.expiresAt <= now + 600 && op.policyDigest === await digest(policy2));
  return op;
}

// src/deployment-authority.mjs
var HEX = /^[a-f0-9]{64}$/;
var UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
var terminal = /* @__PURE__ */ new Set(["completed", "uncertain"]);
function requireThat(value, code) {
  if (!value) throw Error(code);
}
function exact2(value, keys, code = "invalid-request") {
  requireThat(value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).sort().join(",") === [...keys].sort().join(","), code);
}
function freeze(value) {
  if (value && typeof value === "object") {
    Object.values(value).forEach(freeze);
    Object.freeze(value);
  }
  return value;
}
function snapshot(value) {
  const text = JSON.stringify(value);
  requireThat(typeof text === "string" && new TextEncoder().encode(text).length <= 65536, "request-too-large");
  return freeze(JSON.parse(text));
}
function token(value) {
  requireThat(typeof value === "string" && value.length > 0 && value.length <= 16384, "invalid-identity");
}
function identifier(value) {
  requireThat(typeof value === "string" && HEX.test(value), "invalid-request");
}
function run(value) {
  requireThat(Number.isSafeInteger(value) && value > 0, "invalid-request");
}
function randomLease() {
  return [...crypto.getRandomValues(new Uint8Array(32))].map((x) => x.toString(16).padStart(2, "0")).join("");
}
function createDeploymentAuthority({ storage, policy: policy2, evidence, verifyIdentity = verifyOIDC, jwks = githubJWKS, now = () => Math.floor(Date.now() / 1e3) } = {}) {
  requireThat(typeof evidence?.verify === "function", "evidence-required");
  requireThat(typeof storage?.transaction === "function" && typeof storage?.get === "function", "atomic-storage-required");
  requireThat(typeof policy2 === "function", "policy-required");
  async function current(operation) {
    const value = snapshot(policy2());
    validatePolicy(value);
    requireThat(value.enabled === true, "authority-disabled");
    requireThat(/^[^/]+\/workflow_depot$/.test(value.authorizer.repository), "invalid-authorizer");
    requireThat(value.executor.repository === value.authorizer.repository.replace(/workflow_depot$/, "delivery_control"), "invalid-executor");
    if (operation) {
      await validateOperation(operation, value, now());
      requireThat(await digest(value) === operation.policyDigest, "policy-changed");
    }
    return value;
  }
  async function identity(oidcToken, trust, operationID, runID, runAttempt) {
    token(oidcToken);
    run(runID);
    run(runAttempt);
    const who = await verifyIdentity(oidcToken, trust, { operationID, runID, runAttempt }, await jwks(), now());
    requireThat(who && typeof who.jti === "string" && /^[\x21-\x7e]{1,256}$/.test(who.jti) && Number.isSafeInteger(who.expiresAt) && who.expiresAt > now() && who.runID === String(runID) && who.runAttempt === String(runAttempt), "invalid-identity");
    return { ...who, tombstone: "jti:" + await sha256(new TextEncoder().encode(who.jti)) };
  }
  function unexpired(who) {
    requireThat(who.expiresAt > now(), "identity-expired");
  }
  async function verified(operation) {
    const result = await evidence.verify(freeze(structuredClone(operation)));
    exact2(result, ["verified", "operationID", "artifactDigest", "sourceSHA"], "evidence-rejected");
    requireThat(result.verified === true && result.operationID === operation.operationID && result.artifactDigest === operation.artifactDigest && result.sourceSHA === operation.source.commitSHA, "evidence-rejected");
  }
  async function get(operationID, source = storage) {
    const record = await source.get("op:" + operationID);
    requireThat(record, "operation-not-found");
    return record;
  }
  function active(record, leaseID) {
    requireThat(record.leaseID === leaseID, "lease-mismatch");
    requireThat(!record.revoked, "operation-revoked");
    requireThat(record.identityExpiresAt > now(), "identity-expired");
  }
  const lease = (record) => ({ operation: structuredClone(record.operation), leaseID: record.leaseID, identityExpiresAt: record.identityExpiresAt });
  const targetKey = (op) => "target:" + op.accountID + ":" + op.scriptName;
  async function status(input) {
    input = snapshot(input);
    exact2(input, ["operationID", "oidcToken", "runID", "runAttempt"]);
    identifier(input.operationID);
    const p = await current(), who = await identity(input.oidcToken, p.executor, input.operationID, input.runID, input.runAttempt);
    const record = await storage.get("op:" + input.operationID);
    unexpired(who);
    requireThat(await digest(await current()) === await digest(p), "policy-changed");
    if (!record) return { operationID: input.operationID, state: "pending" };
    await current(record.operation);
    unexpired(who);
    requireThat(record.operation.execution.runID === input.runID && record.operation.execution.runAttempt === input.runAttempt, "execution-mismatch");
    requireThat(record.state === "authorized" && !record.revoked, "operation-not-authorized");
    return { operationID: input.operationID, state: "authorized" };
  }
  async function authorize(input) {
    input = snapshot(input);
    exact2(input, ["operation", "oidcToken", "authorizerRunID", "authorizerRunAttempt"]);
    const op = input.operation, p = await current(op), who = await identity(input.oidcToken, p.authorizer, op.operationID, input.authorizerRunID, input.authorizerRunAttempt);
    await verified(op);
    return storage.transaction(async (tx) => {
      await current(op);
      unexpired(who);
      requireThat(!await tx.get("op:" + op.operationID), "operation-exists");
      requireThat(!await tx.get("nonce:" + op.nonce), "nonce-replayed");
      requireThat(!await tx.get(who.tombstone), "identity-replayed");
      await tx.put("op:" + op.operationID, { operation: op, state: "authorized", revoked: false, authorizedAt: now() });
      await tx.put("nonce:" + op.nonce, op.operationID);
      await tx.put(who.tombstone, op.operationID);
      return { operationID: op.operationID, state: "authorized" };
    });
  }
  async function revoke(input) {
    input = snapshot(input);
    exact2(input, ["operation", "oidcToken", "authorizerRunID", "authorizerRunAttempt"]);
    identifier(input.operation?.operationID);
    const op = input.operation, p = await current(), who = await identity(input.oidcToken, p.authorizer, op.operationID, input.authorizerRunID, input.authorizerRunAttempt), policyHash = await digest(p);
    return storage.transaction(async (tx) => {
      requireThat(await digest(await current()) === policyHash, "policy-changed");
      unexpired(who);
      const record = await get(op.operationID, tx);
      requireThat(canonical(record.operation) === canonical(op), "operation-mismatch");
      requireThat(!await tx.get(who.tombstone), "identity-replayed");
      requireThat(!record.revoked, "operation-revoked");
      await tx.put(who.tombstone, op.operationID);
      await tx.put("op:" + op.operationID, { ...record, revoked: true, revokedAt: now() });
      return { operationID: op.operationID, state: "revoked" };
    });
  }
  async function consume(input) {
    input = snapshot(input);
    exact2(input, ["operationID", "oidcToken"]);
    identifier(input.operationID);
    const record = await get(input.operationID), op = record.operation, p = await current(op);
    requireThat(record.state === "authorized", "operation-not-authorized");
    requireThat(!record.revoked, "operation-revoked");
    const who = await identity(input.oidcToken, p.executor, op.operationID, op.execution.runID, op.execution.runAttempt), leaseID = randomLease();
    return storage.transaction(async (tx) => {
      await current(op);
      unexpired(who);
      const retained = await get(op.operationID, tx);
      requireThat(retained.state === "authorized", "operation-not-authorized");
      requireThat(!retained.revoked, "operation-revoked");
      requireThat(!await tx.get(who.tombstone), "identity-replayed");
      requireThat(!await tx.get("consumed:" + op.nonce), "nonce-replayed");
      requireThat(!await tx.get(targetKey(op)), "target-locked");
      const claimed = { ...retained, state: "claimed", leaseID, identityExpiresAt: who.expiresAt, claimedAt: now() };
      await tx.put("op:" + op.operationID, claimed);
      await tx.put(who.tombstone, op.operationID);
      await tx.put("consumed:" + op.nonce, op.operationID);
      await tx.put(targetKey(op), op.operationID);
      return lease(claimed);
    });
  }
  async function check(input) {
    input = snapshot(input);
    exact2(input, ["operationID", "leaseID", "stage"]);
    identifier(input.operationID);
    identifier(input.leaseID);
    requireThat(["upload", "activate"].includes(input.stage), "invalid-stage");
    const expected = input.stage === "upload" ? "claimed" : "upload-authorized";
    const record = await get(input.operationID);
    active(record, input.leaseID);
    requireThat(record.state === expected, "stage-conflict");
    await current(record.operation);
    await verified(record.operation);
    return storage.transaction(async (tx) => {
      const retained = await get(input.operationID, tx);
      active(retained, input.leaseID);
      requireThat(retained.state === expected, "stage-conflict");
      await current(retained.operation);
      active(retained, input.leaseID);
      requireThat(retained.operation.expiresAt > now(), "operation-expired");
      requireThat(await tx.get(targetKey(retained.operation)) === input.operationID, "target-lock-mismatch");
      const next = { ...retained, state: input.stage + "-authorized", [input.stage + "AuthorizedAt"]: now() };
      await tx.put("op:" + input.operationID, next);
      return lease(next);
    });
  }
  async function complete(input) {
    input = snapshot(input);
    exact2(input, ["operationID", "leaseID", "outcome", "receipt"]);
    identifier(input.operationID);
    identifier(input.leaseID);
    requireThat(terminal.has(input.outcome), "invalid-outcome");
    exact2(input.receipt, ["versionID", "deploymentID"], "invalid-receipt");
    for (const value of Object.values(input.receipt)) requireThat(value === null || typeof value === "string" && UUID.test(value), "invalid-receipt");
    if (input.outcome === "completed") requireThat(Object.values(input.receipt).every((v) => typeof v === "string"), "invalid-receipt");
    return storage.transaction(async (tx) => {
      const record = await get(input.operationID, tx);
      requireThat(record.leaseID === input.leaseID, "lease-mismatch");
      requireThat(!terminal.has(record.state), "terminal-state");
      requireThat(input.outcome === "completed" ? record.state === "activate-authorized" : ["claimed", "upload-authorized", "activate-authorized"].includes(record.state), "stage-conflict");
      requireThat(await tx.get(targetKey(record.operation)) === input.operationID, "target-lock-mismatch");
      await tx.put("op:" + input.operationID, { ...record, state: input.outcome, receipt: input.receipt, completedAt: now() });
      if (input.outcome === "completed") await tx.put(targetKey(record.operation), null);
      return { operationID: input.operationID, state: input.outcome };
    });
  }
  return Object.freeze({ authorize, revoke, status, consume, check, complete });
}

// src/deployment-authority-worker.mjs
var LIMIT = 65536;
var publicActions = ["authorize", "revoke", "status"];
var privateActions = ["consume", "check", "complete"];
var RequestError = class extends Error {
  constructor(status, code) {
    super(code);
    this.status = status;
    this.code = code;
  }
};
function json2(value, status = 200) {
  const body = JSON.stringify(value);
  if (new TextEncoder().encode(body).length > LIMIT) return json2({ error: "response-too-large" }, 500);
  return new Response(body, { status, headers: { "content-type": "application/json", "cache-control": "no-store", "x-content-type-options": "nosniff" } });
}
function policy(env) {
  if (typeof env.DEPLOYMENT_POLICY_JSON !== "string" || env.DEPLOYMENT_POLICY_JSON.length > LIMIT) throw new RequestError(503, "authority-unavailable");
  return JSON.parse(env.DEPLOYMENT_POLICY_JSON);
}
function ready(env) {
  if (env.ENABLED !== "true" || !env.DEPLOYMENT_STATE || typeof env.DEPLOYMENT_EVIDENCE?.verify !== "function") throw new RequestError(503, "authority-unavailable");
  if (policy(env).enabled !== true) throw new RequestError(503, "authority-unavailable");
}
async function readJSON(request) {
  if (!/^application\/json(?:\s*;|$)/i.test(request.headers.get("content-type") || "")) throw new RequestError(415, "json-required");
  const declared = request.headers.get("content-length");
  if (declared !== null && (!/^\d+$/.test(declared) || Number(declared) > LIMIT)) throw new RequestError(413, "request-too-large");
  const reader = request.body?.getReader();
  if (!reader) throw new RequestError(400, "invalid-request");
  const chunks = [];
  let length = 0;
  try {
    for (; ; ) {
      const { value, done } = await reader.read();
      if (done) break;
      length += value.byteLength;
      if (length > LIMIT) {
        await reader.cancel();
        throw new RequestError(413, "request-too-large");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    throw new RequestError(400, "invalid-request");
  }
}
function action(request, allowed) {
  const url = new URL(request.url), name = url.pathname.replace(/^\/v1\/deployments\//, "");
  if (url.search || url.pathname !== "/v1/deployments/" + name || !allowed.includes(name)) throw new RequestError(404, "not-found");
  if (request.method !== "POST") throw new RequestError(405, "method-not-allowed");
  return name;
}
function failure(error) {
  return error instanceof RequestError ? json2({ error: error.code }, error.status) : json2({ error: "deployment-authority-denied" }, 403);
}
async function forward(request, env, allowed) {
  try {
    const name = action(request, allowed);
    ready(env);
    const body = await readJSON(request);
    const stub = env.DEPLOYMENT_STATE.get(env.DEPLOYMENT_STATE.idFromName("deployment-authority-v1"));
    return await stub.fetch(new Request("https://deployment-state.internal/v1/deployments/" + name, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) }));
  } catch (error) {
    return failure(error);
  }
}
var deployment_authority_worker_default = { fetch(request, env) {
  return forward(request, env, publicActions);
} };
var DeploymentAuthority = class extends WorkerEntrypoint {
  fetch(request) {
    return forward(request, this.env, privateActions);
  }
};
var DeploymentAuthorityState = class extends DurableObject {
  async fetch(request) {
    try {
      const name = action(request, [...publicActions, ...privateActions]);
      ready(this.env);
      const input = await readJSON(request);
      const authority = createDeploymentAuthority({ storage: this.ctx.storage, policy: () => policy(this.env), evidence: { verify: (operation) => this.env.DEPLOYMENT_EVIDENCE.verify(operation) } });
      return json2(await authority[name](input));
    } catch (error) {
      return failure(error);
    }
  }
};
export {
  DeploymentAuthority,
  DeploymentAuthorityState,
  deployment_authority_worker_default as default
};
