// src/cloudflare-deployer-worker.mjs
import { DurableObject } from "cloudflare:workers";

// src/shared/oidc.mjs
var encoder = new TextEncoder();
var reject = (message) => {
  throw new Error(message);
};
function validateTrust(t) {
  const fields = ["audiencePrefix", "repository", "repositoryID", "ownerID", "ref", "workflowRef", "workflowSHA", "jobWorkflowRef", "jobWorkflowSHA", "eventNames", "actorIDs"];
  const positive2 = (v) => Number.isSafeInteger(v) && v > 0, sha2 = /^[a-f0-9]{40}$/;
  if (!t || Object.getPrototypeOf(t) !== Object.prototype || Object.keys(t).sort().join() !== fields.sort().join()) reject("Invalid executor trust schema");
  if (!["audiencePrefix", "repository", "ref", "workflowRef", "workflowSHA", "jobWorkflowRef", "jobWorkflowSHA"].every((k) => typeof t[k] === "string")) reject("Invalid executor trust field type");
  if (typeof t.audiencePrefix !== "string" || !/^[A-Za-z0-9_.:-]{1,200}$/.test(t.audiencePrefix) || !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(t.repository) || !positive2(t.repositoryID) || !positive2(t.ownerID) || !/^refs\/heads\/[A-Za-z0-9_.\/-]+$/.test(t.ref) || ![t.workflowSHA, t.jobWorkflowSHA].every((v) => sha2.test(v))) reject("Invalid executor trust identity");
  const workflow2 = /^([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+)\/\.github\/workflows\/[A-Za-z0-9_.-]+\.ya?ml@(refs\/heads\/[A-Za-z0-9_.\/-]+|[a-f0-9]{40})$/;
  const caller = typeof t.workflowRef === "string" && t.workflowRef.match(workflow2), job = typeof t.jobWorkflowRef === "string" && t.jobWorkflowRef.match(workflow2);
  if (!caller || caller[1] !== t.repository || caller[2] !== t.ref || !job || sha2.test(job[2]) && job[2] !== t.jobWorkflowSHA) reject("Invalid pinned workflow identity");
  if (!Array.isArray(t.eventNames) || !t.eventNames.length || t.eventNames.length > 20 || !t.eventNames.every((v) => typeof v === "string" && /^[a-z][a-z0-9_]{0,63}$/.test(v)) || new Set(t.eventNames).size !== t.eventNames.length || !Array.isArray(t.actorIDs) || !t.actorIDs.length || t.actorIDs.length > 100 || !t.actorIDs.every(positive2) || new Set(t.actorIDs).size !== t.actorIDs.length) reject("Invalid executor event or actor policy");
  return t;
}

// src/shared/contract.mjs
var encoder2 = new TextEncoder();
var hex = /^[a-f0-9]{64}$/;
var id = /^[a-f0-9]{32}$/;
var sha = /^[a-f0-9]{40}$/;
var uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
var repository = /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/;
var script = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
var identifier = /^[A-Za-z_$][A-Za-z0-9_$]{0,127}$/;
var matches = (pattern, value) => typeof value === "string" && pattern.test(value);
var signerKey = (value) => matches(hex, value) && value.length === 64 || matches(/^SHA256:[A-Za-z0-9+/]{42}[AEIMQUYcgkosw048]$/, value) && value.length === 50;
var positive = (v) => Number.isSafeInteger(v) && v > 0;
var object = (v) => v !== null && typeof v === "object" && Object.getPrototypeOf(v) === Object.prototype;
var exact = (v, keys) => object(v) && Object.keys(v).sort().join() === keys.slice().sort().join();
var fail = () => {
  throw Error("Cloudflare deployment contract denied");
};
var require2 = (v) => {
  if (!v) fail();
};
function canonical(value) {
  if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number" && Number.isSafeInteger(value)) return String(value);
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  if (object(value)) return "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonical(value[k])).join(",") + "}";
  fail();
}
function byteView(value) {
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  fail();
}
async function sha256(bytes) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", byteView(bytes)))].map((v) => v.toString(16).padStart(2, "0")).join("");
}
async function digest(value) {
  return sha256(encoder2.encode(canonical(value)));
}
function hostname(value) {
  return typeof value === "string" && value.length <= 253 && value.includes(".") && value.split(".").every((p) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(p)) && /^[a-z][a-z0-9-]*$/.test(value.split(".").at(-1));
}
function workflow(value) {
  return typeof value === "string" && /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/\.github\/workflows\/[A-Za-z0-9_.-]+\.ya?ml@(?:refs\/heads\/[A-Za-z0-9_.\/-]+|[a-f0-9]{40})$/.test(value);
}
function validateIngress(target) {
  if (!Object.hasOwn(target, "ingress")) {
    require2(matches(id, target.zoneID) && hostname(target.hostname));
    return { type: "custom-domain" };
  }
  const value = target.ingress;
  require2(object(value) && ["routes", "service-only"].includes(value.type) && exact(value, value.type === "routes" ? ["type", "zoneIDs", "routes"] : ["type", "zoneIDs"]));
  require2(Array.isArray(value.zoneIDs) && value.zoneIDs.length > 0 && value.zoneIDs.length <= 100 && value.zoneIDs.every((v) => matches(id, v)) && new Set(value.zoneIDs).size === value.zoneIDs.length && canonical(value.zoneIDs) === canonical([...value.zoneIDs].sort()));
  if (value.type === "service-only") {
    require2(target.zoneID === null && target.hostname === null);
    return value;
  }
  require2(matches(id, target.zoneID) && hostname(target.hostname) && value.zoneIDs.includes(target.zoneID) && Array.isArray(value.routes) && value.routes.length > 0 && value.routes.length <= 100);
  const ids = [];
  for (const route of value.routes) {
    require2(exact(route, ["id", "zoneID", "pattern"]) && matches(id, route.id) && route.zoneID === target.zoneID && typeof route.pattern === "string" && route.pattern.length <= 1024 && route.pattern.startsWith(target.hostname + "/"));
    require2(/^[A-Za-z0-9._~!$&'()+,;=:@\/-]*\*?$/.test(route.pattern.slice(target.hostname.length + 1)));
    ids.push(route.id);
  }
  require2(new Set(ids).size === ids.length && canonical(ids) === canonical([...ids].sort()) && new Set(value.routes.map((r) => r.pattern)).size === value.routes.length);
  return value;
}
function validatePolicy(policy, { requireDeploymentTarget = true } = {}) {
  require2(typeof requireDeploymentTarget === "boolean");
  require2(exact(policy, ["schema", "revision", "enabled", "authorizer", "executor", "targets", "maxArtifactBytes", "verification"]));
  require2(policy.schema === "workflow-depot-cloudflare-policy/v1" && positive(policy.revision) && typeof policy.enabled === "boolean" && positive(policy.maxArtifactBytes) && policy.maxArtifactBytes <= 5 * 1024 * 1024);
  for (const trust of [policy.authorizer, policy.executor]) if (policy.enabled || !exact(trust, [])) validateTrust(trust);
  require2(Array.isArray(policy.targets) && policy.targets.length <= 100 && (!policy.enabled || !requireDeploymentTarget || policy.targets.length > 0));
  const targets = /* @__PURE__ */ new Set();
  for (const t of policy.targets) {
    require2(exact(t, ["accountID", "scriptName", "zoneID", "hostname", "metadataDigest", "sourceRepository", "sourceRepositoryID", ...Object.hasOwn(t, "ingress") ? ["ingress"] : []]));
    require2(matches(id, t.accountID) && matches(script, t.scriptName) && matches(hex, t.metadataDigest) && matches(repository, t.sourceRepository) && positive(t.sourceRepositoryID));
    validateIngress(t);
    const key = t.accountID + "/" + t.scriptName;
    require2(!targets.has(key));
    targets.add(key);
  }
  const v = policy.verification;
  if (policy.enabled || !exact(v, [])) {
    require2(exact(v, ["signerKeyIDs", "ciWorkflowRef", "ciWorkflowSHA", "requiredJobs"]) && Array.isArray(v.signerKeyIDs) && v.signerKeyIDs.length > 0 && v.signerKeyIDs.length <= 20 && v.signerKeyIDs.every(signerKey) && new Set(v.signerKeyIDs).size === v.signerKeyIDs.length && workflow(v.ciWorkflowRef) && matches(sha, v.ciWorkflowSHA));
    require2(Array.isArray(v.requiredJobs) && v.requiredJobs.length > 0 && v.requiredJobs.length <= 20 && v.requiredJobs.every((n) => typeof n === "string" && n.length > 0 && n.length <= 150 && n.trim() === n && !/[\u0000-\u001f\u007f]/.test(n)) && new Set(v.requiredJobs).size === v.requiredJobs.length);
    const ref = v.ciWorkflowRef.split("@")[1];
    if (matches(sha, ref)) require2(ref === v.ciWorkflowSHA);
  }
  return policy;
}
function operationTarget(op, policy) {
  require2(exact(op, ["schema", "operationID", "nonce", "policyDigest", "artifactDigest", "metadataDigest", "accountID", "scriptName", "zoneID", "hostname", "expectedDeploymentID", "source", "execution", "expiresAt", ...Object.hasOwn(op, "ingress") ? ["ingress"] : []]));
  require2(op.schema === "workflow-depot-cloudflare-deploy/v1" && ["operationID", "nonce", "policyDigest", "artifactDigest", "metadataDigest"].every((k) => matches(hex, op[k])) && matches(uuid, op.expectedDeploymentID) && positive(op.expiresAt));
  require2(exact(op.source, ["repository", "repositoryID", "commitSHA", "signerKeyID", "signingReceiptDigest", "ciRunID", "ciRunAttempt"]) && matches(repository, op.source.repository) && positive(op.source.repositoryID) && matches(sha, op.source.commitSHA) && signerKey(op.source.signerKeyID) && matches(hex, op.source.signingReceiptDigest) && positive(op.source.ciRunID) && positive(op.source.ciRunAttempt));
  require2(exact(op.execution, ["runID", "runAttempt"]) && positive(op.execution.runID) && positive(op.execution.runAttempt));
  require2(policy.verification.signerKeyIDs.includes(op.source.signerKeyID));
  const target = policy.targets.find((t) => t.accountID === op.accountID && t.scriptName === op.scriptName && t.zoneID === op.zoneID && t.hostname === op.hostname && t.metadataDigest === op.metadataDigest && t.sourceRepository === op.source.repository && t.sourceRepositoryID === op.source.repositoryID);
  require2(target && Object.hasOwn(target, "ingress") === Object.hasOwn(op, "ingress") && canonical(validateIngress(target)) === canonical(validateIngress(op)));
  return target;
}
async function validateOperation(op, policy, now = Math.floor(Date.now() / 1e3)) {
  validatePolicy(policy);
  require2(policy.enabled && positive(now));
  operationTarget(op, policy);
  require2(op.expiresAt > now && op.expiresAt <= now + 600 && op.policyDigest === await digest(policy));
  return op;
}
function binding(b) {
  require2(object(b) && matches(identifier, b.name));
  const keys = { inherit: ["name", "type"], plain_text: ["name", "type", "text"], r2_bucket: ["name", "type", "bucket_name"], d1: ["name", "type", "database_id"], kv_namespace: ["name", "type", "namespace_id"], service: ["name", "type", "service", ...Object.hasOwn(b, "entrypoint") ? ["entrypoint"] : []], durable_object_namespace: ["name", "type", "namespace_id"] };
  require2(Object.hasOwn(keys, b.type) && exact(b, keys[b.type]));
  if (b.type === "plain_text") require2(typeof b.text === "string" && encoder2.encode(b.text).length <= 32768);
  if (b.type === "r2_bucket") require2(typeof b.bucket_name === "string" && /^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(b.bucket_name));
  if (b.type === "d1") require2(matches(uuid, b.database_id));
  if (["kv_namespace", "durable_object_namespace"].includes(b.type)) require2(matches(id, b.namespace_id));
  if (b.type === "service") require2(matches(script, b.service) && (!Object.hasOwn(b, "entrypoint") || matches(identifier, b.entrypoint)));
}
async function validateArtifact(bytes, op, policy) {
  validatePolicy(policy);
  require2(policy.enabled);
  operationTarget(op, policy);
  require2(op.policyDigest === await digest(policy));
  const inspected = await inspectArtifact(bytes, policy.maxArtifactBytes);
  require2(op.artifactDigest === inspected.artifactDigest && op.metadataDigest === inspected.metadataDigest);
  return inspected.artifact;
}
async function inspectArtifact(bytes, maxArtifactBytes) {
  require2(positive(maxArtifactBytes) && maxArtifactBytes <= 5 * 1024 * 1024);
  const data = byteView(bytes);
  require2(data.length > 0 && data.length <= maxArtifactBytes);
  const artifact = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(data));
  require2(exact(artifact, ["schema", "metadata", "modules"]) && artifact.schema === "workflow-depot-worker-artifact/v1");
  const m = artifact.metadata;
  require2(exact(m, ["main_module", "compatibility_date", "compatibility_flags", "bindings"]) && m.main_module === "worker.mjs");
  require2(typeof m.compatibility_date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(m.compatibility_date));
  const date = /* @__PURE__ */ new Date(m.compatibility_date + "T00:00:00Z");
  require2(Number.isFinite(date.valueOf()) && date.toISOString().slice(0, 10) === m.compatibility_date);
  require2(Array.isArray(m.compatibility_flags) && m.compatibility_flags.length <= 100 && m.compatibility_flags.every((v) => typeof v === "string" && /^[a-z][a-z0-9_]{0,99}$/.test(v)) && new Set(m.compatibility_flags).size === m.compatibility_flags.length);
  require2(Array.isArray(m.bindings) && m.bindings.length <= 100);
  const names = /* @__PURE__ */ new Set();
  for (const b of m.bindings) {
    binding(b);
    require2(!names.has(b.name));
    names.add(b.name);
  }
  require2(Array.isArray(artifact.modules) && artifact.modules.length === 1);
  const module = artifact.modules[0];
  require2(exact(module, ["name", "type", "content"]) && module.name === "worker.mjs" && module.type === "esm" && typeof module.content === "string" && module.content.length > 0);
  return { artifact, artifactDigest: await sha256(data), metadataDigest: await digest(m) };
}

// src/cloudflare-provider.mjs
var cfOrigin = "https://api.cloudflare.com/client/v4";
var githubOrigin = "https://api.github.com";
var uuid2 = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
var denied = () => {
  throw Error("Provider deployment verification failed");
};
async function boundedBytes(body, maximum) {
  if (!body || !Number.isSafeInteger(maximum) || maximum <= 0) denied();
  const reader = body.getReader(), chunks = [];
  let size = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maximum) {
        await reader.cancel();
        denied();
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}
function root(op) {
  if (!/^[a-f0-9]{32}$/.test(op?.accountID ?? "") || !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(op?.scriptName ?? "")) denied();
  return `/accounts/${op.accountID}/workers/scripts/${op.scriptName}`;
}
function createCloudflareProvider({ token, githubToken, fetcher = fetch }) {
  if (typeof token !== "string" || !token.length || typeof fetcher !== "function" || githubToken !== void 0 && (typeof githubToken !== "string" || !githubToken.length)) denied();
  async function request(path, { method = "GET", body, github = false, envelope = false } = {}) {
    const headers2 = { Accept: "application/json" };
    if (github) {
      headers2["User-Agent"] = "delivery-control-deployer";
      headers2["X-GitHub-Api-Version"] = "2026-03-10";
      if (githubToken) headers2.Authorization = `Bearer ${githubToken}`;
    } else headers2.Authorization = `Bearer ${token}`;
    if (body !== void 0 && !(body instanceof FormData)) headers2["Content-Type"] = "application/json";
    try {
      const response = await fetcher((github ? githubOrigin : cfOrigin) + path, {
        method,
        headers: headers2,
        redirect: "error",
        signal: AbortSignal.timeout(2e4),
        ...body === void 0 ? {} : { body: body instanceof FormData ? body : JSON.stringify(body) }
      });
      if (!response.ok) {
        await response.body?.cancel();
        denied();
      }
      const parsed = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(await boundedBytes(response.body, 1024 * 1024)));
      if (!github && (parsed?.success !== true || !Object.hasOwn(parsed, "result"))) denied();
      return github || envelope ? parsed : parsed.result;
    } catch {
      denied();
    }
  }
  async function current(op) {
    const data = await request(root(op) + "/deployments");
    if (!Array.isArray(data?.deployments) || !data.deployments.length || !uuid2.test(data.deployments[0]?.id ?? "")) denied();
    return data.deployments[0];
  }
  async function routing(op) {
    root(op);
    const ingress = validateIngress(op);
    if (ingress.type !== "custom-domain") {
      const first = await ingressSnapshot(op, ingress), second = await ingressSnapshot(op, ingress);
      if (canonical(first) !== canonical(second)) denied();
      return;
    }
    if (!/^[a-f0-9]{32}$/.test(op.zoneID ?? "") || typeof op.hostname !== "string" || !/^[a-z0-9.-]+$/.test(op.hostname)) denied();
    const zone = await request(`/zones/${op.zoneID}`);
    if (zone?.id !== op.zoneID || zone.account?.id !== op.accountID || zone.status !== "active" || typeof zone.name !== "string" || !(op.hostname === zone.name || op.hostname.endsWith("." + zone.name))) denied();
    const domains = await request(`/accounts/${op.accountID}/workers/domains?hostname=${encodeURIComponent(op.hostname)}`);
    if (!Array.isArray(domains) || domains.length !== 1) denied();
    const domain = domains[0];
    if (domain.hostname !== op.hostname || domain.service !== op.scriptName || domain.zone_id !== op.zoneID || domain.enabled !== true || domain.previews_enabled !== false) denied();
    const subdomain = await request(root(op) + "/subdomain");
    if (subdomain?.enabled !== false || subdomain.previews_enabled !== false) denied();
  }
  async function ingressSnapshot(op, ingress) {
    const zones = [];
    let total, pages;
    for (let page = 1; page <= 2; page++) {
      const data = await request(`/zones?account.id=${op.accountID}&type=full,partial,secondary,internal&per_page=50&page=${page}`, { envelope: true }), info2 = data.result_info;
      if (!Array.isArray(data.result) || !info2 || info2.page !== page || info2.per_page !== 50 || info2.count !== data.result.length || !Number.isSafeInteger(info2.total_count) || info2.total_count < 1 || info2.total_count > 100 || !Number.isSafeInteger(info2.total_pages) || info2.total_pages !== Math.ceil(info2.total_count / 50)) denied();
      if (page === 1) {
        total = info2.total_count;
        pages = info2.total_pages;
      } else if (total !== info2.total_count || pages !== info2.total_pages) denied();
      zones.push(...data.result);
      if (page === pages) break;
    }
    if (zones.length !== total || new Set(zones.map((z) => z.id)).size !== zones.length || canonical(zones.map((z) => z.id).sort()) !== canonical(ingress.zoneIDs)) denied();
    const observed = [];
    for (const zone of zones) {
      if (zone.account?.id !== op.accountID || zone.status !== "active" || typeof zone.name !== "string" || !/^[a-z0-9.-]+$/.test(zone.name)) denied();
      if (zone.id === op.zoneID && !(op.hostname === zone.name || op.hostname.endsWith("." + zone.name))) denied();
      const routes = await request(`/zones/${zone.id}/workers/routes`);
      if (!Array.isArray(routes) || routes.length > 1e3 || new Set(routes.map((r) => r.id)).size !== routes.length) denied();
      for (const route of routes) {
        if (typeof route.id !== "string" || !/^[a-f0-9]{32}$/.test(route.id) || typeof route.pattern !== "string" || route.script !== void 0 && route.script !== null && typeof route.script !== "string") denied();
        if (route.script === op.scriptName) observed.push({ id: route.id, zoneID: zone.id, pattern: route.pattern });
      }
    }
    observed.sort((a, b) => a.id.localeCompare(b.id));
    if (canonical(observed) !== canonical(ingress.type === "routes" ? ingress.routes : [])) denied();
    const domains = await request(`/accounts/${op.accountID}/workers/domains?service=${op.scriptName}`, { envelope: true }), info = domains.result_info;
    if (!Array.isArray(domains.result) || domains.result.length !== 0) denied();
    if (info && (Object.hasOwn(info, "page") && info.page !== 1 || Object.hasOwn(info, "count") && info.count !== 0 || Object.hasOwn(info, "total_count") && info.total_count !== 0 || Object.hasOwn(info, "total_pages") && ![0, 1].includes(info.total_pages))) denied();
    const subdomain = await request(root(op) + "/subdomain");
    if (subdomain?.enabled !== false || subdomain.previews_enabled !== false) denied();
    return { zones: zones.map((z) => ({ id: z.id, name: z.name })).sort((a, b) => a.id.localeCompare(b.id)), routes: observed };
  }
  return {
    async preflight(op, artifact) {
      await routing(op);
      const source = op.source;
      if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(source?.repository ?? "") || !/^[a-f0-9]{40}$/.test(source?.commitSHA ?? "") || !Number.isSafeInteger(source.repositoryID) || source.repositoryID <= 0) denied();
      const repository2 = await request(`/repos/${source.repository}`, { github: true });
      if (repository2?.id !== source.repositoryID || repository2.archived !== false || repository2.fork !== false) denied();
      const commit = await request(`/repos/${source.repository}/git/commits/${source.commitSHA}`, { github: true });
      if (commit?.sha !== source.commitSHA || commit.verification?.verified !== true || commit.verification.reason !== "valid") denied();
      await this.baseline(op, artifact);
    },
    async baseline(op, artifact, uploadedVersionID) {
      if (Object.hasOwn(op, "ingress")) await routing(op);
      const deployment = await current(op);
      if (!uuid2.test(op.expectedDeploymentID ?? "") || deployment.id !== op.expectedDeploymentID) denied();
      if (deployment.strategy !== "percentage" || deployment.versions?.length !== 1 || deployment.versions[0].percentage !== 100 || !uuid2.test(deployment.versions[0].version_id ?? "")) denied();
      const activeVersionID = deployment.versions[0].version_id;
      const latest = await request(root(op) + "/versions?per_page=1");
      if (!Array.isArray(latest?.items) || latest.items[0]?.id !== (uploadedVersionID ?? activeVersionID)) denied();
      const active = await request(root(op) + `/versions/${activeVersionID}`);
      if (active?.id !== activeVersionID || !Array.isArray(active.resources?.bindings) || !Array.isArray(artifact?.metadata?.bindings)) denied();
      const secrets = active.resources.bindings.filter((binding2) => ["secret_text", "secret_key"].includes(binding2.type)).map((binding2) => binding2.name).sort();
      const inherited = artifact.metadata.bindings.filter((binding2) => binding2.type === "inherit").map((binding2) => binding2.name).sort();
      if (secrets.some((name) => typeof name !== "string") || new Set(secrets).size !== secrets.length || JSON.stringify(secrets) !== JSON.stringify(inherited)) denied();
    },
    async upload(op, artifact) {
      const multipart = new FormData();
      multipart.set("metadata", new Blob([JSON.stringify(artifact.metadata)], { type: "application/json" }));
      for (const module of artifact.modules) {
        if (module.name !== "worker.mjs" || module.type !== "esm" || typeof module.content !== "string") denied();
        multipart.set(module.name, new Blob([module.content], { type: "application/javascript+module" }), module.name);
      }
      const result = await request(root(op) + "/versions?bindings_inherit=strict", { method: "POST", body: multipart });
      if (!uuid2.test(result?.id ?? "")) denied();
      return { versionID: result.id };
    },
    async activate(op, versionID) {
      if (!uuid2.test(versionID ?? "")) denied();
      const result = await request(root(op) + "/deployments", { method: "POST", body: { strategy: "percentage", versions: [{ version_id: versionID, percentage: 100 }] } });
      if (!uuid2.test(result?.id ?? "")) denied();
      return { deploymentID: result.id };
    },
    async verify(op, receipt) {
      if (!uuid2.test(receipt?.versionID ?? "") || !uuid2.test(receipt?.deploymentID ?? "")) denied();
      const version = await request(root(op) + `/versions/${receipt.versionID}`);
      if (version?.id !== receipt.versionID) denied();
      const deployed = await current(op);
      if (deployed.id !== receipt.deploymentID || deployed.strategy !== "percentage" || deployed.versions?.length !== 1 || deployed.versions[0].version_id !== receipt.versionID || deployed.versions[0].percentage !== 100) denied();
      await routing(op);
      return { versionID: receipt.versionID, deploymentID: receipt.deploymentID };
    }
  };
}

// src/cloudflare-deployer.mjs
var hex2 = /^[a-f0-9]{64}$/;
var uuid3 = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
var exact2 = (value, keys) => value && Object.getPrototypeOf(value) === Object.prototype && Object.keys(value).sort().join() === [...keys].sort().join();
var failure = () => {
  throw Error("Deployment failed; reconciliation may be required");
};
var headers = { "Cache-Control": "no-store", "Content-Type": "application/json" };
function validateRequest(input) {
  if (!exact2(input, ["operationID", "oidcToken"]) || !hex2.test(input.operationID) || typeof input.oidcToken !== "string" || !input.oidcToken.length || input.oidcToken.length > 16e3) failure();
}
function createCloudflareDeployer({ storage, authority, artifacts, provider, policy, clock = () => Math.floor(Date.now() / 1e3) }) {
  if (!storage?.transaction || !storage.get || !storage.put || !authority?.consume || !authority.check || !authority.complete || !artifacts?.get || !["preflight", "baseline", "upload", "activate", "verify"].every((name) => typeof provider?.[name] === "function")) failure();
  const trustedPolicy = structuredClone(validatePolicy(policy));
  return {
    async execute(input) {
      let grant, operation, record, key, claimed = false;
      let receipt = { versionID: null, deploymentID: null };
      try {
        validateRequest(input);
        key = `deployment:${input.operationID}`;
        if (await storage.get(key)) failure();
        grant = await authority.consume({ operationID: input.operationID, oidcToken: input.oidcToken });
        if (!exact2(grant, ["operation", "leaseID", "identityExpiresAt"]) || !hex2.test(grant.leaseID) || !Number.isSafeInteger(grant.identityExpiresAt) || grant.identityExpiresAt <= clock()) failure();
        operation = structuredClone(grant.operation);
        await validateOperation(operation, trustedPolicy, clock());
        if (operation.operationID !== input.operationID) failure();
        record = { operationID: input.operationID, leaseID: grant.leaseID, state: "reserved", receipt };
        await storage.transaction(async (transaction) => {
          if (await transaction.get(key)) failure();
          await transaction.put(key, record);
        });
        claimed = true;
        const save = async (state) => {
          record = { ...record, state, receipt: { ...receipt } };
          await storage.put(key, record);
        };
        const check = async (stage) => {
          if (operation.expiresAt <= clock() || grant.identityExpiresAt <= clock()) failure();
          const confirmation = await authority.check({ operationID: operation.operationID, leaseID: grant.leaseID, stage });
          if (!exact2(confirmation, ["operation", "leaseID", "identityExpiresAt"]) || confirmation.leaseID !== grant.leaseID || confirmation.identityExpiresAt !== grant.identityExpiresAt || confirmation.identityExpiresAt <= clock() || canonical(confirmation.operation) !== canonical(operation)) failure();
          await validateOperation(confirmation.operation, trustedPolicy, clock());
        };
        const object2 = await artifacts.get(`artifacts/sha256/${operation.artifactDigest}.json`);
        if (!object2 || !Number.isSafeInteger(object2.size) || object2.size <= 0 || object2.size > trustedPolicy.maxArtifactBytes) failure();
        const bytes = await boundedBytes(object2.body, trustedPolicy.maxArtifactBytes);
        if (bytes.byteLength !== object2.size) failure();
        const artifact = await validateArtifact(bytes, operation, trustedPolicy);
        await provider.preflight(operation, artifact);
        await save("upload-intent");
        await check("upload");
        const uploaded = await provider.upload(operation, artifact);
        if (!exact2(uploaded, ["versionID"]) || !uuid3.test(uploaded.versionID)) failure();
        receipt.versionID = uploaded.versionID;
        await save("uploaded");
        await provider.baseline(operation, artifact, receipt.versionID);
        await save("activate-intent");
        await check("activate");
        const activated = await provider.activate(operation, receipt.versionID);
        if (!exact2(activated, ["deploymentID"]) || !uuid3.test(activated.deploymentID)) failure();
        receipt.deploymentID = activated.deploymentID;
        await save("activated");
        const verified = await provider.verify(operation, receipt, artifact);
        if (!exact2(verified, ["versionID", "deploymentID"]) || canonical(verified) !== canonical(receipt)) failure();
        await save("verified");
        const completed = await authority.complete({ operationID: operation.operationID, leaseID: grant.leaseID, outcome: "completed", receipt: { ...receipt } });
        if (completed?.operationID !== operation.operationID || completed.state !== "completed") failure();
        await save("completed");
        return { operationID: operation.operationID, state: "completed", artifactDigest: operation.artifactDigest, ...receipt };
      } catch {
        if (claimed) {
          try {
            await storage.put(key, { ...record, state: "uncertain", receipt: { ...receipt } });
          } catch {
          }
          try {
            await authority.complete({ operationID: operation.operationID, leaseID: grant.leaseID, outcome: "uncertain", receipt: { ...receipt } });
          } catch {
          }
        }
        failure();
      }
    }
  };
}
async function handleDeploymentRequest(request, executor, { enabled = false } = {}) {
  if (new URL(request.url).pathname !== "/v1/deployments/execute" || request.method !== "POST") return Response.json({ error: "not_found" }, { status: 404, headers });
  if (!enabled) return Response.json({ error: "deployer_disabled" }, { status: 503, headers });
  let input;
  try {
    const bytes = await boundedBytes(request.body, 2e4);
    input = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
    validateRequest(input);
  } catch {
    return Response.json({ error: "invalid_deployment_request" }, { status: 400, headers });
  }
  try {
    return Response.json(await executor.execute(input), { headers });
  } catch {
    return Response.json({ error: "deployment_failed_or_uncertain" }, { status: 409, headers });
  }
}

// src/cloudflare-deployer-worker.mjs
var unavailable = () => Response.json({ error: "deployer_not_configured" }, { status: 503, headers: { "Cache-Control": "no-store" } });
function authorityBinding(binding2) {
  if (typeof binding2?.fetch !== "function") throw Error("Missing private deployment authority");
  const call = async (action, body) => {
    const response = await binding2.fetch(new Request(`https://deployment-authority.internal/v1/deployments/${action}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(2e4)
    }));
    if (!response.ok) {
      await response.body?.cancel();
      throw Error("Deployment authority denied");
    }
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(await boundedBytes(response.body, 64e3)));
  };
  return {
    consume: (input) => call("consume", input),
    check: (input) => call("check", input),
    complete: (input) => call("complete", input)
  };
}
var DeploymentJob = class extends DurableObject {
  async fetch(request) {
    if (this.env.DEPLOYER_ENABLED !== "true") return unavailable();
    try {
      const executor = createCloudflareDeployer({
        storage: this.ctx.storage,
        authority: authorityBinding(this.env.DEPLOYMENT_AUTHORITY),
        artifacts: this.env.DEPLOYMENT_ARTIFACTS,
        provider: createCloudflareProvider({ token: this.env.CLOUDFLARE_API_TOKEN, githubToken: this.env.GITHUB_READ_TOKEN }),
        policy: JSON.parse(this.env.DEPLOYMENT_POLICY_JSON)
      });
      return await handleDeploymentRequest(request, executor, { enabled: true });
    } catch {
      return unavailable();
    }
  }
};
var cloudflare_deployer_worker_default = {
  async fetch(request, env) {
    return handleDeploymentRequest(request, {
      async execute(input) {
        if (!env.DEPLOYMENT_JOBS || !env.DEPLOYMENT_AUTHORITY || !env.DEPLOYMENT_ARTIFACTS) throw Error("Missing deployment bindings");
        const stub = env.DEPLOYMENT_JOBS.get(env.DEPLOYMENT_JOBS.idFromName(input.operationID));
        const response = await stub.fetch(new Request("https://deployment-job.internal/v1/deployments/execute", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(input)
        }));
        if (!response.ok) {
          await response.body?.cancel();
          throw Error("Deployment failed");
        }
        return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(await boundedBytes(response.body, 4096)));
      }
    }, { enabled: env.DEPLOYER_ENABLED === "true" });
  }
};
export {
  DeploymentJob,
  cloudflare_deployer_worker_default as default
};
