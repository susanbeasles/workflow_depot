// src/deployment-provenance-worker.mjs
import { DurableObject, WorkerEntrypoint } from "cloudflare:workers";

// src/shared/oidc.mjs
var encoder = new TextEncoder();
var issuer = "https://token.actions.githubusercontent.com";
var reject = (message) => {
  throw new Error(message);
};
function decode(value) {
  if (typeof value !== "string" || !value.length || !/^[A-Za-z0-9_-]+$/.test(value)) reject("Invalid OIDC encoding");
  return Uint8Array.from(atob(value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4)), (c) => c.charCodeAt(0));
}
function json(value) {
  return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(decode(value)));
}
async function githubJWKS(fetcher = fetch) {
  const response = await fetcher(`${issuer}/.well-known/jwks`, { redirect: "manual", signal: AbortSignal.timeout(1e4) });
  if (!response.ok) reject("OIDC trust-key retrieval failed");
  const raw = await response.text();
  if (raw.length > 128e3) reject("OIDC trust-key inventory too large");
  const data = JSON.parse(raw);
  if (!Array.isArray(data.keys) || data.keys.length > 32) reject("Invalid OIDC trust-key inventory");
  return data;
}
async function verifyExecutorOIDC(token, trust, { operationID, runID, runAttempt }, jwks, now = Math.floor(Date.now() / 1e3)) {
  if (typeof token !== "string" || token.length > 2e4) reject("Invalid OIDC token size");
  const parts = token.split(".");
  if (parts.length !== 3) reject("Invalid OIDC token");
  const header = json(parts[0]);
  if (header.alg !== "RS256" || typeof header.kid !== "string" || header.jku || header.jwk || header.x5u || header.crit) reject("Unsupported OIDC signature header");
  const keys = jwks?.keys?.filter((k) => k.kid === header.kid && k.kty === "RSA" && (k.alg === void 0 || k.alg === "RS256") && (k.use === void 0 || k.use === "sig") && !k.d);
  if (keys?.length !== 1) reject("Unknown or ambiguous OIDC signing key");
  const key = await crypto.subtle.importKey("jwk", keys[0], { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
  if (!await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, decode(parts[2]), encoder.encode(`${parts[0]}.${parts[1]}`))) reject("Invalid OIDC signature");
  const c = json(parts[1]);
  if (c.iss !== issuer || c.aud !== `${trust.audiencePrefix}:${operationID}`) reject("Wrong OIDC issuer/audience");
  if (![c.exp, c.iat, c.nbf].every(Number.isSafeInteger) || c.exp <= now || c.iat > now + 30 || c.nbf > now + 30 || c.exp <= c.iat || c.exp - c.iat > 600 || c.iat < now - 600) reject("Expired or invalid OIDC lifetime");
  const exact3 = { repository: trust.repository, repository_id: String(trust.repositoryID), repository_owner_id: String(trust.ownerID), ref: trust.ref, workflow_ref: trust.workflowRef, workflow_sha: trust.workflowSHA, job_workflow_ref: trust.jobWorkflowRef, job_workflow_sha: trust.jobWorkflowSHA, runner_environment: "github-hosted", run_id: String(runID), run_attempt: String(runAttempt) };
  for (const [name, value] of Object.entries(exact3)) if (typeof value !== "string" || !value.length || c[name] !== value) reject(`Untrusted executor claim: ${name}`);
  if (!trust.eventNames?.includes(c.event_name) || !trust.actorIDs?.includes(Number(c.actor_id))) reject("Untrusted executor event/actor");
  if (typeof c.jti !== "string" || c.jti.length < 8 || c.jti.length > 200) reject("Missing OIDC replay identity");
  return { jti: c.jti, runID: String(runID), runAttempt: String(runAttempt), expiresAt: c.exp, workflowSHA: c.job_workflow_sha };
}
function validateTrust(t) {
  const fields = ["audiencePrefix", "repository", "repositoryID", "ownerID", "ref", "workflowRef", "workflowSHA", "jobWorkflowRef", "jobWorkflowSHA", "eventNames", "actorIDs"];
  const positive3 = (v) => Number.isSafeInteger(v) && v > 0, sha3 = /^[a-f0-9]{40}$/;
  if (!t || Object.getPrototypeOf(t) !== Object.prototype || Object.keys(t).sort().join() !== fields.sort().join()) reject("Invalid executor trust schema");
  if (!["audiencePrefix", "repository", "ref", "workflowRef", "workflowSHA", "jobWorkflowRef", "jobWorkflowSHA"].every((k) => typeof t[k] === "string")) reject("Invalid executor trust field type");
  if (typeof t.audiencePrefix !== "string" || !/^[A-Za-z0-9_.:-]{1,200}$/.test(t.audiencePrefix) || !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(t.repository) || !positive3(t.repositoryID) || !positive3(t.ownerID) || !/^refs\/heads\/[A-Za-z0-9_.\/-]+$/.test(t.ref) || ![t.workflowSHA, t.jobWorkflowSHA].every((v) => sha3.test(v))) reject("Invalid executor trust identity");
  const workflow2 = /^([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+)\/\.github\/workflows\/[A-Za-z0-9_.-]+\.ya?ml@(refs\/heads\/[A-Za-z0-9_.\/-]+|[a-f0-9]{40})$/;
  const caller = typeof t.workflowRef === "string" && t.workflowRef.match(workflow2), job = typeof t.jobWorkflowRef === "string" && t.jobWorkflowRef.match(workflow2);
  if (!caller || caller[1] !== t.repository || caller[2] !== t.ref || !job || sha3.test(job[2]) && job[2] !== t.jobWorkflowSHA) reject("Invalid pinned workflow identity");
  if (!Array.isArray(t.eventNames) || !t.eventNames.length || t.eventNames.length > 20 || !t.eventNames.every((v) => typeof v === "string" && /^[a-z][a-z0-9_]{0,63}$/.test(v)) || new Set(t.eventNames).size !== t.eventNames.length || !Array.isArray(t.actorIDs) || !t.actorIDs.length || t.actorIDs.length > 100 || !t.actorIDs.every(positive3) || new Set(t.actorIDs).size !== t.actorIDs.length) reject("Invalid executor event or actor policy");
  return t;
}
async function verifyOIDC(token, trust, binding2, jwks, now = Math.floor(Date.now() / 1e3)) {
  validateTrust(trust);
  if (!binding2 || Object.keys(binding2).sort().join() !== ["operationID", "runID", "runAttempt"].sort().join() || typeof binding2.operationID !== "string" || !/^[a-f0-9]{64}$/.test(binding2.operationID) || ![binding2.runID, binding2.runAttempt, now].every((v) => Number.isSafeInteger(v) && v > 0)) reject("Invalid execution binding");
  return verifyExecutorOIDC(token, trust, binding2, jwks, now);
}

// src/shared/contract.mjs
var encoder2 = new TextEncoder();
var hex = /^[a-f0-9]{64}$/;
var id = /^[a-f0-9]{32}$/;
var sha = /^[a-f0-9]{40}$/;
var uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
var repository = /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/;
var script = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
var identifier = /^[A-Za-z_$][A-Za-z0-9_$]{0,127}$/;
var matches = (pattern, value) => typeof value === "string" && pattern.test(value);
var signerKey = (value) => matches(hex, value) && value.length === 64 || matches(/^SHA256:[A-Za-z0-9+/]{42}[AEIMQUYcgkosw048]$/, value) && value.length === 50;
var positive = (v) => Number.isSafeInteger(v) && v > 0;
var object = (v) => v !== null && typeof v === "object" && Object.getPrototypeOf(v) === Object.prototype;
var exact = (v, keys) => object(v) && Object.keys(v).sort().join() === keys.slice().sort().join();
var fail = () => {
  throw Error("Cloudflare deployment contract denied");
};
var require2 = (v) => {
  if (!v) fail();
};
function canonical(value) {
  if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number" && Number.isSafeInteger(value)) return String(value);
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  if (object(value)) return "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonical(value[k])).join(",") + "}";
  fail();
}
function byteView(value) {
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  fail();
}
async function sha256(bytes) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", byteView(bytes)))].map((v) => v.toString(16).padStart(2, "0")).join("");
}
async function digest(value) {
  return sha256(encoder2.encode(canonical(value)));
}
function hostname(value) {
  return typeof value === "string" && value.length <= 253 && value.includes(".") && value.split(".").every((p) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(p)) && /^[a-z][a-z0-9-]*$/.test(value.split(".").at(-1));
}
function workflow(value) {
  return typeof value === "string" && /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/\.github\/workflows\/[A-Za-z0-9_.-]+\.ya?ml@(?:refs\/heads\/[A-Za-z0-9_.\/-]+|[a-f0-9]{40})$/.test(value);
}
function validateIngress(target) {
  if (!Object.hasOwn(target, "ingress")) {
    require2(matches(id, target.zoneID) && hostname(target.hostname));
    return { type: "custom-domain" };
  }
  const value = target.ingress;
  require2(object(value) && ["routes", "service-only"].includes(value.type) && exact(value, value.type === "routes" ? ["type", "zoneIDs", "routes"] : ["type", "zoneIDs"]));
  require2(Array.isArray(value.zoneIDs) && value.zoneIDs.length > 0 && value.zoneIDs.length <= 100 && value.zoneIDs.every((v) => matches(id, v)) && new Set(value.zoneIDs).size === value.zoneIDs.length && canonical(value.zoneIDs) === canonical([...value.zoneIDs].sort()));
  if (value.type === "service-only") {
    require2(target.zoneID === null && target.hostname === null);
    return value;
  }
  require2(matches(id, target.zoneID) && hostname(target.hostname) && value.zoneIDs.includes(target.zoneID) && Array.isArray(value.routes) && value.routes.length > 0 && value.routes.length <= 100);
  const ids = [];
  for (const route2 of value.routes) {
    require2(exact(route2, ["id", "zoneID", "pattern"]) && matches(id, route2.id) && route2.zoneID === target.zoneID && typeof route2.pattern === "string" && route2.pattern.length <= 1024 && route2.pattern.startsWith(target.hostname + "/"));
    require2(/^[A-Za-z0-9._~!$&'()+,;=:@\/-]*\*?$/.test(route2.pattern.slice(target.hostname.length + 1)));
    ids.push(route2.id);
  }
  require2(new Set(ids).size === ids.length && canonical(ids) === canonical([...ids].sort()) && new Set(value.routes.map((r) => r.pattern)).size === value.routes.length);
  return value;
}
function validatePolicy(policy2, { requireDeploymentTarget = true } = {}) {
  require2(typeof requireDeploymentTarget === "boolean");
  require2(exact(policy2, ["schema", "revision", "enabled", "authorizer", "executor", "targets", "maxArtifactBytes", "verification"]));
  require2(policy2.schema === "workflow-depot-cloudflare-policy/v1" && positive(policy2.revision) && typeof policy2.enabled === "boolean" && positive(policy2.maxArtifactBytes) && policy2.maxArtifactBytes <= 5 * 1024 * 1024);
  for (const trust of [policy2.authorizer, policy2.executor]) if (policy2.enabled || !exact(trust, [])) validateTrust(trust);
  require2(Array.isArray(policy2.targets) && policy2.targets.length <= 100 && (!policy2.enabled || !requireDeploymentTarget || policy2.targets.length > 0));
  const targets = /* @__PURE__ */ new Set();
  for (const t of policy2.targets) {
    require2(exact(t, ["accountID", "scriptName", "zoneID", "hostname", "metadataDigest", "sourceRepository", "sourceRepositoryID", ...Object.hasOwn(t, "ingress") ? ["ingress"] : []]));
    require2(matches(id, t.accountID) && matches(script, t.scriptName) && matches(hex, t.metadataDigest) && matches(repository, t.sourceRepository) && positive(t.sourceRepositoryID));
    validateIngress(t);
    const key = t.accountID + "/" + t.scriptName;
    require2(!targets.has(key));
    targets.add(key);
  }
  const v = policy2.verification;
  if (policy2.enabled || !exact(v, [])) {
    require2(exact(v, ["signerKeyIDs", "ciWorkflowRef", "ciWorkflowSHA", "requiredJobs"]) && Array.isArray(v.signerKeyIDs) && v.signerKeyIDs.length > 0 && v.signerKeyIDs.length <= 20 && v.signerKeyIDs.every(signerKey) && new Set(v.signerKeyIDs).size === v.signerKeyIDs.length && workflow(v.ciWorkflowRef) && matches(sha, v.ciWorkflowSHA));
    require2(Array.isArray(v.requiredJobs) && v.requiredJobs.length > 0 && v.requiredJobs.length <= 20 && v.requiredJobs.every((n) => typeof n === "string" && n.length > 0 && n.length <= 150 && n.trim() === n && !/[\u0000-\u001f\u007f]/.test(n)) && new Set(v.requiredJobs).size === v.requiredJobs.length);
    const ref = v.ciWorkflowRef.split("@")[1];
    if (matches(sha, ref)) require2(ref === v.ciWorkflowSHA);
  }
  return policy2;
}
function binding(b) {
  require2(object(b) && matches(identifier, b.name));
  const keys = { inherit: ["name", "type"], plain_text: ["name", "type", "text"], r2_bucket: ["name", "type", "bucket_name"], d1: ["name", "type", "database_id"], kv_namespace: ["name", "type", "namespace_id"], service: ["name", "type", "service", ...Object.hasOwn(b, "entrypoint") ? ["entrypoint"] : []], durable_object_namespace: ["name", "type", "namespace_id"] };
  require2(Object.hasOwn(keys, b.type) && exact(b, keys[b.type]));
  if (b.type === "plain_text") require2(typeof b.text === "string" && encoder2.encode(b.text).length <= 32768);
  if (b.type === "r2_bucket") require2(typeof b.bucket_name === "string" && /^[a-z0-9][a-z0-9-]{1,61}[a-z0-9]$/.test(b.bucket_name));
  if (b.type === "d1") require2(matches(uuid, b.database_id));
  if (["kv_namespace", "durable_object_namespace"].includes(b.type)) require2(matches(id, b.namespace_id));
  if (b.type === "service") require2(matches(script, b.service) && (!Object.hasOwn(b, "entrypoint") || matches(identifier, b.entrypoint)));
}
async function inspectArtifact(bytes, maxArtifactBytes) {
  require2(positive(maxArtifactBytes) && maxArtifactBytes <= 5 * 1024 * 1024);
  const data = byteView(bytes);
  require2(data.length > 0 && data.length <= maxArtifactBytes);
  const artifact = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(data));
  require2(exact(artifact, ["schema", "metadata", "modules"]) && artifact.schema === "workflow-depot-worker-artifact/v1");
  const m = artifact.metadata;
  require2(exact(m, ["main_module", "compatibility_date", "compatibility_flags", "bindings"]) && m.main_module === "worker.mjs");
  require2(typeof m.compatibility_date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(m.compatibility_date));
  const date = /* @__PURE__ */ new Date(m.compatibility_date + "T00:00:00Z");
  require2(Number.isFinite(date.valueOf()) && date.toISOString().slice(0, 10) === m.compatibility_date);
  require2(Array.isArray(m.compatibility_flags) && m.compatibility_flags.length <= 100 && m.compatibility_flags.every((v) => typeof v === "string" && /^[a-z][a-z0-9_]{0,99}$/.test(v)) && new Set(m.compatibility_flags).size === m.compatibility_flags.length);
  require2(Array.isArray(m.bindings) && m.bindings.length <= 100);
  const names = /* @__PURE__ */ new Set();
  for (const b of m.bindings) {
    binding(b);
    require2(!names.has(b.name));
    names.add(b.name);
  }
  require2(Array.isArray(artifact.modules) && artifact.modules.length === 1);
  const module = artifact.modules[0];
  require2(exact(module, ["name", "type", "content"]) && module.name === "worker.mjs" && module.type === "esm" && typeof module.content === "string" && module.content.length > 0);
  return { artifact, artifactDigest: await sha256(data), metadataDigest: await digest(m) };
}

// src/candidate-admission-client.mjs
function validateCandidateReviewPolicy(value, source, candidate, expected = {}) {
  if (value === null) return null;
  const require3 = (value2) => {
    if (!value2) throw Error("Invalid candidate review policy");
  };
  const exact3 = (value2, keys) => require3(value2 && typeof value2 === "object" && !Array.isArray(value2) && Object.keys(value2).sort().join(",") === [...keys].sort().join(","));
  const positive3 = (v) => Number.isSafeInteger(v) && v > 0, hex2 = (v) => typeof v === "string" && /^[a-f0-9]{64}$/.test(v), sha3 = (v) => typeof v === "string" && /^[a-f0-9]{40}$/.test(v);
  const text = (v, max = 1e3) => typeof v === "string" && v.length > 0 && v.length <= max;
  const strings = (xs, max = 100, maxLength = 300) => Array.isArray(xs) && xs.length <= max && xs.every((v) => text(v, maxLength)) && new Set(xs).size === xs.length;
  const ids = (xs) => Array.isArray(xs) && xs.length <= 100 && xs.every(positive3) && new Set(xs).size === xs.length;
  require3(new TextEncoder().encode(JSON.stringify(value)).length <= 256 * 1024);
  exact3(value, ["repositoryID", "commitSHA", "policyDigest", "policy"]);
  require3(value.repositoryID === source.repositoryID && value.commitSHA === source.commitSHA && hex2(value.policyDigest) && value.policyDigest === candidate.policyDigest);
  const p = value.policy;
  exact3(p, ["repository", "repositoryID", "ownerID", "policyDigest", "reviewPolicy", "scanPolicy", "priorJobs", "applicablePolicy", "maxAgeSeconds"]);
  require3(p.repository === source.repository && p.repositoryID === source.repositoryID && positive3(p.ownerID) && p.policyDigest === value.policyDigest && positive3(p.maxAgeSeconds) && p.maxAgeSeconds <= 86400 && (!expected.ownerID || p.ownerID === expected.ownerID));
  const j = p.priorJobs;
  exact3(j, ["workflowID", "workflowPath", "workflowDigest", "jobWorkflowRef", "jobWorkflowSHA", "actorIDs", "requiredJobNames", "scanJobName", "maxAgeSeconds", "policyDigest"]);
  require3(positive3(j.workflowID) && j.workflowPath === ".github/workflows/build.yml" && hex2(j.workflowDigest) && sha3(j.jobWorkflowSHA) && j.jobWorkflowRef === source.repository.split("/")[0] + "/workflow_depot/.github/workflows/orchestration.yml@" + j.jobWorkflowSHA && ids(j.actorIDs) && j.actorIDs.length > 0 && strings(j.requiredJobNames) && j.requiredJobNames.length > 0 && j.requiredJobNames.includes(j.scanJobName) && positive3(j.maxAgeSeconds) && j.maxAgeSeconds <= 86400 && j.policyDigest === value.policyDigest);
  require3((!expected.jobWorkflowRef || j.jobWorkflowRef === expected.jobWorkflowRef) && (!expected.jobWorkflowSHA || j.jobWorkflowSHA === expected.jobWorkflowSHA));
  const r = p.reviewPolicy;
  exact3(r, ["styleGuideDigest", "styleGuideRevision", "styleGuidePath", "reviewerAppID", "reviewerInstallationID", "reviewerActorID", "privilegedAppIDs", "privilegedActorIDs", "allowBotApproval", "requiresHumanReview", ...Object.hasOwn(r ?? {}, "checkName") ? ["checkName"] : []]);
  require3(hex2(r.styleGuideDigest) && sha3(r.styleGuideRevision) && text(r.styleGuidePath, 500) && [r.reviewerAppID, r.reviewerInstallationID, r.reviewerActorID].every(positive3) && ids(r.privilegedAppIDs) && ids(r.privilegedActorIDs) && typeof r.allowBotApproval === "boolean" && typeof r.requiresHumanReview === "boolean" && (!Object.hasOwn(r, "checkName") || text(r.checkName, 300)));
  const a = p.applicablePolicy;
  exact3(a, ["languages", "frameworks", "dependencyPolicyDigest", "documents", "rules"]);
  require3(strings(a.languages) && strings(a.frameworks) && hex2(a.dependencyPolicyDigest) && strings(a.rules) && Array.isArray(a.documents) && a.documents.length <= 100);
  for (const d of a.documents) {
    exact3(d, ["kind", "name", "revision", "digest", "text"]);
    require3(["language", "framework", "dependencies"].includes(d.kind) && text(d.name, 300) && sha3(d.revision) && hex2(d.digest) && text(d.text, 16384));
  }
  const scan = p.scanPolicy;
  exact3(scan, ["supportedLanguages", "supportedFrameworks", "requiredCategories", "requiredTools", "exemptions", "sonarqubeStandardRulesetDigest"]);
  require3(strings(scan.supportedLanguages) && strings(scan.supportedFrameworks) && strings(scan.requiredCategories) && Array.isArray(scan.requiredTools) && scan.requiredTools.length <= 100 && Array.isArray(scan.exemptions) && scan.exemptions.length <= 1e3 && hex2(scan.sonarqubeStandardRulesetDigest));
  for (const t of scan.requiredTools) {
    exact3(t, ["id", "category", "version", "rulesetDigest", "databaseMaxAgeSeconds"]);
    require3(text(t.id) && text(t.category) && text(t.version) && hex2(t.rulesetDigest) && Number.isSafeInteger(t.databaseMaxAgeSeconds) && t.databaseMaxAgeSeconds >= 0);
  }
  for (const e of scan.exemptions) {
    exact3(e, ["toolID", "path", "reason"]);
    require3(text(e.toolID) && text(e.path) && text(e.reason));
  }
  return value;
}

// src/deployment-provenance.mjs
var LIMIT = 6 * 1024 * 1024;
var HEX = /^[a-f0-9]{64}$/;
var requireThat = (value, code) => {
  if (!value) throw Error(code);
};
function exact2(value, keys) {
  requireThat(value && Object.getPrototypeOf(value) === Object.prototype && Object.keys(value).sort().join(",") === [...keys].sort().join(","), "invalid-artifact-request");
}
function snapshot(value, max = LIMIT) {
  const text = JSON.stringify(value);
  requireThat(typeof text === "string" && new TextEncoder().encode(text).length <= max, "artifact-request-too-large");
  return JSON.parse(text);
}
function positive2(value) {
  return Number.isSafeInteger(value) && value > 0;
}
function validateSource(s) {
  exact2(s, ["repository", "repositoryID", "commitSHA", "sourceRef", "runID", "runAttempt"]);
  requireThat(typeof s.repository === "string" && /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(s.repository) && [s.repositoryID, s.runID, s.runAttempt].every(positive2) && typeof s.commitSHA === "string" && /^[a-f0-9]{40}$/.test(s.commitSHA), "invalid-artifact-source");
  const shadow = typeof s.sourceRef === "string" && s.sourceRef.match(/^refs\/heads\/promotion\/([1-9][0-9]*)\/shadow$/);
  requireThat(shadow && positive2(Number(shadow[1])), "invalid-candidate-ref");
  return shadow;
}
async function currentPolicy(policy2, options) {
  const p = snapshot(policy2(), 65536);
  validatePolicy(p, options);
  requireThat(p.enabled && /^[^/]+\/workflow_depot$/.test(p.authorizer.repository), "staging-disabled");
  return p;
}
function validIdentity(identity, s, now) {
  requireThat(typeof identity?.jti === "string" && /^[\x21-\x7e]{8,200}$/.test(identity.jti) && positive2(identity.expiresAt) && identity.expiresAt > now() && identity.runID === String(s.runID) && identity.runAttempt === String(s.runAttempt), "invalid-builder-identity");
}
async function readCandidateEvidence(s, p, github, candidates) {
  const shadow = validateSource(s);
  const [repo, tip, main, commit, candidate] = await Promise.all([github.read(s.repository, ""), github.read(s.repository, "/git/ref/" + s.sourceRef.slice(5)), github.read(s.repository, "/git/ref/heads/main"), github.read(s.repository, "/git/commits/" + s.commitSHA), candidates.lookupCandidate({ repositoryID: s.repositoryID, commitSHA: s.commitSHA, shadowRef: s.sourceRef })]);
  exact2(candidate, ["schema", "verified", "repository", "repositoryID", "commitSHA", "treeSHA", "sourceRef", "sourceSHA", "expectedMainParent", "shadowRef", "sourcePR", "sequence", "signerKeyID", "unsignedCommitDigest", "artifactIntentDigest", "policyDigest", "sourceHistoryDigest"]);
  requireThat(candidate.schema === "repoctl-source-candidate/v1" && candidate.verified === true && candidate.repository === s.repository && candidate.repositoryID === s.repositoryID && candidate.commitSHA === s.commitSHA && candidate.shadowRef === s.sourceRef && candidate.sequence === Number(shadow[1]) && p.verification.signerKeyIDs.includes(candidate.signerKeyID), "candidate-evidence-denied");
  requireThat([candidate.sourceSHA, candidate.expectedMainParent, candidate.treeSHA].every((v) => typeof v === "string" && /^[a-f0-9]{40}$/.test(v)) && [candidate.unsignedCommitDigest, candidate.artifactIntentDigest, candidate.policyDigest, candidate.sourceHistoryDigest].every((v) => typeof v === "string" && HEX.test(v)), "candidate-evidence-denied");
  exact2(candidate.sourcePR, ["number", "repositoryID", "headSHA"]);
  requireThat(positive2(candidate.sourcePR.number) && candidate.sourcePR.repositoryID === s.repositoryID && candidate.sourcePR.headSHA === candidate.sourceSHA, "candidate-evidence-denied");
  requireThat(repo.id === s.repositoryID && repo.full_name === s.repository && repo.owner?.id === p.authorizer.ownerID && !repo.archived && !repo.fork && repo.default_branch === "main" && tip.object?.sha === s.commitSHA && main.object?.sha === candidate.expectedMainParent && commit.sha === s.commitSHA && commit.parents?.length === 1 && commit.parents[0].sha === candidate.expectedMainParent && commit.tree?.sha === candidate.treeSHA && commit.verification?.verified === true && commit.verification.reason === "valid", "source-evidence-denied");
  return snapshot(candidate, 16384);
}
function createCandidateAdmission({ policy: policy2, github, candidates, verifyIdentity = verifyOIDC, jwks = githubJWKS, now = () => Math.floor(Date.now() / 1e3) } = {}) {
  requireThat(typeof policy2 === "function" && typeof github?.read === "function" && typeof candidates?.lookupCandidate === "function", "evidence-required");
  async function verify(request) {
    try {
      const input = snapshot(request, 32768);
      exact2(input, ["source", "oidcToken"]);
      const s = input.source;
      validateSource(s);
      requireThat(typeof input.oidcToken === "string" && input.oidcToken.length > 0 && input.oidcToken.length <= 16384, "invalid-candidate-request");
      const p = await currentPolicy(policy2, { requireDeploymentTarget: false }), policyDigest = await digest(p);
      const base = p.authorizer.repository + "/.github/workflows/", sha3 = p.verification.ciWorkflowSHA;
      requireThat(p.verification.ciWorkflowRef === base + "orchestration.yml@" + sha3, "unapproved-admission-workflow");
      const trust = { ...p.authorizer, audiencePrefix: "workflow-depot-candidate", repository: s.repository, repositoryID: s.repositoryID, ref: s.sourceRef, workflowRef: s.repository + "/.github/workflows/build.yml@" + s.sourceRef, workflowSHA: s.commitSHA, jobWorkflowRef: p.verification.ciWorkflowRef, jobWorkflowSHA: sha3, eventNames: ["push"] };
      const binding2 = { operationID: await digest(s), runID: s.runID, runAttempt: s.runAttempt }, keys = await jwks();
      let identity;
      for (const jobWorkflowRef of [trust.jobWorkflowRef, base + "review-candidate.yml@" + sha3]) {
        try {
          identity = await verifyIdentity(input.oidcToken, { ...trust, jobWorkflowRef }, binding2, keys, now());
          break;
        } catch {
        }
      }
      validIdentity(identity, s, now);
      const candidate = await readCandidateEvidence(s, p, github, candidates), candidateDigest = await digest(candidate);
      const readReviewPolicy = async () => {
        if (typeof candidates.lookupReviewPolicy !== "function") return null;
        const metadata = snapshot(await candidates.lookupReviewPolicy({ repositoryID: s.repositoryID, commitSHA: s.commitSHA, shadowRef: s.sourceRef }), 256 * 1024);
        return validateCandidateReviewPolicy(metadata, s, candidate, { ownerID: p.authorizer.ownerID, jobWorkflowRef: p.verification.ciWorkflowRef, jobWorkflowSHA: p.verification.ciWorkflowSHA });
      };
      const reviewPolicy = await readReviewPolicy();
      requireThat(await digest(await readCandidateEvidence(s, p, github, candidates)) === candidateDigest, "candidate-changed");
      requireThat(await digest(await readReviewPolicy()) === await digest(reviewPolicy), "review-policy-changed");
      requireThat(await digest(await currentPolicy(policy2, { requireDeploymentTarget: false })) === policyDigest, "candidate-policy-changed");
      validIdentity(identity, s, now);
      return { verified: true, source: snapshot(s, 2048), candidateDigest, candidate, reviewPolicy };
    } catch {
      throw Error("Candidate admission denied");
    }
  }
  return Object.freeze({ verify });
}
function createDeploymentProvenance({ storage, artifacts, policy: policy2, github, candidates, verifyIdentity = verifyOIDC, jwks = githubJWKS, now = () => Math.floor(Date.now() / 1e3) } = {}) {
  requireThat(typeof storage?.transaction === "function" && typeof storage?.get === "function", "atomic-storage-required");
  requireThat(typeof artifacts?.put === "function" && typeof artifacts?.get === "function", "artifact-store-required");
  requireThat(typeof policy2 === "function" && typeof github?.read === "function" && typeof candidates?.lookupCandidate === "function", "evidence-required");
  async function current() {
    return currentPolicy(policy2);
  }
  async function unchanged(expected) {
    const p = await current();
    requireThat(await digest(p) === expected, "staging-policy-changed");
    return p;
  }
  async function stage(request) {
    let reserved = false, key, record;
    try {
      const input = snapshot(request);
      exact2(input, ["artifact", "source", "oidcToken"]);
      exact2(input.source, ["repository", "repositoryID", "commitSHA", "sourceRef", "runID", "runAttempt"]);
      const s = input.source;
      requireThat(typeof input.artifact === "string" && typeof input.oidcToken === "string" && input.oidcToken.length > 0 && input.oidcToken.length <= 16384, "invalid-artifact-request");
      validateSource(s);
      const p = await current(), policyDigest = await digest(p), bytes = new TextEncoder().encode(input.artifact);
      const { artifactDigest, metadataDigest } = await inspectArtifact(bytes, p.maxArtifactBytes);
      requireThat(p.targets.some((t) => t.sourceRepository === s.repository && t.sourceRepositoryID === s.repositoryID && t.metadataDigest === metadataDigest), "unapproved-artifact-target");
      requireThat(p.verification.ciWorkflowRef.startsWith(p.authorizer.repository + "/.github/workflows/"), "unapproved-build-workflow");
      const trust = { ...p.authorizer, audiencePrefix: "workflow-depot-build", repository: s.repository, repositoryID: s.repositoryID, ref: s.sourceRef, workflowRef: s.repository + "/.github/workflows/build.yml@" + s.sourceRef, workflowSHA: s.commitSHA, jobWorkflowRef: p.verification.ciWorkflowRef, jobWorkflowSHA: p.verification.ciWorkflowSHA, eventNames: ["push"] };
      const identity = await verifyIdentity(input.oidcToken, trust, { operationID: artifactDigest, runID: s.runID, runAttempt: s.runAttempt }, await jwks(), now());
      requireThat(typeof identity?.jti === "string" && /^[\x21-\x7e]{8,200}$/.test(identity.jti) && positive2(identity.expiresAt) && identity.expiresAt > now() && identity.runID === String(s.runID) && identity.runAttempt === String(s.runAttempt), "invalid-builder-identity");
      const candidateEvidence = async () => digest(await readCandidateEvidence(s, p, github, candidates));
      const candidateDigest = await candidateEvidence();
      const proof = { schema: "workflow-depot-build-provenance/v1", repository: s.repository, repositoryID: s.repositoryID, sourceSHA: s.commitSHA, sourceRef: s.sourceRef, artifactDigest, metadataDigest, runID: s.runID, runAttempt: s.runAttempt, workflowRef: p.verification.ciWorkflowRef, workflowSHA: p.verification.ciWorkflowSHA };
      key = "build:" + artifactDigest;
      const replay = "build-jti:" + await sha256(new TextEncoder().encode(identity.jti));
      record = { state: "staging", proof, policyDigest, identityExpiresAt: identity.expiresAt };
      await storage.transaction(async (tx) => {
        await unchanged(policyDigest);
        requireThat(identity.expiresAt > now(), "builder-identity-expired");
        requireThat(!await tx.get(key), "artifact-already-retained");
        requireThat(!await tx.get(replay), "builder-identity-replayed");
        requireThat(identity.expiresAt > now(), "builder-identity-expired");
        await tx.put(key, record);
        await tx.put(replay, artifactDigest);
      });
      reserved = true;
      const objectKey = "artifacts/sha256/" + artifactDigest + ".json";
      const created = await artifacts.put(objectKey, bytes, { onlyIf: { etagDoesNotMatch: "*" }, httpMetadata: { contentType: "application/json" } });
      if (!created) {
        const existing = await artifacts.get(objectKey);
        requireThat(existing && existing.size === bytes.length && existing.size <= p.maxArtifactBytes, "artifact-store-collision");
        const prior = new Uint8Array(await existing.arrayBuffer());
        requireThat(prior.length === bytes.length && await sha256(prior) === artifactDigest && prior.every((value, index) => value === bytes[index]), "artifact-store-collision");
      }
      requireThat(await candidateEvidence() === candidateDigest, "candidate-changed-during-staging");
      await storage.transaction(async (tx) => {
        await unchanged(policyDigest);
        requireThat(identity.expiresAt > now(), "builder-identity-expired");
        const retained = await tx.get(key);
        requireThat(retained?.state === "staging" && await digest(retained.proof) === await digest(proof), "artifact-registry-collision");
        requireThat(identity.expiresAt > now(), "builder-identity-expired");
        await tx.put(key, { ...record, state: "ready", retainedAt: now() });
      });
      return { artifactDigest, metadataDigest, state: "retained" };
    } catch {
      if (reserved) {
        try {
          await storage.transaction(async (tx) => {
            const retained = await tx.get(key);
            if (retained?.state === "staging") await tx.put(key, { ...record, state: "uncertain" });
          });
        } catch {
        }
      }
      throw Error("Artifact staging denied");
    }
  }
  async function lookup(input) {
    try {
      input = snapshot(input, 1024);
      exact2(input, ["artifactDigest"]);
      requireThat(typeof input.artifactDigest === "string" && HEX.test(input.artifactDigest), "invalid-artifact-digest");
      const record = await storage.get("build:" + input.artifactDigest);
      requireThat(record?.state === "ready", "artifact-not-qualified");
      await unchanged(record.policyDigest);
      return structuredClone(record.proof);
    } catch {
      throw Error("Artifact provenance unavailable");
    }
  }
  return Object.freeze({ stage, lookup });
}

// src/deployment-evidence.mjs
var sha2 = /^[a-f0-9]{40}$/;
var deny = () => {
  throw Error("Deployment evidence denied");
};
function githubEvidenceReader({ fetcher = fetch, token } = {}) {
  async function request(repository2, path, raw = false) {
    if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repository2)) deny();
    const response = await fetcher(`https://api.github.com/repos/${repository2}${path}`, { redirect: "error", signal: AbortSignal.timeout(1e4), headers: { Accept: raw ? "application/vnd.github.raw+json" : "application/vnd.github+json", "X-GitHub-Api-Version": "2026-03-10", "User-Agent": "workflow-depot-evidence", ...token ? { Authorization: `Bearer ${token}` } : {} } });
    if (!response.ok) {
      await response.body?.cancel();
      deny();
    }
    const reader = response.body?.getReader();
    if (!reader) deny();
    const chunks = [];
    let size = 0;
    try {
      for (; ; ) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.length;
        if (size > (raw ? 32768 : 512 * 1024)) {
          await reader.cancel();
          deny();
        }
        chunks.push(value);
      }
    } finally {
      reader.releaseLock();
    }
    const bytes = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, offset);
      offset += chunk.length;
    }
    const text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    return raw ? text : JSON.parse(text);
  }
  return { async read(repository2, path) {
    if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repository2) || !(path === "" || /^\/(?:git\/ref\/heads\/(?:main|promotion\/[1-9][0-9]*\/shadow)|git\/commits\/[a-f0-9]{40}|actions\/runs\/[1-9][0-9]*(?:\/attempts\/[1-9][0-9]*\/jobs\?per_page=100&page=[1-9][0-9]*)?)$/.test(path))) deny();
    return request(repository2, path);
  }, async readWorkflow(repository2, commitSHA) {
    if (!sha2.test(commitSHA)) deny();
    return request(repository2, "/contents/.github/workflows/build.yml?ref=" + commitSHA, true);
  } };
}

// src/deployment-provenance-worker.mjs
var MAX_REQUEST = 6 * 1024 * 1024;
var RequestError = class extends Error {
  constructor(status, code) {
    super(code);
    this.status = status;
    this.code = code;
  }
};
function json2(value, status = 200, max = 65536) {
  const body = JSON.stringify(value);
  if (new TextEncoder().encode(body).length > max) return json2({ error: "response-too-large" }, 500);
  return new Response(body, { status, headers: { "content-type": "application/json", "cache-control": "no-store", "x-content-type-options": "nosniff" } });
}
function policy(env) {
  if (typeof env.DEPLOYMENT_POLICY_JSON !== "string" || env.DEPLOYMENT_POLICY_JSON.length > 65536) throw new RequestError(503, "staging-unavailable");
  return JSON.parse(env.DEPLOYMENT_POLICY_JSON);
}
function ready(env, mode = "stage") {
  if (env.ENABLED !== "true" || typeof env.SOURCE_CANDIDATES?.lookupCandidate !== "function" || policy(env).enabled !== true || mode !== "verify" && (!env.BUILD_PROVENANCE_STATE || !env.DEPLOYMENT_ARTIFACTS)) throw new RequestError(503, "staging-unavailable");
}
function failure(error) {
  return error instanceof RequestError ? json2({ error: error.code }, error.status) : json2({ error: "artifact-request-denied" }, 403);
}
async function readJSON(request, max) {
  if (!/^application\/json(?:\s*;|$)/i.test(request.headers.get("content-type") || "")) throw new RequestError(415, "json-required");
  const declared = request.headers.get("content-length");
  if (declared !== null && (!/^\d+$/.test(declared) || Number(declared) > max)) throw new RequestError(413, "request-too-large");
  const reader = request.body?.getReader();
  if (!reader) throw new RequestError(400, "invalid-request");
  const chunks = [];
  let length = 0;
  try {
    for (; ; ) {
      const { done, value } = await reader.read();
      if (done) break;
      length += value.byteLength;
      if (length > max) {
        await reader.cancel();
        throw new RequestError(413, "request-too-large");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const bytes = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
  } catch {
    throw new RequestError(400, "invalid-request");
  }
}
function route(request, mode) {
  const url = new URL(request.url), path = mode === "stage" ? "/v1/artifacts" : mode === "verify" ? "/v1/candidates/verify" : "/v1/artifacts/lookup";
  if (url.pathname !== path || url.search) throw new RequestError(404, "not-found");
  if (request.method !== "POST") throw new RequestError(405, "method-not-allowed");
}
async function forward(request, env, mode) {
  try {
    route(request, mode);
    ready(env);
    const input = await readJSON(request, mode === "stage" ? MAX_REQUEST : 1024);
    const stub = env.BUILD_PROVENANCE_STATE.get(env.BUILD_PROVENANCE_STATE.idFromName("build-provenance-v1"));
    return await stub.fetch(new Request("https://build-provenance.internal" + (mode === "stage" ? "/v1/artifacts" : "/v1/artifacts/lookup"), { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(input) }));
  } catch (error) {
    return failure(error);
  }
}
var deployment_provenance_worker_default = { async fetch(request, env) {
  if (new URL(request.url).pathname !== "/v1/candidates/verify") return forward(request, env, "stage");
  try {
    route(request, "verify");
    ready(env, "verify");
    const input = await readJSON(request, 32768);
    const candidates = { lookupCandidate: (input2) => env.SOURCE_CANDIDATES.lookupCandidate(input2) };
    if (typeof env.SOURCE_CANDIDATES.lookupReviewPolicy === "function") candidates.lookupReviewPolicy = (input2) => env.SOURCE_CANDIDATES.lookupReviewPolicy(input2);
    const admission = createCandidateAdmission({ policy: () => policy(env), github: githubEvidenceReader({ token: env.GITHUB_READ_TOKEN }), candidates });
    return json2(await admission.verify(input), 200, 512 * 1024);
  } catch (error) {
    return failure(error);
  }
} };
var BuildProvenance = class extends WorkerEntrypoint {
  fetch(request) {
    return forward(request, this.env, "lookup");
  }
  async lookup(input) {
    try {
      const body = JSON.stringify(input);
      if (new TextEncoder().encode(body).length > 1024) throw Error();
      const response = await forward(new Request("https://build-provenance.internal/v1/artifacts/lookup", { method: "POST", headers: { "content-type": "application/json" }, body }), this.env, "lookup");
      if (!response.ok) throw Error();
      return await response.json();
    } catch {
      throw Error("Artifact provenance unavailable");
    }
  }
};
var BuildProvenanceState = class extends DurableObject {
  async fetch(request) {
    try {
      const mode = new URL(request.url).pathname === "/v1/artifacts" ? "stage" : "lookup";
      route(request, mode);
      ready(this.env);
      const input = await readJSON(request, mode === "stage" ? MAX_REQUEST : 1024);
      const provenance = createDeploymentProvenance({ storage: this.ctx.storage, artifacts: this.env.DEPLOYMENT_ARTIFACTS, policy: () => policy(this.env), github: githubEvidenceReader({ token: this.env.GITHUB_READ_TOKEN }), candidates: { lookupCandidate: (input2) => this.env.SOURCE_CANDIDATES.lookupCandidate(input2) } });
      return json2(await provenance[mode](input));
    } catch (error) {
      return failure(error);
    }
  }
};
export {
  BuildProvenance,
  BuildProvenanceState,
  deployment_provenance_worker_default as default
};
