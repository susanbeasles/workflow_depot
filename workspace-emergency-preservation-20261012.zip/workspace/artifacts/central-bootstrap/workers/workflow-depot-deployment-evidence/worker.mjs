// src/deployment-evidence-worker.mjs
import { WorkerEntrypoint } from "cloudflare:workers";

// src/shared/oidc.mjs
var encoder = new TextEncoder();
var reject = (message) => {
  throw new Error(message);
};
function validateTrust(t) {
  const fields = ["audiencePrefix", "repository", "repositoryID", "ownerID", "ref", "workflowRef", "workflowSHA", "jobWorkflowRef", "jobWorkflowSHA", "eventNames", "actorIDs"];
  const positive2 = (v) => Number.isSafeInteger(v) && v > 0, sha3 = /^[a-f0-9]{40}$/;
  if (!t || Object.getPrototypeOf(t) !== Object.prototype || Object.keys(t).sort().join() !== fields.sort().join()) reject("Invalid executor trust schema");
  if (!["audiencePrefix", "repository", "ref", "workflowRef", "workflowSHA", "jobWorkflowRef", "jobWorkflowSHA"].every((k) => typeof t[k] === "string")) reject("Invalid executor trust field type");
  if (typeof t.audiencePrefix !== "string" || !/^[A-Za-z0-9_.:-]{1,200}$/.test(t.audiencePrefix) || !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(t.repository) || !positive2(t.repositoryID) || !positive2(t.ownerID) || !/^refs\/heads\/[A-Za-z0-9_.\/-]+$/.test(t.ref) || ![t.workflowSHA, t.jobWorkflowSHA].every((v) => sha3.test(v))) reject("Invalid executor trust identity");
  const workflow2 = /^([A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+)\/\.github\/workflows\/[A-Za-z0-9_.-]+\.ya?ml@(refs\/heads\/[A-Za-z0-9_.\/-]+|[a-f0-9]{40})$/;
  const caller = typeof t.workflowRef === "string" && t.workflowRef.match(workflow2), job = typeof t.jobWorkflowRef === "string" && t.jobWorkflowRef.match(workflow2);
  if (!caller || caller[1] !== t.repository || caller[2] !== t.ref || !job || sha3.test(job[2]) && job[2] !== t.jobWorkflowSHA) reject("Invalid pinned workflow identity");
  if (!Array.isArray(t.eventNames) || !t.eventNames.length || t.eventNames.length > 20 || !t.eventNames.every((v) => typeof v === "string" && /^[a-z][a-z0-9_]{0,63}$/.test(v)) || new Set(t.eventNames).size !== t.eventNames.length || !Array.isArray(t.actorIDs) || !t.actorIDs.length || t.actorIDs.length > 100 || !t.actorIDs.every(positive2) || new Set(t.actorIDs).size !== t.actorIDs.length) reject("Invalid executor event or actor policy");
  return t;
}

// src/shared/contract.mjs
var encoder2 = new TextEncoder();
var hex = /^[a-f0-9]{64}$/;
var id = /^[a-f0-9]{32}$/;
var sha = /^[a-f0-9]{40}$/;
var uuid = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
var repository = /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/;
var script = /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;
var matches = (pattern, value) => typeof value === "string" && pattern.test(value);
var signerKey = (value) => matches(hex, value) && value.length === 64 || matches(/^SHA256:[A-Za-z0-9+/]{42}[AEIMQUYcgkosw048]$/, value) && value.length === 50;
var positive = (v) => Number.isSafeInteger(v) && v > 0;
var object = (v) => v !== null && typeof v === "object" && Object.getPrototypeOf(v) === Object.prototype;
var exact = (v, keys) => object(v) && Object.keys(v).sort().join() === keys.slice().sort().join();
var fail = () => {
  throw Error("Cloudflare deployment contract denied");
};
var require2 = (v) => {
  if (!v) fail();
};
function canonical(value) {
  if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number" && Number.isSafeInteger(value)) return String(value);
  if (Array.isArray(value)) return "[" + value.map(canonical).join(",") + "]";
  if (object(value)) return "{" + Object.keys(value).sort().map((k) => JSON.stringify(k) + ":" + canonical(value[k])).join(",") + "}";
  fail();
}
function byteView(value) {
  if (value instanceof Uint8Array) return value;
  if (value instanceof ArrayBuffer) return new Uint8Array(value);
  fail();
}
async function sha256(bytes) {
  return [...new Uint8Array(await crypto.subtle.digest("SHA-256", byteView(bytes)))].map((v) => v.toString(16).padStart(2, "0")).join("");
}
async function digest(value) {
  return sha256(encoder2.encode(canonical(value)));
}
function hostname(value) {
  return typeof value === "string" && value.length <= 253 && value.includes(".") && value.split(".").every((p) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(p)) && /^[a-z][a-z0-9-]*$/.test(value.split(".").at(-1));
}
function workflow(value) {
  return typeof value === "string" && /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/\.github\/workflows\/[A-Za-z0-9_.-]+\.ya?ml@(?:refs\/heads\/[A-Za-z0-9_.\/-]+|[a-f0-9]{40})$/.test(value);
}
function validateIngress(target) {
  if (!Object.hasOwn(target, "ingress")) {
    require2(matches(id, target.zoneID) && hostname(target.hostname));
    return { type: "custom-domain" };
  }
  const value = target.ingress;
  require2(object(value) && ["routes", "service-only"].includes(value.type) && exact(value, value.type === "routes" ? ["type", "zoneIDs", "routes"] : ["type", "zoneIDs"]));
  require2(Array.isArray(value.zoneIDs) && value.zoneIDs.length > 0 && value.zoneIDs.length <= 100 && value.zoneIDs.every((v) => matches(id, v)) && new Set(value.zoneIDs).size === value.zoneIDs.length && canonical(value.zoneIDs) === canonical([...value.zoneIDs].sort()));
  if (value.type === "service-only") {
    require2(target.zoneID === null && target.hostname === null);
    return value;
  }
  require2(matches(id, target.zoneID) && hostname(target.hostname) && value.zoneIDs.includes(target.zoneID) && Array.isArray(value.routes) && value.routes.length > 0 && value.routes.length <= 100);
  const ids = [];
  for (const route of value.routes) {
    require2(exact(route, ["id", "zoneID", "pattern"]) && matches(id, route.id) && route.zoneID === target.zoneID && typeof route.pattern === "string" && route.pattern.length <= 1024 && route.pattern.startsWith(target.hostname + "/"));
    require2(/^[A-Za-z0-9._~!$&'()+,;=:@\/-]*\*?$/.test(route.pattern.slice(target.hostname.length + 1)));
    ids.push(route.id);
  }
  require2(new Set(ids).size === ids.length && canonical(ids) === canonical([...ids].sort()) && new Set(value.routes.map((r) => r.pattern)).size === value.routes.length);
  return value;
}
function validatePolicy(policy, { requireDeploymentTarget = true } = {}) {
  require2(typeof requireDeploymentTarget === "boolean");
  require2(exact(policy, ["schema", "revision", "enabled", "authorizer", "executor", "targets", "maxArtifactBytes", "verification"]));
  require2(policy.schema === "workflow-depot-cloudflare-policy/v1" && positive(policy.revision) && typeof policy.enabled === "boolean" && positive(policy.maxArtifactBytes) && policy.maxArtifactBytes <= 5 * 1024 * 1024);
  for (const trust of [policy.authorizer, policy.executor]) if (policy.enabled || !exact(trust, [])) validateTrust(trust);
  require2(Array.isArray(policy.targets) && policy.targets.length <= 100 && (!policy.enabled || !requireDeploymentTarget || policy.targets.length > 0));
  const targets = /* @__PURE__ */ new Set();
  for (const t of policy.targets) {
    require2(exact(t, ["accountID", "scriptName", "zoneID", "hostname", "metadataDigest", "sourceRepository", "sourceRepositoryID", ...Object.hasOwn(t, "ingress") ? ["ingress"] : []]));
    require2(matches(id, t.accountID) && matches(script, t.scriptName) && matches(hex, t.metadataDigest) && matches(repository, t.sourceRepository) && positive(t.sourceRepositoryID));
    validateIngress(t);
    const key = t.accountID + "/" + t.scriptName;
    require2(!targets.has(key));
    targets.add(key);
  }
  const v = policy.verification;
  if (policy.enabled || !exact(v, [])) {
    require2(exact(v, ["signerKeyIDs", "ciWorkflowRef", "ciWorkflowSHA", "requiredJobs"]) && Array.isArray(v.signerKeyIDs) && v.signerKeyIDs.length > 0 && v.signerKeyIDs.length <= 20 && v.signerKeyIDs.every(signerKey) && new Set(v.signerKeyIDs).size === v.signerKeyIDs.length && workflow(v.ciWorkflowRef) && matches(sha, v.ciWorkflowSHA));
    require2(Array.isArray(v.requiredJobs) && v.requiredJobs.length > 0 && v.requiredJobs.length <= 20 && v.requiredJobs.every((n) => typeof n === "string" && n.length > 0 && n.length <= 150 && n.trim() === n && !/[\u0000-\u001f\u007f]/.test(n)) && new Set(v.requiredJobs).size === v.requiredJobs.length);
    const ref = v.ciWorkflowRef.split("@")[1];
    if (matches(sha, ref)) require2(ref === v.ciWorkflowSHA);
  }
  return policy;
}
function operationTarget(op, policy) {
  require2(exact(op, ["schema", "operationID", "nonce", "policyDigest", "artifactDigest", "metadataDigest", "accountID", "scriptName", "zoneID", "hostname", "expectedDeploymentID", "source", "execution", "expiresAt", ...Object.hasOwn(op, "ingress") ? ["ingress"] : []]));
  require2(op.schema === "workflow-depot-cloudflare-deploy/v1" && ["operationID", "nonce", "policyDigest", "artifactDigest", "metadataDigest"].every((k) => matches(hex, op[k])) && matches(uuid, op.expectedDeploymentID) && positive(op.expiresAt));
  require2(exact(op.source, ["repository", "repositoryID", "commitSHA", "signerKeyID", "signingReceiptDigest", "ciRunID", "ciRunAttempt"]) && matches(repository, op.source.repository) && positive(op.source.repositoryID) && matches(sha, op.source.commitSHA) && signerKey(op.source.signerKeyID) && matches(hex, op.source.signingReceiptDigest) && positive(op.source.ciRunID) && positive(op.source.ciRunAttempt));
  require2(exact(op.execution, ["runID", "runAttempt"]) && positive(op.execution.runID) && positive(op.execution.runAttempt));
  require2(policy.verification.signerKeyIDs.includes(op.source.signerKeyID));
  const target = policy.targets.find((t) => t.accountID === op.accountID && t.scriptName === op.scriptName && t.zoneID === op.zoneID && t.hostname === op.hostname && t.metadataDigest === op.metadataDigest && t.sourceRepository === op.source.repository && t.sourceRepositoryID === op.source.repositoryID);
  require2(target && Object.hasOwn(target, "ingress") === Object.hasOwn(op, "ingress") && canonical(validateIngress(target)) === canonical(validateIngress(op)));
  return target;
}
async function validateOperation(op, policy, now = Math.floor(Date.now() / 1e3)) {
  validatePolicy(policy);
  require2(policy.enabled && positive(now));
  operationTarget(op, policy);
  require2(op.expiresAt > now && op.expiresAt <= now + 600 && op.policyDigest === await digest(policy));
  return op;
}

// src/deployment-evidence.mjs
var hash = /^[a-f0-9]{64}$/;
var sha2 = /^[a-f0-9]{40}$/;
var deny = () => {
  throw Error("Deployment evidence denied");
};
var require3 = (value) => {
  if (!value) deny();
};
function deploymentEvidence({ policy, github, signingReceipts, provenance }) {
  if (typeof github?.read !== "function" || typeof signingReceipts?.lookupReceipt !== "function" || typeof provenance?.lookup !== "function" || !policy?.verification) deny();
  return { async verify(op) {
    try {
      const s = op.source, v = policy.verification;
      require3(v.signerKeyIDs.includes(s.signerKeyID));
      const read = (path) => github.read(s.repository, path);
      const repo = await read("");
      require3(repo.id === s.repositoryID && repo.full_name === s.repository && !repo.archived && !repo.fork && repo.default_branch === "main");
      const [tip, commit, run, receipt, build] = await Promise.all([
        read("/git/ref/heads/main"),
        read("/git/commits/" + s.commitSHA),
        read("/actions/runs/" + s.ciRunID),
        signingReceipts.lookupReceipt({ receiptDigest: s.signingReceiptDigest }),
        provenance.lookup({ artifactDigest: op.artifactDigest })
      ]);
      require3(tip.object?.sha === s.commitSHA && commit.sha === s.commitSHA && commit.verification?.verified === true && commit.verification.reason === "valid");
      require3(receipt?.schema === "repoctl-source-receipt/v1" && await digest(receipt) === s.signingReceiptDigest && receipt.repository === s.repository && receipt.repositoryID === s.repositoryID && receipt.finalSignedCommitSHA === s.commitSHA && receipt.signerKeyID === s.signerKeyID && receipt.hardwareApprovalVerified === true && hash.test(receipt.ownerApprovalReference) && Number.isSafeInteger(receipt.sequence) && receipt.sequence > 0);
      require3(commit.parents?.length === 1 && commit.parents[0].sha === receipt.baseSHA && commit.tree?.sha === receipt.treeSHA);
      const pair = receipt.pairedTags;
      require3(pair?.source?.name === `promotion/${receipt.sequence}/source` && pair?.main?.name === `promotion/${receipt.sequence}/main` && pair.source.targetSHA === receipt.sourceSHA && pair.main.targetSHA === s.commitSHA && sha2.test(pair.source.objectSHA) && sha2.test(pair.main.objectSHA));
      require3(receipt.shadowRef === `refs/heads/promotion/${receipt.sequence}/shadow`);
      require3(run.id === s.ciRunID && run.run_attempt === s.ciRunAttempt && run.head_sha === s.commitSHA && run.head_branch === receipt.shadowRef.slice("refs/heads/".length) && run.event === "push" && run.status === "completed" && run.conclusion === "success" && run.repository?.id === s.repositoryID && run.repository.full_name === s.repository);
      require3(run.referenced_workflows?.some((w) => w.path === v.ciWorkflowRef && w.sha === v.ciWorkflowSHA));
      const jobs = [];
      let total;
      for (let page = 1; page <= 10; page++) {
        const result = await read(`/actions/runs/${s.ciRunID}/attempts/${s.ciRunAttempt}/jobs?per_page=100&page=${page}`);
        require3(Array.isArray(result.jobs) && result.jobs.length <= 100 && Number.isSafeInteger(result.total_count) && result.total_count >= 0 && result.total_count <= 1e3);
        if (total === void 0) total = result.total_count;
        require3(total === result.total_count);
        jobs.push(...result.jobs);
        require3(jobs.length <= total);
        if (jobs.length === total) break;
        require3(result.jobs.length === 100);
        if (page === 10) deny();
      }
      require3(Array.isArray(v.requiredJobs) && v.requiredJobs.length > 0);
      for (const name of v.requiredJobs) {
        const matches2 = jobs.filter((j) => j.name === name);
        require3(matches2.length === 1 && matches2[0].status === "completed" && matches2[0].conclusion === "success" && matches2[0].head_sha === s.commitSHA);
      }
      const expected = { schema: "workflow-depot-build-provenance/v1", repository: s.repository, repositoryID: s.repositoryID, sourceSHA: s.commitSHA, sourceRef: receipt.shadowRef, artifactDigest: op.artifactDigest, metadataDigest: op.metadataDigest, runID: s.ciRunID, runAttempt: s.ciRunAttempt, workflowRef: v.ciWorkflowRef, workflowSHA: v.ciWorkflowSHA };
      require3(await digest(build) === await digest(expected));
      require3((await read("/git/ref/heads/main")).object?.sha === s.commitSHA);
      return { verified: true, operationID: op.operationID, artifactDigest: op.artifactDigest, sourceSHA: s.commitSHA };
    } catch {
      deny();
    }
  } };
}
function githubEvidenceReader({ fetcher = fetch, token } = {}) {
  async function request(repository2, path, raw = false) {
    if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repository2)) deny();
    const response = await fetcher(`https://api.github.com/repos/${repository2}${path}`, { redirect: "error", signal: AbortSignal.timeout(1e4), headers: { Accept: raw ? "application/vnd.github.raw+json" : "application/vnd.github+json", "X-GitHub-Api-Version": "2026-03-10", "User-Agent": "workflow-depot-evidence", ...token ? { Authorization: `Bearer ${token}` } : {} } });
    if (!response.ok) {
      await response.body?.cancel();
      deny();
    }
    const reader = response.body?.getReader();
    if (!reader) deny();
    const chunks = [];
    let size = 0;
    try {
      for (; ; ) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.length;
        if (size > (raw ? 32768 : 512 * 1024)) {
          await reader.cancel();
          deny();
        }
        chunks.push(value);
      }
    } finally {
      reader.releaseLock();
    }
    const bytes = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, offset);
      offset += chunk.length;
    }
    const text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    return raw ? text : JSON.parse(text);
  }
  return { async read(repository2, path) {
    if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repository2) || !(path === "" || /^\/(?:git\/ref\/heads\/(?:main|promotion\/[1-9][0-9]*\/shadow)|git\/commits\/[a-f0-9]{40}|actions\/runs\/[1-9][0-9]*(?:\/attempts\/[1-9][0-9]*\/jobs\?per_page=100&page=[1-9][0-9]*)?)$/.test(path))) deny();
    return request(repository2, path);
  }, async readWorkflow(repository2, commitSHA) {
    if (!sha2.test(commitSHA)) deny();
    return request(repository2, "/contents/.github/workflows/build.yml?ref=" + commitSHA, true);
  } };
}

// src/deployment-evidence-worker.mjs
var deployment_evidence_worker_default = { fetch() {
  return new Response("Not found", { status: 404 });
} };
var DeploymentEvidence = class extends WorkerEntrypoint {
  async verify(operation) {
    try {
      if (this.env.EVIDENCE_ENABLED !== "true" || typeof this.env.DEPLOYMENT_POLICY_JSON !== "string" || this.env.DEPLOYMENT_POLICY_JSON.length > 65536) throw Error();
      const policy = validatePolicy(JSON.parse(this.env.DEPLOYMENT_POLICY_JSON));
      await validateOperation(operation, policy, Math.floor(Date.now() / 1e3));
      return await deploymentEvidence({ policy, github: githubEvidenceReader({ token: this.env.GITHUB_READ_TOKEN }), signingReceipts: this.env.SIGNING_RECEIPTS, provenance: this.env.BUILD_PROVENANCE }).verify(operation);
    } catch {
      throw Error("Deployment evidence denied");
    }
  }
};
export {
  DeploymentEvidence,
  deployment_evidence_worker_default as default
};
