// Local artifact preparation only. This program never makes network requests.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
const require = createRequire(import.meta.url);
const esbuild = require('/workspace/personal-control/node_modules/esbuild/lib/main.js');
const root = '/workspace/artifacts/central-bootstrap';
const account = '1a799c6e699d2ef7e87398692ce3ad7b';
const zone = 'c6870f3a4dc8dc31f8331531ac91f888';
const bucket = 'workflow-depot-artifacts';
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const encode = value => Buffer.from(JSON.stringify(value, null, 2) + '\n');
const assert = (value, reason) => { if (!value) throw Error(reason); };
async function write(relative, bytes) {
  const target = path.join(root, relative);
  assert(target.startsWith(root + '/'), 'Artifact path escaped root');
  await fs.mkdir(path.dirname(target), { recursive: true });
  await fs.writeFile(target, bytes);
  return { path: relative, bytes: bytes.length, sha256: sha(bytes) };
}
const targets = [
  { repo: '/workspace/workflow_depot', alias: 'workflow_depot', config: 'deployment/wrangler.provenance.jsonc', flag: 'ENABLED', domain: 'builds.vespoli.me', routes: ['/v1/artifacts', '/v1/candidates/verify'] },
  { repo: '/workspace/workflow_depot', alias: 'workflow_depot', config: 'deployment/wrangler.evidence.jsonc', flag: 'EVIDENCE_ENABLED', domain: null, routes: [] },
  { repo: '/workspace/workflow_depot', alias: 'workflow_depot', config: 'deployment/wrangler.authority.jsonc', flag: 'ENABLED', domain: 'pipeline.vespoli.me', routes: ['/v1/deployments/authorize', '/v1/deployments/status', '/v1/deployments/revoke'] },
  { repo: '/workspace/worktrees/delivery_control-pipeline', alias: 'delivery_control', config: 'deployment/wrangler.deployer.jsonc', flag: 'DEPLOYER_ENABLED', domain: 'deploy.vespoli.me', routes: ['/v1/deployments/execute'] },
];
const inventoryPaths = [
  '/workspace/artifacts/cloudflare-activation-inventory-20261012.json',
  '/workspace/artifacts/cloudflare-exposure-activation-config-20261012.json',
];
const inventoryBytes = await fs.readFile(inventoryPaths[0]);
const inventory = JSON.parse(inventoryBytes);
assert(inventory.accountId === account, 'Inventory account mismatch');
const existing = kind => inventory.inventory.find(v => v.kind === kind);
for (const kind of ['scripts', 'domains', 'zones', 'do', 'r2']) assert(existing(kind)?.success === true && existing(kind)?.status === 200, 'Inventory incomplete: ' + kind);
assert(existing('zones').rows.some(z => z.id === zone && z.name === 'vespoli.me'), 'Zone not verified');
assert(!existing('r2').rows.some(b => b.name === bucket), 'Bucket already exists; review required');
const captured = new Map();
const outputs = [];
const buildOptions = { bundle: true, format: 'esm', platform: 'browser', target: 'es2022', external: ['cloudflare:workers'], sourcemap: false, minify: false, legalComments: 'none', treeShaking: true, charset: 'utf8', metafile: true, write: false, logLevel: 'silent' };
for (const target of targets) {
  const configPath = path.join(target.repo, target.config);
  const configBytes = await fs.readFile(configPath);
  // These four source files use only standalone // comment lines, no JSON5.
  const config = JSON.parse(configBytes.toString('utf8').replace(/^\s*\/\/.*$/gm, ''));
  captured.set(configPath, { bytes: configBytes, alias: target.alias, repo: target.repo });
  assert(config.vars[target.flag] === 'false', 'Runtime flag must remain false');
  const policy = JSON.parse(config.vars.DEPLOYMENT_POLICY_JSON);
  assert(policy.enabled === false && policy.targets.length === 0, 'Bootstrap policy must be disabled and empty');
  assert(config.workers_dev === false && config.preview_urls === false && !(config.routes?.length), 'Source has an unapproved public exposure');
  assert(!existing('scripts').rows.some(s => s.id === config.name), 'Script already exists; review required');
  assert(!target.domain || !existing('domains').rows.some(d => d.hostname === target.domain), 'Domain already exists; review required');
  const main = path.relative(target.repo, path.resolve(path.dirname(configPath), config.main));
  assert(main.startsWith('src/'), 'Entrypoint outside approved source tree');
  const result = await esbuild.build({ ...buildOptions, absWorkingDir: target.repo, entryPoints: [main], outfile: 'worker.mjs', plugins: [{
    name: 'snapshot-exact-inputs', setup(build) {
      build.onLoad({ filter: /\.(mjs|js|json)$/ }, async args => {
        assert(args.path.startsWith(target.repo + '/src/'), 'Unexpected imported source: ' + args.path);
        const bytes = await fs.readFile(args.path);
        const previous = captured.get(args.path);
        assert(!previous || sha(previous.bytes) === sha(bytes), 'Source changed between builds: ' + args.path);
        captured.set(args.path, { bytes, alias: target.alias, repo: target.repo });
        return { contents: bytes, loader: args.path.endsWith('.json') ? 'json' : 'js' };
      });
    },
  }] });
  assert(result.errors.length === 0 && result.warnings.length === 0, 'Build diagnostics must be reviewed');
  assert(result.outputFiles.length === 1, 'Expected exactly one module');
  const info = Object.values(result.metafile.outputs)[0];
  assert(info.imports.every(i => i.external && i.path === 'cloudflare:workers'), 'Unexpected external import');
  const bindings = Object.entries(config.vars).map(([name, text]) => ({ type: 'plain_text', name, text }));
  for (const b of config.durable_objects?.bindings ?? []) bindings.push({ type: 'durable_object_namespace', name: b.name, class_name: b.class_name });
  for (const b of config.r2_buckets ?? []) {
    assert(b.bucket_name === bucket, 'Unapproved bucket binding');
    bindings.push({ type: 'r2_bucket', name: b.binding, bucket_name: b.bucket_name });
  }
  for (const b of config.services ?? []) bindings.push({ type: 'service', name: b.binding, service: b.service, entrypoint: b.entrypoint });
  const metadata = { main_module: 'worker.mjs', compatibility_date: config.compatibility_date, bindings, observability: config.observability };
  if (config.migrations) {
    assert(config.migrations.length === 1 && config.migrations[0].tag === 'v1', 'Only initial v1 SQLite migration allowed');
    assert(Object.keys(config.migrations[0]).every(k => ['tag', 'new_sqlite_classes'].includes(k)), 'Unapproved migration');
    metadata.migrations = { new_tag: 'v1', new_sqlite_classes: config.migrations[0].new_sqlite_classes };
    for (const cls of metadata.migrations.new_sqlite_classes) assert(info.exports.includes(cls), 'DO class not exported: ' + cls);
  }
  const code = await write('workers/' + config.name + '/worker.mjs', result.outputFiles[0].contents);
  const uploadMetadata = await write('workers/' + config.name + '/metadata.json', encode(metadata));
  const metafile = await write('workers/' + config.name + '/esbuild-metafile.json', encode(result.metafile));
  outputs.push({ name: config.name, sourceRepository: target.repo, snapshotRepository: 'sources/' + target.alias, sourceConfig: configPath, snapshotConfig: 'sources/' + target.alias + '/' + target.config, entrypoint: main, runtimeEnableFlag: target.flag, runtimeEnabled: false, publicDomain: target.domain, publicPaths: target.routes, exports: info.exports, code, uploadMetadata, metafile, migration: metadata.migrations ?? null, bindingNames: bindings.map(b => b.name), sourceInputs: Object.keys(result.metafile.inputs).sort().map(p => 'sources/' + target.alias + '/' + p) });
}
const workerNames = outputs.map(o => o.name);
for (const out of outputs) {
  const metadata = JSON.parse(await fs.readFile(path.join(root, out.uploadMetadata.path)));
  for (const b of metadata.bindings.filter(b => b.type === 'service')) {
    const service = outputs.find(o => o.name === b.service);
    assert(service && service.exports.includes(b.entrypoint), 'Service entrypoint missing');
    assert(outputs.indexOf(service) < outputs.indexOf(out), 'Service upload dependency not ordered');
  }
}
const sources = [];
for (const [originalPath, input] of [...captured].sort(([a], [b]) => a.localeCompare(b))) {
  assert(sha(await fs.readFile(originalPath)) === sha(input.bytes), 'Source changed during snapshot: ' + originalPath);
  const file = await write('sources/' + input.alias + '/' + path.relative(input.repo, originalPath), input.bytes);
  sources.push({ originalPath, ...file });
}
const evidence = [];
for (const file of inventoryPaths) {
  const bytes = await fs.readFile(file);
  const parsed = JSON.parse(bytes);
  evidence.push({ originalPath: file, recordedAt: parsed.recordedAt, ...await write('evidence/' + path.basename(file), bytes) });
}
const repoState = [];
for (const repo of [...new Set(targets.map(t => t.repo))]) {
  repoState.push({ path: repo, head: execFileSync('git', ['-C', repo, 'rev-parse', 'HEAD'], { encoding: 'utf8' }).trim(), acceptedImmutableRevision: null, note: 'HEAD is recorded context only; this artifact includes uncommitted source and is identified by file digests.' });
}
const manifest = { schema: 'central-bootstrap-artifacts/v1', preparedAt: new Date().toISOString(), scope: 'local-only inert bootstrap; not applied', accountId: account, zoneId: zone, remoteActionsExecuted: false, approval: 'pending', buildTool: { name: 'esbuild', version: esbuild.version, modulePath: '/workspace/personal-control/node_modules/esbuild/lib/main.js', nodeVersion: process.version, options: buildOptions }, sourceDriftChecked: true, repositoryContext: repoState, evidence, workers: outputs, sourceFiles: sources };
const manifestFile = await write('manifest.json', encode(manifest));
const actions = [];
function action(id, method, endpoint, content, dependsOn = []) { actions.push({ order: actions.length + 1, id, method, endpoint, dependsOn, ...content }); }
action('create-private-artifact-bucket', 'POST', `/accounts/${account}/r2/buckets`, { body: { name: bucket }, preconditions: ['Bucket name absent in fresh inventory; stop on collision'], expected: { publicAccess: false, note: 'No public-domain enablement, object upload, retention, lifecycle, CORS, or credentials are part of this action.' } });
for (const out of outputs) {
  const m = JSON.parse(await fs.readFile(path.join(root, out.uploadMetadata.path)));
  const needs = m.bindings.filter(b => b.type === 'service').map(b => 'disable-public-preview-' + b.service);
  if (m.bindings.some(b => b.type === 'r2_bucket')) needs.push('create-private-artifact-bucket');
  action('upload-' + out.name, 'PUT', `/accounts/${account}/workers/scripts/${out.name}`, { contentType: 'multipart/form-data', multipart: [{ name: 'metadata', contentType: 'application/json', ...out.uploadMetadata }, { name: 'worker.mjs', filename: 'worker.mjs', contentType: 'application/javascript+module', ...out.code }], preconditions: ['Worker name absent immediately before initial upload; do not overwrite an existing Worker'], expected: { runtimeEnabled: false, createdSQLiteClasses: out.migration?.new_sqlite_classes ?? [] } }, needs);
  action('disable-public-preview-' + out.name, 'POST', `/accounts/${account}/workers/scripts/${out.name}/subdomain`, { body: { enabled: false, previews_enabled: false }, expected: { enabled: false, previews_enabled: false } }, ['upload-' + out.name]);
}
for (const out of outputs.filter(o => o.publicDomain)) action('attach-' + out.publicDomain, 'PUT', `/accounts/${account}/workers/domains`, { body: { hostname: out.publicDomain, service: out.name, zone_id: zone, enabled: true, previews_enabled: false }, preconditions: ['Root must independently verify hostname, DNS, route, and custom-domain collisions immediately before attach'], expected: { hostname: out.publicDomain, service: out.name, enabled: true, previews_enabled: false, note: 'Hostname routes to an application that remains disabled; this is not application activation.' } }, workerNames.map(name => 'disable-public-preview-' + name));
const plan = {
  schema: 'central-bootstrap-api-plan/v1', preparedAt: manifest.preparedAt, approval: 'pending', applied: false, applyReady: false,
  apiBase: 'https://api.cloudflare.com/client/v4', accountId: account, zoneId: zone, artifactManifest: manifestFile,
  scope: { workers: workerNames, privateBucket: bucket, sqliteMigrations: outputs.filter(o => o.migration).map(o => ({ worker: o.name, ...o.migration })), customDomains: outputs.filter(o => o.publicDomain).map(o => ({ hostname: o.publicDomain, worker: o.name })), secretBindings: [], exclusions: ['Existing Workers and namespaces', 'Access applications or policies', 'Cron schedules', 'R2 retention or lifecycle rules', 'Build or GitHub triggers', 'Credential creation or binding', 'Runtime enablement', 'Source publication', 'Unrelated resources'] },
  prerequisites: [
    'Explicit owner approval for these exact artifact digests and ordered actions; pending at preparation time.',
    'Root fresh collision checks for the four Worker names, three hostnames, bucket, and account/zone ownership.',
    'Authenticated connector capability for the approved write endpoints; read success does not prove write permission.',
    'Verify every bundled and metadata digest immediately before upload. Source edits require a fresh snapshot and review.',
    'Sequential actions only. Stop on any unexpected response; reconcile completed action IDs before resuming. Do not rerun an initial migration or overwrite a collision.',
  ],
  actions,
  verification: [
    ...outputs.flatMap(o => [
      { method: 'GET', endpoint: `/accounts/${account}/workers/scripts/${o.name}/settings`, assert: { exactMetadata: o.uploadMetadata, noSecretBindings: true, runtimeEnabled: false } },
      { method: 'GET', endpoint: `/accounts/${account}/workers/scripts/${o.name}/subdomain`, assert: { enabled: false, previews_enabled: false } },
      { method: 'GET', endpoint: `/accounts/${account}/workers/scripts/${o.name}/schedules`, assert: { schedules: [] } },
    ]),
    { method: 'GET', endpoint: `/accounts/${account}/workers/durable_objects/namespaces`, assert: { newSQLiteNamespaces: outputs.filter(o => o.migration).map(o => ({ script: o.name, class: o.migration.new_sqlite_classes[0] })), existingNamespacesUnchanged: true } },
    { method: 'GET', endpoint: `/accounts/${account}/workers/domains`, assert: { exactNewDomains: outputs.filter(o => o.publicDomain).map(o => ({ hostname: o.publicDomain, service: o.name, zone_id: zone, enabled: true, previews_enabled: false })), existingDomainsUnchanged: true, evidenceWorkerHasNoDomain: true } },
    { method: 'GET', endpoint: `/accounts/${account}/r2/buckets/${bucket}/domains/managed`, assert: { enabled: false } },
    { method: 'GET', endpoint: `/accounts/${account}/r2/buckets/${bucket}/domains/custom`, assert: { domains: [] } },
  ],
  futureActivationOnly: { credentialReferences: [{ worker: 'delivery-control-cloudflare-deployer', binding: 'CLOUDFLARE_API_TOKEN', boundNow: false }], missingPrivateServices: ['SOURCE_CANDIDATES', 'SIGNING_RECEIPTS'], identityPins: 'Actual accepted immutable caller workflow and job-workflow SHAs plus enabled exact target policy remain separate activation gates.' },
  references: [
    'https://developers.cloudflare.com/api/resources/workers/subresources/scripts/methods/update/',
    'https://developers.cloudflare.com/api/resources/workers/subresources/scripts/subresources/subdomain/methods/create/',
    'https://developers.cloudflare.com/api/resources/workers/subresources/domains/methods/update/',
    'https://developers.cloudflare.com/api/resources/r2/subresources/buckets/methods/create/',
    'https://developers.cloudflare.com/r2/buckets/public-buckets/',
  ],
};
const planFile = await write('api-actions.json', encode(plan));
await write('digests.json', encode({ schema: 'central-bootstrap-digests/v1', manifest: manifestFile, apiActions: planFile, workers: outputs.map(o => ({ name: o.name, code: o.code, metadata: o.uploadMetadata })) }));
console.log(JSON.stringify({ prepared: true, remoteActionsExecuted: false, output: root, sourceFiles: sources.length, workers: outputs.map(o => ({ name: o.name, codeSHA256: o.code.sha256, metadataSHA256: o.uploadMetadata.sha256 })), manifestSHA256: manifestFile.sha256, apiActionsSHA256: planFile.sha256 }, null, 2));
