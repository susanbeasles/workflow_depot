# Central bootstrap review package

Prepared locally on 2026-10-12. No Cloudflare mutation, upload, credential binding, source publication, or application activation has occurred. Owner approval is pending.

The account is `1a799c6e699d2ef7e87398692ce3ad7b`; the existing `vespoli.me` zone is `c6870f3a4dc8dc31f8331531ac91f888`. Copied read-only inventories in `evidence/` record the source of those IDs and the resources to preserve.

| New Worker | New SQLite Durable Object | Proposed domain | Runtime flag |
| --- | --- | --- | --- |
| workflow-depot-build-provenance | BUILD_PROVENANCE_STATE / BuildProvenanceState | builds.vespoli.me | ENABLED=false |
| workflow-depot-deployment-evidence | None | None; private service only | EVIDENCE_ENABLED=false |
| workflow-depot-deployment-authority | DEPLOYMENT_STATE / DeploymentAuthorityState | pipeline.vespoli.me | ENABLED=false |
| delivery-control-cloudflare-deployer | DEPLOYMENT_JOBS / DeploymentJob | deploy.vespoli.me | DEPLOYER_ENABLED=false |

The new private R2 bucket is `workflow-depot-artifacts`, bound only to provenance and the deployer as `DEPLOYMENT_ARTIFACTS`. Evidence binds `BUILD_PROVENANCE` to `BuildProvenance`; authority binds `DEPLOYMENT_EVIDENCE` to `DeploymentEvidence`; deployer binds `DEPLOYMENT_AUTHORITY` to `DeploymentAuthority`. No source-signing service names were invented. `SOURCE_CANDIDATES` and `SIGNING_RECEIPTS` remain unbound activation dependencies.

`api-actions.json` is the concrete declarative API plan, with exact methods, endpoints, JSON bodies, multipart parts, checksums, dependencies, and read-only postconditions. Its 12 ordered mutation proposals create the bucket, upload the four Workers (including the three initial `v1` SQLite migrations), disable each Worker's workers.dev and preview exposure, and finally attach the three custom domains. Custom-domain routing is enabled to otherwise disabled application handlers; domain creation is not application activation. There is no evidence Worker domain. No command in this package executes those API actions.

`manifest.json` identifies all four bundle and metadata hashes, the complete 18-file source/config snapshot, exported entrypoints, repository context, and input inventory hashes. `digests.json` is the compact exact-digest review record. `sources/` contains the actual inputs; their recorded repository HEAD values are context, not accepted immutable revisions for uncommitted source.

`verification.json` records four byte-identical snapshot rebuilds and local workerd checks: six public operations return 503, four unknown routes return 404, all three Durable Objects return 503, and the three private entrypoints deny requests. All outbound requests are trapped; the observed count was zero. `schema-verification.json` records successful source validation against the installed official Wrangler schema and explicit upload-field checks against current official API documentation. An initial local harness mismatch was resolved using the installed Miniflare `convertV4MiniflareOptions` adapter; no Worker source change was needed.

To repeat local verification:

```sh
node /workspace/artifacts/central-bootstrap/verify-local.mjs
```

`prepare.mjs` is a local-only artifact builder. Re-running it changes the preparation timestamp and document hashes, so any replacement package needs renewed digest review. The verifier fails on source drift or modified snapshot/bundle/metadata bytes.

Remote execution still requires approval of these exact digests, fresh collision checks by the parent, and authorization for the listed write endpoints. Successful read access does not establish write access. Stop on unexpected responses and reconcile completed action IDs before resuming; do not overwrite pre-existing resources or replay an initial migration indiscriminately. workers.dev suppression is a separate post-upload API step; all code gates remain disabled throughout that sequence.

The bootstrap binds **no secrets**. `CLOUDFLARE_API_TOKEN` appears only as a future deployer binding reference, never a bound value. GitHub read credentials, accepted workflow/job-workflow SHA pins, actual source-authority runtime composition, reviewed exact target policy, and runtime enablement belong to a later commissioning decision. Existing resources, Access, schedules, R2 retention/lifecycle, build triggers, and unrelated resources are outside this package.

API shapes were checked against the official [Worker upload](https://developers.cloudflare.com/api/resources/workers/subresources/scripts/methods/update/), [workers.dev settings](https://developers.cloudflare.com/api/resources/workers/subresources/scripts/subresources/subdomain/methods/create/), [custom domains](https://developers.cloudflare.com/api/resources/workers/subresources/domains/methods/update/), and [R2 creation](https://developers.cloudflare.com/api/resources/r2/subresources/buckets/methods/create/) references. R2 buckets begin private unless explicitly made public, per the [R2 public bucket documentation](https://developers.cloudflare.com/r2/buckets/public-buckets/).
