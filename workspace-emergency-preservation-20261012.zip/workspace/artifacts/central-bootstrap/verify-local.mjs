// Verify the prepared artifacts locally; this file is never uploaded.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const esbuild=require('/workspace/personal-control/node_modules/esbuild/lib/main.js');
const {Miniflare,convertV4MiniflareOptions}=require('/workspace/personal-control/node_modules/miniflare/dist/src/index.js');
const root='/workspace/artifacts/central-bootstrap';
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const readJSON=async file=>JSON.parse(await fs.readFile(path.join(root,file),'utf8'));
const manifest=await readJSON('manifest.json');
const digests=await readJSON('digests.json');
for(const item of [digests.manifest,digests.apiActions,...manifest.sourceFiles,...manifest.evidence,...manifest.workers.flatMap(w=>[w.code,w.uploadMetadata,w.metafile])]) {
 const bytes=await fs.readFile(path.join(root,item.path));
 assert.equal(sha(bytes),item.sha256,`Digest mismatch: ${item.path}`);
 assert.equal(bytes.length,item.bytes,`Size mismatch: ${item.path}`);
}
for(const source of manifest.sourceFiles)assert.equal(sha(await fs.readFile(source.originalPath)),source.sha256,`Source drift: ${source.originalPath}`);
for(const worker of manifest.workers){
 const rebuilt=await esbuild.build({...manifest.buildTool.options,absWorkingDir:path.join(root,worker.snapshotRepository),entryPoints:[worker.entrypoint],outfile:'worker.mjs'});
 assert.equal(rebuilt.outputFiles.length,1);
 assert.equal(sha(rebuilt.outputFiles[0].contents),worker.code.sha256,`Snapshot rebuild differs: ${worker.name}`);
 assert.equal(rebuilt.warnings.length,0);
}
let outboundRequests=0;
const denyOutbound=async()=>{outboundRequests++;throw Error('No outbound network allowed in disabled bootstrap verification');};
const workers=[];
for(const worker of manifest.workers){
 const metadata=await readJSON(worker.uploadMetadata.path);
 assert(metadata.bindings.every(b=>['plain_text','durable_object_namespace','r2_bucket','service'].includes(b.type)));
 const config={name:worker.name,modules:true,scriptPath:path.join(root,worker.code.path),compatibilityDate:metadata.compatibility_date,bindings:{},durableObjects:{},r2Buckets:{},serviceBindings:{},outboundService:denyOutbound};
 for(const b of metadata.bindings){
  if(b.type==='plain_text')config.bindings[b.name]=b.text;
  if(b.type==='durable_object_namespace')config.durableObjects[b.name]={className:b.class_name,useSQLite:true};
  if(b.type==='r2_bucket')config.r2Buckets[b.name]=b.bucket_name;
  if(b.type==='service')config.serviceBindings[b.name]={name:b.service,entrypoint:b.entrypoint};
 }
 assert.equal(config.bindings[worker.runtimeEnableFlag],'false');
 assert.equal(JSON.parse(config.bindings.DEPLOYMENT_POLICY_JSON).enabled,false);
 assert.deepEqual(JSON.parse(config.bindings.DEPLOYMENT_POLICY_JSON).targets,[]);
 workers.push(config);
}
workers.push({name:'local-verification-only',modules:true,compatibilityDate:'2026-10-08',outboundService:denyOutbound,serviceBindings:{
 PROVENANCE:{name:'workflow-depot-build-provenance',entrypoint:'BuildProvenance'},
 EVIDENCE:{name:'workflow-depot-deployment-evidence',entrypoint:'DeploymentEvidence'},
 AUTHORITY:{name:'workflow-depot-deployment-authority',entrypoint:'DeploymentAuthority'},
},script:`export default {async fetch(request,env){
 const result={};
 try{await env.PROVENANCE.lookup({});result.provenance='unexpected-success';}catch{result.provenance='denied';}
 try{await env.EVIDENCE.verify({});result.evidence='unexpected-success';}catch{result.evidence='denied';}
 result.authority=(await env.AUTHORITY.fetch(new Request('https://local.invalid/v1/deployments/consume',{method:'POST',headers:{'content-type':'application/json'},body:'{}'}))).status;
 return Response.json(result);
}}`});
const mf=new Miniflare(convertV4MiniflareOptions({workers,cf:false}));
const checks=[];
try{
 for(const worker of manifest.workers){
  const fetcher=await mf.getWorker(worker.name);
  for(const route of worker.publicPaths){
   const response=await fetcher.fetch('https://local.invalid'+route,{method:'POST',headers:{'content-type':'application/json'},body:'{}'});
   assert.equal(response.status,503,`${worker.name} ${route} must remain disabled`);
   checks.push({worker:worker.name,route,method:'POST',status:response.status});
   await response.arrayBuffer();
  }
  const response=await fetcher.fetch('https://local.invalid/unapproved-path');
  assert.equal(response.status,404);
  checks.push({worker:worker.name,route:'/unapproved-path',method:'GET',status:response.status});
  await response.arrayBuffer();
 }
 for(const [name,binding,route] of [
  ['workflow-depot-build-provenance','BUILD_PROVENANCE_STATE','/v1/artifacts'],
  ['workflow-depot-deployment-authority','DEPLOYMENT_STATE','/v1/deployments/authorize'],
  ['delivery-control-cloudflare-deployer','DEPLOYMENT_JOBS','/v1/deployments/execute'],
 ]){
  const ns=await mf.getDurableObjectNamespace(binding,name);
  const response=await ns.get(ns.idFromName('local-bootstrap-verification')).fetch('https://local.invalid'+route,{method:'POST',headers:{'content-type':'application/json'},body:'{}'});
  assert.equal(response.status,503);
  checks.push({worker:name,durableObjectBinding:binding,status:response.status});
  await response.arrayBuffer();
 }
 const privateResults=await (await (await mf.getWorker('local-verification-only')).fetch('https://local.invalid/')).json();
 assert.deepEqual(privateResults,{provenance:'denied',evidence:'denied',authority:503});
 checks.push({privateEntrypoints:privateResults});
 assert.equal(outboundRequests,0);
 const report={schema:'central-bootstrap-local-verification/v1',verifiedAt:new Date().toISOString(),success:true,manifestSHA256:digests.manifest.sha256,apiActionsSHA256:digests.apiActions.sha256,digestsVerified:true,sourceDrift:false,reproducibleSnapshotBuilds:4,metadataHasNoSecretBindings:true,disabledRuntimeChecks:checks,outboundRequests,cloudflareRequests:0,limitations:['Local simulation does not establish Cloudflare write permission, remote upload acceptance, endpoint collision status, or deployed runtime state.','Owner approval and fresh remote collision checks remain pending.']};
 await fs.writeFile(path.join(root,'verification.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify(report,null,2));
}finally{await mf.dispose();}
