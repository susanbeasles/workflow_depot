# Cloudflare signer: protocol feasibility and commissioning boundary

Status: independent source review, 2026-10-12. No signing, credential access, provider mutation, deployment, or source upload was performed. This document supersedes the earlier proposed source-local signer route: the signer must be standalone on Cloudflare; `workflow_depot` remains the policy authority.

## Decision

A metadata-only remote signing protocol is feasible. It is not yet an executable, commissioned route for the seven unpublished local trees. The missing fact is independently trustworthy evidence that each claimed tree and parent belong to the exact eligible source generation. A tree hash, unsigned commit payload, or self-reported `complete: true` cannot supply that evidence.

Automatic feature eligibility is already the requested policy. Do not introduce a per-feature owner approval prompt, a local signer, or a second signing authorizer. A producer/attestor may report observations; only depot decides eligibility.

## Exact signing contract

1. The request identifies the numeric repository, exact allowed feature ref, expected parent, tree, author, committer, message, producer evidence reference, request nonce, and expiry. Repository identity and signer selection come from depot's installed policy, not the request. Reconstruct the complete unsigned commit bytes from strictly validated fields; reject unexpected headers, extra parents, NULs, oversized input, and noncanonical or mismatched bytes.
2. Depot verifies the producer evidence, repository/owner identity, current expected parent/ref state, identity policy, complete source custody evidence, current policy revision, and pinned signing key. It retains a short-lived eligibility grant bound to the full request, exact unsigned payload SHA256, evidence digest, repository/ref/parent/tree, key ID and one-use reservation. The grant is an automatic policy result, not a caller approval boolean.
3. The Cloudflare signer verifies that retained depot grant through its private capability, checks the exact bytes and all bindings, and atomically consumes the signing reservation before key access. Recheck policy/expiry immediately before effects. Ambiguous signing remains consumed and is not automatically retried.
4. Sign the **exact complete unsigned Git commit payload bytes** using the installed SSH signer in namespace `git`. SHA256 is an authorization binding; signing the naked SHA256 value would not produce the required Git signature. The existing runtime already passes the payload itself to `ssh-keygen -Y sign -U -n git`.
5. Return only bounded signature/retained signed-commit metadata and its authenticated receipt. The local Git publisher verifies the pinned key and exact payload, assembles the signed commit, recomputes its final Git object ID, confirms parent/tree closure, and publishes through the existing authorized normal Git transport. No source blob/tree/archive RPC is introduced.
6. Promotion candidate signing remains distinct from initial feature signing. Paired annotated tags require their exact complete tag bytes, retained candidate/source crosslinks, and the existing later detached owner hardware approval plus required checks. Do not make the initial automatic feature grant a tag or main-update grant.

Source anchors: `signing-control-staging/src/service/feature.mjs`, `src/service/authorization.mjs`, and `runtime/op-git-signer.mjs:58-77`.

## Why current provenance cannot authorize the first signature

`workflow_depot/src/deployment-provenance.mjs:19-27` requires an already published signed candidate S, an existing immutable shadow ref, a source PR, and `SOURCE_CANDIDATES.lookupCandidate`. Both candidate admission and build provenance use that check. Using either to obtain the first signature would be circular.

`workflow_depot/src/shared/oidc.mjs:18-34` is a reusable real authentication primitive: it verifies GitHub-issued JWTs, an audience bound to the request digest, exact repository/owner/workflow revisions, github-hosted runner, run/attempt, actor and expiry. It does **not** authenticate this local workspace. A real pinned GitHub job could be an attestor only if it independently possessed and inspected the exact source tree through an allowed custody route. Dispatching a workflow with a caller-supplied tree hash does not achieve that.

The current signer exposes `SOURCE_POLICY.authorizeFeatureCommit` as an injected interface, but no production depot implementation or commissioned initial-source producer was found in the inspected sources. The current `prepareFeature` implementation instead calls a fixed local tree verifier inside the signer. That must be replaced by genuinely verified depot evidence for the Cloudflare-only architecture, not by a success stub.

## Existing trust identities: reuse limits

| Existing identity/capability | Can establish initial local tree provenance now? |
| --- | --- |
| Pinned GitHub OIDC verifier | No local-workspace identity. Reusable for a real trusted producer job that actually observes the tree. |
| Existing Git publication authorization | Authorizes Git publication; no exposed signed producer attestation or depot request authentication was demonstrated. Do not reinterpret it as tree proof. |
| Owner hardware approval | Existing later promotion authority; using it for every initial feature request would add the explicitly rejected manual gate. |
| Cloudflare OAuth deployment access | Provider administration only; not a runtime producer or source-policy capability. |
| GitHub connector access/browser login | Useful for verified public account/repository/key metadata; not a runtime tree attestation protocol. |
| Proposed automated Git signing key | Output-signature identity; cannot establish its own input eligibility. |

No already commissioned identity in the inspected implementation can attest the seven unpublished local trees under this protocol today. This is a statement about the available implementation/evidence, not a claim that no suitable organizational platform exists elsewhere.

## Producer commissioning without a competing authority

Register one producer profile in **depot-owned policy**, once, through the existing owner configuration authority. Pin the real authentication mechanism, producer identity, reviewed collector/runtime revision, allowed repositories/refs and identity constraints, evidence schema, freshness, replay policy, and revocation. Its evidence must bind repository ID, exact parent/tree, complete closure digest, canonical commit-payload digest and the execution that actually observed those bytes.

The producer only attests those observations. Depot independently verifies the authenticated evidence and applies eligibility; the signer consumes depot's result. Subsequent qualifying feature requests are automatic.

There are only two sound evidence routes within the stated boundaries: an independently authenticated approved producer that actually observes the unpublished local tree, or independent access to its real objects through normal Git. Neither route is currently commissioned. Do not solve this by uploading source blobs/archives through an RPC/artifact API, publishing an unsigned transport commit, or accepting a caller-selected attestor key. Selecting/registering a new producer trust mechanism requires its own concrete commissioning decision; no new credential is approved by this review.

## Minimal Cloudflare commissioning plan

**Source work that can proceed fail closed:** implement the strict metadata contract, a depot-owned feature eligibility verifier with a required producer-evidence capability, one-use grant/state checks, remote signer consumption, and signature verification/assembly tests. Keep missing producer evidence an explicit denial. Make capability requirements action-specific: initial feature signing does not require promotion CI/review/hardware/tag capabilities, and may not fabricate those capabilities to pass a blanket readiness check.

**Public configuration to collect and bind:** exact target repository IDs, existing allowed refs/parents, accepted depot policy digest, actual producer registration, existing SSH public key/fingerprint and public GitHub signing-key registration, exact immutable 1Password vault/item/field references, approved op origins, executable/image digests, Cloudflare account and reviewed private service identities. The item name is **`gh-signing-key`**. Vault placement is interchangeable configuration; do not require a new named vault or service account merely because an earlier proposal suggested one.

**Minimum live capability relationships:** depot's admitted signing action privately invokes `signing-control`; the signer privately resolves/consumes depot eligibility; signer Durable Object state retains reservations/receipts; an isolated Container receives its authorized op token only through the existing private handoff. For initial metadata-only signing, a GitHub read capability can remain on depot for parent/repository checks; signer Git source downloads and a promotion-history mount are not necessary to that action. Existing later pipeline candidate/receipt readers remain separate capabilities.

**Still requires express setup authorization:** any key generation/import, public-key registration mutation, service-account/token creation or scope change, secret installation, new private bindings/resources, image deployment, or activation. None is newly approved here. Reuse an existing suitable item and runtime credential only after exact scope and custody verification; never reuse a broader credential by assumption. Qualify the actual image, op/intercept CA path, egress restrictions, private handoff, deadlines, and container descendant destruction before activation.

Repository creation of `susanbeasles/signing_control` is separately parent-owned and already authorized, but it is not the missing source-tree proof. Its completion cannot commission the signer or satisfy the producer evidence gap. Full promotion scans/reviewer/tag/main gates remain later steps and should not be made prerequisites for this first automatic feature signature.

## Immediate next action

Proceed with the fail-closed depot/signing protocol source and synthetic composition tests. In parallel, identify the concrete existing execution platform capable of authenticated source observation, then prepare one depot producer-registration proposal for that real identity. If none is available, report that specific commissioning gap; do not describe the seven feature commits as publishable yet.

The seven recorded unsigned payload hashes and parent HEADs were independently checked. Their local Git closures are present and below the current 8 MiB limit. This establishes local readiness only, not authenticated remote provenance.
