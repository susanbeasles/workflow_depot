# Disposable credential provisioner: design for review

**Status:** Proposed design; not approved for implementation or live use.  
**Date:** 2026-10-12.  
**Initial providers:** Cloudflare and Backblaze B2, subject to browser-flow qualification.  
**Integration:** Existing personal-control gateway and repoctl authorization, enrollment, execution, and receipt components.  
**This deliverable:** A written design only. No implementation plan, code changes, deployments, credentials, vault changes, account changes, commits, or pushes are authorized by it.

## 1. Outcome and scope

An owner authorizes one exact job. A protected disposable remote environment logs in to the provider with account-login credentials from a dedicated read-only 1Password input vault and supported MFA. It creates or rotates the approved credential through the provider's authenticated flow, writes the result directly through the 1Password CLI to a separate output vault, optionally also delivers an encrypted copy to the selected KV destination, and terminates.

Issued runtime credentials remain valid after teardown. The job authorization, browser session, runner credentials, and issued runtime credential are different lifecycle objects.

The reusable engine is configuration-driven. A new provider ordinarily adds a reviewed declarative manifest, not a service. New authentication mechanisms or unsupported controls may require reviewed engine changes. Initial issuance does **not** require the user to pre-create a privileged API issuer token on their local device. API issuance endpoints can be used only by a separately supported and explicitly approved flow; they do not replace the requested account-login bootstrap.

Three stages:

1. **Authorizer:** authenticated, hardware-signed request; server nonce; final proof and payload; permanent single-use admission; durable dispatch.
2. **Provisioner:** fixed remote browser and `op` runtime; approved provider mutation; confirmed secret delivery; reconciliation and cleanup.
3. **Future mover:** separately authorized copy/move from output vault to a final destination. Stage 3 is a contract, not a feature to implement now.

No per-provider deployments or always-on execution fleet are needed. An independently governed authorizer, durable state/outbox, private ingress, launcher, and recovery path are still required; reuse existing infrastructure where it can meet these boundaries.

## 2. Threat model and trust roots

Local-device compromise is a **hypothetical design assumption**, not a finding. The baseline goal is practical reduction of reusable privileged-key exposure on the local device or in model-visible output. Hardware-backed approval increases resistance to unattended abuse; it is not proof that a compromised client accurately displayed transaction intent.

### 2.1 Trusted components

| Boundary | Required trust |
|---|---|
| Enrolled owner signing key | Cryptographic identity, supported hardware provenance, revocation, and agreed presence/verification policy. |
| Authorizer and accepted policy | Exact request binding, durable consumption, independent destination/scope enforcement, no self-asserted client trust. |
| Release authority and launcher | Pinned reviewed image/engine/manifest, fixed execution identity, no agent-controlled deployment or shell. |
| Runtime supervisor and secret helper | Correct isolation, restricted subprocess invocation, private capture and delivery, bounded output. |
| Provider and 1Password | Correct authentication, authorization, storage, and lifecycle behavior. |
| Optional KV unwrap authority | Keys and decrypt permission governed separately from ciphertext storage. |
| Recovery and audit authority | Durable evidence and strictly bounded recovery access. |

Provider passwords, sessions, generated values, TOTP seeds, and 1Password service tokens must not reach the model, local terminal, screenshots, clipboard, downloads, or raw browser stream. The current agent-accessible service-account token is outside the privileged boundary and must not be reused as its bootstrap identity.

A process that controls the privileged runtime, its deployment, or its identity can extract plaintext. Redaction, remote execution, hashing, and encryption at rest do not change this. Browser compromise can expose the provider credential being used inside that browser; separating the browser from the `op` helper limits access to other vault material, not to secrets already entered on the page. Host/cloud administrators remain trusted. No claim of an unsniffable channel, perfect zeroization, or protection against a fully compromised host is made.

An independently trusted display/device for transaction review is an optional stronger tier. It is not a mandatory prerequisite for the baseline, but fully compromised endpoints cannot securely establish all their own trust solely through themselves.

## 3. Existing code to reuse and proposed gaps

Paths below refer to inspected workspace source, not a claim of current deployed behavior.

| Component | Reuse | Proposed change or gap |
|---|---|---|
| `personal-control/src/gate.mjs`, `oauth.mjs`, `capabilities.mjs`, `owner-session.mjs` | Shared owner identity, capability registration, scoped sessions, existing interface. | Register provisioning capability; use the same accepted owner identity inventory. Add private transport and job-specific hardware proof. Do not build a second general control plane. |
| `personal-control/src/tools.mjs` and `worker.mjs` | Exact-operation plans, owner decision, expiry, audit, uncertain-outcome reporting. | Every provisioning job requires exact approval. Do not inherit the generic session's optional per-action approval setting. Implement the two-message protocol in section 6. |
| `personal-control/src/policy.mjs` | Existing generic-tool restrictions on credential export and token-management mutations. | Preserve restrictions. Provisioning is a narrow capability, not a new arbitrary API proxy. |
| `repoctl/controller/src/enrollment-authority/service.mjs` | Domain-separated signatures, trusted key lookup, hardware verifier, revocation, expiry, recovery-only renewals. | Existing intent binds GitHub owner/role/manifest. Add a new versioned provisioning protocol; do not reinterpret old signatures. Actual enrolled trust/hardware verification still needs qualification. |
| `repoctl/controller/src/provisioning/registration.mjs`, `enrollment/journal.mjs`, `enrollment/github.mjs` | Reviewed plan matching, single-use exchange reservation, staged recovery, fixed provider endpoints. | Browser host and authenticated operator transport are not implemented in this inspected registration path. No Cloudflare/B2 browser adapter found. |
| `repoctl/controller/src/runtime/state.mjs`, `runtime/coordinator.mjs` | Atomic reservation, durable replay state, cleanup/reconciliation. | Extend with provisioning-specific states/outbox. Never reuse GitHub promotion semantics implicitly. |
| `repoctl/controller/src/receipts/service.mjs` and checkpoint components | Signed, linked, idempotent receipts and independent evidence patterns. | Provisioning receipts need separate schema and evidence rules. Keep all secret values out. |
| `delivery_control/src/execute.mjs` | Fixed operation execution, no candidate code or arbitrary shell, bounded transport, sanitized failures. | Implement a pinned provisioning executor, not an extension accepting arbitrary commands. |
| `personal-control/workers/backup-control/src/worker.mjs` | Pinned machine identity and verified OIDC claims. | Reuse verification principles; its credential-returning endpoint is not the receipt-only provisioner API. |
| Existing credential vaults | Existing state and keys must remain intact. | New output custody uses `op`; no silent migration/export of existing DO secrets. |

The repoctl configurations inspected have rollout switches disabled. Its local tests and source establish useful patterns, not live provider qualification. Repository documentation records Cloudflare token-management and Git-integration failures; those observations are historical evidence, not retested account state.

## 4. Topology, private ingress, and deployment ownership

Use an owned hostname such as **`provisioner.vespoli.me`**, proposed and not deployed, reachable through WARP/private routing to a private authorizer endpoint. No public IP ingress, published application route, `workers.dev`, preview route, or alternate public origin may reach the authorizer. An unauthorized request gets a uniform minimal response; a public 404 is concealment only.

A public Cloudflare Access-protected Worker remains public ingress. Workers VPC connects Workers **outward** to private services; it does not make a Worker privately reachable. Reuse the personal-control capability interface and authority contracts, while placing the actual admission endpoint behind a genuine private route. The exact existing/private host and connector are an open deployment choice. [Private routes](https://developers.cloudflare.com/cloudflare-one/networks/routes/add-routes/), [Workers VPC](https://developers.cloudflare.com/workers-vpc/)

```mermaid
flowchart LR
  C[Owner client and enrolled hardware signer] -->|private route; signed metadata| A[Existing authority extended with provisioning admission]
  A --> D[(Durable challenges, jobs and outbox)]
  D --> L[Trusted launcher]
  L --> R[Disposable protected runtime]
  R --> P[Allowlisted provider login and issuance]
  R -->|fixed op CLI helper| O[Configured output vault]
  R -->|approved envelope ciphertext only| K[Optional KV]
  R --> E[Nonsecret receipts and recovery status]
  E --> A
```

Git owns engine, manifests, schema, private routes, IAM/bindings, image definition, deployment metadata, retention, and tests. It contains no secret values. Protect releases and deployment authority independently from the agent and jobs. Build a pinned artifact before secrets are available; never install dependencies or execute candidate checkout code in the privileged job.

## 5. Owner identity and hardware proof

### 5.1 Preferred protocol fit: PIV signing

PIV can sign the initial request before a server nonce exists. Enroll and verify the key/certificate under an independently administered owner trust inventory. Validate proof of possession, certificate/key identity, accepted algorithm, revocation, and any verified provenance. A presented certificate or HTTP header claiming YubiKey/SEP identity is insufficient. A TLS client certificate is useful for transport authentication but does not itself sign the job intent.

Touch and PIN behavior depends on key policy, firmware, middleware, and session behavior. If the user requires touch and PIN per approval, qualify the actual signing path and enforce the supported policy; do not infer it from a certificate. Existing keys may require different enrollment to change policy, which is a separately authorized action. [Yubico PIV policies](https://docs.yubico.com/yesdk/users-manual/application-piv/pin-touch-policies.html)

### 5.2 WebAuthn alternative

WebAuthn signs authenticator data and the hash of client data containing a challenge and origin; it does not sign arbitrary HTTP headers. Verify RP ID, exact allowed origin, challenge, signature, owner credential, user-presence and required user-verification flags, and relevant authenticator policy. User verification does not guarantee a fresh PIN prompt on every assertion. [WebAuthn verification](https://www.w3.org/TR/webauthn-3/#sctn-verifying-assertion)

If WebAuthn is selected, use an **additional initial server-challenge ceremony or an explicitly accepted existing authenticated bootstrap** before the first owner-authenticated request. It must bind the payload digest and context just as PIV does. It cannot be described as the identical two-message PIV exchange without accounting for that ceremony. Strict hardware-only acceptance also needs a policy for synced credentials, attestation/provenance availability, and recovery. Mode selection remains open.

## 6. Exact protocol: signed request, nonce, signed submission

### 6.1 Encoding and immutable context

The payload is one flat UTF-8 JSON object, max **32 KiB** in v1. The client freezes its exact bytes and computes `SHA-256(payloadBytes)` before requesting authorization. The final request sends those same bytes: whitespace changes change the digest. Do not parse and reserialize before hashing. A dedicated strict parser later rejects duplicate keys, invalid UTF-8, non-finite numbers, excess nesting, and unknown fields.

Signed protocol metadata uses one specified canonical encoding, proposed RFC 8785 JSON with domain separation. This does not canonicalize the payload. Every signature binds the endpoint audience, owner/client key identity, payload digest, immutable profile digest, engine/image digest, provider-manifest digest, and policy revision. The profile includes exact provider account and input/output/KV/recovery destinations. No mutable `latest` reference is permitted.

### 6.2 Message 1: owner-authenticated preflight

The client sends bounded metadata and a detached signature under domain `provisioner.auth-request.v1`:

| Signed field | Meaning |
|---|---|
| `requestId` | Fresh random 128-bit-or-greater replay identifier. |
| `issuedAt` | Unix seconds; proposed allowed clock skew 60 seconds. |
| `audience` | Exact private authorizer endpoint/protocol audience. |
| `clientKeyId` | Enrolled key identifier, independently resolved. |
| `payloadHash` | SHA-256 of the exact eventual payload bytes. |
| `profileDigest` | Immutable runtime account, mappings, destinations and limits. |
| `manifestDigest` | Reviewed provider workflow. |
| `codeDigest` | Approved engine/image identity. |
| `policyRevision` | Current accepted policy version. |

The server verifies signature and context against accepted trust before returning detailed information. It checks timestamp, rate limits, revocation, current code/manifest policy, and request replay. Atomic replay storage permits one challenge per owner/request ID; replay does not produce another authorization. Keep request tombstones at least through the full accepted replay window, and terminal operation evidence afterward. Denials do not reveal whether an owner, key, account, or vault exists.

The server generates a cryptographically random nonce of at least 256 bits, records the signed context, and returns a server-authenticated challenge response with `challengeId`, nonce, `issuedAt`, and **`expiresAt = issuedAt + 120 seconds`**. This authorization is job-bound and single-use. It is **not** a 1Password token and requires no separate bearer-token roundtrip. Challenge expiry is an admission deadline, not the provider token's lifetime or the job runtime limit.

### 6.3 Message 2: payload plus final proof

The client signs domain `provisioner.submit.v1` over the nonce, challenge ID, request ID, payload digest, audience, identity, profile/manifest/code digests, policy revision, and challenge expiry. It submits the raw payload body plus the bounded detached proof in a fixed transport envelope. The proof is available before reading the body; do not embed it inside the JSON whose validity has not yet been established.

Server ordering is mandatory:

1. Apply safe transport/header limits and cheap rate limits. Do not parse the semantic job or echo request data. No body or proof logging.
2. Resolve the durable challenge; authenticate enrolled identity and the final signature; verify audience, nonce/context, current revocation, expiry, and accepted versions. Unauthenticated, forged, expired, or mismatched proofs receive uniform denial. They do not consume someone else's otherwise valid challenge.
3. In one durable transaction, compare-and-set the challenge from `issued` to **`consumed`** and create the immutable operation reservation (`consumed_awaiting_body`). Recheck expiry/current authority at this boundary. Only one concurrent request can win. Commit before acknowledging consumption or evaluating payload content.
4. Read/hash the body with a hard byte limit and deadline. A disconnect, timeout, oversized body observed here, invalid UTF-8, wrong digest, malformed JSON, or semantic failure leaves authorization permanently consumed. No new nonce/grant is returned automatically.
5. Only after digest equality, parse the payload and validate fields, references, destinations, account, permissions, supported operation, and manifest constraints. Apply documented defaults from the immutable profile; retain both the original payload digest and normalized-job digest.
6. In one transaction, change the reserved operation to `admitted`, store the validated nonsecret immutable job, and insert the outbox record. Never enqueue before that commit. Do not store raw invalid bodies.
7. Return operation ID and admission state. The outbox dispatcher retries delivery of **the same operation**, not a new job. Status retrieval authenticates the same owner and cannot mint authority.

An authentic, valid authorization is burned even if its body is invalid. Correcting any payload requires a fresh signed request and approval. Signature verification must precede consumption so an attacker cannot burn another owner's nonce without valid proof. Whole requests rejected by transport infrastructure before proof reaches the authorizer cannot have application-level consumption guaranteed; configure the admitted body envelope and ingress limits consistently and document this outer boundary.

Crash after consumption but before durable admission does not authorize execution. Mark the orphaned reservation `admission_incomplete`; reconcile to no dispatch, then require fresh approval to submit a new operation. Crash after admission but before response is resolved by status/outbox state. Never restore a consumed challenge.

### 6.4 Errors without values

After valid consumption, return precise schema-owned field paths and fixed error codes, for example `{"state":"rejected","field":"/permissions/0/value","code":"value_not_allowed","authorizationConsumed":true}`. A digest mismatch reports `$body` / `hash_mismatch`; malformed JSON reports `$body` / `invalid_json` and an optional numeric offset. Never echo values, provider text, cookies, URL query strings, or parser excerpts. Unknown property names are untrusted: report the stable unknown-member index and offset rather than reflecting a possibly secret name.

## 7. Minimal flat job schema

This is the proposed complete v1 caller-facing schema. Unknown fields are rejected. Selection of the reviewed provider/profile occurs in signed context, avoiding a workflow language inside each job. Authentication proofs are transport metadata, not job fields.

| Field | Type / default | Meaning and constraints |
|---|---|---|
| `operation` | Required enum | `generate-api-key`, `rotate-password`, `rotate-recovery-codes`, `rotate-totp`, `enroll-passkey`. Only manifest-qualified operations are admitted; passkey is reserved/disabled initially. |
| `uDomId` | Optional string | Literal username DOM ID; must match the reviewed manifest. |
| `pwdDomId` | Optional string | Literal password DOM ID; must match the manifest. |
| `otpDomId` | Optional string | Literal OTP-code DOM ID; never an OTP value or seed. |
| `loginUrl` | Optional HTTPS URL | Must equal an allowed manifest login entry; absent uses its pinned default. |
| `secretUrl` | Required HTTPS URL | Reviewed credential-management entry path; no arbitrary destination. |
| `1passwordRecordUrl` | Required `op://vault/item` reference | Input login item locator. Field references come from the explicit immutable profile mapping, not inferred `username/password/credential` names. Resolve names to exact allowed IDs before execution. |
| `recordType` | Optional string | Output 1Password category, selected from profile allowlist; absent uses that profile's explicit category. |
| `generatedCredentialName` | Optional nonsecret string | Provider-facing label; default exactly `Provisioner secret #<runId>`. Validate vendor constraints; reject unsupported default rather than silently truncate/change it. |
| `generatedCredentialType` | Required enum | `token`, `key`, `password`, `recovery-codes`, `totp-seed`, `passkey`; must match operation and manifest. |
| `duration` | Optional integer seconds | Requested provider credential lifetime, not job TTL. Absence resolves to an explicitly approved profile lifetime rule; never silently means unlimited. Unsupported expiry for an operation requires explicit profile treatment. |
| `KV` | Optional boolean; **true** | Request secondary delivery to the profile's approved encrypted KV mode. No target/unwrap policy means rejection before any provider mutation. `false` explicitly disables secondary delivery. |
| `toVault` | Optional nonsecret vault locator | Proposed future mover destination only. Bind and display it as `move_pending`; it does not replace the Stage 2 output vault or authorize copying/deletion now. |
| `permissions` | Required array; may be empty | Each entry is exactly `{fieldDomId, value}`; `value` is string, number, or boolean and must belong to the manifest's nonsecret permission vocabulary. |

Limits proposed for review: at most 32 permission entries; no duplicate permission field; DOM IDs 1–128 ASCII characters from a conservative manifest-validated set; no CSS/XPath/JavaScript expressions; string permission values max 128 characters and enumerated where possible; names max 128 before provider-specific checks; URL max 2048; only top-level object plus the permissions array/entries. Raw credentials, OTPs, recovery codes, seeds, cookies, arbitrary text fields, and inline scripts are forbidden in jobs.

`1passwordRecordUrl` is an `op` item reference despite its user-facing name, not a share URL or a web page to fetch. The profile stores explicit references for each necessary input field, capture-to-output mapping, category, output vault ID, item title, KV binding/consumer, recovery policy, and provider account. No universal field schema or `/credential` suffix expansion exists.

Output item naming is **`{vendorShorthand}-{scope?}-{credentialType}`**. The item title is explicit in the approved profile; no naming compiler is needed. It is separate from the provider-facing label. Existing title collisions fail or use an explicitly approved update policy; never overwrite by ambiguous name.

### 7.1 Synthetic example: account-login API key generation

All names, paths and DOM IDs below are illustrative and are not claimed to match a live provider page. `provider.example` is an external synthetic provider, not an owned interface.

```json
{
  "operation": "generate-api-key",
  "uDomId": "account-user",
  "pwdDomId": "account-password",
  "otpDomId": "mfa-code",
  "loginUrl": "https://provider.example/login",
  "secretUrl": "https://provider.example/account/keys",
  "1passwordRecordUrl": "op://input-vault-example/provider-admin-login",
  "recordType": "API Credential",
  "generatedCredentialType": "key",
  "duration": 86400,
  "KV": true,
  "toVault": "runtime-vault-example",
  "permissions": [
    {"fieldDomId": "permission-read", "value": true},
    {"fieldDomId": "resource-scope", "value": "approved-test-resource"}
  ]
}
```

Its immutable profile might explicitly select output vault `output-vault-example`, item title `vendor-test-key`, and fields `access-id` and `secret-value`; these are configuration examples, not standard schema. It also names the allowed consumer and KV envelope-key policy. `toVault` is future intent only.

### 7.2 Synthetic example: password rotation

```json
{
  "operation": "rotate-password",
  "secretUrl": "https://provider.example/account/security/password",
  "1passwordRecordUrl": "op://input-vault-example/provider-admin-login",
  "generatedCredentialType": "password",
  "KV": false,
  "permissions": []
}
```

The approved profile must supply the new-password generation policy, exact output field, encrypted recovery escrow, irreversible-step authorization, and a supported fresh-login verification flow. Read-only input means the runner cannot update the original login item. Reconciliation/movement of the successor login reference is a separate authorized action; otherwise the input copy becomes stale after rotation.

### 7.3 Normalized immutable job

Internally retain: operation/run IDs, owner and proof reference, payload digest, validated body, resolved provider/account and exact input/output field IDs, explicit defaults and provider label, normalized scope/lifetime, code/manifest/profile/policy digests, allowed executor identity, admission deadline, separate maximum execution duration, approved irreversible transitions, KV envelope policy, recovery policy, and optional future mover intent. The runner may not choose replacements if any binding fails.

## 8. Reviewed provider manifest and constrained engine

Manifests contain allowed origins/paths/redirects, expected page and account states, literal DOM IDs and element types, login/MFA methods, bounded navigation/field actions, issuance confirmations, capture fields, permissions vocabulary, lifespan constraints, output mapping, and recovery/cleanup expectations. Their digest is independently approved and bound to the job. Client-supplied DOM IDs are overrides only where the manifest explicitly permits those exact alternatives.

Allowed engine actions are fixed primitives: navigate to a named allowed page, wait for an expected state, enter a secret from a named internal reference, set an allowlisted nonsecret permission, select an enumerated option, click a named expected control, capture a named secret field/download, verify expected account/scope, store through the secret helper, and emit a fixed status.

No arbitrary JavaScript, shell, `evaluate`, custom HTTP, plugins, arbitrary selector capture, executable downloads, destination overrides, or page-authored instructions. Use browser APIs without evaluating caller code. Reject unexpected frames, origins, consent expansion, duplicate elements, changed labels/types, permission drift, new authentication challenges, and navigation outside the approved graph. Do not add a domain because the page asks for it.

Enforce network policy independently of the browser: block link-local/metadata/internal-service access from the browser, local-file protocols, unrestricted downloads, DNS rebinding, unapproved redirects, and direct use of the vault helper. Allow only reviewed provider/identity origins and necessary assets. Validate submission and redirect destinations before releasing secrets into a page. Provider assets/CDNs are policy dependencies, not blanket host wildcards.

Provider pages are untrusted data. CAPTCHA or interactive MFA is a supported intervention state only if an approved channel can complete it without exposing secret pages or sessions; otherwise stop. Do not bypass challenges or stream the privileged browser back to the agent.

## 9. Protected disposable runtime

**Recommendation for review:** a fresh hardened EC2 VM per job with a pinned image and verified Chromium sandbox. This is a deployment choice to approve, not a deployment performed. Fargate is a lower-operations alternative only after real sandbox qualification. Its task-definition restrictions include unsupported controls relevant to browser hardening; substituting `--no-sandbox` is not acceptable. A Cloudflare Container's VM boundary alone does not establish browser/secret-helper separation inside it. Plain Workers cannot execute `op` through the non-functional `child_process` stub. [Fargate constraints](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/fargate-tasks-services.html), [Playwright sandbox guidance](https://playwright.dev/docs/docker), [Workers runtime](https://developers.cloudflare.com/workers/runtime-apis/nodejs/#non-functional-stub-modules)

Required qualification:

- Fixed engine/browser/`op` versions and image digest; signature/provenance checked by the launcher.
- Browser as an unprivileged OS identity with working Chromium sandbox, separate from supervisor and vault helper; narrow IPC schema. Browser cannot inspect helper environment, process memory, files, or 1Password bootstrap credentials.
- Private `tmpfs` for browser profile and temporary secret data; no swap/hibernation/core dumps. Read-only image where practical; no runtime package installation or agent shell/remote desktop/CDP access.
- No secrets in cloud-init/user-data, container/task definitions, instance tags, command arguments, build cache, environment dumps, console output, or telemetry. Deliver workload bootstrap through an independently governed authenticated channel. A cloud role does not automatically authenticate to 1Password.
- Restrict cloud metadata/role access to the supervisor; browser gets only narrow provider egress. No broad cloud-admin role, arbitrary image launch, or policy-edit authority.
- No browser screenshots/video/trace/HAR, request bodies, provider error bodies, clipboard capture, crash uploads, console mirroring, shell history, host memory snapshots or disk snapshots. Allowlisted event codes only.
- Encrypt unavoidable disks and verify `DeleteOnTermination` on **all** attached job volumes; exclude them from backup/snapshot policies. Termination does not imply deletion of retained volumes or snapshots. [EC2 termination](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/how-ec2-instance-termination-works.html)
- Independent deadline/watchdog and launcher reconciliation; no abandoned privileged jobs. Queue redelivery cannot launch a second mutation attempt.

Best-effort clearing of explicit buffers is useful. Hashing is not zeroization. Browser/managed-language copies, swap avoidance, allocator behavior and cloud-host memory are not all controllable; teardown evidence reports observable cleanup, never perfect erasure.

## 10. 1Password custody and delivery

Use the existing CLI interface for all supported secret handling. Two separately scoped identities are preferable: input `read_items`; output `read_items,write_items`. 1Password explicitly requires read permission for item writes. A service-account token's expiry is separate from the author's single-use execution authorization. [Service-account permissions](https://www.1password.dev/cli/reference/management-commands/service-account)

Identity provisioning/installation itself is a separate bootstrap authorization. Use no current agent token and make no new grants as part of job execution. Selecting a vault never grants access. Runtime-selected names/IDs and field mappings are checked against independent policy and the identity's real permissions. Production uses a production-authorized identity, not a development vault hardcode.

If old outputs must be unreadable, use a fresh output vault per approved batch, or later move them through Stage 3. Reusing a vault accepts that its writer can read existing items. Vault creation, copying login items, provisioning identities, and changing grants are not implicit side effects of a job.

The supervisor captures the generated value privately, constructs a bounded JSON item template in memory, and invokes a fixed `op item create - --vault <approved-id>` command with JSON stdin. No values in arguments, shell substitutions, temp template files, or user-visible output. Parse CLI responses in the protected helper and release only schema-approved metadata. [CLI stdin support](https://www.1password.dev/cli/reference/management-commands/item)

Confirm the persisted item ID, vault ID, category and required fields; where needed, compare the stored value internally through `op` with captured bytes, without returning or logging either value. No secret hashes in receipts: low-entropy secrets can be attacked through public fingerprints. A confirmed storage receipt proves storage, not successful provider authentication. Any provider-use verification must be an approved bounded check inside the runtime.

Lost create responses require metadata correlation with an internal operation ID, no title-based blind recreation. Listing/reading for reconciliation stays within trusted helper policy; multiple candidates require investigation. An op reference is an identifier, not a permission grant.

## 11. KV default and encryption decision

`KV` defaults to **true**, as requested. The exact KV product, namespace, consumer, and cryptographic mode remain a review decision. **No raw secret write is authorized by this default.** If no approved encrypted target is configured, reject the job before login/issuance. Do not silently switch storage products or silently treat `KV: true` as false.

Recommended mode if Workers KV is selected: envelope-encrypt the credential with authenticated encryption; bind operation ID, provider/account, credential type, destination, and version as authenticated data. Store ciphertext, nonce, wrapped data key, wrapping-key identifier, and nonsecret metadata. Generate a unique data key/nonce correctly; keep unwrap authority in separately governed KMS/secret infrastructure. Consumer identity and its decrypt policy must be explicitly selected. Existing platform encryption at rest is not application-level separation from KV readers. [KV data security](https://developers.cloudflare.com/kv/reference/data-security/)

The authorized consumer will obtain plaintext. An identity able to read ciphertext **and** unwrap it has the secret. If the same agent or administrator controls both, the intended separation is defeated. A supported secret store is an alternative to review, not a silent substitution for KV.

Use versioned immutable keys tied to operation/item version, not overwriting one mutable key during issuance. If Workers KV is selected, its eventual consistency means a successful write is not proof of immediate global consumer visibility. The authority's transactional store/outbox remains the source of execution truth; KV must not consume grants or lock jobs. Report primary-vault storage and secondary-delivery readiness separately. [KV consistency](https://developers.cloudflare.com/kv/concepts/how-kv-works/)

If vault storage succeeds and KV fails, retain the valid credential and report `secondary_delivery_pending`; retry storage delivery under the existing authorized recovery rules. Never regenerate or revoke the credential merely to repair KV delivery.

## 12. Operation capabilities and irreversible transitions

| Operation | Admission requirement | Safe transition / limitation |
|---|---|---|
| Generate API key/token | Verified account UI, exact scope/resource/expiry controls, one-time capture, output delivery and reconciliation path. | Reserve before the provider's create action. Capture/store immediately. Provider may return secret once; lost responses are uncertain. |
| Rotate password | Explicit operation approval, provider-specific password rules, encrypted recovery checkpoint, known account-recovery path. | Generate/store candidate securely before change where possible; verify new login before retiring old access where provider permits. Input vault remains read-only. |
| Rotate recovery codes | Explicit irreversible-step approval and tested recovery channel. | Often invalidates old codes immediately. Capture and durably escrow new codes in the same protected sequence; if the provider cannot offer safe recovery, mark unsupported until separately reviewed. Do not consume a code as a test unless explicitly included. |
| Rotate TOTP | Explicit seed reenrollment approval, existing-factor recovery, allowed seed capture and confirmation. | Per-run code input is distinct from reading a seed. Escrow new seed before activation where possible; confirm a derived code before removing old factor where supported. Some providers do not overlap factors; require an explicit documented failure policy. |
| Enroll/replace passkey | Provider and remote authenticator capability qualified; explicit destination and recovery semantics. | Disabled initially. A local YubiKey is not automatically available to a headless cloud browser. Non-exportable private keys cannot simply be captured into 1Password like API tokens. No synthetic authenticator substitution. |

Cloudflare and B2 are candidates for account-login browser issuance, not already-qualified manifests. Cloudflare API creation needs existing provisioning authority; B2 API key creation needs existing `writeKeys` authority. Neither requirement proves or substitutes for the requested remote dashboard bootstrap. [Cloudflare issuance](https://developers.cloudflare.com/fundamentals/api/how-to/create-via-api/), [B2 issuance](https://www.backblaze.com/apidocs/b2-create-key)

OAuth/browser consent is a distinct provider capability. It may permit remote callback exchange after account consent, but client registration and supported scopes still need bootstrap. Cloudflare third-party clients support Authorization Code flow; do not infer that Wrangler's device flow is available to a custom client. MFA, CAPTCHA, conditional access and recovery differ by provider. No universal automation or hardware-only authentication claim is made. [Cloudflare OAuth](https://developers.cloudflare.com/fundamentals/oauth/create-an-oauth-client/)

## 13. Recovery escrow and authorization limits

Credential rotation can invalidate the old value before final delivery. Destruction must not erase the sole surviving successor. Before admitting an irreversible rotation, require a reviewed encrypted durable recovery checkpoint and a qualified recovery procedure, or reject that operation.

Recovery escrow is **not zero remnants**: encrypted secret material intentionally survives the disposable environment. Its storage, key access, retention, deletion verification, permitted recovery operations, and approvers must be bound into the profile. No plaintext escrow in a job database, logs, or KV. Prefer early 1Password staging where practical; provider-issued values may need a separate encrypted checkpoint before final vault write. This exception is explicit, independently controlled, and time-bounded.

Record only opaque checkpoint references in normal state/audit. Recovery may finish already-approved delivery or reconcile an attempted mutation; it cannot enlarge scope or create a new credential. A new irreversible attempt requires new approval. Bound recovery-only authorization separately after ordinary expiry, using the existing renewal pattern without reopening issuance. Do not automatically revoke orphaned output keys at teardown; an explicit provider-remediation decision may later revoke an unwanted orphan.

## 14. State machines and deduplication

### 14.1 Authorization/admission

```text
signed_request_verified -> challenge_issued (120s)
challenge_issued -> expired | consumed_awaiting_body
consumed_awaiting_body -> rejected | admission_incomplete | admitted+outbox
```

All terminal challenges remain unusable. Status requests and queue messages are not new authority. Every state transition checks immutable identity/context.

### 14.2 Execution and delivery

```text
admitted -> launch_reserved -> running -> login_ready
login_ready -> intervention_required | mutation_reserved
mutation_reserved -> captured | mutation_uncertain
captured -> checkpointed -> vault_stored -> secondary_delivered_or_disabled
delivery_confirmed -> cleanup_pending -> terminated
```

State names describe evidence, not optimistic progress. Capture may be followed directly by durable vault storage; `checkpointed` is mandatory where the approved recovery policy requires escrow. The mutation reservation must commit **before** any irreversible click/API action. A crash in or after `mutation_reserved` never replays that action automatically. A resumed worker performs only provider-specific reconciliation and delivery from retained evidence.

At-least-once outbox/queue transport is expected. Durable operation ID, transactional launch reservation, pinned executor identity, fencing generation and mutation reservation prevent duplicate authorization. Launcher task IDs/idempotency references must be recoverable before replacement; an uncertain launch does not justify a second live worker. Expired worker leases require evidence that the previous runtime is stopped and its provider outcome reconciled before takeover. Exactly-once provider effects cannot be promised across arbitrary UI/network failures.

### 14.3 Independent status dimensions

Keep `providerMutation`, `vaultDelivery`, `kvDelivery`, `recovery`, and `cleanup` independently reportable. A vault-stored credential can remain usable while cleanup or KV delivery is pending. A cleanup success never proves delivery. A timeout never proves that no provider mutation occurred.

## 15. Failure behavior

| Failure | Required result |
|---|---|
| Unauthorized client, forged proof, wrong audience | Uniform minimal denial; no owner/vault enumeration; no job. |
| Replayed first request | No new challenge; bounded denial/status under authenticated policy. |
| Concurrent valid final submissions | One atomic consumption; all others cannot queue/execute. |
| Valid proof + bad body/hash/schema | Burn permanently; schema-owned field/error only; no provider call. |
| Crash after consumption, before admission | `admission_incomplete`; no dispatch; fresh approval after reconciliation. |
| Crash after admission, before acknowledgment | Status/outbox recovers the same operation; no resubmission mutation. |
| Output vault/KV permission or configuration missing | Reject during pre-mutation readiness; do not create credential. |
| Changed DOM/account/scope, unsupported MFA | Stop without speculative clicks; sanitized intervention/error state. |
| Provider response lost after create/rotation | Mark uncertain; do not retry generation; reconcile with approved provider evidence. |
| Capture exists, vault unavailable | Use approved encrypted checkpoint; delivery recovery; never destroy sole new credential. |
| `op` result lost | Reconcile operation-correlated item metadata internally; no duplicate create by title. |
| Vault succeeds, KV fails | Keep runtime credential valid; secondary delivery pending; no regeneration/revocation. |
| Fresh-login verification fails after rotation | Preserve successor and evidence; use approved recovery path; never assume old credential works. |
| Logout/revocation/termination fails | Nonsecret cleanup alert; supervisor/launcher retries permitted cleanup independently; preserve issued credential. |
| Recovery escrow cannot be confirmed after irreversible action | Incident state; do not claim success or secure destruction; preserve the only recoverable copy under approved protected handling and escalate. |

## 16. Secret lifecycle and cleanup

| Object | Location/lifetime | Teardown behavior |
|---|---|---|
| Owner private signing key | Enrolled hardware; never uploaded. | Not rotated/deleted by a job. |
| Job authorization | Durable authorizer challenge/consumption record. | Permanently consumed/expired; never reusable. |
| 1Password runner identities | Protected helper/launcher bootstrap only. | Expiry or narrowly approved retirement; no implicit deletion of shared identities. |
| Input login values | Read-only vault; transient browser memory. | Clear local copies best effort; do not modify input records. |
| Provider browser session | Disposable browser profile plus provider-side state. | Perform supported logout/session retirement if approved; delete local session data. Provider-side revocation and local cookie deletion are different evidence. |
| New runtime credential | Output vault; optional encrypted secondary delivery. | **Remains valid. Never revoke merely because the runner ends.** |
| Recovery checkpoint | Explicit encrypted recovery custody. | Retain until verified delivery/recovery and approved retention completion; report remaining escrow. |
| Audit receipt | Nonsecret durable evidence. | Retain under audit policy; no secret values or secret fingerprints. |

Do not confuse deletion of an authenticator with revocation of existing sessions or issued tokens. Do not rotate/remove account authenticators as generic cleanup. Provisioning authority may be account-session authority rather than a bootstrap API issuer token; retire only what the specific job is authorized to retire. Verify that provider cleanup preserves the issued credential rather than assuming independence.

Watchdog cleanup disables local access, closes the browser/helper, performs permitted session cleanup, destroys temporary data and terminates the job. Independent launcher evidence verifies termination, volume deletion, and lack of job snapshots. No secret-bearing recordings or dumps should exist to delete. Residual-data limits and any retained recovery escrow are stated in the receipt.

## 17. Stage 3: future mover contract

`toVault` records the desired final vault, but generation does not execute a move or delete. A separate approved operation checks exact source item/version and destination identity/mappings. A trusted process handles plaintext via `op` or uses a qualified provider-side move operation where supported. Copying is not a write-only mechanism.

Confirm destination permissions, item identity and content readback inside the trusted boundary before removing source. Preserve source on failed/ambiguous copy or verification. Source deletion, archival and updates to runtime references are separate explicit effects. Existing output credentials remain valid throughout unless a separately approved provider lifecycle operation says otherwise. Stage 3 implementation is deferred.

## 18. Nonsecret receipts

Receipt fields: operation/run ID; authenticated owner/key reference; payload/normalized-job/profile/manifest/code/policy digests; approved provider account and scope/expiry; provider-issued nonsecret key ID where available; output vault/item ID and version; KV ciphertext object/version and readiness; recovery checkpoint status without secret content; provider-mutation outcome; cleanup/termination evidence; timestamps and sanitized fixed error codes; signed audit/checkpoint reference.

Never include password/TOTP/recovery values, API tokens, bearer grants, provider cookies, session URLs/callback codes, full browser/network errors, CLI stdout, HTML, screenshots, seed fingerprints, or a hash of a secret. Store request IDs and audit data without retaining raw invalid payloads.

## 19. Acceptance and qualification tests

These are required future evidence, not tests run by producing this spec.

| Area | Required test |
|---|---|
| Identity | Reject forged headers/cert labels, unenrolled/revoked keys, wrong audience/origin/RP, mismatched proof and expired challenge. Verify actual supported touch/PIN/UV behavior without claiming universal fresh PIN. |
| First-request replay | Concurrent identical request IDs create at most one challenge; skew/rate-limit failures do not leak details. |
| Burn ordering | Valid final proof with wrong hash, duplicate JSON keys, bad schema, oversize/disconnected body consumes once and cannot issue. Forged proof cannot burn another owner's challenge. |
| Atomic admission | Kill process around every consumption/admission/outbox commit boundary. No uncommitted job dispatch and no restored grant. |
| Queue/launch | Duplicate/out-of-order messages and lost launcher responses yield no second mutation attempt; expired lease cannot overlap a live predecessor. |
| Approval integrity | Changing account, vault, field mapping, permissions, TTL, operation, code, manifest, destination or defaults requires new proof. |
| Browser confinement | Exercise redirect/frame/DOM substitution, selector injection, page prompt injection, metadata access, outbound exfiltration and helper access. All fail closed. |
| Secret suppression | Synthetic canary credentials never occur in stdout/stderr, audit, receipts, screenshots, trace/HAR, downloads to client, crash/console logs, disk snapshots or Library artifacts. Inspect only synthetic test data. |
| Runtime | Prove Chromium sandbox under the selected image/host, browser/helper OS separation, no swap/dumps, independent network enforcement, signed image and image substitution rejection. |
| 1Password | Qualify dedicated disposable test input/output vault permissions, stdin delivery, internal readback, collisions, lost responses, rate limits and empty/fresh vault policy. No production secret required for acceptance. |
| KV | Prove ciphertext-only writes, authenticated-context mismatch rejection, unavailable unwrap denial, separate consumer identity, duplicate delivery handling and consistency/readiness behavior. |
| Rotation | Test interruption before/after each irreversible boundary, escrow retrieval under recovery-only authority, fresh-login verification, non-overlapping factors, and stale read-only input references. Unsupported providers remain disabled. |
| Teardown | Verify local destruction and provider-session cleanup separately; verify issued test credential **still works** afterward; verify all job volumes deleted and no snapshots/recordings created. |
| Mover (future) | Destination mismatch/failed readback never removes source. No mover executes merely because `toVault` exists. |

Live provider qualification needs its own explicit approval and disposable test accounts/vaults. Passing unit tests or a dry-run does not establish provider behavior or production readiness.

## 20. Decisions required before an implementation plan

| Decision | Proposed position | What remains to choose/verify |
|---|---|---|
| Hardware protocol | PIV for the exact two-message request-before-nonce design. | Accepted key/provenance/PIN/touch policy, enrollment/revocation authority; or WebAuthn with its explicit extra bootstrap ceremony. |
| Private ingress | Private hostname under `vespoli.me` or `anthonyvespoli.com`, WARP/private route, no public origin. | Existing host/connector/private service topology and authority integration. |
| Runtime | Fresh hardened EC2 VM per job. | Approve platform after sandbox/OS separation qualification; Fargate remains conditional, not rejected categorically. |
| Bootstrap identities | Remote protected login input and scoped `op` identities; no local issuer-key handling. | Secure initial installation channel and independently governed launcher credentials; no credential creation implied. |
| Provider v1 scope | Cloudflare/B2 API-key creation first; rotations capability-gated. | Exact account login/MFA, UI selectors, permission controls, limits, cleanup independence and provider-supported intervention. |
| Input/output isolation | Dedicated input read-only, separate output read/write. | Fresh output vault per batch versus accepted read access to existing outputs; explicit field/title mappings. |
| KV default true | Envelope encryption with separately governed unwrap. | Which KV, namespace, consumer, key authority, delivery-readiness rule; alternative secret store only by explicit decision. Missing mode blocks issuance. |
| Irreversible recovery | Durable encrypted escrow and tested recovery before enabling rotations. | Escrow/key owners, retention, break-glass bounds and provider cases where safe overlap is impossible. |
| Execution limits | 120s admission challenge; separate bounded run/intervention/recovery deadlines. | Maximum run duration and permitted cleanup/recovery windows in each immutable profile. |
| Stage 3 | Deferred, separately approved mover. | Copy/move semantics, final vault permissions, readback and source-removal policy. |

Review of this written spec is the next gate. Approval of a concept does not approve credentials, deployments, provider actions, or irreversible changes. After the user reviews and accepts the written design, an implementation plan can be prepared separately.

## 21. Evidence and source boundaries

Local architectural references: `/workspace/personal-control/docs/architecture.md`; `/workspace/repoctl/docs/GOVERNANCE-SPEC.md`; `APP-REGISTRATION-ENDPOINT.md`; `ENROLLMENT-APPROVAL.md`; `BROKER-RUNTIME.md`; `DEPLOYMENT-TOPOLOGY.md`, plus source paths in section 3. This spec preserves their split between current code, required bindings, and unqualified deployment. It does not activate disabled services.

Official documentation was consulted on 2026-10-12 and linked at relevant claims. Provider account state and permission availability were not probed. Examples are synthetic. No actual credentials, account values, authenticated sessions, vault contents, or secret fields were retrieved to write this document.
