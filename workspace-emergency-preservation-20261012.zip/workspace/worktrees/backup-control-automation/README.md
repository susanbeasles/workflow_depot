# Persistent GitHub and image backups

This project captures every delivered repository push and container publication into private Cloudflare R2 storage. A dedicated Worker verifies GitHub webhooks, journals each delivery, and dispatches a trusted central Actions workflow. The delivery stays pending until the workflow uploads its archives and the Worker verifies the completion manifests. A daily inventory sweep captures existing repositories and container versions and checks for missed changes.

## Current status

Cloudflare infrastructure was deployed on October 6, 2026 after write access was granted: all four R2 buckets, their retention/lifecycle policies, the `backup-control` Worker, and the `backup-setup` registration Worker are live. Public health checks succeed. **Backup execution is not active yet:** the backup GitHub App must be registered and installed, and the central repository/workflow must be created. The current GitHub integration still rejects repository creation with HTTP 403.

The hosted registration page uses an expiring capability link, verifies GitHub manifest state and browser session cookies, and stores the generated App key and webhook secret inside its private Durable Object. The main Worker obtains those credentials through a private cross-Worker binding. The public setup Worker never exposes the internal credential route. Once configured, the backup workflow can obtain a short-lived read-only GitHub token using its Actions OIDC identity; it does not need an App private-key secret in GitHub. The original local bootstrap is retained as an alternative, but do not register a duplicate App after using the hosted flow.

Local validation covers raw-byte HMAC verification, OIDC claim boundaries, scope filtering, real Git history restoration, archive traversal rejection, OCI layout restoration, and checksum corruption detection. Live Worker runtime, GitHub installation, GHCR private-package access, and end-to-end backup/restore remain to be qualified.

## Storage layout

| Resource | Purpose | Retention |
| --- | --- | --- |
| `backup-control` Worker | Webhook verification, durable outbox, Actions dispatch, OIDC upload API | Durable retry until receipt |
| `backup-webhooks` | Signed event journal, upload sessions, completion receipts | Event journal locked indefinitely |
| `backup-git` | Full Git mirrors, bundles, LFS objects, metadata, release assets | Locked indefinitely; archive blobs transition to Infrequent Access after 30 days |
| `canon-images` | Deduplicated OCI manifests, indexes, configs, layers, tag history | Locked indefinitely; blobs transition to Infrequent Access after 30 days |
| `image-hot` | Golden-tier OCI objects, manifests and tag history in Standard storage | Indefinite retention locks on objects, manifests and tags; no automatic deletion |

All buckets remain private. No public image-serving or Docker Registry HTTP API is exposed by this project. `image-hot` is the retained golden tier, not yet a registry endpoint for `docker push` or `docker pull`. Capture currently duplicates every archived image into this tier; selective golden promotion is still pending. Restored OCI layouts can be imported into a registry using `skopeo` or another OCI tool. Running Containers is a separate capability from storing container images.

Retention locks can be removed by a sufficiently privileged Cloudflare administrator. They are protection against ordinary deletion, not an irreversible compliance guarantee. Infrequent Access is a storage class transition, not a separate disaster-recovery copy. Google One/Drive is the requested Google destination; Google Cloud Storage must not be substituted without authorization. Replication is pending destination authorization and identification of the provider called R8. The requested Cloudflare budget alert threshold is $25 per billing period; updating the existing alert was rejected by the Cloudflare API with an authentication error. The existing $10 usage alert to anthonyvespoli@gmail.com remains configured; the $25 threshold is not active.

Objects use `objects/sha256/<first-two-hex>/<digest>`. Manifests identify the object set needed for restoration. Tags are append-only timestamped records, preserving historical tag-to-digest mappings. Original source tags and annotations remain in the archived manifests. This format can be copied unchanged to Google storage or another provider.

Export a sortable CSV from any downloaded bucket with `python3 scripts/catalog.py /path/to/bucket > catalogue.csv`. Optional exact filters are `--repository`, `--kind git|oci`, and `--tag-or-ref`. Git rows include commit IDs and branch/tag refs; OCI rows include image tags and immutable digests. This is an offline export, not a deployed catalogue dashboard.

## Bootstrap

Prerequisites: Node.js/npm, Python 3.12+, Git, OpenSSL, GitHub CLI, and a working local Git signing/SSH setup. The GitHub CLI must be authenticated as `susanbeasles` and able to create repositories, push workflows, and configure repository secrets and environments. Cloudflare R2 must be enabled on the account. Wrangler browser OAuth is used for deployment; this does not rely on the read-only ChatGPT connection.

Extract this project, enter its directory, then run:

```bash
python3 scripts/setup.py
```

The script opens Cloudflare OAuth, provisions the four buckets and retention rules, deploys the Worker, creates a private `susanbeasles/backup-control` repository, preserves configured Git signing, and pushes the workflow. It then opens a local browser page for GitHub App registration. GitHub generates the webhook secret and App key; the script routes them through stdin into the Worker and the central repository's `backup` environment. Install the private App into **All repositories** so current and future repositories generate events. The initial inventory backup is dispatched after installation.

The App has read access to repository contents, issues, pull requests, and packages, plus Actions write access for dispatch. The Worker narrows its installation token to Actions write on the control repository. Backup jobs narrow their App token to read permissions. Changes to the central backup workflow should receive the same protection as other privileged automation.

Separate setup phases are available:

```bash
python3 scripts/setup.py --cloud-only
python3 scripts/setup.py --github-only
```

If App activation is interrupted after credentials were routed into the Worker, download a new private key from the existing App settings and resume without registering another App:

```bash
python3 scripts/setup.py --github-only \
  --resume-app-key /path/to/existing-app-key.pem --app-id YOUR_APP_ID
```

This preserves the existing Worker webhook secret. If the interruption occurred before that secret was configured, recover or reset the webhook secret locally in the App settings and pass it to `wrangler secret put WEBHOOK_SECRET` through stdin before resuming. Credentials should remain on your machine and in the platforms' secret storage.

## Private images

The central workflow uses its `GITHUB_TOKEN` with `packages: read` for GHCR. Existing private packages must grant the central repository Actions read access under their package settings. For account-wide private package inventory that is unavailable to that token, an optional `GHCR_READ_TOKEN` environment secret can hold a classic token with `read:packages`, supplied locally through `gh secret set`. A GitHub App installation alone is not assumed to make every private GHCR package readable. Unreadable packages fail visibly and remain pending; they are never marked backed up.

The App receives `registry_package` and `package` events. The backup job resolves the exact package version ID to a digest when the webhook lacks a digest. It copies all platforms recursively and deduplicates every blob by SHA-256. Manifest-supplied external layer URLs are not fetched; inaccessible foreign layers make the backup fail rather than silently produce an incomplete image.

For guaranteed capture before a source image is deleted or a tag is replaced, the producer should wait for a successful digest backup after publication. A webhook arriving after the source bytes have already been deleted cannot recover those bytes. For a manual exact-digest backup:

```bash
gh workflow run backup.yml \
  --repo susanbeasles/backup-control \
  -f image='ghcr.io/susanbeasles/IMAGE@sha256:DIGEST'
```

The first full sweep inventories all visible GHCR versions. Its manifest records per-repository and per-image failures and the workflow fails if any capture is incomplete.

## Git restoration

Git archives contain a bare mirror, a verified full-history bundle when nonempty, reachable LFS objects, repository metadata, issues/PR summaries, issue comments, review comments, and release metadata. Release assets are separate verified blobs referenced by the manifest. Event before/after commit IDs are fetched and pinned where GitHub still makes them available, including overwritten branch tips.

The archive is scoped to remotely accessible repository data. It cannot recover unpushed local commits, local working-tree files, dangling GitHub objects already pruned, encrypted Actions secrets, unselected repositories, private submodule repositories outside the installed account, wiki repositories, discussions, or all GitHub administrative settings. Source repository deletions preserve prior snapshots and produce an unresolved delivery requiring investigation rather than a false success.

Download or replicate a bucket's object and manifest layout, then restore into a new directory:

```bash
python3 scripts/restore.py \
  /path/to/backup-git \
  /path/to/git-snapshot-manifest.json \
  /path/to/restored-repository

git --git-dir=/path/to/restored-repository/repository.git fsck --full
git clone /path/to/restored-repository/repository.git /path/to/working-copy
```

The restore command verifies archive SHA-256 and size, rejects unsafe paths and links, and refuses an existing destination. Release assets are restored by asset ID. Copy or configure the restored mirror's LFS storage when serving it as an LFS remote; a normal Git clone alone does not serve its archived LFS objects.

## Image restoration

```bash
python3 scripts/restore.py \
  /path/to/canon-images \
  /path/to/image-snapshot-manifest.json \
  /path/to/restored-oci-layout
```

The output is a standard OCI layout with verified blobs and a root descriptor. Import it into the desired registry or runtime with your OCI tooling. Tag history is available beside the manifests; restoration does not overwrite a remote tag automatically.

## Off-site replication

Configure source and destination remotes locally in `rclone`, then run:

```bash
bash scripts/replicate.sh r2-remote: google-remote:backups
```

The script copies objects without deleting destination data, checks destination bytes through downloads, then publishes verified manifests and tag histories. It accepts any configured provider remote, so the second provider can change independently of the archive format. No provider credentials, unattended replication schedule, or background account session is created here. Configure target retention controls independently before relying on it as a disaster-recovery copy.

## Verification and activation

```bash
npm test
python3 -m unittest discover -s tests -p 'test_*.py' -v
node --check src/worker.mjs
```

After deployment, `/health` reports whether webhook and dispatch credentials are configured. It does not prove that archives have been stored. Verify the first inventory workflow succeeds, inspect its sweep manifest for complete coverage, and restore at least one Git archive and one multi-platform image from R2 before treating the system as operational. The Worker API accepts only signed Actions OIDC tokens from the exact control workflow on `main` in the `backup` environment. No R2 credential is stored in source repositories.

## References

- [Cloudflare R2 Worker API](https://developers.cloudflare.com/r2/api/workers/workers-api-reference/)
- [R2 bucket locks](https://developers.cloudflare.com/r2/buckets/bucket-locks/)
- [Wrangler R2 commands](https://developers.cloudflare.com/workers/wrangler/commands/r2/)
- [GitHub App manifest registration](https://docs.github.com/en/apps/sharing-github-apps/registering-a-github-app-from-a-manifest)
- [GitHub Container registry authentication](https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-container-registry)


## Shared control plane

Owner configuration and monitoring now live at https://control.vespoli.me/owner/apps/backups. Public setup routes redirect to this shared gate; the Bootstrap Durable Object exposes owner operations only through the private binding. The expiring setup link and its independent session stack are retired.

Canonical integrated source, navigation, infrastructure snapshots, verification and four-worker release code are in https://github.com/susanbeasles/personal-control. This repository preserves the backup Actions caller identity and recovery tooling. Worker dispatch is paused in the deployed baseline and stays paused; the shared pane displays that state. Actions OIDC pins the numeric repository and owner IDs, main branch, workflow and environment.

## Provisioner-backed B2 replication adapter

`scripts/replicate_provisioned.py` consumes the existing provisioner's successful **owner status response** and runs the unchanged `scripts/replicate.sh` copy-and-verify path. It does not create a B2 application key. This interface is for credentials created by the provisioner and saved to its approved 1Password Secure Note. Initial keys already present in 1Password use the separate [owner-approved existing-item interface](EXISTING-ITEM-REPLICATION.md), without a fabricated creation receipt.

The expected status response is the actual owner API shape:

```json
{
  "id": "PROVISIONER_JOB_UUID",
  "state": "succeeded",
  "provider": "b2",
  "operation": "generate-api-key",
  "createdAt": 1700000000,
  "receipt": {
    "itemId": "IMMUTABLE_1PASSWORD_ITEM_ID",
    "vaultId": "IMMUTABLE_1PASSWORD_VAULT_ID",
    "recoveryId": "NONSECRET_RECOVERY_IDENTIFIER"
  }
}
```

`recoveryId` and `kvId` are optional receipt identifiers. The adapter requires the SHA-256 of the exact response bytes in trusted runtime configuration and checks the job, vault and item identities. The launcher must obtain this response through the authenticated owner path and approve its digest; hashing an arbitrary caller-provided JSON document does not authenticate it. Flat internal runner receipts are rejected. No shared signing secret is given to a backup job.

The two reads are exactly `op://<vaultId>/<itemId>/key_id` and `op://<vaultId>/<itemId>/application_key`. Those field IDs match the provisioner's B2 output template. The runtime may select an approved vault through configuration; mutable vault or item names are rejected. An existing least-privileged 1Password runtime token arrives through private FD3, goes only to the fixed `op read` child, and is not passed to rclone. The B2 values are supplied only in the rclone child's environment and are not written into a new rclone configuration or returned in the replication receipt. Encrypted KV is not an unwrap source.

[The rclone B2 documentation](https://rclone.org/b2/#application-keys) maps the application-key ID to `account` and the application key to `key`. The wrapper uses that mapping with a temporary environment remote named `provisioned_b2`. Source access reuses an existing private rclone configuration. The destination is an explicit existing bucket and prefix; no default bucket, new account, secret registration, retention change or manual issuer workaround is provided. The generated key must have the approved bucket/prefix permissions needed by the existing copy and download verification operations.

`config/replication.disabled.json` lists the nonsecret activation inputs and is deliberately disabled. A trusted runner must provide the authenticated successful status response, reviewed configuration, existing source access, pinned `op` and `rclone` binaries, and the private FD3 token handoff. Configuration-only verification is:

```bash
python3 scripts/replicate_provisioned.py \
  --config /trusted/replication.json \
  --receipt /trusted/provisioner-owner-status.json
```

The same command with `--execute` performs the approved copy after reading FD3. Child output is bounded and suppressed; a failed read, copy or byte verification returns a generic failure. SIGTERM, keyboard interruption and timeouts stop the active process group and reap its direct child. The trusted runner must still own a container or cgroup that removes all descendants if the wrapper is killed with uncatchable SIGKILL or its host fails. A successful nonsecret replication receipt means both existing archive tiers were copied and checked. It does not assert that an earlier inventory sweep captured every source repository or image.

Local tests use synthetic credentials and generated local directories only. They exercise the installed rclone's real immutable copy/download-check path, ensure a conflicting object blocks metadata publication, and check the actual owner-status implementation when its source is provided:

```bash
PROVISIONER_CONTRACT_SOURCE=/path/to/reviewed/personal-control/src/provisioner.mjs \
  PYTHONPATH=scripts python3 -m unittest discover -s tests -p 'test_*.py' -v
```

In the standalone recovery repository, the cross-repository composition test is explicitly skipped when that reviewed source path is not supplied. In the canonical `personal-control/workers/backup-control` layout it automatically imports the parent repository's `src/provisioner.mjs`; a missing implementation fails the test instead of skipping. No B2 credential, upload, scheduled replication run or live qualification was performed by this local change. The existing daily capture workflow remains separate; its recorded container-inventory failure must still be resolved and the required Git/OCI restores verified before claiming end-to-end backup health.
