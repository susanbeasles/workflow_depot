#!/usr/bin/env python3
"""Offline, checksum-verified restoration from replicated R2 key layout."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import shutil
import tarfile

MAX_ARCHIVE_BYTES = 2 * 1024**3
MAX_EXPANDED_BYTES = 2 * 1024**3
MAX_MEMBER_BYTES = 512 * 1024**2
MAX_ARCHIVE_MEMBERS = 100000
MAX_EXTENDED_HEADER_BYTES = 64 * 1024


class BoundedTarInfo(tarfile.TarInfo):
    def _proc_gnusparse_00(self, *args):
        raise ValueError('sparse-archive-refused')

    def _proc_gnusparse_01(self, *args):
        raise ValueError('sparse-archive-refused')

    def _proc_gnusparse_10(self, *args):
        raise ValueError('sparse-archive-refused')

    def _proc_member(self, tar):
        # Legacy GNU sparse is considered a regular file by TarInfo.isfile().
        # Reject its type before the inherited parser can read extension maps.
        if self.type == tarfile.GNUTYPE_SPARSE:
            raise ValueError('sparse-archive-refused')
        # Count raw headers, including PAX extensions, before their payload is read.
        tar._bounded_header_count = getattr(tar, '_bounded_header_count', 0) + 1
        if tar._bounded_header_count > MAX_ARCHIVE_MEMBERS:
            raise ValueError('member-count-limit')
        if self.type in (tarfile.XHDTYPE, tarfile.XGLTYPE, tarfile.GNUTYPE_LONGNAME, tarfile.GNUTYPE_LONGLINK):
            if self.size < 0 or self.size > MAX_EXTENDED_HEADER_BYTES:
                raise ValueError('extended-header-limit')
            # Local PAX headers preserve normal producer mtimes and non-UTF8 names.
            # Global headers and GNU extensions are unnecessary for this producer.
            if self.type != tarfile.XHDTYPE:
                raise ValueError('unsupported-archive-header')
        elif not (self.isfile() or self.isdir()):
            raise ValueError('unsafe-archive-member')
        return super()._proc_member(tar)


def extract_bounded(archive, target):
    if archive.stat().st_size > MAX_ARCHIVE_BYTES:
        raise ValueError('archive-size-limit')
    # Accepted producer format is an uncompressed tar. Never auto-decompress.
    with tarfile.open(archive, mode='r|', tarinfo=BoundedTarInfo) as tar:
        target.mkdir(parents=True)
        seen = set()
        total = 0
        for item in tar:
            parts = item.name.rstrip('/').split('/')
            if (not parts or any(p in ('', '.', '..') for p in parts) or
                '\\' in item.name or '\x00' in item.name or
                item.sparse is not None or not (item.isfile() or item.isdir())):
                raise ValueError('unsafe-archive-member')
            if item.name in seen:
                raise ValueError('duplicate-archive-member')
            seen.add(item.name)
            if item.size < 0 or item.size > MAX_MEMBER_BYTES:
                raise ValueError('member-size-limit')
            total += item.size
            if total > MAX_EXPANDED_BYTES:
                raise ValueError('expanded-size-limit')
            destination = target.joinpath(*parts)
            if item.isdir():
                if item.size != 0:
                    raise ValueError('invalid-directory-size')
                destination.mkdir(parents=True, exist_ok=True)
                continue
            destination.parent.mkdir(parents=True, exist_ok=True)
            source = tar.extractfile(item)
            if source is None:
                raise ValueError('missing-member-data')
            with source, destination.open('xb') as out:
                remaining = item.size
                while remaining:
                    chunk = source.read(min(1024**2, remaining))
                    if not chunk:
                        raise ValueError('truncated-archive-member')
                    out.write(chunk)
                    remaining -= len(chunk)


def verified_blob(root, value):
    hash_value = value['sha256']
    if len(hash_value) != 64 or any(c not in '0123456789abcdef' for c in hash_value):
        raise ValueError('invalid-digest')
    key = f'objects/sha256/{hash_value[:2]}/{hash_value}'
    if value['key'] != key:
        raise ValueError('invalid-object-key')
    path = root / key
    h = hashlib.sha256()
    with path.open('rb') as f:
        while b := f.read(16*1024*1024):
            h.update(b)
    if h.hexdigest() != hash_value or path.stat().st_size != value['size']:
        raise ValueError('checksum-mismatch')
    return path


def restore(root, manifest, target):
    if target.exists() or target.is_symlink():
        raise ValueError('restore-target-must-not-exist')
    if manifest['schema'] == 'git-backup/v1':
        for asset in manifest.get('release_assets', []):
            if not re.fullmatch(r'[0-9]+', str(asset.get('id', ''))):
                raise ValueError('invalid-release-asset-id')
        archive = verified_blob(root, manifest['archive'])
        extract_bounded(archive, target)
        asset_dir = target / 'release-assets'
        for asset in manifest.get('release_assets', []):
            asset_dir.mkdir(exist_ok=True)
            shutil.copyfile(verified_blob(root, asset), asset_dir / str(asset['id']))
    elif manifest['schema'] == 'oci-backup/v1':
        blobs = []
        for hash_value, value in manifest['objects'].items():
            if hash_value != 'sha256:' + value['sha256']:
                raise ValueError('descriptor-digest-mismatch')
            blobs.append((hash_value, verified_blob(root, value)))
        if manifest['digest'] not in manifest['objects']:
            raise ValueError('missing-root-manifest')
        target.mkdir(parents=True)
        (target / 'blobs/sha256').mkdir(parents=True)
        for hash_value, path in blobs:
            shutil.copyfile(path, target / 'blobs/sha256' / hash_value[7:])
        (target / 'oci-layout').write_text('{"imageLayoutVersion":"1.0.0"}\n')
        root_value = manifest['objects'][manifest['digest']]
        root_json = json.loads((target / 'blobs/sha256' / manifest['digest'][7:]).read_text())
        descriptor = {'mediaType': root_json['mediaType'], 'digest': manifest['digest'], 'size': root_value['size'],
                      'annotations': {'org.opencontainers.image.ref.name': 'restored'}}
        (target / 'index.json').write_text(json.dumps({'schemaVersion': 2, 'manifests': [descriptor]}) + '\n')
    else:
        raise ValueError('unsupported-manifest-schema')


def restore_and_verify(root, manifest, target):
    if manifest.get('schema') != 'git-backup/v1':
        raise ValueError('verification-requires-git-manifest')
    from git_verification import verify_git
    restore(root, manifest, target)
    return verify_git(target, manifest)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('bucket_root', type=Path)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('destination', type=Path)
    parser.add_argument('--verify', action='store_true', help='verify offline Git refs, bundle, metadata and reachable LFS bytes')
    args = parser.parse_args()
    manifest = json.loads(args.manifest.read_text())
    if args.verify:
        print(json.dumps(restore_and_verify(args.bucket_root, manifest, args.destination), sort_keys=True))
    else:
        restore(args.bucket_root, manifest, args.destination)

