#!/usr/bin/env python3
"""Interactive OAuth bootstrap. App keys pass through stdin, never command arguments."""
import argparse
import html
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
from pathlib import Path
import secrets
import shlex
import subprocess
import tempfile
import time
import urllib.parse
import webbrowser

from backup import app_jwt, github

ROOT = Path(__file__).resolve().parents[1]
WRANGLER = shlex.split(os.environ.get('WRANGLER', 'npx --yes wrangler@4'))


def run(args, data=None, capture=False):
    return subprocess.run(args, cwd=ROOT, input=data, text=True, check=True,
                          stdout=subprocess.PIPE if capture else None)


def wrangler(*args, data=None, capture=False):
    return run([*WRANGLER, *args], data, capture)


def gh_api(path, method='GET', body=None):
    args = ['gh', 'api', path, '--method', method]
    if body is not None:
        args += ['--input', '-']
    return json.loads(run(args, json.dumps(body) if body is not None else None, True).stdout or '{}')


def provision():
    config = json.loads((ROOT / 'wrangler.json').read_text())
    os.environ['CLOUDFLARE_ACCOUNT_ID'] = config['account_id']
    wrangler('login')
    existing = wrangler('r2', 'bucket', 'list', capture=True).stdout
    for bucket in ['backup-webhooks', 'backup-git', 'canon-images', 'image-hot']:
        if bucket not in existing:
            wrangler('r2', 'bucket', 'create', bucket, '--location', 'enam')
    for bucket in ['backup-git', 'canon-images']:
        existing_locks = wrangler('r2', 'bucket', 'lock', 'list', bucket, capture=True).stdout
        if 'retain-canonical' not in existing_locks:
            wrangler('r2', 'bucket', 'lock', 'add', bucket, 'retain-canonical', '', '--retention-indefinite', '--force')
        rules = wrangler('r2', 'bucket', 'lifecycle', 'list', bucket, capture=True).stdout
        if 'cold-after-30-days' not in rules:
            wrangler('r2', 'bucket', 'lifecycle', 'add', bucket, 'cold-after-30-days', 'objects/', '--ia-transition-days', '30', '--force')
    for bucket in ['backup-webhooks', 'backup-git', 'canon-images', 'image-hot']:
        rules = wrangler('r2', 'bucket', 'lifecycle', 'list', bucket, capture=True).stdout
        if 'abort-incomplete' not in rules:
            wrangler('r2', 'bucket', 'lifecycle', 'add', bucket, 'abort-incomplete', '', '--abort-multipart-days', '7', '--force')
    rules = wrangler('r2', 'bucket', 'lifecycle', 'list', 'image-hot', capture=True).stdout
    if 'expire-hot-after-30-days' in rules:
        wrangler('r2', 'bucket', 'lifecycle', 'remove', 'image-hot', 'expire-hot-after-30-days', '--force')
    locks = wrangler('r2', 'bucket', 'lock', 'list', 'image-hot', capture=True).stdout
    for name, prefix in [('retain-golden-artifacts', 'objects/'), ('retain-golden-manifests', 'manifests/'), ('retain-tag-history', 'tags/')]:
        if name not in locks:
            wrangler('r2', 'bucket', 'lock', 'add', 'image-hot', name, prefix, '--retention-indefinite', '--force')
    rules = wrangler('r2', 'bucket', 'lock', 'list', 'backup-webhooks', capture=True).stdout
    if 'retain-webhooks' not in rules:
        wrangler('r2', 'bucket', 'lock', 'add', 'backup-webhooks', 'retain-webhooks', 'events/', '--retention-indefinite', '--force')
    wrangler('deploy')


def app_registration(origin, owner):
    state = secrets.token_urlsafe(32)
    result = {}

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # Callback codes never enter an access log.

        def do_GET(self):
            u = urllib.parse.urlsplit(self.path)
            query = urllib.parse.parse_qs(u.query)
            if u.path == '/start' and query.get('state') == [state]:
                manifest = {
                    'name': owner + '-backup-control', 'url': origin,
                    'hook_attributes': {'url': origin + '/webhooks/github', 'active': True},
                    'redirect_url': callback, 'public': False,
                    'default_permissions': {'contents': 'read', 'metadata': 'read', 'issues': 'read', 'pull_requests': 'read', 'packages': 'read', 'actions': 'write'},
                    'default_events': ['push', 'create', 'delete', 'repository', 'release', 'registry_package'],
                }
                body = ('<!doctype html><meta charset="utf-8"><title>Backup setup</title>'
                        '<form method="post" action="https://github.com/settings/apps/new?state=' + state + '">'
                        '<input type="hidden" name="manifest" value="' + html.escape(json.dumps(manifest), quote=True) + '">'
                        '<button>Register your private backup GitHub App</button></form>').encode()
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Content-Security-Policy', "default-src 'none'; form-action https://github.com; frame-ancestors 'none'")
                self.end_headers()
                self.wfile.write(body)
                return
            if u.path == '/callback' and query.get('state') == [state] and len(query.get('code', [])) == 1:
                result['code'] = query['code'][0]
                self.send_response(200)
                self.send_header('Content-Type', 'text/plain')
                self.send_header('Cache-Control', 'no-store')
                self.end_headers()
                self.wfile.write(b'Registered. Return to your terminal; credentials are being configured automatically.')
                return
            self.send_response(404)
            self.end_headers()

    server = HTTPServer(('127.0.0.1', 0), Handler)
    server.timeout = 1
    callback = f'http://127.0.0.1:{server.server_port}/callback'
    start = f'http://127.0.0.1:{server.server_port}/start?state={state}'
    print('Opening GitHub App registration in your browser.', flush=True)
    webbrowser.open(start)
    print(start, flush=True)
    deadline = time.monotonic() + 3500
    while 'code' not in result:
        if time.monotonic() > deadline:
            server.server_close()
            raise RuntimeError('GitHub App registration timed out')
        server.handle_request()
    server.server_close()
    return gh_api('/app-manifests/' + result['code'] + '/conversions', 'POST')


def pkcs8(pem):
    return subprocess.run(['openssl', 'pkcs8', '-topk8', '-nocrypt'], input=pem, text=True, capture_output=True, check=True).stdout


def activate(resume_key=None, resume_id=None):
    config = json.loads((ROOT / 'wrangler.json').read_text())
    owner, full = config['vars']['GITHUB_OWNER'], config['vars']['CONTROL_REPO']
    origin = config['vars']['PUBLIC_ORIGIN']
    run(['gh', 'auth', 'status'])
    if gh_api('/user')['login'].lower() != owner.lower():
        raise RuntimeError('Select the susanbeasles GitHub account with gh auth switch before running setup.')
    found = subprocess.run(['gh', 'repo', 'view', full, '--json', 'isPrivate'], text=True, capture_output=True)
    if found.returncode:
        run(['gh', 'repo', 'create', full, '--private', '--description', 'Persistent Git and OCI backups to R2'])
    elif not json.loads(found.stdout)['isPrivate']:
        raise RuntimeError('Existing backup-control repository must be private; refusing to upload control code to an unexpected public repository.')
    if not (ROOT / '.git').exists():
        run(['git', 'init', '-b', 'main'])
        # Honor the user's configured signing and SSH transport.
        source = Path.home() / 'code/repoctl'
        if (source / '.git').exists():
            for key in ['user.name', 'user.email', 'user.signingkey', 'commit.gpgsign', 'tag.gpgsign', 'gpg.format', 'gpg.ssh.program', 'gpg.ssh.allowedSignersFile', 'core.sshCommand']:
                v = subprocess.run(['git', '-C', str(source), 'config', '--get', key], capture_output=True, text=True)
                if v.returncode == 0:
                    run(['git', 'config', '--local', key, v.stdout.strip()])
        remote = gh_api('/repos/' + full)['ssh_url']
        run(['git', 'remote', 'add', 'origin', remote])
    else:
        remote = run(['git', 'remote', 'get-url', 'origin'], capture=True).stdout.strip()
        if not remote.endswith(owner + '/backup-control.git'):
            raise RuntimeError('Unexpected Git origin; refusing to push.')
    run(['git', 'add', '.'])
    staged = subprocess.run(['git', 'diff', '--cached', '--quiet'], cwd=ROOT)
    if staged.returncode == 1:
        run(['git', 'commit', '-m', 'feat: persistent Git and OCI backups with durable webhooks'])
    run(['git', 'push', '-u', 'origin', 'main'])
    gh_api('/repos/' + full + '/environments/backup', 'PUT', {'deployment_branch_policy': {'protected_branches': False, 'custom_branch_policies': True}})
    policies = gh_api('/repos/' + full + '/environments/backup/deployment-branch-policies').get('branch_policies', [])
    if not any(p['name'] == 'main' for p in policies):
        gh_api('/repos/' + full + '/environments/backup/deployment-branch-policies', 'POST', {'name': 'main', 'type': 'branch'})
    if resume_key:
        pem = pkcs8(resume_key.read_text())
        app = github('/app', app_jwt(resume_id, pem))
        if app['owner']['login'].lower() != owner.lower():
            raise RuntimeError('App is owned by a different account')
        print('Resuming existing App. Existing Worker webhook secret is preserved.', flush=True)
    else:
        app = app_registration(origin, owner)
        pem = pkcs8(app['pem'])
    # Secrets are sent via stdin into each platform; none are saved into project files.
    app_secrets = {'GITHUB_APP_PRIVATE_KEY': pem, 'GITHUB_APP_ID': str(app['id'])}
    if app.get('webhook_secret'):
        app_secrets['WEBHOOK_SECRET'] = app['webhook_secret']
    for name, value in app_secrets.items():
        wrangler('secret', 'put', name, data=value)
    run(['gh', 'secret', 'set', 'BACKUP_APP_PRIVATE_KEY', '--repo', full, '--env', 'backup'], pem)
    run(['gh', 'variable', 'set', 'BACKUP_APP_ID', '--repo', full, '--env', 'backup', '--body', str(app['id'])])
    run(['gh', 'variable', 'set', 'BACKUP_ORIGIN', '--repo', full, '--env', 'backup', '--body', origin])
    webbrowser.open('https://github.com/apps/' + app['slug'] + '/installations/new')
    print('Install the App into your personal account with All repositories selected. Waiting for installation...', flush=True)
    deadline = time.monotonic() + 1800
    installation = None
    while not installation:
        installations = github('/app/installations', app_jwt(app['id'], pem))
        installation = next((i for i in installations if i['account']['login'].lower() == owner.lower()), None)
        if not installation:
            if time.monotonic() > deadline:
                raise RuntimeError('App installation timed out. App remains registered. Resume activation with a downloaded App private key; do not create a duplicate App.')
            time.sleep(5)
    if installation['repository_selection'] != 'all':
        raise RuntimeError('All repositories must be selected for complete automatic coverage.')
    wrangler('secret', 'put', 'GITHUB_INSTALLATION_ID', data=str(installation['id']))
    run(['gh', 'variable', 'set', 'BACKUP_INSTALLATION_ID', '--repo', full, '--env', 'backup', '--body', str(installation['id'])])
    run(['gh', 'workflow', 'run', 'backup.yml', '--repo', full])
    print('Infrastructure deployed; App installed; initial full backup dispatched. Check the workflow result to verify actual backup coverage.', flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cloud-only', action='store_true')
    parser.add_argument('--github-only', action='store_true')
    parser.add_argument('--resume-app-key', type=Path, help='Existing App private key PEM for interrupted activation')
    parser.add_argument('--app-id', help='App ID when resuming')
    args = parser.parse_args()
    if args.cloud_only and args.github_only:
        parser.error('Choose at most one setup phase')
    if bool(args.resume_app_key) != bool(args.app_id):
        parser.error('--resume-app-key and --app-id must be provided together')
    os.chdir(ROOT)
    if not args.github_only:
        provision()
    if not args.cloud_only:
        activate(args.resume_app_key.resolve() if args.resume_app_key else None, args.app_id)


if __name__ == '__main__':
    main()

