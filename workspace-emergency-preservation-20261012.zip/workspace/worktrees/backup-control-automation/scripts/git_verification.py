"""Offline verification of the Git evidence restored by restore.py."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile


def git(repository, *args, input_data=None):
    # Do not inherit caller Git configuration, credentials, or archived hooks/config.
    env = {'PATH': os.environ.get('PATH', ''), 'GIT_CONFIG_NOSYSTEM': '1',
           'GIT_CONFIG_GLOBAL': os.devnull, 'GIT_TERMINAL_PROMPT': '0', 'GIT_NO_LAZY_FETCH': '1'}
    command = ['git', '-c', 'protocol.allow=never', '-c', 'core.hooksPath=' + os.devnull,
               '--no-replace-objects', '--git-dir=' + str(repository), *map(str, args)]
    result = subprocess.run(command, env=env, input=input_data, capture_output=True)
    if result.returncode:
        raise ValueError('git-verification-failed')
    return result.stdout


def isolated_repository(mirror, destination, refs):
    # Only the object database and refs are read. Archived config is not trusted:
    # it could enable lazy fetching, external includes, helpers, or alternate paths.
    objects = mirror / 'objects'
    if not objects.is_dir() or (objects / 'info/alternates').exists() or (objects / 'info/http-alternates').exists():
        raise ValueError('unsafe-git-object-store')
    if list(objects.glob('pack/*.promisor')) or (mirror / 'shallow').exists():
        raise ValueError('incomplete-git-object-store')
    object_format = 'sha256' if refs and len(refs[0].split()[0]) == 64 else 'sha1'
    git(destination, 'init', '--bare', '--object-format=' + object_format, destination)
    # This alternate is generated from a local resolved path, never archive content.
    if '\n' in str(objects.resolve()):
        raise ValueError('unsafe-git-object-path')
    (destination / 'objects/info/alternates').write_text(str(objects.resolve()) + '\n')
    for name in ['HEAD', 'packed-refs']:
        if (mirror / name).is_file():
            shutil.copyfile(mirror / name, destination / name)
    if (mirror / 'refs').is_dir():
        shutil.copytree(mirror / 'refs', destination / 'refs', dirs_exist_ok=True)
    return destination


def repository_refs(repository):
    return git(repository, 'for-each-ref', '--format=%(objectname) %(refname)').decode().splitlines()


def verify_metadata(target, manifest):
    metadata = json.loads((target / 'metadata.json').read_text())
    for name in ['schema', 'snapshot', 'captured_at', 'refs', 'empty', 'release_assets']:
        if name not in manifest or metadata.get(name) != manifest[name]:
            raise ValueError('metadata-mismatch:' + name)
    repository = metadata.get('repository', {})
    if repository.get('full_name') != manifest.get('repository') or repository.get('id') != manifest.get('repository_id'):
        raise ValueError('metadata-mismatch:repository')
    fields = ['releases', 'pull_requests', 'pull_review_comments', 'release_assets']
    if repository.get('has_issues'):
        fields += ['issues_and_prs', 'issue_comments']
    for name in fields:
        if not isinstance(metadata.get(name), list):
            raise ValueError('missing-metadata-field:' + name)
    return fields


def parse_lfs_pointer(body):
    # Git LFS v3.6.1 lfs/pointer.go supports these version aliases, CRLF,
    # surrounding whitespace and empty lines. Extensions require a separate
    # transformation capability, so recognizable extensions fail closed.
    versions = {'https://git-lfs.github.com/spec/v1',
                'https://hawser.github.com/spec/v1', 'http://git-media.io/v/2'}
    try:
        text = body.decode('utf-8').strip()
    except UnicodeDecodeError:
        if any(('version ' + version).encode() in body for version in versions):
            raise ValueError('invalid-lfs-pointer')
        return None
    lines = [line.removesuffix('\r') for line in text.split('\n') if line.removesuffix('\r')]
    if not any(line.startswith('version ') and any(marker in line for marker in ['git-lfs', 'hawser', 'git-media']) for line in lines):
        return None
    if any(line.startswith('ext-') for line in lines):
        raise ValueError('unsupported-lfs-extension')
    if len(lines) != 3 or lines[0] not in {'version ' + version for version in versions}:
        raise ValueError('invalid-lfs-pointer')
    digest = re.fullmatch(r'oid sha256:([a-f0-9]{64})', lines[1])
    size = re.fullmatch(r'size ([-+]?[0-9]+)', lines[2])
    if not digest or not size or not 0 <= int(size[1]) <= 2**63 - 1:
        raise ValueError('invalid-lfs-pointer')
    return digest[1], int(size[1])


def reachable_lfs(repository):
    object_ids = [line.split()[0] for line in git(repository, 'rev-list', '--objects', '--all', '--no-object-names').decode('ascii').splitlines()]
    inventory = git(repository, 'cat-file', '--batch-check', input_data=('\n'.join(object_ids) + '\n').encode()) if object_ids else b''
    small_blobs = [oid for oid, kind, size in (line.split() for line in inventory.decode().splitlines())
                   if kind == 'blob' and int(size) <= 1024]
    contents = git(repository, 'cat-file', '--batch', input_data=('\n'.join(small_blobs) + '\n').encode()) if small_blobs else b''
    pointers = {}
    offset = 0
    for _ in small_blobs:
        end = contents.index(b'\n', offset)
        size = int(contents[offset:end].split()[2])
        body = contents[end + 1:end + 1 + size]
        offset = end + size + 2
        pointer = parse_lfs_pointer(body)
        if pointer is None:
            continue
        digest, size = pointer
        if digest in pointers and pointers[digest] != size:
            raise ValueError('conflicting-lfs-pointer')
        pointers[digest] = size
    return pointers


def verify_lfs(repository, mirror):
    pointers = reachable_lfs(repository)
    for digest, size in pointers.items():
        path = mirror / 'lfs/objects' / digest[:2] / digest[2:4] / digest
        if not path.is_file():
            raise ValueError('missing-lfs-object')
        with path.open('rb') as source:
            actual = hashlib.file_digest(source, 'sha256').hexdigest()
        if actual != digest or path.stat().st_size != size:
            raise ValueError('lfs-checksum-mismatch')
    return {'scope': 'all-reachable-history', 'objects': len(pointers)}


def verify_git(target, manifest):
    expected = manifest.get('refs')
    if not isinstance(expected, list) or any(not isinstance(ref, str) or not re.fullmatch(r'[a-f0-9]{40}(?:[a-f0-9]{24})? refs/\S+', ref) for ref in expected):
        raise ValueError('invalid-declared-refs')
    if len(expected) != len(set(expected)) or manifest.get('empty') is not (not bool(expected)):
        raise ValueError('invalid-declared-refs')
    mirror = target / 'repository.git'
    with tempfile.TemporaryDirectory(prefix='backup-verify-') as temporary:
        directory = Path(temporary)
        repository = isolated_repository(mirror, directory / 'mirror.git', expected)
        if sorted(repository_refs(repository)) != sorted(expected):
            raise ValueError('git-ref-mismatch')
        git(repository, 'fsck', '--full', '--strict')
        metadata_fields = verify_metadata(target, manifest)
        bundle = target / 'repository.bundle'
        bundle_status = 'not-required-empty-repository'
        if expected:
            if not bundle.is_file():
                raise ValueError('missing-git-bundle')
            # Verify in an empty repository: prerequisites cannot be borrowed from the mirror.
            bundle_repo = directory / 'bundle.git'
            git(bundle_repo, 'init', '--bare', '--object-format=' + ('sha256' if len(expected[0].split()[0]) == 64 else 'sha1'), bundle_repo)
            git(bundle_repo, 'bundle', 'verify', bundle.resolve())
            git(bundle_repo, '-c', 'protocol.file.allow=always', 'fetch', bundle.resolve(), '+refs/*:refs/*')
            if sorted(repository_refs(bundle_repo)) != sorted(expected):
                raise ValueError('bundle-ref-mismatch')
            git(bundle_repo, 'fsck', '--full', '--strict')
            bundle_status = 'verified'
        lfs = verify_lfs(repository, mirror)
    return {'schema': 'git-restore-verification/v1', 'status': 'verified', 'refs': len(expected),
            'git_fsck': 'verified', 'bundle': bundle_status, 'lfs': lfs, 'metadata_fields': sorted(metadata_fields),
            'release_assets': len(manifest['release_assets']),
            'scope': 'archived-evidence-only; remote completeness and excluded data are not verified'}
