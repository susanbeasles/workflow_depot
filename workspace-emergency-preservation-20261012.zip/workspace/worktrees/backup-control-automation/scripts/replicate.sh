#!/usr/bin/env bash
set -euo pipefail
# Provider-neutral copies, never sync/deletion. Credentials live in rclone's configured remotes.
source_remote=${1:?Usage: replicate.sh r2-remote: destination-remote:path}
target_remote=${2:?Usage: replicate.sh r2-remote: destination-remote:path}
command -v rclone >/dev/null
snapshot_dir=$(mktemp -d)
trap 'rm -rf "$snapshot_dir"' EXIT
for bucket in backup-git canon-images; do
  source_path="${source_remote%/}/${bucket}"
  target_path="${target_remote%/}/${bucket}"
  # Freeze metadata first. Its referenced objects already exist by the archive commit contract.
  rclone lsf "$source_path" --recursive --files-only --include 'manifests/**' --include 'tags/**' > "$snapshot_dir/metadata"
  rclone lsf "$source_path" --recursive --files-only --include 'objects/**' > "$snapshot_dir/objects"
  rclone copy "$source_path" "$target_path" --files-from "$snapshot_dir/objects" --immutable
  rclone check "$source_path" "$target_path" --files-from "$snapshot_dir/objects" --one-way --download
  # Publish exactly the frozen metadata, avoiding manifests created during the object transfer.
  rclone copy "$source_path" "$target_path" --files-from "$snapshot_dir/metadata" --immutable
  rclone check "$source_path" "$target_path" --files-from "$snapshot_dir/metadata" --one-way --download
done

