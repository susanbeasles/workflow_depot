#!/usr/bin/env python3
"""Consume an approved provisioner receipt and reuse the existing nondeleting replication script.

The trusted launcher owns configuration and authenticates the receipt before pinning its hash.
This program does not issue credentials, fetch jobs, unwrap encrypted KV, or install a scheduler.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import selectors
import signal
import stat
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / 'scripts' / 'replicate.sh'
OP = '/usr/local/bin/op'
RCLONE = '/usr/bin/rclone'
HEX = re.compile(r'[a-f0-9]{64}')
ID = re.compile(r'[a-z0-9]{26}')


def require(condition):
    if not condition:
        raise ValueError('replication-configuration-invalid')


def exact(value, names):
    return isinstance(value, dict) and set(value) == set(names)


def read_public_input(path):
    with Path(path).open('rb') as file:
        raw = file.read(65537)
    require(0 < len(raw) <= 65536)
    return raw


def parse_json(raw):
    def unique(pairs):
        out = {}
        for key, value in pairs:
            require(key not in out)
            out[key] = value
        return out
    require(isinstance(raw, bytes) and 0 < len(raw) <= 65536)
    try:
        return json.loads(raw, object_pairs_hook=unique)
    except (ValueError, UnicodeError):
        raise ValueError('replication-json-invalid') from None


def validate_transfer(config, schema):
    require(exact(config, ['schema', 'enabled', 'sourceRemote', 'sourceConfig', 'destination',
                           'credential', 'toolchain', 'timeoutSeconds']))
    require(config['schema'] == schema and config['enabled'] is True)
    source = config['sourceRemote']
    require(isinstance(source, str) and re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,63}:(?:[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*)?', source))
    require(source.split(':')[0].lower() != 'provisioned_b2')
    require(isinstance(config['sourceConfig'], str) and re.fullmatch(r'/[A-Za-z0-9_./-]+', config['sourceConfig']) and '..' not in config['sourceConfig'].split('/'))
    target = config['destination']
    require(exact(target, ['bucket', 'prefix']))
    require(isinstance(target['bucket'], str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9-]{5,62}', target['bucket']))
    require(isinstance(target['prefix'], str) and len(target['prefix']) <= 256 and re.fullmatch(r'[A-Za-z0-9_-]+(?:/[A-Za-z0-9_-]+)*', target['prefix']))
    require(exact(config['toolchain'], ['op', 'rclone', 'replicate']) and all(isinstance(v, str) and HEX.fullmatch(v) for v in config['toolchain'].values()))
    require(type(config['timeoutSeconds']) is int and 60 <= config['timeoutSeconds'] <= 7200)
    return {'source': source, 'destination': 'provisioned_b2:' + target['bucket'] + '/' + target['prefix']}


def validate(config, receipt_bytes):
    transfer = validate_transfer(config, 'backup-provisioned-replication/v1')
    credential = config['credential']
    require(exact(credential, ['jobId', 'itemId', 'vaultId', 'receiptSha256']))
    require(isinstance(credential['jobId'], str) and re.fullmatch(r'[A-Za-z0-9_-]{1,128}', credential['jobId']))
    require(all(isinstance(credential[k], str) and ID.fullmatch(credential[k]) for k in ['itemId', 'vaultId']))
    require(isinstance(credential['receiptSha256'], str) and HEX.fullmatch(credential['receiptSha256']))
    require(isinstance(receipt_bytes, bytes) and 0 < len(receipt_bytes) <= 65536)
    require(hashlib.sha256(receipt_bytes).hexdigest() == credential['receiptSha256'])
    receipt = parse_json(receipt_bytes)
    require(exact(receipt, ['id', 'state', 'provider', 'operation', 'createdAt', 'receipt']))
    require(receipt['id'] == credential['jobId'] and receipt['state'] == 'succeeded'
            and receipt['provider'] == 'b2' and receipt['operation'] == 'generate-api-key')
    require(type(receipt['createdAt']) is int and 0 < receipt['createdAt'] <= 9007199254740991)
    saved = receipt['receipt']
    require(isinstance(saved, dict) and {'itemId', 'vaultId'} <= set(saved)
            and set(saved) <= {'itemId', 'vaultId', 'recoveryId', 'kvId'})
    require(all(saved[k] == credential[k] for k in ['itemId', 'vaultId']))
    for key in ['kvId', 'recoveryId']:
        if key in saved:
            require(isinstance(saved[key], str) and re.fullmatch(r'[A-Za-z0-9:/_.-]{1,512}', saved[key]))
    item = 'op://' + credential['vaultId'] + '/' + credential['itemId']
    return {'keyIdRef': item + '/key_id', 'applicationKeyRef': item + '/application_key',
            'credentialItem': item, **transfer}


def file_digest(path):
    sha = hashlib.sha256()
    with open(path, 'rb') as file:
        while chunk := file.read(1024 * 1024):
            sha.update(chunk)
    return sha.hexdigest()


def verify_runtime(config):
    # Credentials already configured for the source are read by rclone only, never printed here.
    try:
        source = os.lstat(config['sourceConfig'])
        require(stat.S_ISREG(source.st_mode) and source.st_mode & 0o077 == 0 and source.st_uid in (0, os.geteuid()))
        for name, path in [('op', OP), ('rclone', RCLONE), ('replicate', SCRIPT)]:
            require(file_digest(path) == config['toolchain'][name])
            if name != 'replicate': require(os.access(path, os.X_OK))
    except (OSError, ValueError):
        raise ValueError('replication-runtime-unqualified') from None


def bounded_process(executable, arguments, *, env, timeout, max_bytes):
    process = None
    output = []
    size = 0
    deadline = time.monotonic() + timeout
    previous_term = None
    def interrupted(_signal, _frame):
        raise KeyboardInterrupt('interrupted')
    try:
        previous_term = signal.signal(signal.SIGTERM, interrupted)
        process = subprocess.Popen([executable, *arguments], env=env, stdin=subprocess.DEVNULL,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   shell=False, close_fds=True, start_new_session=True)
        with selectors.DefaultSelector() as selector:
            for pipe in (process.stdout, process.stderr):
                os.set_blocking(pipe.fileno(), False)
                selector.register(pipe, selectors.EVENT_READ)
            while selector.get_map():
                remaining = deadline - time.monotonic()
                if remaining <= 0: raise RuntimeError()
                for key, _ in selector.select(min(remaining, 0.1)):
                    chunk = os.read(key.fileobj.fileno(), 65536)
                    if not chunk:
                        selector.unregister(key.fileobj)
                        continue
                    size += len(chunk)
                    if size > max_bytes: raise RuntimeError()
                    if key.fileobj is process.stdout: output.append(chunk)
        if process.wait(timeout=max(0.001, deadline-time.monotonic())) != 0:
            raise RuntimeError()
        return b''.join(output)
    except BaseException:
        if process is not None:
            try: os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError: pass
            process.wait()
        raise RuntimeError('process-failed') from None
    finally:
        if previous_term is not None:
            signal.signal(signal.SIGTERM, previous_term)
        if process is not None:
            for pipe in (process.stdout, process.stderr):
                if pipe is not None: pipe.close()
        output.clear()


def replicate(config, receipt_bytes, *, token, execute=bounded_process):
    plan = validate(config, receipt_bytes)
    return {**execute_plan(config, plan, token=token, execute=execute),
            'provisionerJobId': config['credential']['jobId']}


def execute_plan(config, plan, *, token, execute=bounded_process):
    """Internal shared execution, reached only after the entrypoint validates its authority input."""
    verify_runtime(config)
    require(isinstance(token, str) and re.fullmatch(r'[\x21-\x7e]{1,8192}', token))
    credential = {}
    op_env = {}
    copy_env = {}
    try:
        with tempfile.TemporaryDirectory(prefix='backup-replication-') as directory:
            base = {'PATH': '/usr/bin:/bin', 'HOME': directory, 'TMPDIR': directory, 'LANG': 'C.UTF-8'}
            op_config = Path(directory) / 'op'; op_config.mkdir(mode=0o700)
            op_env = {**base, 'OP_SERVICE_ACCOUNT_TOKEN': token, 'OP_CONFIG_DIR': str(op_config),
                      'XDG_RUNTIME_DIR': directory, 'OP_CACHE': 'false'}
            for field, ref in [('account', plan['keyIdRef']), ('key', plan['applicationKeyRef'])]:
                value = execute(OP, ['read', ref, '--no-newline'], env=op_env, timeout=20, max_bytes=8192).decode('utf-8')
                require(re.fullmatch(r'[\x21-\x7e]{1,4096}', value))
                credential[field] = value
            op_env['OP_SERVICE_ACCOUNT_TOKEN'] = ''; token = ''
            copy_env = {**base, 'RCLONE_CONFIG': config['sourceConfig'],
                        'RCLONE_CONFIG_PROVISIONED_B2_TYPE': 'b2',
                        'RCLONE_CONFIG_PROVISIONED_B2_ACCOUNT': credential['account'],
                        'RCLONE_CONFIG_PROVISIONED_B2_KEY': credential['key'],
                        'RCLONE_CONFIG_PROVISIONED_B2_ENDPOINT': '',
                        'RCLONE_CONFIG_PROVISIONED_B2_DOWNLOAD_URL': '',
                        'RCLONE_CONFIG_PROVISIONED_B2_HARD_DELETE': 'false'}
            execute('/bin/bash', [str(SCRIPT), plan['source'], plan['destination']],
                    env=copy_env, timeout=config['timeoutSeconds'], max_bytes=1024*1024)
        return {'schema': 'backup-replication-receipt/v1', 'state': 'verified',
                'credentialItem': plan['credentialItem'],
                'sourceRemote': plan['source'], 'destination': plan['destination'],
                'buckets': ['backup-git', 'canon-images']}
    except Exception:
        raise RuntimeError('replication-runtime-failed') from None
    finally:
        token = ''; credential.clear(); op_env.clear(); copy_env.clear()


def read_token(fd=3):
    parts = []
    size = 0
    deadline = time.monotonic() + 5
    try:
        with selectors.DefaultSelector() as selector:
            selector.register(fd, selectors.EVENT_READ)
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0 or not selector.select(remaining): raise ValueError()
                chunk = os.read(fd, 8193)
                if not chunk: break
                size += len(chunk)
                if size > 8192: raise ValueError()
                parts.append(chunk)
        value = b''.join(parts).decode('utf-8')
        require(bool(value))
        return value
    except Exception:
        raise ValueError('credential-pipe-invalid') from None
    finally:
        os.close(fd)
        parts.clear()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--receipt', type=Path, required=True)
    parser.add_argument('--execute', action='store_true', help='Read the op token from private FD3 and run the approved copy')
    args = parser.parse_args()
    try:
        config = parse_json(read_public_input(args.config))
        receipt = read_public_input(args.receipt)
        validate(config, receipt)
        verify_runtime(config)
        result = replicate(config, receipt, token=read_token()) if args.execute else {'state': 'configuration-verified'}
        print(json.dumps(result, sort_keys=True))
    except Exception:
        print('{"state":"failed","code":"replication-unavailable"}')
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
