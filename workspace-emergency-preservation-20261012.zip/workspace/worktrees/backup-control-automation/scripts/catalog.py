#!/usr/bin/env python3
"""Export a searchable CSV from a downloaded or replicated bucket's manifests."""
import argparse
import csv
import json
import sys
from pathlib import Path


def rows(root):
    for path in sorted((root / 'manifests').rglob('*.json')):
        value = json.loads(path.read_text())
        schema = value.get('schema')
        common = {'snapshot': value.get('snapshot', ''), 'captured_at': value.get('captured_at', ''),
                  'manifest': path.relative_to(root).as_posix()}
        if schema == 'git-backup/v1':
            refs = value.get('refs', []) or [' ']
            for ref in refs:
                digest, _, name = ref.partition(' ')
                yield {**common, 'kind': 'git', 'repository': value['repository'],
                       'ref_or_tag': name, 'digest': digest,
                       'archive_key': value['archive'].get('key', '')}
        elif schema == 'oci-backup/v1':
            for tag in value.get('tags', []) or ['']:
                yield {**common, 'kind': 'oci', 'repository': value['image'],
                       'ref_or_tag': tag, 'digest': value['digest'], 'archive_key': ''}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('bucket', type=Path)
    parser.add_argument('--repository')
    parser.add_argument('--kind', choices=['git', 'oci'])
    parser.add_argument('--tag-or-ref')
    args = parser.parse_args()
    if not (args.bucket / 'manifests').is_dir():
        parser.error('bucket must contain a manifests directory')
    writer = csv.DictWriter(sys.stdout, fieldnames=['kind', 'repository', 'snapshot', 'captured_at',
                                                   'ref_or_tag', 'digest', 'archive_key', 'manifest'])
    writer.writeheader()
    for row in rows(args.bucket):
        if args.repository and row['repository'] != args.repository:
            continue
        if args.kind and row['kind'] != args.kind:
            continue
        if args.tag_or_ref and row['ref_or_tag'] != args.tag_or_ref:
            continue
        # Avoid spreadsheet formula execution from source-controlled tag/ref names.
        writer.writerow({key: "'" + str(value) if str(value).startswith(('=', '+', '-', '@', '\t', '\r')) else value
                         for key, value in row.items()})


if __name__ == '__main__':
    main()

