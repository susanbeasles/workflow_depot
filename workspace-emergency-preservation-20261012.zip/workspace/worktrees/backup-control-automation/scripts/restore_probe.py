"""Draft fixed-target read-only restore probe. Not published or production-run."""
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import urllib.request

SNAPSHOT='1791630745-38047579998-1'
MANIFEST_KEY='manifests/git/1412827677/'+SNAPSHOT+'.json'
MAX_BLOB=2*1024**3

def checked_origin(value):
    if value != 'https://backup.vespoli.me':
        raise ValueError('unapproved-backup-origin')
    return value

def descriptor(desc):
    sha=desc.get('sha256')
    size=desc.get('size')
    if not isinstance(sha,str) or not re.fullmatch('[a-f0-9]{64}',sha):
        raise ValueError('invalid-digest')
    key='objects/sha256/'+sha[:2]+'/'+sha
    if desc.get('key') != key or type(size) is not int or not 0 <= size <= MAX_BLOB:
        raise ValueError('invalid-object-descriptor')
    return sha,size,key

def save_blob(stream, desc, root):
    sha,size,key=descriptor(desc)
    target=root/key
    target.parent.mkdir(parents=True,exist_ok=True)
    h=hashlib.sha256()
    total=0
    with tempfile.NamedTemporaryFile(dir=target.parent) as f:
        while True:
            chunk=stream.read(min(1024**2,size-total+1))
            if not chunk:break
            total+=len(chunk)
            if total>size:raise ValueError('size-mismatch')
            h.update(chunk)
            f.write(chunk)
        if total != size or h.hexdigest() != sha:raise ValueError('checksum-mismatch')
        f.flush()
        # Exclusive creation; never overwrite an existing object or follow a symlink.
        with target.open('xb') as out, open(f.name,'rb') as src:
            while chunk:=src.read(1024**2):out.write(chunk)
    return target

def check_manifest(manifest, expected):
    if not re.fullmatch('[a-f0-9]{40}',expected or ''):
        raise ValueError('expected-main-commit-required')
    if (manifest.get('schema') != 'git-backup/v1' or
        manifest.get('repository_id') != 1412827677 or
        manifest.get('repository') != 'susanbeasles/ProsRUs' or
        manifest.get('snapshot') != SNAPSHOT or
        expected+' refs/heads/main' not in manifest.get('refs',[])):
        raise ValueError('manifest-identity-or-expected-ref-mismatch')

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):
        raise ValueError('restore-probe-redirect-refused')

def main():
    # Run only from the reviewed existing backup.yml job, with that job's OIDC identity.
    # The imported Store performs ordinary short-lived OIDC acquisition. It is never
    # asked for a GitHub token, upload, record write, dispatch, or credential change.
    import backup
    from restore import restore_and_verify
    backup.ORIGIN=checked_origin(os.environ.get('BACKUP_ORIGIN'))
    backup.OPENER=urllib.request.build_opener(NoRedirect())
    expected=os.environ.get('RESTORE_EXPECTED_MAIN','')
    if not re.fullmatch('[a-f0-9]{40}',expected):raise ValueError('expected-main-commit-required')
    store=backup.Store()
    with store.call('records/git/'+MANIFEST_KEY,'GET') as response:
        body=response.read(1024**2+1)
        if len(body)>1024**2:raise ValueError('manifest-too-large')
        manifest=json.loads(body)
    check_manifest(manifest,expected)
    values=[manifest['archive'],*manifest.get('release_assets',[])]
    if len(values)>1001:raise ValueError('too-many-assets')
    descriptions=[descriptor(v) for v in values]
    if sum(x[1] for x in descriptions)>MAX_BLOB:raise ValueError('restore-budget-exceeded')
    with tempfile.TemporaryDirectory(prefix='verified-restore-',dir=os.environ['RUNNER_TEMP']) as temp:
        root=Path(temp)/'bucket'
        root.mkdir()
        seen=set()
        for value,(sha,size,key) in zip(values,descriptions):
            if sha in seen:continue
            with store.call('objects/git/'+sha,'GET') as response:save_blob(response,value,root)
            seen.add(sha)
        report=restore_and_verify(root,manifest,Path(temp)/'restored')
        if report.get('status')!='verified':raise ValueError('restore-not-verified')
        # Only non-sensitive verification summary enters Actions logs. Never upload
        # archives, restored source, tokens, manifests or raw refs as artifacts.
        print(json.dumps({'schema':'fixed-restore-probe/v1','status':'verified',
            'repository_id':1412827677,'snapshot':SNAPSHOT,'expected_main':expected,
            'archive_sha256':manifest['archive']['sha256'],'objects_verified':len(seen),
            'bytes_verified':sum(x[1] for x in descriptions)},sort_keys=True))

if __name__=='__main__':main()
