#!/usr/bin/env python3
"""Git and OCI backups. No cloud storage credentials; the Worker accepts Actions OIDC."""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

CHUNK = 16 * 1024 * 1024
OWNER = os.environ.get('BACKUP_OWNER', 'susanbeasles')
ORIGIN = (os.environ.get('BACKUP_ORIGIN') or 'https://backup.vespoli.me').rstrip('/')
DIGEST = re.compile(r'^sha256:[a-f0-9]{64}$')


class SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if urllib.parse.urlsplit(newurl).scheme != 'https':
            raise RuntimeError('non-https-redirect')
        redirected = super().redirect_request(req, fp, code, msg, headers, newurl)
        if urllib.parse.urlsplit(req.full_url).netloc != urllib.parse.urlsplit(newurl).netloc:
            for name in ['Authorization', 'Cookie', 'X-Backup-Run']:
                redirected.remove_header(name)
        return redirected


class BackupRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise ValueError('backup-redirect-refused')


OPENER = urllib.request.build_opener(SafeRedirect())
BACKUP_OPENER = urllib.request.build_opener(BackupRedirect())


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()


def request(url, method='GET', data=None, headers=None, attempts=5, *, opener=None):
    headers = {'User-Agent': 'backup-control/1.0', **(headers or {})}
    for attempt in range(attempts):
        try:
            return (opener or OPENER).open(urllib.request.Request(url, data=data, method=method, headers=headers or {}), timeout=120)
        except urllib.error.HTTPError as e:
            if e.code not in (429, 500, 502, 503, 504) or attempt == attempts-1:
                raise
            time.sleep(min(30, 2 ** attempt))
        except (TimeoutError, urllib.error.URLError):
            if attempt == attempts-1:
                raise
            time.sleep(min(30, 2 ** attempt))


def github(path, token, data=None):
    headers = {'Authorization': 'Bearer ' + token, 'Accept': 'application/vnd.github+json', 'User-Agent': 'backup-control', 'X-GitHub-Api-Version': '2022-11-28'}
    if data is not None:
        headers['Content-Type'] = 'application/json'
    with request('https://api.github.com' + path, 'POST' if data is not None else 'GET', encode(data) if data is not None else None, headers) as r:
        return json.load(r)


def pages(path, token, field=None):
    result = []
    for page in range(1, 10001):
        values = github(path + ('&' if '?' in path else '?') + f'per_page=100&page={page}', token)
        values = values[field] if field else values
        result.extend(values)
        if len(values) < 100:
            return result
    raise RuntimeError('pagination-limit')


def app_jwt(app_id, pem):
    now = int(time.time())
    b64 = lambda b: base64.urlsafe_b64encode(b).rstrip(b'=')
    unsigned = b64(encode({'alg': 'RS256', 'typ': 'JWT'})) + b'.' + b64(encode({'iat': now-60, 'exp': now+540, 'iss': str(app_id)}))
    with tempfile.TemporaryDirectory() as d:
        key = Path(d) / 'key.pem'
        key.write_text(pem)
        key.chmod(0o600)
        signed = subprocess.run(['openssl', 'dgst', '-sha256', '-sign', str(key)], input=unsigned, capture_output=True, check=True).stdout
    return (unsigned + b'.' + b64(signed)).decode()


class App:
    def __init__(self, store=None):
        self.token = None
        self.expires = 0
        self.store = store

    def access(self):
        if time.time() > self.expires:
            if os.environ.get('BACKUP_APP_PRIVATE_KEY'):
                jwt = app_jwt(os.environ['BACKUP_APP_ID'], os.environ['BACKUP_APP_PRIVATE_KEY'])
                value = github(f"/app/installations/{os.environ['BACKUP_INSTALLATION_ID']}/access_tokens", jwt,
                               {'permissions': {'contents': 'read', 'metadata': 'read', 'issues': 'read', 'pull_requests': 'read'}})
            else:
                with self.store.call('github/token', 'POST', b'{}', {'Content-Type': 'application/json'}) as r:
                    value = json.load(r)
            self.token = value['token']
            self.expires = time.time() + 3000
            print('::add-mask::' + self.token, flush=True)
        return self.token


class Store:
    def __init__(self):
        if ORIGIN != 'https://backup.vespoli.me':
            raise ValueError('unapproved-backup-origin')
        self.token = None
        self.expires = 0

    def access(self):
        if time.time() > self.expires:
            url = os.environ['ACTIONS_ID_TOKEN_REQUEST_URL']
            url += ('&' if '?' in url else '?') + urllib.parse.urlencode({'audience': ORIGIN})
            with request(url, headers={'Authorization': 'Bearer ' + os.environ['ACTIONS_ID_TOKEN_REQUEST_TOKEN']}) as r:
                self.token = json.load(r)['value']
            self.expires = time.time() + 180
            print('::add-mask::' + self.token, flush=True)
        return self.token

    def call(self, path, method='GET', data=None, headers=None):
        h = {'Authorization': 'Bearer ' + self.access(), 'X-Backup-Run': os.environ.get('GITHUB_RUN_ID', 'local')}
        h.update(headers or {})
        return request(ORIGIN + '/api/' + path, method, data, h, opener=BACKUP_OPENER)

    def exists(self, tier, hash_value):
        try:
            with self.call(f'objects/{tier}/{hash_value}', 'HEAD'):
                return True
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return False
            raise

    def record(self, tier, key, value):
        with self.call(f'records/{tier}/{key}', 'PUT', encode(value), {'Content-Type': 'application/json'}) as r:
            json.load(r)
        return {'tier': tier, 'key': key}

    def blob(self, tier, path, expected=None):
        sha = hashlib.sha256()
        with Path(path).open('rb') as f:
            while chunk := f.read(CHUNK):
                sha.update(chunk)
        h = sha.hexdigest()
        if expected and h != expected:
            raise RuntimeError('source-checksum-mismatch')
        size = Path(path).stat().st_size
        if self.exists(tier, h):
            return {'sha256': h, 'size': size, 'key': f'objects/sha256/{h[:2]}/{h}'}
        if size <= 8*1024*1024:
            with self.call(f'objects/{tier}/{h}', 'PUT', Path(path).read_bytes()) as r:
                result = json.load(r)
        else:
            with self.call('uploads', 'POST', encode({'tier': tier, 'sha256': h, 'size': size}), {'Content-Type': 'application/json'}) as r:
                session = json.load(r)
            if session.get('exists'):
                return {'sha256': h, 'size': size, 'key': session['key']}
            parts = []
            with Path(path).open('rb') as f:
                while chunk := f.read(CHUNK):
                    with self.call(f"uploads/{session['id']}/{len(parts)+1}", 'PUT', chunk, {'X-Content-SHA256': hashlib.sha256(chunk).hexdigest()}) as r:
                        parts.append(json.load(r))
            with self.call(f"uploads/{session['id']}/complete", 'POST', encode(parts), {'Content-Type': 'application/json'}) as r:
                result = json.load(r)
        if not self.exists(tier, h):
            raise RuntimeError('upload-verification-failed')
        return {**result, 'size': size}


def git_environment(token):
    env = os.environ.copy()
    auth = base64.b64encode(('x-access-token:' + token).encode()).decode()
    env.update({'GIT_TERMINAL_PROMPT': '0', 'GIT_CONFIG_COUNT': '1', 'GIT_CONFIG_KEY_0': 'http.https://github.com/.extraheader', 'GIT_CONFIG_VALUE_0': 'AUTHORIZATION: basic ' + auth})
    return env


def git(args, token, cwd=None):
    # No credentials in process arguments, persisted remotes, or logs.
    return subprocess.run(['git', *args], env=git_environment(token), cwd=cwd, capture_output=True, check=True).stdout.decode().strip()


def archive_git(full_name, directory, token, preserve=()):
    if not re.fullmatch(r'[A-Za-z0-9-]+/[A-Za-z0-9_.-]+', full_name) or full_name.split('/')[0].lower() != OWNER.lower():
        raise ValueError('out-of-scope-repo')
    mirror = Path(directory) / 'repository.git'
    git(['clone', '--mirror', 'https://github.com/' + full_name + '.git', str(mirror)], token)
    for sha in dict.fromkeys(preserve):
        if not re.fullmatch(r'[a-f0-9]{40,64}', sha or '') or set(sha) == {'0'}:
            continue
        try:
            git(['cat-file', '-e', sha + '^{commit}'], token, mirror)
        except subprocess.CalledProcessError:
            git(['fetch', 'origin', sha], token, mirror)
        git(['update-ref', 'refs/backup/events/' + sha, sha], token, mirror)
    git(['fsck', '--full'], token, mirror)
    refs = git(['show-ref'], token, mirror) if git(['for-each-ref', '--format=%(refname)'], token, mirror) else ''
    # Fetch reachable LFS objects across every advertised ref; fail rather than silently archive pointers alone.
    if refs:
        git(['lfs', 'fetch', '--all', 'origin'], token, mirror)
        git(['bundle', 'create', str(Path(directory) / 'repository.bundle'), '--all'], token, mirror)
        git(['bundle', 'verify', str(Path(directory) / 'repository.bundle')], token, mirror)
    # The mirror and bundle contain no credential header; remove environment-specific hooks.
    shutil.rmtree(mirror / 'hooks', ignore_errors=True)
    return {'refs': refs.splitlines(), 'empty': not bool(refs)}


def backup_repo(store, app, repo, snapshot, event=None):
    full = repo['full_name']
    with tempfile.TemporaryDirectory() as d:
        metadata = archive_git(full, d, app.access(), [event.get('after'), event.get('before')] if event else [])
        metadata.update({'schema': 'git-backup/v1', 'repository': repo, 'snapshot': snapshot, 'captured_at': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())})
        token = app.access()
        metadata['releases'] = pages(f'/repos/{full}/releases', token)
        if repo.get('has_issues'):
            metadata['issues_and_prs'] = pages(f'/repos/{full}/issues?state=all', token)
            metadata['issue_comments'] = pages(f'/repos/{full}/issues/comments', token)
        metadata['pull_requests'] = pages(f'/repos/{full}/pulls?state=all', token)
        metadata['pull_review_comments'] = pages(f'/repos/{full}/pulls/comments', token)
        asset_refs = []
        for release in metadata['releases']:
            for asset in release.get('assets', []):
                path = Path(d) / ('asset-' + str(asset['id']))
                # urllib removes Authorization on redirects to the signed asset host.
                with request(f"https://api.github.com/repos/{full}/releases/assets/{asset['id']}", headers={'Authorization': 'Bearer ' + app.access(), 'Accept': 'application/octet-stream', 'User-Agent': 'backup-control'}) as r, path.open('wb') as f:
                    shutil.copyfileobj(r, f)
                asset_refs.append({'id': asset['id'], 'name': asset['name'], **store.blob('git', path)})
                path.unlink()
        metadata['release_assets'] = asset_refs
        (Path(d) / 'metadata.json').write_bytes(encode(metadata))
        archive = Path(d) / 'archive.tar'
        with tarfile.open(archive, 'w') as tar:
            for name in ['repository.git', 'repository.bundle', 'metadata.json']:
                if (Path(d) / name).exists():
                    tar.add(Path(d) / name, arcname=name)
        blob = store.blob('git', archive)
        manifest = {k: metadata[k] for k in ['schema', 'snapshot', 'captured_at', 'refs', 'empty']}
        manifest.update({'repository': full, 'repository_id': repo['id'], 'archive': blob, 'release_assets': asset_refs})
        return store.record('git', f"manifests/git/{repo['id']}/{snapshot}.json", manifest)


class Registry:
    def __init__(self, name):
        if not re.fullmatch(r'[a-z0-9._-]+(?:/[a-z0-9._-]+)+', name) or name.split('/')[0] != OWNER.lower():
            raise ValueError('out-of-scope-image')
        self.name = name
        self.refresh()

    def refresh(self):
        token = os.environ.get('GHCR_TOKEN') or os.environ.get('GITHUB_TOKEN')
        headers = {}
        if token:
            headers['Authorization'] = 'Basic ' + base64.b64encode((OWNER + ':' + token).encode()).decode()
        with request('https://ghcr.io/token?' + urllib.parse.urlencode({'service': 'ghcr.io', 'scope': f'repository:{self.name}:pull'}), headers=headers) as r:
            self.token = json.load(r)['token']

    def get(self, resource):
        for attempt in range(2):
            try:
                return request(f'https://ghcr.io/v2/{self.name}/{resource}', headers={'Authorization': 'Bearer ' + self.token,
                    'Accept': ','.join(['application/vnd.oci.image.index.v1+json', 'application/vnd.oci.image.manifest.v1+json', 'application/vnd.docker.distribution.manifest.list.v2+json', 'application/vnd.docker.distribution.manifest.v2+json'])})
            except urllib.error.HTTPError as e:
                if e.code != 401 or attempt:
                    raise
                self.refresh()


def webhook_tags(version):
    tags = list(version.get('metadata', {}).get('container', {}).get('tags', []))
    container = version.get('container_metadata', {})
    if isinstance(container, dict):
        tag = container.get('tag', {})
        if isinstance(tag, dict) and isinstance(tag.get('name'), str):
            tags.append(tag['name'])
        tags.extend(t for t in container.get('tags', []) if isinstance(t, str))
    return sorted(set(tags))


def backup_image(store, name, reference, snapshot, tags=()):
    if not (DIGEST.fullmatch(reference) or re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}', reference)):
        raise ValueError('invalid-image-reference')
    registry = Registry(name)
    seen = {}
    with tempfile.TemporaryDirectory() as d:
        def copy_blob(hash_value, response):
            if not DIGEST.fullmatch(hash_value):
                raise ValueError('unsupported-image-digest')
            path = Path(d) / hash_value[7:]
            with response as r, path.open('wb') as f:
                shutil.copyfileobj(r, f)
            result = store.blob('canon', path, hash_value[7:])
            store.blob('hot', path, hash_value[7:])
            seen[hash_value] = result
            path.unlink()

        def manifest(ref):
            with registry.get('manifests/' + urllib.parse.quote(ref, safe=':')) as r:
                body = r.read(16*1024*1024+1)
            if len(body) > 16*1024*1024:
                raise RuntimeError('manifest-too-large')
            hash_value = 'sha256:' + hashlib.sha256(body).hexdigest()
            if DIGEST.fullmatch(ref) and hash_value != ref:
                raise RuntimeError('manifest-checksum-mismatch')
            if hash_value in seen:
                return hash_value
            path = Path(d) / hash_value[7:]
            path.write_bytes(body)
            seen[hash_value] = store.blob('canon', path, hash_value[7:])
            store.blob('hot', path, hash_value[7:])
            path.unlink()
            value = json.loads(body)
            for desc in value.get('manifests', []):
                manifest(desc['digest'])
            for desc in [value.get('config'), *value.get('layers', []), *value.get('blobs', [])]:
                if desc and desc['digest'] not in seen:
                    # Fetch from GHCR only. Never follow a manifest-supplied external URL.
                    copy_blob(desc['digest'], registry.get('blobs/' + desc['digest']))
            return hash_value

        root = manifest(reference)
        value = {'schema': 'oci-backup/v1', 'image': 'ghcr.io/' + name, 'digest': root, 'reference': reference,
                 'snapshot': snapshot, 'tags': sorted(set(tags)), 'objects': seen}
        key = 'manifests/oci/' + name + '/' + snapshot + '.json'
        receipt = store.record('canon', key, value)
        store.record('hot', key, value)
        for tag in tags:
            if not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}', tag):
                raise ValueError('invalid-tag')
            key = f'tags/{name}/{tag}/{snapshot}.json'
            pointer = {'schema': 'image-tag/v1', 'image': name, 'tag': tag, 'digest': root, 'snapshot': snapshot}
            store.record('canon', key, pointer)
            store.record('hot', key, pointer)
        return receipt


def failure_details(error):
    # Do not serialize exception messages, response bodies, headers, URLs or tokens.
    details = {'error': type(error).__name__}
    if isinstance(error, urllib.error.HTTPError):
        details['http_status'] = error.code
    return details


def sweep(store, app, snapshot):
    receipts, failures = [], []
    repos = pages('/installation/repositories', app.access(), 'repositories')
    for repo in repos:
        if repo['owner']['login'].lower() != OWNER.lower():
            continue
        try:
            print('Backing up', repo['full_name'], flush=True)
            receipts.append(backup_repo(store, app, repo, snapshot))
        except Exception as e:
            failures.append({'repository': repo['full_name'], **failure_details(e)})
    packages = []
    try:
        package_token = os.environ.get('GHCR_TOKEN') or os.environ['GITHUB_TOKEN']
        packages = pages(f'/users/{OWNER}/packages?package_type=container', package_token)
    except Exception as e:
        failures.append({'inventory': 'containers', 'stage': 'list-packages', **failure_details(e)})
    for package in packages:
        stage = 'list-versions'
        try:
            name = package['name']
            versions = pages(f'/users/{OWNER}/packages/container/{urllib.parse.quote(name, safe="")}/versions', package_token)
            stage = 'validate-version'
            for version in versions:
                ref = version['name']
                if not DIGEST.fullmatch(ref):
                    raise RuntimeError('package-version-without-digest')
                tags = version.get('metadata', {}).get('container', {}).get('tags', [])
                try:
                    receipts.append(backup_image(store, OWNER.lower() + '/' + name, ref, snapshot + '-' + str(version['id']), tags))
                except Exception as e:
                    failures.append({'image': name, 'version_id': version['id'], **failure_details(e)})
        except Exception as e:
            failures.append({'inventory': 'containers', 'stage': stage, **failure_details(e)})
    store.record('git', f'manifests/sweeps/{snapshot}.json', {'schema': 'backup-sweep/v1', 'receipts': receipts, 'failures': failures, 'repository_count': len(repos)})
    if failures:
        print(json.dumps(failures), flush=True)
        raise RuntimeError('incomplete-backup-sweep')
    return receipts


def run():
    parser = argparse.ArgumentParser()
    parser.add_argument('--delivery', default='')
    parser.add_argument('--image', default='')
    args = parser.parse_args()
    store = Store()
    app = App(store)
    snapshot = f"{int(time.time())}-{os.environ.get('GITHUB_RUN_ID', uuid.uuid4().hex)}-{os.environ.get('GITHUB_RUN_ATTEMPT', '1')}"
    if args.image:
        name, sep, ref = args.image.removeprefix('ghcr.io/').partition('@')
        if not sep or not DIGEST.fullmatch(ref):
            raise ValueError('image-input-must-be-ghcr-name-at-sha256-digest')
        backup_image(store, name, ref, snapshot)
    elif args.delivery:
        if not re.fullmatch(r'[a-zA-Z0-9-]{1,100}', args.delivery):
            raise ValueError('invalid-delivery')
        with store.call('events/' + args.delivery) as r:
            event = json.load(r)
        p, kind = event['payload'], event['event']
        if kind in ('package', 'registry_package'):
            package = p.get('package') or p.get('registry_package')
            version = package['package_version']
            name = OWNER.lower() + '/' + package['name']
            ref = version.get('name', '')
            tags = webhook_tags(version)
            if not DIGEST.fullmatch(ref):
                # Resolve exact version ID; never fall back to a mutable tag.
                package_token = os.environ.get('GHCR_TOKEN') or os.environ['GITHUB_TOKEN']
                resolved = github(f'/users/{OWNER}/packages/container/{urllib.parse.quote(package["name"], safe="")}/versions/{version["id"]}', package_token)
                ref = resolved['name']
                tags = sorted(set(tags + resolved.get('metadata', {}).get('container', {}).get('tags', [])))
            receipts = [backup_image(store, name, ref, snapshot, tags)]
        elif p.get('repository') and kind not in ('installation', 'installation_repositories'):
            if kind == 'repository' and p.get('action') == 'deleted':
                raise RuntimeError('repository-already-deleted-previous-snapshots-retained')
            repo = github('/repos/' + p['repository']['full_name'], app.access())
            receipts = [backup_repo(store, app, repo, snapshot, p if kind == 'push' else None)]
        else:
            receipts = sweep(store, app, snapshot)
        with store.call('events/' + args.delivery + '/ack', 'POST', encode({'snapshot': snapshot, 'manifests': receipts}), {'Content-Type': 'application/json'}) as r:
            json.load(r)
    else:
        sweep(store, app, snapshot)


if __name__ == '__main__':
    run()
