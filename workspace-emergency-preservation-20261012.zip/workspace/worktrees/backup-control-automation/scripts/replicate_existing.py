#!/usr/bin/env python3
"""Consume independently owner-approved existing-item refs; never fabricate a provisioner receipt."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import replicate_provisioned as runtime

# Golden roles are intentionally absent: the unchanged copy/check path needs
# destination writes plus download verification, not a restore-only credential.
RW_BUCKET_LABELS = {'files', 'test', 'images', 'continuous', 'logs', 'backups', 'working'}


def field_reference(item, field):
    runtime.require(runtime.exact(field, ['id', 'sectionId']))
    valid = lambda value: isinstance(value, str) and re.fullmatch(r'[A-Za-z0-9_-]{1,128}', value)
    runtime.require(valid(field['id']) and (field['sectionId'] is None or valid(field['sectionId'])))
    return item + '/' + (field['sectionId'] + '/' if field['sectionId'] else '') + field['id']


def validate_existing(config_bytes, approved_config_sha256):
    # This hash comes from the trusted launcher's authenticated owner approval.
    # A caller-supplied hash beside caller-supplied JSON is NOT owner authority.
    runtime.require(isinstance(approved_config_sha256, str) and runtime.HEX.fullmatch(approved_config_sha256))
    runtime.require(isinstance(config_bytes, bytes) and 0 < len(config_bytes) <= 65536
                    and hashlib.sha256(config_bytes).hexdigest() == approved_config_sha256)
    config = runtime.parse_json(config_bytes)
    transfer = runtime.validate_transfer(config, 'backup-existing-item-replication/v1')
    credential = config['credential']
    runtime.require(runtime.exact(credential, ['vaultId', 'itemId', 'role', 'bucketLabel', 'bucketName', 'keyIdField', 'applicationKeyField']))
    runtime.require(all(isinstance(credential[key], str) and re.fullmatch(r'[a-z2-7]{26}', credential[key]) for key in ['vaultId', 'itemId']))
    runtime.require(credential['role'] == 'read-write' and isinstance(credential['bucketLabel'], str)
                    and credential['bucketLabel'] in RW_BUCKET_LABELS)
    runtime.require(credential['bucketName'] == config['destination']['bucket'])
    item = 'op://' + credential['vaultId'] + '/' + credential['itemId']
    key_id = field_reference(item, credential['keyIdField'])
    application_key = field_reference(item, credential['applicationKeyField'])
    runtime.require(key_id != application_key)
    return config, {**transfer, 'credentialItem': item, 'keyIdRef': key_id,
                    'applicationKeyRef': application_key, 'approvedConfigSha256': approved_config_sha256}


def replicate_existing(config_bytes, approved_config_sha256, *, token, execute=runtime.bounded_process):
    config, plan = validate_existing(config_bytes, approved_config_sha256)
    return {**runtime.execute_plan(config, plan, token=token, execute=execute),
            'credentialSource': 'owner-approved-existing-item', 'approvedConfigSha256': approved_config_sha256}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--approved-config-sha256', required=True)
    parser.add_argument('--execute', action='store_true', help='Use private FD3 after configuration and runtime verification')
    args = parser.parse_args()
    try:
        raw = runtime.read_public_input(args.config)
        config, _ = validate_existing(raw, args.approved_config_sha256)
        runtime.verify_runtime(config)
        result = replicate_existing(raw, args.approved_config_sha256, token=runtime.read_token()) if args.execute else {'state': 'configuration-verified'}
        print(json.dumps(result, sort_keys=True))
    except Exception:
        print('{"state":"failed","code":"replication-unavailable"}')
        return 1
    return 0


if __name__ == '__main__': sys.exit(main())
