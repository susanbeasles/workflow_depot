import contextlib, importlib.util, io, json, pathlib, unittest, urllib.error
from unittest.mock import patch
spec=importlib.util.spec_from_file_location('b',pathlib.Path(__file__).resolve().parents[1]/'scripts'/'backup.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
class SweepDiagnostic(unittest.TestCase):
 def test_container_http_failure_is_nonzero_and_records_safe_status(self):
  class Store:
   def __init__(self):self.recorded=[]
   def record(self,*args):self.recorded.append(args)
  class App:
   def access(self):return 'test-token'
  store=Store()
  e=urllib.error.HTTPError('https://api.github.com/users/secret/packages?token=hidden',403,'secret response',{},None)
  with patch.object(b,'pages',side_effect=[[],e]),patch.dict(b.os.environ,{'GITHUB_TOKEN':'test-token'}),self.assertRaisesRegex(RuntimeError,'incomplete-backup-sweep'):
   b.sweep(store,App(),'test-snapshot')
  self.assertEqual(store.recorded[0][2]['failures'],[{'inventory':'containers','stage':'list-packages','error':'HTTPError','http_status':403}])

 def run_fixture(self, package_pages):
  class Store:
   def __init__(self):self.recorded=[]
   def record(self,*args):self.recorded.append(args)
  class App:
   def access(self):return 'synthetic-app-token'
  store=Store()
  def github(path, token, data=None):
   self.assertIsNone(data)
   if path.startswith('/installation/repositories?'):
    return {'repositories': []}
   self.assertEqual(token,'synthetic-package-token')
   return package_pages(path)
  return store, App(), github

 def test_version_listing_failure_keeps_later_package_receipts_and_fails_sweep(self):
  first='/users/'+b.OWNER+'/packages?package_type=container&per_page=100&page=1'
  versions='/users/'+b.OWNER+'/packages/container/'
  def package_pages(path):
   if path==first:return [{'name':'unavailable'},{'name':'available'}]
   if path==versions+'unavailable/versions?per_page=100&page=1':
    raise urllib.error.HTTPError('https://api.github.com/private?token=DO_NOT_LOG',400,'DO_NOT_LOG',{'Secret':'DO_NOT_LOG'},io.BytesIO(b'DO_NOT_LOG'))
   if path==versions+'available/versions?per_page=100&page=1':
    return [{'id':7,'name':'sha256:'+'a'*64,'metadata':{'container':{'tags':['latest']}}}]
   self.fail('unexpected fixture endpoint')
  store,app,github=self.run_fixture(package_pages)
  receipt={'tier':'canon','key':'manifests/oci/available/fixture.json'}
  with patch.object(b,'github',side_effect=github),patch.object(b,'backup_image',return_value=receipt),patch.dict(b.os.environ,{'GHCR_TOKEN':'synthetic-package-token','GITHUB_TOKEN':'DO_NOT_LOG'}),contextlib.redirect_stdout(io.StringIO()) as output:
   with self.assertRaisesRegex(RuntimeError,'incomplete-backup-sweep'):b.sweep(store,app,'fixture')
  manifest=store.recorded[0][2]
  self.assertEqual(manifest['receipts'],[receipt])
  self.assertEqual(manifest['failures'],[{'inventory':'containers','stage':'list-versions','error':'HTTPError','http_status':400}])
  self.assertNotIn('DO_NOT_LOG',output.getvalue()+json.dumps(manifest))
  self.assertNotIn('synthetic-package-token',output.getvalue()+json.dumps(manifest))

 def test_invalid_version_is_distinguished_and_does_not_hide_later_packages(self):
  def package_pages(path):
   if '?package_type=container&' in path:return [{'name':'bad-version'},{'name':'empty'}]
   if '/bad-version/versions?' in path:return [{'id':1,'name':'latest'}]
   if '/empty/versions?' in path:return []
   self.fail('unexpected fixture endpoint')
  store,app,github=self.run_fixture(package_pages)
  with patch.object(b,'github',side_effect=github),patch.dict(b.os.environ,{'GHCR_TOKEN':'synthetic-package-token'}),contextlib.redirect_stdout(io.StringIO()):
   with self.assertRaisesRegex(RuntimeError,'incomplete-backup-sweep'):b.sweep(store,app,'fixture')
  self.assertEqual(store.recorded[0][2]['failures'],[{'inventory':'containers','stage':'validate-version','error':'RuntimeError'}])

 def test_successful_empty_inventory_remains_successful(self):
  store,app,github=self.run_fixture(lambda path:[])
  with patch.object(b,'github',side_effect=github),patch.dict(b.os.environ,{'GHCR_TOKEN':'synthetic-package-token'}):
   self.assertEqual(b.sweep(store,app,'fixture'),[])
  self.assertEqual(store.recorded[0][2]['failures'],[])
if __name__=='__main__':unittest.main()
