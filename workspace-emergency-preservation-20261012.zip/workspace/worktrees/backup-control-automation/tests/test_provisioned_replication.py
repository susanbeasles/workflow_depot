import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

PATH = Path(__file__).resolve().parents[1] / 'scripts' / 'replicate_provisioned.py'
spec = importlib.util.spec_from_file_location('replicate_provisioned', PATH) if PATH.exists() else None
adapter = importlib.util.module_from_spec(spec) if spec else None
if spec:
    spec.loader.exec_module(adapter)


def fixture():
    receipt = {'id': '11111111-1111-4111-8111-111111111111', 'state': 'succeeded', 'provider': 'b2', 'operation': 'generate-api-key', 'createdAt': 1700000000, 'receipt': {'itemId': 'b'*26, 'vaultId': 'a'*26, 'recoveryId': 'r2://fixture/capture/job.json'}}
    raw = json.dumps(receipt).encode()
    config = {'schema': 'backup-provisioned-replication/v1', 'enabled': True,
              'sourceRemote': 'existing_r2:', 'sourceConfig': '/run/backup/rclone.conf',
              'destination': {'bucket': 'fixture-existing-bucket', 'prefix': 'archives'},
              'credential': {'jobId': receipt['id'], 'itemId': receipt['receipt']['itemId'], 'vaultId': receipt['receipt']['vaultId'],
                             'receiptSha256': hashlib.sha256(raw).hexdigest()},
              'toolchain': {'op': '1'*64, 'rclone': '2'*64, 'replicate': '3'*64},
              'timeoutSeconds': 3600}
    return config, raw


class ProvisionedReplication(unittest.TestCase):
    def test_contract_requires_exact_success_receipt_and_immutable_ids(self):
        self.assertTrue(callable(getattr(adapter, 'validate', None)))
        config, raw = fixture()
        plan = adapter.validate(config, raw)
        self.assertEqual(plan['keyIdRef'], 'op://'+'a'*26+'/'+'b'*26+'/key_id')
        self.assertEqual(plan['applicationKeyRef'], 'op://'+'a'*26+'/'+'b'*26+'/application_key')
        self.assertEqual(plan['destination'], 'provisioned_b2:fixture-existing-bucket/archives')
        for change in [lambda c: c.update(enabled=False), lambda c: c['credential'].update(vaultId='mutable-name'),
                       lambda c: c['credential'].update(receiptSha256='0'*64),
                       lambda c: c['destination'].update(prefix='../outside'),
                       lambda c: c.update(sourceRemote=':http:https://untrusted.example'),
                       lambda c: c.update(sourceRemote='provisioned_b2:')]:
            changed = copy.deepcopy(config)
            change(changed)
            with self.assertRaises(ValueError):
                adapter.validate(changed, raw)
        flat = json.dumps({'jobId': config['credential']['jobId'], 'state': 'succeeded', 'itemId': 'b'*26, 'vaultId': 'a'*26}).encode()
        changed = copy.deepcopy(config); changed['credential']['receiptSha256'] = hashlib.sha256(flat).hexdigest()
        with self.assertRaises(ValueError): adapter.validate(changed, flat)
        for state in ['accepted', 'uncertain', 'recovery-required']:
            bad = json.loads(raw); bad['state'] = state; encoded = json.dumps(bad).encode()
            changed = copy.deepcopy(config); changed['credential']['receiptSha256'] = hashlib.sha256(encoded).hexdigest()
            with self.assertRaises(ValueError): adapter.validate(changed, encoded)

    def test_runtime_reads_only_two_provisioned_fields_and_never_passes_op_token_to_copy_process(self):
        self.assertTrue(callable(getattr(adapter, 'replicate', None)))
        config, raw = fixture(); calls = []
        def execute(executable, arguments, *, env, timeout, max_bytes):
            calls.append((executable, arguments, dict(env)))
            if executable == '/usr/local/bin/op':
                self.assertEqual(env['OP_SERVICE_ACCOUNT_TOKEN'], 'SYNTHETIC-OP')
                self.assertEqual(arguments[0], 'read'); self.assertEqual(arguments[-1], '--no-newline')
                return b'SYNTHETIC-ID' if arguments[1].endswith('/key_id') else b'SYNTHETIC-KEY'
            self.assertEqual(executable, '/bin/bash')
            self.assertNotIn('OP_SERVICE_ACCOUNT_TOKEN', env)
            self.assertEqual(env['RCLONE_CONFIG_PROVISIONED_B2_ACCOUNT'], 'SYNTHETIC-ID')
            self.assertEqual(env['RCLONE_CONFIG_PROVISIONED_B2_KEY'], 'SYNTHETIC-KEY')
            self.assertNotIn('SYNTHETIC', repr(arguments))
            self.assertEqual(arguments[1:], ['existing_r2:', 'provisioned_b2:fixture-existing-bucket/archives'])
            return b''
        with patch.object(adapter, 'verify_runtime', return_value=None):
            result = adapter.replicate(config, raw, token='SYNTHETIC-OP', execute=execute)
        self.assertEqual(len(calls), 3); self.assertEqual(result['state'], 'verified')
        self.assertNotIn('SYNTHETIC', json.dumps(result))
        self.assertEqual(result['credentialItem'], 'op://'+'a'*26+'/'+'b'*26)
        self.assertFalse(Path(calls[0][2]['HOME']).exists())

    def test_unqualified_input_or_failed_read_never_reaches_replication_and_errors_are_redacted(self):
        self.assertTrue(callable(getattr(adapter, 'replicate', None)))
        config, raw = fixture(); calls = []
        def bad(*args, **kwargs): calls.append(args); raise RuntimeError('SYNTHETIC-PRIVATE-BODY')
        changed = copy.deepcopy(config); changed['enabled'] = False
        with self.assertRaises(ValueError): adapter.replicate(changed, raw, token='SYNTHETIC', execute=bad)
        self.assertEqual(calls, [])
        with patch.object(adapter, 'verify_runtime', return_value=None):
            with self.assertRaisesRegex(RuntimeError, '^replication-runtime-failed$'):
                adapter.replicate(config, raw, token='SYNTHETIC', execute=bad)
        self.assertEqual(len(calls), 1)

    def test_bounded_process_rejects_timeout_and_output_without_including_child_values(self):
        self.assertTrue(callable(getattr(adapter, 'bounded_process', None)))
        import sys
        for code, timeout, limit in [('import time; time.sleep(2)', .05, 1024),
                                     ("print('SYNTHETIC-PRIVATE'*1000)", 2, 32),
                                     ("import sys; sys.stderr.write('SYNTHETIC-PRIVATE'); sys.exit(1)", 2, 1024)]:
            with self.assertRaisesRegex(RuntimeError, '^process-failed$'):
                adapter.bounded_process(sys.executable, ['-c', code], env={'PATH':'/usr/bin:/bin'}, timeout=timeout, max_bytes=limit)

    def test_tool_and_existing_source_configuration_pins_fail_before_op(self):
        self.assertTrue(callable(getattr(adapter, 'verify_runtime', None)))
        config, _ = fixture()
        with tempfile.TemporaryDirectory() as d:
            conf = Path(d)/'rclone.conf'; conf.write_text('synthetic source config'); conf.chmod(0o600)
            config['sourceConfig'] = str(conf)
            with self.assertRaises(ValueError): adapter.verify_runtime(config)
            conf.chmod(0o644)
            with self.assertRaises(ValueError): adapter.verify_runtime(config)


    def test_private_fd_token_is_consumed_and_closed_without_environment_fallback(self):
        self.assertTrue(callable(getattr(adapter, 'read_token', None)))
        read_fd, write_fd = os.pipe()
        os.write(write_fd, b'SYNTHETIC-FD-TOKEN'); os.close(write_fd)
        self.assertEqual(adapter.read_token(read_fd), 'SYNTHETIC-FD-TOKEN')
        with self.assertRaises(OSError): os.fstat(read_fd)

    def test_public_input_reader_rejects_oversized_configuration_before_parsing(self):
        self.assertTrue(callable(getattr(adapter, 'read_public_input', None)))
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'fixture.json'; path.write_bytes(b'x'*65537)
            with self.assertRaises(ValueError): adapter.read_public_input(path)
            path.write_bytes(b'{}'); self.assertEqual(adapter.read_public_input(path), b'{}')


class OwnerStatusComposition(unittest.TestCase):
    def test_actual_owner_status_output_is_consumed_without_flattening_or_extra_trust_claims(self):
        import subprocess
        root = Path(__file__).resolve().parents[1]
        embedded = root.parent.name == 'workers'
        # The canonical repository must exercise its own owner API, even if an
        # unrelated cross-repository override exists in the test environment.
        source = root.parents[1] / 'src' / 'provisioner.mjs' if embedded else os.environ.get('PROVISIONER_CONTRACT_SOURCE')
        if source is None:
            self.skipTest('set PROVISIONER_CONTRACT_SOURCE to the reviewed personal-control src/provisioner.mjs for cross-repository composition')
        self.assertTrue(Path(source).is_file(), 'actual provisioner owner-status implementation is required')
        config, _ = fixture()
        script = """
import {pathToFileURL} from 'node:url';
const {createProvisioner}=await import(pathToFileURL(process.argv[1]));
const owner='synthetic-owner',job={id:'11111111-1111-4111-8111-111111111111',owner,state:'succeeded',provider:'b2',operation:'generate-api-key',createdAt:1700000000,receipt:{itemId:'b'.repeat(26),vaultId:'a'.repeat(26),recoveryId:'r2://fixture/capture/job.json'}};
const core=createProvisioner({storage:{get:async key=>key==='provisioner:job:'+job.id?job:null},profiles:[]});
process.stdout.write(JSON.stringify(await core.status(owner,job.id)));
"""
        result = subprocess.run(['node', '--input-type=module', '-e', script, str(source)],
                                capture_output=True, timeout=10, check=True)
        config['credential']['receiptSha256'] = hashlib.sha256(result.stdout).hexdigest()
        plan = adapter.validate(config, result.stdout)
        self.assertEqual(plan['keyIdRef'], 'op://'+'a'*26+'/'+'b'*26+'/key_id')


if __name__ == '__main__':
    unittest.main()
