import test from 'node:test';
import assert from 'node:assert/strict';
import {generateKeyPairSync} from 'node:crypto';
import {BootstrapCore,privateKeyBytes} from '../src/setup-core.mjs';
test('GitHub PKCS1 key converts into importable PKCS8 and signs correctly',async()=>{
  const {privateKey}=generateKeyPairSync('rsa',{modulusLength:2048});
  const pem=privateKey.export({type:'pkcs1',format:'pem'});
  const key=await crypto.subtle.importKey('pkcs8',privateKeyBytes(pem),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign']);
  assert.ok((await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,new TextEncoder().encode('probe'))).byteLength>0);
});
test('public setup router never exposes internal configuration',async()=>{
  const core=new BootstrapCore({storage:{}},{});const r=await core.fetch(new Request('https://setup/start'));
  assert.equal(r.status,404);
});

