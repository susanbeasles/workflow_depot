import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
PATH = ROOT / 'scripts' / 'replicate_existing.py'
spec = importlib.util.spec_from_file_location('replicate_existing', PATH) if PATH.exists() else None
adapter = importlib.util.module_from_spec(spec) if spec else None
if spec: spec.loader.exec_module(adapter)


def fixture():
    return {'schema': 'backup-existing-item-replication/v1', 'enabled': True,
            'sourceRemote': 'existing_r2:', 'sourceConfig': '/run/backup/rclone.conf',
            'destination': {'bucket': 'fixture-backups', 'prefix': 'archives'},
            'credential': {'vaultId': 'a'*26, 'itemId': 'b'*26, 'role': 'read-write',
                           'bucketLabel': 'backups', 'bucketName': 'fixture-backups',
                           'keyIdField': {'id': 'account_id', 'sectionId': None},
                           'applicationKeyField': {'id': 'credential_value', 'sectionId': 'c'*26}},
            'toolchain': {'op': '1'*64, 'rclone': '2'*64, 'replicate': '3'*64},
            'timeoutSeconds': 3600}


def encoded(config):
    raw = json.dumps(config).encode()
    return raw, hashlib.sha256(raw).hexdigest()


class ExistingItemReplication(unittest.TestCase):
    def test_owner_approved_exact_config_accepts_existing_ids_without_fabricating_a_receipt(self):
        self.assertTrue(callable(getattr(adapter, 'validate_existing', None)))
        raw, digest = encoded(fixture()); config, plan = adapter.validate_existing(raw, digest)
        self.assertEqual(plan['keyIdRef'], 'op://'+'a'*26+'/'+'b'*26+'/account_id')
        self.assertEqual(plan['applicationKeyRef'], 'op://'+'a'*26+'/'+'b'*26+'/'+'c'*26+'/credential_value')
        self.assertEqual(plan['approvedConfigSha256'], digest)
        self.assertNotIn('jobId', config['credential'])
        self.assertNotIn('provisionerJobId', plan)

    def test_unapproved_tampered_disabled_or_unresolved_metadata_denies_before_op(self):
        self.assertTrue(callable(getattr(adapter, 'validate_existing', None)))
        raw, digest = encoded(fixture())
        for bad_digest in [None, '', '0'*64]:
            with self.assertRaises(ValueError): adapter.validate_existing(raw, bad_digest)
        with self.assertRaises(ValueError): adapter.validate_existing(raw+b' ', digest)
        for change in [lambda c: c.update(enabled=False), lambda c: c['credential'].update(itemId='mutable-name'),
                       lambda c: c['credential']['keyIdField'].update(id=None),
                       lambda c: c['credential']['applicationKeyField'].update(id='label with spaces'),
                       lambda c: c['credential']['applicationKeyField'].update(sectionId='../other'),
                       lambda c: c['credential']['keyIdField'].update(id='field?attribute=otp'),
                       lambda c: c['credential'].update(bucketName='different-bucket'),
                       lambda c: c['credential'].update(applicationKeyField=c['credential']['keyIdField']),
                       lambda c: c['credential'].update(receiptSha256='f'*64)]:
            config=fixture(); change(config)
            with self.assertRaises(ValueError): adapter.validate_existing(*encoded(config))

    def test_golden_reader_writer_and_fallback_aliases_never_enter_rw_replication(self):
        self.assertTrue(callable(getattr(adapter, 'replicate_existing', None)))
        for label, role in [('GOLDEN','restore-reader'),('GOLDEN','capture-writer'),('GOLDEN','read-write'),('backups','restore-reader'),('backups','capture-writer')]:
            config=fixture();config['credential'].update(bucketLabel=label,role=role);calls=[]
            with self.assertRaises(ValueError): adapter.replicate_existing(*encoded(config), token='SYNTHETIC', execute=lambda *args,**kwargs:calls.append(args))
            self.assertEqual(calls, [])

    def test_existing_fields_use_same_bounded_fd_token_route_without_op_token_in_rclone(self):
        self.assertTrue(callable(getattr(adapter, 'replicate_existing', None)))
        raw,digest=encoded(fixture());calls=[]
        def execute(program,args,*,env,timeout,max_bytes):
            calls.append((program,args,dict(env)))
            if program==adapter.runtime.OP:
                self.assertEqual(env['OP_SERVICE_ACCOUNT_TOKEN'],'SYNTHETIC-OP')
                return b'SYNTHETIC-ID' if args[1].endswith('/account_id') else b'SYNTHETIC-KEY'
            self.assertEqual(program,'/bin/bash');self.assertNotIn('OP_SERVICE_ACCOUNT_TOKEN',env)
            self.assertEqual(env['RCLONE_CONFIG_PROVISIONED_B2_ACCOUNT'],'SYNTHETIC-ID')
            self.assertEqual(env['RCLONE_CONFIG_PROVISIONED_B2_KEY'],'SYNTHETIC-KEY')
            self.assertEqual(args[1:],['existing_r2:','provisioned_b2:fixture-backups/archives'])
            self.assertNotIn('SYNTHETIC',repr(args));return b''
        with patch.object(adapter.runtime,'verify_runtime',return_value=None):
            result=adapter.replicate_existing(raw,digest,token='SYNTHETIC-OP',execute=execute)
        self.assertEqual(len(calls),3);self.assertEqual(result['credentialSource'],'owner-approved-existing-item')
        self.assertEqual(result['approvedConfigSha256'],digest);self.assertNotIn('provisionerJobId',result)
        self.assertNotIn('SYNTHETIC',json.dumps(result));self.assertFalse(Path(calls[0][2]['HOME']).exists())

    def test_failed_existing_item_read_is_redacted_and_never_runs_copy(self):
        self.assertTrue(callable(getattr(adapter, 'replicate_existing', None)))
        calls=[]
        def denied(*args,**kwargs):calls.append(args);raise RuntimeError('SYNTHETIC-PRIVATE')
        with patch.object(adapter.runtime,'verify_runtime',return_value=None):
            with self.assertRaisesRegex(RuntimeError,'^replication-runtime-failed$'):
                adapter.replicate_existing(*encoded(fixture()),token='SYNTHETIC',execute=denied)
        self.assertEqual(len(calls),1)


if __name__=='__main__': unittest.main()
