"""Real rclone runs use generated local directories and an empty credential configuration only."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


@unittest.skipUnless(Path('/usr/bin/rclone').is_file(), 'local rclone is unavailable')
class LocalReplication(unittest.TestCase):
    def fixture(self, directory):
        root = Path(directory)
        source, target = root/'source', root/'target'
        for bucket in ['backup-git', 'canon-images']:
            data = ('synthetic archive for '+bucket).encode()
            sha = hashlib.sha256(data).hexdigest()
            path = Path('objects')/'sha256'/sha[:2]/sha
            (source/bucket/path).parent.mkdir(parents=True)
            (source/bucket/path).write_bytes(data)
            (source/bucket/'manifests').mkdir()
            (source/bucket/'manifests'/'fixture.json').write_text(json.dumps({'object': str(path)}))
        target.mkdir()
        (target/'unrelated-retained-object').write_bytes(b'keep')
        return source, target

    def run_script(self, source, target, directory):
        env = {'PATH': '/usr/bin:/bin', 'HOME': directory, 'TMPDIR': directory,
               'RCLONE_CONFIG': '/dev/null', 'LANG': 'C.UTF-8'}
        return subprocess.run(['/bin/bash', str(ROOT/'scripts'/'replicate.sh'), str(source), str(target)],
                              env=env, text=True, capture_output=True, timeout=30, check=False)

    def test_real_local_copy_and_download_checks_preserve_objects_metadata_and_unrelated_destination_data(self):
        with tempfile.TemporaryDirectory(prefix='backup-local-copy-') as directory:
            source, target = self.fixture(directory)
            result = self.run_script(source, target, directory)
            self.assertEqual(result.returncode, 0, result.stderr)
            for path in source.rglob('*'):
                if path.is_file(): self.assertEqual(path.read_bytes(), (target/path.relative_to(source)).read_bytes())
            self.assertEqual((target/'unrelated-retained-object').read_bytes(), b'keep')

    def test_immutable_object_mismatch_blocks_metadata_publication_and_leaves_prior_data(self):
        with tempfile.TemporaryDirectory(prefix='backup-local-conflict-') as directory:
            source, target = self.fixture(directory)
            original = next(p for p in (source/'backup-git'/'objects').rglob('*') if p.is_file())
            existing = target/original.relative_to(source)
            existing.parent.mkdir(parents=True)
            existing.write_bytes(b'corrupt immutable bytes with different length')
            result = self.run_script(source, target, directory)
            self.assertNotEqual(result.returncode, 0)
            self.assertFalse((target/'backup-git'/'manifests'/'fixture.json').exists())
            self.assertFalse((target/'canon-images'/'manifests'/'fixture.json').exists())
            self.assertEqual(existing.read_bytes(), b'corrupt immutable bytes with different length')
            self.assertEqual((target/'unrelated-retained-object').read_bytes(), b'keep')


if __name__ == '__main__':
    unittest.main()
