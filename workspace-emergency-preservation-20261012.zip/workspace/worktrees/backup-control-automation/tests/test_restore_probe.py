import hashlib
import io
import tempfile
from pathlib import Path
import unittest
import restore_probe as p

class ProbeTests(unittest.TestCase):
    def test_origin_requires_exact_migrated_https_host(self):
        self.assertEqual(p.checked_origin('https://backup.vespoli.me'), 'https://backup.vespoli.me')
        for value in ['https://backup-control.anthonyvespoli.workers.dev', 'http://backup.vespoli.me', 'https://backup.vespoli.me.evil.test', 'https://u:p@backup.vespoli.me', 'https://backup.vespoli.me/path']:
            with self.assertRaises(ValueError): p.checked_origin(value)

    def test_stream_exact_bytes_and_hash(self):
        data=b'\xff\x00\x80real bytes'
        desc={'sha256':hashlib.sha256(data).hexdigest(),'size':len(data)}
        desc['key']='objects/sha256/'+desc['sha256'][:2]+'/'+desc['sha256']
        with tempfile.TemporaryDirectory() as d:
            result=p.save_blob(io.BytesIO(data),desc,Path(d))
            self.assertEqual(result.read_bytes(),data)

    def test_truncated_extra_and_corrupt_bytes_fail(self):
        data=b'correct'
        desc={'sha256':hashlib.sha256(data).hexdigest(),'size':len(data)}
        desc['key']='objects/sha256/'+desc['sha256'][:2]+'/'+desc['sha256']
        for bad in [data[:-1],data+b'x',b'incorrc']:
            with tempfile.TemporaryDirectory() as d:
                with self.assertRaises(ValueError):p.save_blob(io.BytesIO(bad),desc,Path(d))
                self.assertFalse((Path(d)/desc['key']).exists())

    def test_manifest_bound_to_fixed_repository_snapshot_and_expected_ref(self):
        m={'schema':'git-backup/v1','repository_id':1412827677,'repository':'susanbeasles/ProsRUs','snapshot':p.SNAPSHOT,'refs':['a'*40+' refs/heads/main']}
        p.check_manifest(m,'a'*40)
        for key,bad in [('repository_id',123),('snapshot','other'),('refs',['b'*40+' refs/heads/main'])]:
            with self.assertRaises(ValueError):p.check_manifest({**m,key:bad},'a'*40)

if __name__=='__main__':unittest.main()
