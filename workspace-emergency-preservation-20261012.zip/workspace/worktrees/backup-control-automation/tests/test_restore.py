import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
from restore import restore
from backup import SafeRedirect
import urllib.request


class RestoreTests(unittest.TestCase):
    def blob(self, root, body):
        h = hashlib.sha256(body).hexdigest()
        key = f'objects/sha256/{h[:2]}/{h}'
        path = root / key
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(body)
        return {'sha256': h, 'key': key, 'size': len(body)}

    def test_real_git_history_restore(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            repo = root / 'source'
            subprocess.run(['git','init',str(repo)],check=True,capture_output=True)
            for i in range(2):
                (repo/'file').write_text(str(i))
                subprocess.run(['git','-C',str(repo),'add','.'],check=True)
                subprocess.run(['git','-C',str(repo),'-c','user.name=Fixture','-c','user.email=fixture@example.test','-c','commit.gpgsign=false','commit','-m',str(i)],check=True,capture_output=True)
            mirror = root / 'repository.git'
            subprocess.run(['git','clone','--mirror',str(repo),str(mirror)],check=True,capture_output=True)
            buffer=io.BytesIO()
            with tarfile.open(fileobj=buffer,mode='w') as tar:
                tar.add(mirror,arcname='repository.git')
            blob=self.blob(root,buffer.getvalue())
            target=root/'restored'
            restore(root,{'schema':'git-backup/v1','archive':blob},target)
            r=subprocess.run(['git','--git-dir',str(target/'repository.git'),'rev-list','--all','--count'],capture_output=True,text=True,check=True)
            self.assertEqual(r.stdout.strip(),'2')
            subprocess.run(['git','--git-dir',str(target/'repository.git'),'fsck','--full'],capture_output=True,check=True)

    def test_oci_restore_and_corruption(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            body=json.dumps({'schemaVersion':2,'mediaType':'application/vnd.oci.image.manifest.v1+json','layers':[]}).encode()
            blob=self.blob(root,body)
            digest='sha256:'+blob['sha256']
            manifest={'schema':'oci-backup/v1','digest':digest,'objects':{digest:blob}}
            restore(root,manifest,root/'image')
            self.assertEqual(json.loads((root/'image/index.json').read_text())['manifests'][0]['digest'],digest)
            (root/blob['key']).write_bytes(b'corrupt')
            with self.assertRaisesRegex(ValueError,'checksum-mismatch'):
                restore(root,manifest,root/'corrupt-image')

    def test_archive_traversal_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            buffer=io.BytesIO()
            with tarfile.open(fileobj=buffer,mode='w') as tar:
                item=tarfile.TarInfo('../escape');item.size=1
                tar.addfile(item,io.BytesIO(b'x'))
            blob=self.blob(root,buffer.getvalue())
            with self.assertRaisesRegex(ValueError,'unsafe-archive-member'):
                restore(root,{'schema':'git-backup/v1','archive':blob},root/'restored')
            self.assertFalse((root/'escape').exists())

    def test_redirect_strips_credentials(self):
        req=urllib.request.Request('https://ghcr.io/v2/a/blobs/x',headers={'Authorization':'Bearer secret'})
        redirected=SafeRedirect().redirect_request(req,None,302,'Found',{},'https://storage.example.test/signed')
        self.assertIsNone(redirected.get_header('Authorization'))


if __name__ == '__main__':
    unittest.main()

