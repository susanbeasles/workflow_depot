import hashlib
import io
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import restore

class ExtractionLimits(unittest.TestCase):
    def make(self,root,entries,mode='w'):
        archive=root/'fixture.tar'
        with tarfile.open(archive,mode) as tar:
            for name,data in entries:
                member=tarfile.TarInfo(name)
                member.size=len(data)
                tar.addfile(member,io.BytesIO(data))
        raw=archive.read_bytes();sha=hashlib.sha256(raw).hexdigest()
        key='objects/sha256/'+sha[:2]+'/'+sha
        blob=root/key;blob.parent.mkdir(parents=True);blob.write_bytes(raw)
        return {'schema':'git-backup/v1','archive':{'sha256':sha,'size':len(raw),'key':key}}

    def test_compressed_expansion_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);m=self.make(root,[('large',b'0'*1024**2)],'w:gz')
            self.assertLess(m['archive']['size'],2048)
            with self.assertRaises((ValueError,tarfile.ReadError)):
                restore.restore(root,m,root/'out')
            self.assertFalse((root/'out/large').exists())

    def test_per_member_limit(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);m=self.make(root,[('large',b'x'*17)])
            with patch.object(restore,'MAX_MEMBER_BYTES',16,create=True):
                with self.assertRaisesRegex(ValueError,'member-size-limit'):
                    restore.restore(root,m,root/'out')
            self.assertFalse((root/'out/large').exists())

    def test_total_expanded_limit(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);m=self.make(root,[('a',b'x'*12),('b',b'y'*12)])
            with patch.object(restore,'MAX_EXPANDED_BYTES',20,create=True):
                with self.assertRaisesRegex(ValueError,'expanded-size-limit'):
                    restore.restore(root,m,root/'out')
            self.assertFalse((root/'out/b').exists())

    def test_header_count_limit(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);m=self.make(root,[('a',b''),('b',b'')])
            with patch.object(restore,'MAX_ARCHIVE_MEMBERS',1,create=True):
                with self.assertRaisesRegex(ValueError,'member-count-limit'):
                    restore.restore(root,m,root/'out')
            self.assertFalse((root/'out/b').exists())

    def test_bounded_pax_metadata(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);m=self.make(root,[('x'*150,b'data')])
            with patch.object(restore,'MAX_EXTENDED_HEADER_BYTES',16,create=True):
                with self.assertRaisesRegex(ValueError,'extended-header-limit'):
                    restore.restore(root,m,root/'out')

    def test_uncompressed_binary_and_long_names_still_restore(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);name='x'*150;m=self.make(root,[(name,b'\x00\xff\x80')])
            restore.restore(root,m,root/'out')
            self.assertEqual((root/'out'/name).read_bytes(),b'\x00\xff\x80')

    def test_nonutf8_and_newline_names_preserved(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);names=['nonutf8-\udcff','line\nbreak']
            m=self.make(root,[(name,b'content') for name in names])
            restore.restore(root,m,root/'out')
            for name in names:self.assertEqual((root/'out'/name).read_bytes(),b'content')

    def test_sparse_handlers_refuse_before_processing_map(self):
        item=restore.BoundedTarInfo('fixture')
        for name,args in [('_proc_gnusparse_00',(None,[])),('_proc_gnusparse_01',(None,{})),('_proc_gnusparse_10',(None,{},None))]:
            with self.assertRaisesRegex(ValueError,'sparse-archive-refused'):
                getattr(item,name)(*args)

    def test_legacy_gnu_sparse_rejected_before_any_map_read(self):
        class ForbiddenMap:
            reads=0
            def read(self,*args):
                self.reads+=1
                raise AssertionError('legacy sparse map was read')
        class Archive:
            fileobj=ForbiddenMap()
            offset=0
        item=restore.BoundedTarInfo('legacy')
        item.type=tarfile.GNUTYPE_SPARSE
        # The legacy extended-map flag makes the inherited parser read blocks.
        item._sparse_structs=([], True, 1)
        archive=Archive()
        with self.assertRaisesRegex(ValueError,'sparse-archive-refused'):
            item._proc_member(archive)
        self.assertEqual(archive.fileobj.reads,0)

if __name__=='__main__':unittest.main()
