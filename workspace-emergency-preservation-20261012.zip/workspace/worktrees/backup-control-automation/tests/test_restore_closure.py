import pathlib
import subprocess
import unittest


class RestoreClosure(unittest.TestCase):
    def test_actual_restore_workflow_checksum_gate_accepts_the_current_reviewable_source(self):
        root = pathlib.Path(__file__).resolve().parents[1]
        result = subprocess.run(['sha256sum', '-c', 'restore-closure.sha256'], cwd=root,
                                text=True, capture_output=True, check=False)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)


if __name__ == '__main__':
    unittest.main()
