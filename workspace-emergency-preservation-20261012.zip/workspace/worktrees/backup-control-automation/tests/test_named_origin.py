import importlib.util, pathlib, unittest, urllib.error
from unittest.mock import patch
p=pathlib.Path(__file__).resolve().parents[1]/'scripts'/'backup.py'
spec=importlib.util.spec_from_file_location('backup_named',p)
b=importlib.util.module_from_spec(spec); spec.loader.exec_module(b)
class NamedOrigin(unittest.TestCase):
 def test_default_origin_is_named_domain(self):
  self.assertEqual(b.ORIGIN,'https://backup.vespoli.me')
 def test_store_refuses_other_origins_before_auth(self):
  for origin in ['https://backup-control.anthonyvespoli.workers.dev','https://backup.vespoli.me.evil.test','http://backup.vespoli.me','https://backup.vespoli.me/path']:
   with self.subTest(origin=origin),patch.object(b,'ORIGIN',origin),self.assertRaisesRegex(ValueError,'unapproved-backup-origin'):b.Store()
 def test_backup_storage_redirect_cannot_forward_payload(self):
  handler=b.BackupRedirect()
  req=b.urllib.request.Request('https://backup.vespoli.me/api/objects/git/'+'a'*64,data=b'private',method='PUT')
  with self.assertRaisesRegex(ValueError,'backup-redirect-refused'):handler.redirect_request(req,None,307,'redirect',{},'https://other.test/upload')
 def test_safe_http_failure_has_status_not_response_or_token(self):
  e=urllib.error.HTTPError('https://example.test/?secret=token',403,'secret response',{},None)
  self.assertEqual(b.failure_details(e),{'error':'HTTPError','http_status':403})
if __name__=='__main__':unittest.main()
