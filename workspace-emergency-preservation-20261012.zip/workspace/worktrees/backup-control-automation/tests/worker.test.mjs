import test from 'node:test';
import assert from 'node:assert/strict';
import worker, { validSignature, trustedClaims, relevant, digest } from '../src/worker.mjs';
const env = {PUBLIC_ORIGIN:'https://backup.vespoli.me',CONTROL_REPO:'susanbeasles/backup-control',GITHUB_OWNER:'susanbeasles',GITHUB_OWNER_ID:'215839550',CONTROL_REPO_ID:'1407276404'};
test('HMAC authenticates exact raw bytes; tampering and missing secrets fail closed', async () => {
  const body = new TextEncoder().encode('{"event":1}');
  const key = await crypto.subtle.importKey('raw',new TextEncoder().encode('test-secret'),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const signature='sha256='+Buffer.from(await crypto.subtle.sign('HMAC',key,body)).toString('hex');
  assert.equal(await validSignature('test-secret',body,signature),true);
  assert.equal(await validSignature('test-secret',new TextEncoder().encode('{"event":2}'),signature),false);
  assert.equal(await validSignature('',body,signature),false);
  assert.equal(await validSignature('test-secret',body,'sha1=abc'),false);
});
test('OIDC rejects forks, feature branches, alternate workflows, audiences and expired claims', () => {
  const c={iss:'https://token.actions.githubusercontent.com',aud:env.PUBLIC_ORIGIN,repository:env.CONTROL_REPO,repository_owner:env.GITHUB_OWNER,repository_id:env.CONTROL_REPO_ID,repository_owner_id:env.GITHUB_OWNER_ID,ref:'refs/heads/main',workflow_ref:`${env.CONTROL_REPO}/.github/workflows/backup.yml@refs/heads/main`,sub:`repo:susanbeasles@215839550/backup-control@1407276404:environment:backup`,iat:1000,exp:1300};
  assert.equal(trustedClaims(c,env,1100),true);
  for (const changed of [{repository:'attacker/backup-control'},{ref:'refs/heads/evil'},{workflow_ref:'other'},{aud:'other'},{exp:1099},{iat:1400},{sub:`repo:${env.CONTROL_REPO}:pull_request`}]) assert.equal(trustedClaims({...c,...changed},env,1100),false);
});
test('event scope includes every branch and new repository installations, excludes other owners',()=>{
  assert.equal(relevant('push',{repository:{owner:{login:'susanbeasles'}},ref:'refs/heads/feature'},'susanbeasles'),true);
  assert.equal(relevant('installation',{installation:{account:{login:'susanbeasles'}}},'susanbeasles'),true);
  assert.equal(relevant('push',{repository:{owner:{login:'other'}}},'susanbeasles'),false);
});
test('SHA-256 object identity is deterministic',async()=>assert.equal(await digest(new TextEncoder().encode('abc')),'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad'));
test('webhook journals before acknowledgement and retries repair an indexing interruption',async()=>{
  const saved=new Map();let queueCalls=0;
  const mock={...env,WEBHOOK_SECRET:'secret',EVENTS:{
    head:async key=>saved.get(key)?.metadata || null,
    put:async(key,body,options)=>saved.set(key,{body,metadata:{customMetadata:options.customMetadata}})
  },OUTBOX:{idFromName:()=>0,get:()=>({fetch:async()=>{queueCalls++;return queueCalls===1?new Response(null,{status:503}):Response.json({queued:true});}})}};
  const body=JSON.stringify({repository:{owner:{login:'susanbeasles'}}});
  const key=await crypto.subtle.importKey('raw',new TextEncoder().encode('secret'),{name:'HMAC',hash:'SHA-256'},false,['sign']);
  const signature='sha256='+Buffer.from(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(body))).toString('hex');
  const make=()=>new Request('https://worker/webhooks/github',{method:'POST',body,headers:{'x-hub-signature-256':signature,'x-github-event':'push','x-github-delivery':'delivery-1'}});
  assert.equal((await worker.fetch(make(),mock)).status,503);
  assert.equal(saved.size,1);
  assert.equal((await worker.fetch(make(),mock)).status,202);
  assert.equal(saved.size,1);
  assert.equal(queueCalls,2);
  const forged=new Request('https://worker/webhooks/github',{method:'POST',body,headers:{'x-hub-signature-256':'sha256='+'0'.repeat(64),'x-github-event':'push','x-github-delivery':'forged'}});
  assert.equal((await worker.fetch(forged,mock)).status,401);
  assert.equal(saved.size,1);
});
test('upload API verifies a real signed JWT, not just decoded claims',async()=>{
  const originalFetch=globalThis.fetch;
  const pair=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
  const jwk=await crypto.subtle.exportKey('jwk',pair.publicKey);jwk.kid='fixture';jwk.alg='RS256';
  globalThis.fetch=async()=>Response.json({keys:[jwk]});
  try {
    const now=Math.floor(Date.now()/1000);
    const claims={iss:'https://token.actions.githubusercontent.com',aud:env.PUBLIC_ORIGIN,repository:env.CONTROL_REPO,repository_owner:env.GITHUB_OWNER,repository_id:env.CONTROL_REPO_ID,repository_owner_id:env.GITHUB_OWNER_ID,ref:'refs/heads/main',workflow_ref:`${env.CONTROL_REPO}/.github/workflows/backup.yml@refs/heads/main`,sub:`repo:susanbeasles@215839550/backup-control@1407276404:environment:backup`,iat:now,exp:now+300};
    const header=Buffer.from(JSON.stringify({alg:'RS256',kid:'fixture'})).toString('base64url');
    const payload=Buffer.from(JSON.stringify(claims)).toString('base64url');
    const unsigned=`${header}.${payload}`;
    const signature=Buffer.from(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',pair.privateKey,new TextEncoder().encode(unsigned))).toString('base64url');
    const mock={...env,GIT:{head:async()=>({size:1})}};
    const make=token=>new Request('https://worker/api/objects/git/'+'a'.repeat(64),{method:'HEAD',headers:{authorization:'Bearer '+token}});
    assert.equal((await worker.fetch(make(`${unsigned}.${signature}`),mock)).status,200);
    assert.equal((await worker.fetch(make(`${unsigned}.${'a'.repeat(signature.length)}`),mock)).status,401);
  } finally {globalThis.fetch=originalFetch;}
});

