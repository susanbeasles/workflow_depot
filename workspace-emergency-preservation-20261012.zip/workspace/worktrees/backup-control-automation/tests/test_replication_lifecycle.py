import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]


class ReplicationLifecycle(unittest.TestCase):
    def test_terminating_wrapper_stops_and_reaps_its_active_child_without_waiting_for_tool_timeout(self):
        with tempfile.TemporaryDirectory() as directory:
            pidfile = Path(directory)/'synthetic-child.pid'
            child_code = "import os,time;from pathlib import Path;Path("+repr(str(pidfile))+").write_text(str(os.getpid()));time.sleep(30)"
            wrapper_code = "import sys;sys.path.insert(0,"+repr(str(ROOT/'scripts'))+");from replicate_provisioned import bounded_process;bounded_process(sys.executable,['-c',"+repr(child_code)+"],env={'PATH':'/usr/bin:/bin'},timeout=60,max_bytes=1024)"
            wrapper = subprocess.Popen([sys.executable, '-c', wrapper_code], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            child_pid = None
            try:
                for _ in range(100):
                    if pidfile.exists(): break
                    time.sleep(.01)
                self.assertTrue(pidfile.exists(), 'synthetic child did not start')
                child_pid = int(pidfile.read_text())
                wrapper.terminate(); wrapper.wait(timeout=3)
                # The wrapper owns/reaps this direct child; it must no longer exist.
                with self.assertRaises(ProcessLookupError): os.kill(child_pid, 0)
            finally:
                if wrapper.poll() is None: wrapper.kill(); wrapper.wait(timeout=3)
                if child_pid:
                    try: os.killpg(child_pid, signal.SIGKILL)
                    except ProcessLookupError: pass


if __name__ == '__main__':
    unittest.main()
