import contextlib, hashlib, io, json, os, tempfile, unittest
from pathlib import Path
from unittest.mock import patch
import backup, restore, restore_probe
class ProbeEntrypoint(unittest.TestCase):
 def test_entrypoint_reads_only_fixed_manifest_and_object_and_keeps_named_backup_client(self):
  data=b'synthetic archive bytes';sha=hashlib.sha256(data).hexdigest();expected='c21cf2e77cb93111db755197ad9a29ea8d1d5487'
  desc={'sha256':sha,'size':len(data),'key':f'objects/sha256/{sha[:2]}/{sha}'}
  manifest={'schema':'git-backup/v1','repository_id':1412827677,'repository':'susanbeasles/ProsRUs','snapshot':restore_probe.SNAPSHOT,'refs':[expected+' refs/heads/main'],'archive':desc,'release_assets':[]}
  calls=[]
  class ReadOnlyStore:
   def call(self,path,method='GET',*args,**kwargs):
    calls.append((path,method));assert method=='GET'
    if path=='records/git/'+restore_probe.MANIFEST_KEY:return io.BytesIO(json.dumps(manifest).encode())
    if path=='objects/git/'+sha:return io.BytesIO(data)
    raise AssertionError('unexpected route')
  def verify(root,got,destination):
   self.assertEqual(got,manifest);self.assertEqual((root/desc['key']).read_bytes(),data)
   return {'status':'verified'}
  old_origin,old_opener=backup.ORIGIN,backup.OPENER
  try:
   with tempfile.TemporaryDirectory() as d, patch.dict(os.environ,{'RUNNER_TEMP':d,'BACKUP_ORIGIN':'https://backup.vespoli.me','RESTORE_EXPECTED_MAIN':expected}),patch.object(backup,'Store',ReadOnlyStore),patch.object(restore,'restore_and_verify',side_effect=verify) as verifier,contextlib.redirect_stdout(io.StringIO()) as output:
    restore_probe.main();self.assertEqual(verifier.call_count,1)
    self.assertEqual(json.loads(output.getvalue())['archive_sha256'],sha)
   self.assertEqual(calls,[('records/git/'+restore_probe.MANIFEST_KEY,'GET'),('objects/git/'+sha,'GET')])
   self.assertTrue(any(isinstance(h,backup.BackupRedirect) for h in backup.BACKUP_OPENER.handlers))
  finally:backup.ORIGIN,backup.OPENER=old_origin,old_opener
if __name__=='__main__':unittest.main()
