"""Pure parser/Git-output tests; no Git subprocess or fixture commits."""
import hashlib
from pathlib import Path
import sys
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import git_verification as v

class PreservedParserTests(unittest.TestCase):
    def test_exact_accepted_verifier_bytes(self):
        self.assertEqual(hashlib.sha256(Path(v.__file__).read_bytes()).hexdigest(),
            'bf2eb5cdb07a44e11ee879e4d9c2c19ac85e89d4cb267ffceb36fbeec2cac483')

    def test_all_legacy_and_crlf_variants_remain_recognized(self):
        for version in ['https://git-lfs.github.com/spec/v1','https://hawser.github.com/spec/v1','http://git-media.io/v/2']:
            for newline in ['\n','\r\n']:
                with self.subTest(version=version,newline=newline):
                    body=newline.join(['version '+version,'oid sha256:'+'a'*64,'size 17','']).encode()
                    self.assertEqual(v.parse_lfs_pointer(body),('a'*64,17))

    def test_object_inventory_requests_no_names(self):
        oid='b'*40
        body=b'not a pointer\xff\n'
        def fake_git(repo,*args,**kwargs):
            if args[0]=='rev-list':
                self.assertIn('--no-object-names',args)
                return (oid+'\n').encode()
            if '--batch-check' in args:return f'{oid} blob {len(body)}\n'.encode()
            return f'{oid} blob {len(body)}\n'.encode()+body+b'\n'
        with patch.object(v,'git',side_effect=fake_git):
            self.assertEqual(v.reachable_lfs(Path('unused')), {})

if __name__=='__main__':unittest.main()
