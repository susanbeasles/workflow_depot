# Existing 1Password item references

Initial B2 keys that already exist do not require a provisioner creation receipt.
`scripts/replicate_existing.py` accepts a separate
`backup-existing-item-replication/v1` configuration. It reuses the existing bounded
op/rclone execution and unchanged immutable copy/download-check script. The old
provisioner receipt interface remains available for credentials created through
that path; no fake provisioner job or success response is created for an existing
item.

The trusted launcher must supply `--approved-config-sha256` from independently
authenticated owner approval of the **exact configuration file bytes**. This
digest binds the source, destination bucket/prefix, role, immutable item/field
references, executable hashes and timeout. Passing a caller-selected hash alongside
caller-selected JSON does not authenticate ownership. This patch does not install
a new approval authority, scheduler, credential binding or owner API.

The source-owned launch interface is:

```
python3 scripts/replicate_existing.py --config /trusted/existing-replication.json \
  --approved-config-sha256 <independently-approved-64-hex-digest>
```

Only a later expressly approved execution adds `--execute` and supplies the
least-privileged op runtime token through private FD3. No token environment fallback
is added. The op token reaches only the fixed op subprocess; the B2 values reach
only the existing rclone child environment. Receipts identify
`credentialSource: owner-approved-existing-item` and the approved configuration
digest, with no `provisionerJobId` or credential value.

Credential configuration requires exact vault/item IDs, a `keyIdField` and
`applicationKeyField`, each `{id,sectionId}` with a public field ID and either a
public section ID or `null` for an unsectioned field. These produce
`op://vaultID/itemID/fieldID` or `op://vaultID/itemID/sectionID/fieldID`. Field labels,
query strings, name-based vault/item lookup and inferred field names are not used.
The two references must differ. `credential.bucketName` must equal the exact
approved destination bucket; the entire selection is covered by the owner-approved
configuration digest. A configured role is an owner-approved restriction, not an
independent claim that B2 provider capabilities were inspected.

The current nondeleting copy path requires writes **and destination reads** for
download verification. It accepts `role: read-write` for the seven ordinary bucket
labels (`files`, `test`, `images`, `continuous`, `logs`, `backups`, `working`).
Golden credentials are excluded: `restore-reader` must be used only by a separately
approved restore path, and `capture-writer` only by a capture path compatible with
its actual capabilities. Neither is substituted or relabeled as a general RW key,
and this patch does not bypass download verification to accommodate a writer.

`config/replication-existing.disabled.json` records the metadata-verified backups
item ID in `remote-agent-vault`; it remains disabled. Its null field IDs, exact
bucket name, prefix, source remote and binary hashes are unresolved inputs. The
metadata map currently contains eight visible B2 items, including the Golden
reader, but no field IDs and no identified Golden writer. No `key_id` or
`application_key` assumption is carried over from the provisioner template.

The existing workflow/owner setup authorizes backup capture and metadata reads;
there is no installed policy endpoint in this adapter that authenticates existing
item approvals. That trusted launch integration must be commissioned separately.
No credentials were retrieved, provider calls made, config enabled or staged
repository files changed while preparing this patch. Tests use synthetic responses
and local generated fixture directories only.
