const encoder = new TextEncoder();
const json = (value, status = 200) => Response.json(value, { status, headers: { 'cache-control': 'no-store' } });
const hex = bytes => [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2, '0')).join('');
const unbase64 = value => Uint8Array.from(atob(value.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
const base64url = value => btoa(String.fromCharCode(...new Uint8Array(value))).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
export const digest = async bytes => hex(await crypto.subtle.digest('SHA-256', bytes));
export async function validSignature(secret, bytes, signature) {
  if (!secret || !/^sha256=[a-f0-9]{64}$/.test(signature || '')) return false;
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
  const signatureBytes = Uint8Array.from(signature.slice(7).match(/../g), b => parseInt(b, 16));
  return crypto.subtle.verify('HMAC', key, signatureBytes, bytes);
}
export function trustedClaims(c, env, now = Date.now() / 1000) {
  const ownerID = String(env.GITHUB_OWNER_ID || '');
  const repositoryID = String(env.CONTROL_REPO_ID || '');
  const [owner, repository] = env.CONTROL_REPO.split('/');
  if (!/^[1-9]\d*$/.test(ownerID) || !/^[1-9]\d*$/.test(repositoryID)) return false;
  const subject = `repo:${owner}@${ownerID}/${repository}@${repositoryID}:environment:backup`;
  return c.iss === 'https://token.actions.githubusercontent.com' && c.aud === env.PUBLIC_ORIGIN &&
    c.repository === env.CONTROL_REPO && c.repository_owner?.toLowerCase() === env.GITHUB_OWNER.toLowerCase() &&
    String(c.repository_id) === repositoryID && String(c.repository_owner_id) === ownerID &&
    c.ref === 'refs/heads/main' && c.workflow_ref === `${env.CONTROL_REPO}/.github/workflows/backup.yml@refs/heads/main` &&
    c.sub === subject &&
    Number.isFinite(c.exp) && c.exp > now && Number.isFinite(c.iat) && c.iat <= now + 30 && c.iat > now - 600 &&
    (!c.nbf || c.nbf <= now + 30);
}
let jwksCache;
async function authorized(request, env) {
  try {
    const token = request.headers.get('authorization')?.replace(/^Bearer /, '');
    const pieces = token?.split('.');
    if (pieces?.length !== 3) return false;
    const header = JSON.parse(new TextDecoder().decode(unbase64(pieces[0])));
    const claims = JSON.parse(new TextDecoder().decode(unbase64(pieces[1])));
    if (header.alg !== 'RS256' || !trustedClaims(claims, env)) {
      console.warn(JSON.stringify({event:'backup-auth-rejected',run:request.headers.get('x-backup-run'),stage:'claims',checks:{algorithm:header.alg==='RS256',issuer:claims.iss==='https://token.actions.githubusercontent.com',audience:claims.aud===env.PUBLIC_ORIGIN,repository:claims.repository===env.CONTROL_REPO,owner:claims.repository_owner?.toLowerCase()===env.GITHUB_OWNER.toLowerCase(),ref:claims.ref==='refs/heads/main',workflow:claims.workflow_ref===`${env.CONTROL_REPO}/.github/workflows/backup.yml@refs/heads/main`,subject:claims.sub===`repo:${env.GITHUB_OWNER}@${env.GITHUB_OWNER_ID}/${env.CONTROL_REPO.split('/')[1]}@${env.CONTROL_REPO_ID}:environment:backup`,time:claims.exp>Date.now()/1000&&claims.iat>Date.now()/1000-600},subject:claims.sub,workflow:claims.workflow_ref}));
      return false;
    }
    if (!jwksCache || jwksCache.expires < Date.now() || !jwksCache.keys.some(k => k.kid === header.kid)) {
      const r = await fetch('https://token.actions.githubusercontent.com/.well-known/jwks');
      if (!r.ok) { console.warn(JSON.stringify({event:'backup-auth-rejected',stage:'jwks-fetch',status:r.status})); return false; }
      jwksCache = { ...(await r.json()), expires: Date.now() + 300000 };
    }
    const jwk = jwksCache.keys.find(k => k.kid === header.kid);
    if (!jwk) { console.warn(JSON.stringify({event:'backup-auth-rejected',stage:'unknown-signing-key'})); return false; }
    const key = await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
    const verified=await crypto.subtle.verify('RSASSA-PKCS1-v1_5', key, unbase64(pieces[2]), encoder.encode(`${pieces[0]}.${pieces[1]}`));
    if (!verified) console.warn(JSON.stringify({event:'backup-auth-rejected',stage:'signature'}));
    return verified;
  } catch(e) { console.warn(JSON.stringify({event:'backup-auth-rejected',stage:'validation-exception',type:e.name})); return false; }
}
const outbox = env => env.OUTBOX.get(env.OUTBOX.idFromName('github-backup'));
async function configuredEnv(env) {
  if (!env.APP_CONFIG) return env;
  const response = await env.APP_CONFIG.get(env.APP_CONFIG.idFromName('owner')).fetch('https://bootstrap/config/internal');
  if (!response.ok) throw new Error('configuration-unavailable');
  return {...env,...await response.json()};
}
export function relevant(event, p, owner) {
  const packageType = (p.package || p.registry_package)?.package_type;
  if (['package','registry_package'].includes(event) && packageType && !['container','docker'].includes(packageType)) return false;
  const repoOwner = p.repository?.owner?.login || p.repository?.owner?.name;
  const account = repoOwner || p.installation?.account?.login || p.package?.owner?.login || p.registry_package?.owner?.login;
  if (account?.toLowerCase() !== owner.toLowerCase()) return false;
  return ['push', 'create', 'delete', 'repository', 'release', 'registry_package', 'package', 'installation', 'installation_repositories'].includes(event);
}
async function smallBody(request, limit) {
  if (Number(request.headers.get('content-length')) > limit) throw new Error('body-too-large');
  const reader = request.body?.getReader();
  if (!reader) return new Uint8Array();
  const chunks = []; let size = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    size += value.length;
    if (size > limit) { await reader.cancel(); throw new Error('body-too-large'); }
    chunks.push(value);
  }
  const bytes = new Uint8Array(size); let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  return bytes;
}
const buckets = env => ({ git: env.GIT, canon: env.CANON, hot: env.HOT });
const validId = id => /^[a-zA-Z0-9-]{1,100}$/.test(id);
const objectKey = hash => `objects/sha256/${hash.slice(0, 2)}/${hash}`;
const safeKey = key => /^(manifests|tags|receipts)\/[a-zA-Z0-9_./-]{1,600}\.json$/.test(key) && !key.includes('..') && !key.includes('//');
async function api(request, env, url) {
  if (!await authorized(request, env)) return json({ error: 'unauthorized' }, 401);
  const pieces = url.pathname.slice(5).split('/');
  if (url.pathname === '/api/github/token' && request.method === 'POST') {
    const token = await installationToken(env, {permissions:{contents:'read',metadata:'read',issues:'read',pull_requests:'read'}});
    return json({token,expires_in:3000});
  }
  if (pieces[0] === 'events' && validId(pieces[1])) {
    if (request.method === 'GET' && pieces.length === 2) {
      const o = await env.EVENTS.get(`events/${pieces[1]}.json`);
      return o ? new Response(o.body, { headers: { 'content-type': 'application/json' } }) : json({ error: 'not-found' }, 404);
    }
    if (request.method === 'POST' && pieces[2] === 'ack') {
      const receipt = JSON.parse(new TextDecoder().decode(await smallBody(request, 65536)));
      if (!Array.isArray(receipt.manifests) || !receipt.manifests.length || receipt.manifests.length > 10000) return json({error:'missing-manifests'},400);
      for (const m of receipt.manifests) {
        if (!buckets(env)[m.tier] || !safeKey(m.key) || !await buckets(env)[m.tier].head(m.key)) return json({error:'unverified-receipt'},400);
      }
      const key = `receipts/${pieces[1]}.json`;
      await env.EVENTS.put(key, JSON.stringify({ ...receipt, completed_at: new Date().toISOString() }), { onlyIf: { etagDoesNotMatch: '*' } });
      return outbox(env).fetch(`https://outbox/ack/${pieces[1]}`, { method: 'POST' });
    }
  }
  if (pieces[0] === 'objects' && buckets(env)[pieces[1]] && /^[a-f0-9]{64}$/.test(pieces[2] || '') && pieces.length === 3) {
    const bucket = buckets(env)[pieces[1]], key = objectKey(pieces[2]);
    if (request.method === 'HEAD') return new Response(null, { status: await bucket.head(key) ? 200 : 404 });
    if (request.method === 'GET') { const o = await bucket.get(key); return o ? new Response(o.body) : json({error:'not-found'},404); }
    if (request.method === 'PUT') {
      const bytes = await smallBody(request, 8 * 1024 * 1024);
      if (await digest(bytes) !== pieces[2]) return json({error:'checksum-mismatch'},422);
      if (!await bucket.head(key)) await bucket.put(key, bytes, { sha256: pieces[2], onlyIf: { etagDoesNotMatch: '*' } });
      return json({ key, sha256: pieces[2] });
    }
  }
  if (pieces[0] === 'records' && buckets(env)[pieces[1]]) {
    const key = pieces.slice(2).join('/');
    if (!safeKey(key)) return json({error:'invalid-key'},400);
    const bucket = buckets(env)[pieces[1]];
    if (request.method === 'GET') { const o = await bucket.get(key); return o ? new Response(o.body, {headers:{'content-type':'application/json'}}) : json({error:'not-found'},404); }
    if (request.method === 'PUT') {
      const bytes = await smallBody(request, 1024 * 1024);
      JSON.parse(new TextDecoder().decode(bytes));
      const existing = await bucket.get(key);
      if (existing) return await digest(await existing.arrayBuffer()) === await digest(bytes) ? json({key}) : json({error:'immutable-key-conflict'},409);
      const result = await bucket.put(key, bytes, { onlyIf: { etagDoesNotMatch:'*' }, httpMetadata:{contentType:'application/json'} });
      if (!result) return json({error:'concurrent-write-retry'},409);
      return json({ key });
    }
  }
  if (pieces[0] === 'uploads') {
    if (request.method === 'POST' && pieces.length === 1) {
      const p = JSON.parse(new TextDecoder().decode(await smallBody(request, 4096)));
      if (!buckets(env)[p.tier] || !/^[a-f0-9]{64}$/.test(p.sha256) || !Number.isSafeInteger(p.size) || p.size <= 0 || p.size > 5e12) return json({error:'invalid-upload'},400);
      const key = objectKey(p.sha256), bucket = buckets(env)[p.tier];
      if (await bucket.head(key)) return json({ exists:true,key });
      const upload = await bucket.createMultipartUpload(key, { customMetadata:{sha256:p.sha256,size:String(p.size)} });
      const id = crypto.randomUUID();
      await env.EVENTS.put(`uploads/${id}.json`, JSON.stringify({ ...p, key, uploadId:upload.uploadId, created:Date.now(), runId:request.headers.get('x-backup-run') || '' }));
      return json({ id, key });
    }
    if (!validId(pieces[1] || '')) return json({error:'invalid-upload'},400);
    const session = await env.EVENTS.get(`uploads/${pieces[1]}.json`);
    if (!session) return json({error:'not-found'},404);
    const p = await session.json();
    if (p.created < Date.now() - 86400000) return json({error:'expired-upload'},410);
    const upload = buckets(env)[p.tier].resumeMultipartUpload(p.key, p.uploadId);
    if (request.method === 'PUT' && /^[0-9]{1,5}$/.test(pieces[2] || '')) {
      const part = Number(pieces[2]);
      if (part < 1 || part > 10000) return json({error:'invalid-part'},400);
      const bytes = await smallBody(request, 16 * 1024 * 1024);
      if (await digest(bytes) !== request.headers.get('x-content-sha256')) return json({error:'checksum-mismatch'},422);
      const result = await upload.uploadPart(part, bytes);
      return json({ ...result, size:bytes.length });
    }
    if (request.method === 'POST' && pieces[2] === 'complete') {
      const parts = JSON.parse(new TextDecoder().decode(await smallBody(request, 1024 * 1024)));
      if (!Array.isArray(parts) || !parts.length || parts.length > 10000 || parts.some((part,i) => part.partNumber !== i+1 || typeof part.etag !== 'string' || !Number.isSafeInteger(part.size) || part.size <= 0 || (i < parts.length-1 && part.size < 5*1024*1024)) || parts.reduce((sum,p)=>sum+p.size,0) !== p.size) return json({error:'invalid-parts'},400);
      if (!await buckets(env)[p.tier].head(p.key)) await upload.complete(parts.map(({partNumber,etag})=>({partNumber,etag})));
      await env.EVENTS.delete(`uploads/${pieces[1]}.json`);
      return json({ key:p.key, sha256:p.sha256 });
    }
  }
  if (pieces[0] === 'pending' && pieces.length === 1 && request.method === 'GET') return outbox(env).fetch('https://outbox/pending' + url.search);
  if (pieces[0] === 'status' && request.method === 'GET') return outbox(env).fetch('https://outbox/status');
  return json({error:'not-found'},404);
}
export default {
  async scheduled(controller,env) {
    env=await configuredEnv(env);
    const token=await installationToken(env,{repositories:[env.CONTROL_REPO.split('/')[1]],permissions:{actions:'read'}});
    const headers={authorization:`Bearer ${token}`,'user-agent':'backup-control',accept:'application/vnd.github+json'};
    const r=await fetch(`https://api.github.com/repos/${env.CONTROL_REPO}/actions/workflows/backup.yml/runs?per_page=5`,{headers});
    if (!r.ok) { console.warn(JSON.stringify({event:'backup-monitor-error',status:r.status})); return; }
    const runs=(await r.json()).workflow_runs;
    for(const run of runs) console.log(JSON.stringify({event:'backup-run-status',id:run.id,status:run.status,conclusion:run.conclusion,created:run.created_at,updated:run.updated_at}));
    console.log(JSON.stringify({event:'backup-outbox-status',...await (await outbox(env).fetch('https://outbox/status')).json()}));
  },
  async fetch(request, env) {
    try {
      env = await configuredEnv(env);
      const url = new URL(request.url);
      if (['/','/owner','/control'].includes(url.pathname)&&request.method==='GET')return Response.redirect('https://control.vespoli.me/owner/apps/backups',302);
      if (url.pathname === '/health' && request.method === 'GET') return json({service:'backup-control',webhook_configured:Boolean(env.WEBHOOK_SECRET),dispatch_configured:Boolean(env.GITHUB_APP_ID && env.GITHUB_APP_PRIVATE_KEY && env.GITHUB_INSTALLATION_ID)});
      if (url.pathname.startsWith('/api/')) return await api(request,env,url);
      if (url.pathname !== '/webhooks/github' || request.method !== 'POST') return json({error:'not-found'},404);
      if (!env.WEBHOOK_SECRET) return json({error:'webhook-not-configured'},503);
      const bytes = await smallBody(request, 25*1024*1024);
      if (!await validSignature(env.WEBHOOK_SECRET,bytes,request.headers.get('x-hub-signature-256'))) return json({error:'invalid-signature'},401);
      const id = request.headers.get('x-github-delivery'), event = request.headers.get('x-github-event');
      if (!validId(id || '') || !/^[a-z_]{1,60}$/.test(event || '')) return json({error:'invalid-headers'},400);
      const payload = JSON.parse(new TextDecoder().decode(bytes));
      if (event !== 'ping' && !relevant(event,payload,env.GITHUB_OWNER)) return json({accepted:false,reason:'out-of-scope'});
      const key=`events/${id}.json`, bodyHash=await digest(bytes);
      const existing=await env.EVENTS.head(key);
      if (existing && existing.customMetadata.sha256 !== bodyHash) return json({error:'delivery-conflict'},409);
      if (!existing) await env.EVENTS.put(key,JSON.stringify({id,event,received_at:new Date().toISOString(),payload}),{onlyIf:{etagDoesNotMatch:'*'},customMetadata:{sha256:bodyHash},httpMetadata:{contentType:'application/json'}});
      // Acknowledgement waits for durable indexing. Retried deliveries repair a put/index interruption.
      if (event !== 'ping') {
        const r=await outbox(env).fetch('https://outbox/enqueue',{method:'POST',body:JSON.stringify({id,event})});
        if (!r.ok) return json({error:'outbox-unavailable'},503);
      }
      return json({accepted:true,id},202);
    } catch (e) { return json({error:e.message === 'body-too-large' ? 'body-too-large':'request-failed'},e.message === 'body-too-large' ? 413:500); }
  }
};
async function installationToken(env, scope = {repositories:[env.CONTROL_REPO.split('/')[1]],permissions:{actions:'read'}}) {
  const now=Math.floor(Date.now()/1000);
  const header=base64url(encoder.encode(JSON.stringify({alg:'RS256',typ:'JWT'})));
  const claims=base64url(encoder.encode(JSON.stringify({iat:now-60,exp:now+540,iss:env.GITHUB_APP_ID})));
  const pem=env.GITHUB_APP_PRIVATE_KEY.replace(/-----[^-]+-----/g,'').replace(/\s/g,'');
  const key=await crypto.subtle.importKey('pkcs8',unbase64(pem),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign']);
  const signature=base64url(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,encoder.encode(`${header}.${claims}`)));
  const r=await fetch(`https://api.github.com/app/installations/${env.GITHUB_INSTALLATION_ID}/access_tokens`,{method:'POST',headers:{authorization:`Bearer ${header}.${claims}.${signature}`,'user-agent':'backup-control',accept:'application/vnd.github+json','content-type':'application/json'},body:JSON.stringify(scope)});
  if (!r.ok) throw new Error(`installation-token-${r.status}`);
  return (await r.json()).token;
}
export class Outbox {
  constructor(ctx,env) {
    this.ctx=ctx;this.env=env;
    ctx.storage.sql.exec('CREATE TABLE IF NOT EXISTS deliveries (id TEXT PRIMARY KEY,event TEXT NOT NULL,status TEXT NOT NULL DEFAULT \'pending\',due INTEGER NOT NULL,attempts INTEGER NOT NULL DEFAULT 0,last_error TEXT)');
  }
  async fetch(request) {
    const url=new URL(request.url),sql=this.ctx.storage.sql;
    if (url.pathname === '/enqueue') {
      const p=await request.json();
      sql.exec('INSERT OR IGNORE INTO deliveries (id,event,due) VALUES (?,?,?)',p.id,p.event,Date.now());
      await this.ctx.storage.setAlarm(Date.now()+1000);
      return json({queued:true});
    }
    if (url.pathname.startsWith('/ack/')) {sql.exec('UPDATE deliveries SET status=\'complete\',last_error=NULL WHERE id=?',url.pathname.slice(5));return json({complete:true});}
    if (url.pathname === '/pending') {
      const after=url.searchParams.get('after') || '';
      if (after && !validId(after)) return json({error:'invalid-cursor'},400);
      const deliveries=[...sql.exec("SELECT id,event FROM deliveries WHERE status != 'complete' AND id > ? ORDER BY id LIMIT 100",after)];
      return json({deliveries,next:deliveries.length===100?deliveries.at(-1).id:null});
    }
    if (url.pathname === '/status') return json({counts:[...sql.exec('SELECT status,COUNT(*) AS count FROM deliveries GROUP BY status')],oldest_pending:[...sql.exec('SELECT id,event,attempts,last_error FROM deliveries WHERE status != \'complete\' ORDER BY due LIMIT 20')]});
    return json({error:'not-found'},404);
  }
  async alarm() {
    this.ctx.storage.sql.exec("UPDATE deliveries SET last_error='github-dispatch-disabled-read-only' WHERE status != 'complete'");
    console.log(JSON.stringify({event:'backup-dispatch-paused',reason:'github-read-only-boundary'}));
  }
}



export async function backupStatus(env){const configured=await configuredEnv(env);return {service:'backup-control',webhook_configured:!!configured.WEBHOOK_SECRET,app_configured:!!configured.GITHUB_APP_ID,installation_configured:!!configured.GITHUB_INSTALLATION_ID,dispatch_enabled:false,dispatch_state:'paused',outbox:await (await outbox(env).fetch('https://outbox/status')).json()};}
