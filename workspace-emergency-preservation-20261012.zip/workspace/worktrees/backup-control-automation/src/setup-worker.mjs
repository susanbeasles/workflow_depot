import {DurableObject} from 'cloudflare:workers';
import {BootstrapCore} from './setup-core.mjs';
export {privateKeyBytes} from './setup-core.mjs';
export default {async fetch(request,env){const u=new URL(request.url);if(u.pathname==='/health')return Response.json({service:'backup-setup',auth_gate:env.AUTH_ORIGIN});const path=['/callback','/installed','/status','/start'].includes(u.pathname)?u.pathname:'/start';return Response.redirect(env.AUTH_ORIGIN+'/owner/apps/backups/setup'+path+(path==='/callback'?u.search:''),303);}};
export class Bootstrap extends DurableObject {
  fetch(request){return new BootstrapCore(this.ctx,this.env).fetch(request);}
  owner(request,email){return new BootstrapCore(this.ctx,this.env).owner(request,email);}
}
