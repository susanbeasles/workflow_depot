import {WorkerEntrypoint} from 'cloudflare:workers';
import {backupStatus} from './worker.mjs';
export {default,Outbox} from './worker.mjs';
export class BackupCapability extends WorkerEntrypoint {
  status(){return backupStatus(this.env);}
}
