const json = (p,s=200)=>Response.json(p,{status:s,headers:{'cache-control':'no-store'}});
const encoder=new TextEncoder();
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
const unb64=value=>Uint8Array.from(atob(value),c=>c.charCodeAt(0));
const escape=value=>String(value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;');
const hash=async value=>b64(await crypto.subtle.digest('SHA-256',encoder.encode(value)));
const random=()=>b64(crypto.getRandomValues(new Uint8Array(32)));
const html=body=>new Response(body,{headers:{'content-type':'text/html; charset=utf-8','cache-control':'no-store'}});
function derLength(n){if(n<128)return Uint8Array.of(n);const bytes=[];while(n){bytes.unshift(n&255);n=Math.floor(n/256);}return Uint8Array.of(128+bytes.length,...bytes);}
function sequence(...values){const size=values.reduce((s,a)=>s+a.length,0);return Uint8Array.of(48,...derLength(size),...values.flatMap(a=>[...a]));}
export function privateKeyBytes(pem){
  const raw=unb64(pem.replace(/-----[^-]+-----/g,'').replace(/\s/g,''));
  if(pem.includes('BEGIN PRIVATE KEY'))return raw;
  if(!pem.includes('BEGIN RSA PRIVATE KEY'))throw new Error('unsupported-key');
  return sequence(Uint8Array.of(2,1,0),Uint8Array.of(48,13,6,9,42,134,72,134,247,13,1,1,1,5,0),Uint8Array.of(4,...derLength(raw.length),...raw));
}
async function jwt(app){
  const now=Math.floor(Date.now()/1000),unsigned=b64(encoder.encode(JSON.stringify({alg:'RS256',typ:'JWT'})))+'.'+b64(encoder.encode(JSON.stringify({iat:now-60,exp:now+540,iss:String(app.id)})));
  const key=await crypto.subtle.importKey('pkcs8',privateKeyBytes(app.pem),{name:'RSASSA-PKCS1-v1_5',hash:'SHA-256'},false,['sign']);
  return unsigned+'.'+b64(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',key,encoder.encode(unsigned)));
}
async function github(path,token,method='GET',body){
  const headers={'user-agent':'backup-control-setup',accept:'application/vnd.github+json','content-type':'application/json','x-github-api-version':'2022-11-28'};
  if(token)headers.authorization='Bearer '+token;
  const r=await fetch('https://api.github.com'+path,{method,headers,body:body?JSON.stringify(body):undefined});
  if(!r.ok)throw new Error('github-'+r.status);
  return r.json();
}
export class BootstrapCore {
  constructor(ctx,env){this.ctx=ctx;this.env=env;}
  async fetch(request){
    const url=new URL(request.url),s=this.ctx.storage;
    // This route is only reachable through a cross-Worker Durable Object binding.
    if(url.pathname==='/config/internal'){
      const app=await s.get('app'),installation=await s.get('installation');
      if(!app)return json({});
      const bytes=privateKeyBytes(app.pem);
      const pem='-----BEGIN PRIVATE KEY-----\n'+btoa(String.fromCharCode(...bytes)).match(/.{1,64}/g).join('\n')+'\n-----END PRIVATE KEY-----\n';
      return json({GITHUB_APP_ID:String(app.id),GITHUB_APP_PRIVATE_KEY:pem,WEBHOOK_SECRET:app.webhook_secret,...(installation?{GITHUB_INSTALLATION_ID:String(installation.id)}:{})});
    }
    return json({error:'not-found'},404);
  }
  async owner(request,email){
    const url=new URL(request.url),s=this.ctx.storage;
    const base='https://control.vespoli.me/owner/apps/backups/setup';
    if(!email||!url.pathname.startsWith('/owner/apps/backups/setup/'))return json({error:'invalid-capability-call'},403);
    const path=url.pathname.slice('/owner/apps/backups/setup'.length);
    try{
      if(path==='/start'){
        const existing=await s.get('app');
        const state=random();await s.put('setup-state:'+await hash(state),{owner:email,expires:Date.now()+600000});
        const manifest={name:'susanbeasles-backup-control',url:this.env.BACKUP_ORIGIN,public:false,
          hook_attributes:{url:this.env.BACKUP_ORIGIN+'/webhooks/github',active:true},
          redirect_url:base+'/callback',setup_url:base+'/installed',
          default_permissions:{contents:'read',metadata:'read',issues:'read',pull_requests:'read',packages:'read',actions:'write'},
          default_events:['push','create','delete','repository','release','registry_package']};
        const body=existing?`<h1>Install your backup App</h1><p>The App is already registered. Install it for All repositories.</p><a href="https://github.com/apps/${escape(existing.slug)}/installations/new">Install GitHub backup App</a>`:
          `<h1>Connect persistent GitHub backups</h1><p>Register a private App for susanbeasles. It reads repository data and package events, and dispatches backup workflows.</p><form method="post" action="https://github.com/settings/apps/new?state=${state}"><input type="hidden" name="manifest" value="${escape(JSON.stringify(manifest))}"><button>Register GitHub backup App</button></form>`;
        return html(body);
      }
      if(path==='/callback'){
        const stateKey='setup-state:'+await hash(url.searchParams.get('state')||''),state=await s.get(stateKey);
        if(!state||state.owner!==email||state.expires<=Date.now()||!/^[a-zA-Z0-9]{20,100}$/.test(url.searchParams.get('code')||''))return json({error:'invalid-callback'},403);
        if(await s.get('app'))return html('<p>App already registered. Return to the setup link to install it.</p>');
        const app=await github('/app-manifests/'+url.searchParams.get('code')+'/conversions',null,'POST');
        if(app.owner?.login?.toLowerCase()!=='susanbeasles')return json({error:'wrong-github-account'},403);
        // Save only the backup key and webhook secret. OAuth credentials are unnecessary here.
        await s.put('app',{id:app.id,pem:app.pem,webhook_secret:app.webhook_secret,slug:app.slug});
        await s.delete(stateKey);
        return html(`<h1>App registered</h1><p>Next, install it into susanbeasles with <strong>All repositories</strong> selected.</p><a href="https://github.com/apps/${escape(app.slug)}/installations/new">Install GitHub backup App</a>`);
      }
      if(path==='/installed'){
        const app=await s.get('app');if(!app)return json({error:'app-not-registered'},409);
        const values=await github('/app/installations?per_page=100',await jwt(app));
        const installation=values.find(i=>i.account?.login?.toLowerCase()==='susanbeasles');
        if(!installation)return html('<p>Installation is not visible yet. Reload this page after installing the App.</p>');
        if(installation.repository_selection!=='all')return html('<p>Select All repositories for the App installation, then reload this page.</p>');
        await s.put('installation',{id:installation.id,account_id:installation.account.id});
        return html('<h1>GitHub webhook connection is active</h1><p>The Worker can now verify and retain signed deliveries. Backup execution still requires the central backup-control repository and workflow to be installed. Return to ChatGPT to finish activation.</p>');
      }
      if(path==='/status')return json({registered:Boolean(await s.get('app')),installed:Boolean(await s.get('installation'))});
      return json({error:'not-found'},404);
    }catch(e){return json({error:/^github-\d+$/.test(e.message)?e.message:'setup-failed'},502);}
  }
}

