#!/usr/bin/env python3
"""Offline, checksum-verified restoration from replicated R2 key layout."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tarfile


def verified_blob(root, value):
    hash_value = value['sha256']
    if len(hash_value) != 64 or any(c not in '0123456789abcdef' for c in hash_value):
        raise ValueError('invalid-digest')
    key = f'objects/sha256/{hash_value[:2]}/{hash_value}'
    if value['key'] != key:
        raise ValueError('invalid-object-key')
    path = root / key
    h = hashlib.sha256()
    with path.open('rb') as f:
        while b := f.read(16*1024*1024):
            h.update(b)
    if h.hexdigest() != hash_value or path.stat().st_size != value['size']:
        raise ValueError('checksum-mismatch')
    return path


def restore(root, manifest, target):
    if target.exists():
        raise ValueError('restore-target-must-not-exist')
    if manifest['schema'] == 'git-backup/v1':
        archive = verified_blob(root, manifest['archive'])
        with tarfile.open(archive) as tar:
            for item in tar.getmembers():
                path = Path(item.name)
                if path.is_absolute() or '..' in path.parts or item.issym() or item.islnk() or not (item.isfile() or item.isdir()):
                    raise ValueError('unsafe-archive-member')
            target.mkdir(parents=True)
            tar.extractall(target, filter='data')
        asset_dir = target / 'release-assets'
        for asset in manifest.get('release_assets', []):
            asset_dir.mkdir(exist_ok=True)
            shutil.copyfile(verified_blob(root, asset), asset_dir / str(asset['id']))
    elif manifest['schema'] == 'oci-backup/v1':
        blobs = []
        for hash_value, value in manifest['objects'].items():
            if hash_value != 'sha256:' + value['sha256']:
                raise ValueError('descriptor-digest-mismatch')
            blobs.append((hash_value, verified_blob(root, value)))
        if manifest['digest'] not in manifest['objects']:
            raise ValueError('missing-root-manifest')
        target.mkdir(parents=True)
        (target / 'blobs/sha256').mkdir(parents=True)
        for hash_value, path in blobs:
            shutil.copyfile(path, target / 'blobs/sha256' / hash_value[7:])
        (target / 'oci-layout').write_text('{"imageLayoutVersion":"1.0.0"}\n')
        root_value = manifest['objects'][manifest['digest']]
        root_json = json.loads((target / 'blobs/sha256' / manifest['digest'][7:]).read_text())
        descriptor = {'mediaType': root_json['mediaType'], 'digest': manifest['digest'], 'size': root_value['size'],
                      'annotations': {'org.opencontainers.image.ref.name': 'restored'}}
        (target / 'index.json').write_text(json.dumps({'schemaVersion': 2, 'manifests': [descriptor]}) + '\n')
    else:
        raise ValueError('unsupported-manifest-schema')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('bucket_root', type=Path)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    restore(args.bucket_root, json.loads(args.manifest.read_text()), args.destination)

