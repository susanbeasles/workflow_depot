throw Error('Central deployment is required. Package this component from the personal-control repository and use workflow_depot authorization with delivery_control execution.');
