import {readFile,stat,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {canonical,inspectArtifact} from './deployment-contract/contract.mjs';

const configs={
 'personal-control':'wrangler.json',
 'ghcaretaker':'workers/ghcaretaker/wrangler.jsonc',
 'backup-control':'workers/backup-control/wrangler.json',
 'backup-setup':'workers/backup-control/wrangler.setup.json',
};
function requireThat(value,code){if(!value)throw Error(code);}
function baselineBindings(config){
 return [
  ...Object.entries(config.vars||{}).map(([name,text])=>({name,type:'plain_text',text})),
  ...(config.r2_buckets||[]).map(b=>({name:b.binding,type:'r2_bucket',bucket_name:b.bucket_name})),
  ...(config.d1_databases||[]).map(b=>({name:b.binding,type:'d1',database_id:b.database_id})),
  ...(config.kv_namespaces||[]).map(b=>({name:b.binding,type:'kv_namespace',namespace_id:b.id})),
  ...(config.services||[]).map(b=>({name:b.binding,type:'service',service:b.service,...(b.entrypoint?{entrypoint:b.entrypoint}:{})})),
  ...(config.durable_objects?.bindings||[]).map(b=>({name:b.name,type:'durable_object_namespace'})),
 ];
}

// Explicit metadata is reviewed separately and its digest is pinned by central
// policy. This helper never resolves infrastructure IDs or reads credentials.
export async function packageArtifact({bundle,metadata,config}){
 requireThat(metadata&&typeof metadata==='object','reviewed-metadata-required');
 requireThat(config&&typeof bundle==='string'&&bundle.length>0,'bundle-and-config-required');
 requireThat(metadata.compatibility_date===config.compatibility_date&&canonical(metadata.compatibility_flags)===canonical(config.compatibility_flags||[]),'compatibility-settings-differ');
 const bytes=new TextEncoder().encode(canonical({schema:'workflow-depot-worker-artifact/v1',metadata,modules:[{name:'worker.mjs',type:'esm',content:bundle}]}));
 const {artifactDigest,metadataDigest}=await inspectArtifact(bytes,5*1024*1024);
 const required=baselineBindings(config),names=new Set(required.map(b=>b.name));
 requireThat(names.size===required.length,'duplicate-config-binding');
 for(const expected of required){
  const actual=metadata.bindings.find(b=>b.name===expected.name);
  requireThat(actual&&actual.type===expected.type,'baseline-binding-missing-or-changed');
  if(expected.type==='durable_object_namespace')requireThat(/^[a-f0-9]{32}$/.test(actual.namespace_id),'reviewed-namespace-id-required');
  else requireThat(canonical(actual)===canonical(expected),'baseline-binding-missing-or-changed');
 }
 requireThat(metadata.bindings.every(b=>names.has(b.name)||b.type==='inherit'),'unreviewed-additional-binding');
 return {bytes,artifactDigest,metadataDigest};
}

async function boundedFile(path,max){requireThat((await stat(path)).size<=max,'local-input-too-large');return readFile(path,'utf8');}
async function main(){
 const [component,metadataPath,outputPath,...extra]=process.argv.slice(2);
 requireThat(Object.hasOwn(configs,component)&&metadataPath&&outputPath&&!extra.length,'usage: node scripts/package-deployment.mjs <component> <reviewed-metadata.json> <artifact.json>');
 const root=fileURLToPath(new URL('../',import.meta.url));
 const [bundle,rawMetadata,rawConfig]=await Promise.all([boundedFile(resolve(root,'dist/'+component+'.mjs'),5*1024*1024),boundedFile(resolve(metadataPath),65536),boundedFile(resolve(root,configs[component]),65536)]);
 const result=await packageArtifact({bundle,metadata:JSON.parse(rawMetadata),config:JSON.parse(rawConfig)});
 // Exclusive creation prevents silently replacing an artifact under review.
 await writeFile(resolve(outputPath),result.bytes,{flag:'wx'});
 console.log(JSON.stringify({component,artifactDigest:result.artifactDigest,metadataDigest:result.metadataDigest,bytes:result.bytes.length}));
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{await main();}catch{console.error('Artifact packaging failed. Supply a built component, explicit reviewed metadata matching its configuration, and a new output path. See docs/CENTRAL-DEPLOYMENT.md.');process.exitCode=1;}
}
