export function authPlan(desired,apps,policies){
 const owner=apps.find(a=>a.id===desired.owner_application_id);
 if(!owner||owner.domain!==desired.owner_domain||owner.aud!==desired.owner_audience)throw Error('Owner gate differs from the pinned authentication boundary');
 const allowed=new Set(desired.owners);
 const ownerPolicies=policies.result??policies;
 if(!ownerPolicies.length||ownerPolicies.some(p=>p.decision!=='allow'||p.include?.some(rule=>!rule.email||!allowed.has(rule.email.email))||!p.include?.length||p.exclude?.length))throw Error('Owner policies differ from the explicit owner allowlist');
 const actual=new Set(ownerPolicies.flatMap(p=>p.include.map(r=>r.email.email)));
 if(actual.size!==allowed.size||[...allowed].some(x=>!actual.has(x)))throw Error('Owner allowlist incomplete');
 const plan=[];
 if(desired.public_ingress){
  const body=desired.public_ingress;
  if(body.domain!==desired.owner_domain.split('/')[0]||body.policies.length!==1||body.policies[0].decision!=='bypass'||JSON.stringify(body.policies[0].include)!=='[{"everyone":{}}]')throw Error('Invalid public protocol transport');
  const matches=apps.filter(a=>a.name===body.name);if(matches.length>1||matches.some(a=>a.id===owner.id))throw Error('Ambiguous public ingress');
  const existing=matches[0];
  const destinations=x=>JSON.stringify((x.destinations??[]).map(d=>d.type==='worker'?{type:d.type,worker_id:d.worker_id}:{type:d.type,uri:d.uri}).sort((a,b)=>JSON.stringify(a).localeCompare(JSON.stringify(b))));
  if(!existing)plan.push({method:'POST',path:`/accounts/${desired.account_id}/access/apps`,body});
  else if(destinations(existing)!==destinations(body)||existing.domain!==body.domain||existing.policies?.length!==1||existing.policies[0].decision!=='bypass'||JSON.stringify(existing.policies[0].include)!=='[{"everyone":{}}]'||existing.policies[0].exclude?.length||existing.policies[0].require?.length)plan.push({method:'PUT',path:`/accounts/${desired.account_id}/access/apps/${existing.id}`,body});
 }
 return [...plan,...desired.retired_application_ids.filter(id=>apps.some(a=>a.id===id)).map(id=>({method:'DELETE',path:`/accounts/${desired.account_id}/access/apps/${id}`}))];
}
