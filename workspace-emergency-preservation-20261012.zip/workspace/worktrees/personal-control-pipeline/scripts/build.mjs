import {build} from 'esbuild';
import {mkdir} from 'node:fs/promises';
export const workers={
 'personal-control':{root:'.',main:'src/worker.mjs',config:'wrangler.json'},
 'ghcaretaker':{root:'workers/ghcaretaker',main:'src/index.mjs',config:'wrangler.jsonc'},
 'backup-control':{root:'workers/backup-control',main:'src/index.mjs',config:'wrangler.json'},
 'backup-setup':{root:'workers/backup-control',main:'src/setup-worker.mjs',config:'wrangler.setup.json'},
};
await mkdir('dist',{recursive:true});
for(const [name,w] of Object.entries(workers))await build({entryPoints:[w.root+'/'+w.main],outfile:'dist/'+name+'.mjs',bundle:true,format:'esm',platform:'browser',external:['cloudflare:workers'],metafile:false});
