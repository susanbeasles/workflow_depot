import {readFile} from 'node:fs/promises';
import {authPlan} from './auth-plan.mjs';
const desired=JSON.parse(await readFile(new URL('../infrastructure/auth.json',import.meta.url),'utf8'));
if(process.env.CONTROL_PLANE_BUILD!=='1'||!process.env.CLOUDFLARE_API_TOKEN)throw Error('Run in the managed Cloudflare release environment');
async function api(method,path,payload){const r=await fetch('https://api.cloudflare.com/client/v4'+path,{method,headers:{Authorization:'Bearer '+process.env.CLOUDFLARE_API_TOKEN,'Content-Type':'application/json'},...(payload?{body:JSON.stringify(payload)}:{})});const body=await r.json();if(!r.ok||!body.success)throw Error('Access reconciliation failed: '+method+' '+path+' '+JSON.stringify(body.errors));return body;}
let apps=[],page=1;for(;;){const r=await api('GET',`/accounts/${desired.account_id}/access/apps?page=${page}&per_page=100`);apps.push(...r.result);if(page>=(r.result_info?.total_pages??1))break;page++;}
const policies=await api('GET',`/accounts/${desired.account_id}/access/apps/${desired.owner_application_id}/policies`);
const plan=authPlan(desired,apps,policies);
if(!process.argv.includes('--apply')){console.log(JSON.stringify({plan},null,2));}else{for(const op of plan){await api(op.method,op.path,op.body);console.log('Reconciled Access operation',op.path);}console.log('One pinned owner gate; no retired application remains.');}
