// Kept as the existing npm/Workers Build entrypoint so legacy callers stop safely.
throw Error('Central deployment is required. Build and package the reviewed artifact, then use workflow_depot authorization and delivery_control execution. This repository does not deploy Workers, apply migrations, or reconcile Access during release.');
