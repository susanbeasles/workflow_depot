import {readFile} from 'node:fs/promises';
const desired=JSON.parse(await readFile(new URL('../infrastructure/build.json',import.meta.url),'utf8'));
if(!process.argv.includes('--apply')){console.log(JSON.stringify(desired,null,2));process.exit(0);}
if(process.env.CONTROL_PLANE_BUILD!=='1'||!process.env.CLOUDFLARE_API_TOKEN||!process.env.CONTROL_PLANE_BUILD_TOKEN_UUID)throw Error('Use managed provisioning with a server-side deployment token UUID; no secrets belong in Git');
async function api(method,path,payload){const response=await fetch('https://api.cloudflare.com/client/v4'+path,{method,headers:{Authorization:'Bearer '+process.env.CLOUDFLARE_API_TOKEN,'Content-Type':'application/json'},...(payload?{body:JSON.stringify(payload)}:{})});const result=await response.json();if(!response.ok||!result.success)throw Error('Build reconciliation failed: '+JSON.stringify(result.errors));return result.result;}
const base=`/accounts/${desired.account_id}/builds`;
const connection=await api('PUT',base+'/repos/connections',desired.repository);
const connections=Array.isArray(connection)?connection:[connection];const linked=connections.find(x=>x.repo_id===desired.repository.repo_id)||connections[0];
if(!linked?.repo_connection_uuid)throw Error('Repository connection returned no UUID');
const existing=await api('GET',base+'/workers/'+desired.trigger.external_script_id+'/triggers');
const matches=existing.filter(t=>t.trigger_name===desired.trigger.trigger_name);if(matches.length>1)throw Error('Ambiguous managed build trigger');
const payload={...desired.trigger,repo_connection_uuid:linked.repo_connection_uuid,build_token_uuid:process.env.CONTROL_PLANE_BUILD_TOKEN_UUID};
let trigger;
if(matches.length){const {external_script_id,repo_connection_uuid,...patch}=payload;if(matches[0].repo_connection.repo_connection_uuid!==repo_connection_uuid)throw Error('Managed trigger points to another repository');trigger=await api('PATCH',base+'/triggers/'+matches[0].trigger_uuid,patch);}else trigger=await api('POST',base+'/triggers',payload);
const uuid=trigger.trigger_uuid??matches[0]?.trigger_uuid;if(!uuid)throw Error('Build trigger returned no UUID');
await api('PATCH',base+'/triggers/'+uuid+'/environment_variables',desired.environment);
// Preserve the prior deployment path until a complete unified release succeeds.
if(process.argv.includes('--retire-legacy-after-verified-release'))await api('PATCH',base+'/triggers/'+desired.legacy_trigger_uuid,{branch_includes:[],branch_excludes:['*']});
console.log(JSON.stringify({trigger_uuid:uuid,legacy_retired:process.argv.includes('--retire-legacy-after-verified-release')}));
