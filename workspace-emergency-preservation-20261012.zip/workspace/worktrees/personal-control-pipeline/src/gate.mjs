import {owner} from './security.mjs';
import {ownerPath} from './capabilities.mjs';
export function loginTarget(path,env){
  if(typeof path!=='string'||!path.startsWith('/')||path.startsWith('//')||/[\\%\x00-\x20]/.test(path)||path.includes('#')||path.split(/[/?]/).some(p=>p==='.'||p==='..'))throw Error('invalid-return-path');
  const target=new URL(path,env.ORIGIN);if(target.origin!==env.ORIGIN||!ownerPath(target.pathname))throw Error('invalid-return-path');return target.href;
}
export async function ownerGate(request,env,authenticate=owner){
  const email=await authenticate(request,env);
  if(!['GET','POST'].includes(request.method))throw Error('method-not-allowed');
  if(request.method==='POST'&&request.headers.get('origin')!==env.ORIGIN)throw Error('invalid-owner-origin');
  return email;
}
