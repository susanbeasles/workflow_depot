import {profileScopes,alive} from './policy.mjs';
import {hash} from './security.mjs';
import {resource} from './oauth.mjs';
export async function uiSession(c,email,profile){
  const key='ui-session:'+await hash(email)+':'+profile;const cached=await c.storage.get(key);let s=cached?.id?await c.storage.get('session:'+cached.id):undefined;
  if(!alive(s)){s={id:crypto.randomUUID(),owner:email,client:'owner-pane',profile,resource:resource(c.env,profile),scopes:profileScopes(profile),accounts:[c.env.CF_ACCOUNT],zones:c.env.CF_ZONES.split(','),repos:[c.env.GITHUB_OWNER+'/*'],created:Date.now(),expires:Date.now()+600000,perAction:true,revoked:false};await c.storage.put('session:'+s.id,s);await c.storage.put(key,s);}
  return s;
}
