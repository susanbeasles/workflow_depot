import {panel,outcome} from '../ui.mjs';
export async function backupSetupPanel(c,request,email,cap){const u=new URL(request.url),route='/owner/apps/'+cap.id,body=`<h2>${cap.title}</h2><p>${cap.description}</p>`;
    const path=u.pathname.slice((route+'/setup').length)||'/status';
    if(!['/start','/callback','/installed','/status'].includes(path)||request.method!=='GET')throw Error('invalid-setup-route');
    const target=new URL(c.env.ORIGIN+route+'/setup'+path+u.search);
    const response=await c.env.APP_CONFIG.get(c.env.APP_CONFIG.idFromName('owner')).owner(new Request(target),email);
    const type=response.headers.get('content-type')||'';
    if(type.includes('text/html'))return panel(body+await response.text(),cap.id,email);
    return panel(body+outcome(await response.json()),cap.id,email);
}
