import {panel,outcome,toolForm,argumentsFrom} from '../ui.mjs';
import {escape} from '../security.mjs';
import {form,resource} from '../oauth.mjs';
import {uiSession} from '../owner-session.mjs';
export async function caretakerPanel(c,request,email,cap){const u=new URL(request.url),route='/owner/apps/'+cap.id;let body=`<h2>${cap.title}</h2><p>${cap.description}</p>`;
    if(!c.env.CARETAKER)return panel(body+'<p>Caretaker capability binding is unavailable.</p>',cap.id,email);
    const action=u.pathname.slice(route.length)||'/';
    if(action==='/callback'){
      await c.env.CARETAKER.convert(u.searchParams.get('code'),u.searchParams.get('state'),email);
      return Response.redirect(c.env.ORIGIN+route,303);
    }
    const s=await c.env.CARETAKER.status();body+=outcome(s);
    if(request.method==='POST'){
      const f=await form(request);await c.oauth.consumeNonce(f.get('nonce'),email,'caretaker');
      if(f.get('action')==='verify')body+=outcome(await c.env.CARETAKER.install());
      else if(f.get('action')==='register'){const state=await c.env.CARETAKER.begin(email),manifest=await c.env.CARETAKER.manifest();body+=`<form method="post" action="https://github.com/settings/apps/new?state=${escape(state)}"><input type="hidden" name="manifest" value="${escape(JSON.stringify(manifest))}"><button>Review App registration at GitHub</button></form>`;}
      else if(f.get('action')==='tool'){const session=await uiSession(c,email,'caretaker'),tools=await c.env.CARETAKER.tools(session.scopes),tool=tools.find(t=>t.name===f.get('tool'));if(!tool)throw Error('tool-not-granted');const args=argumentsFrom(f,tool.inputSchema);body+=outcome(await c.env.CARETAKER.callTool(tool.name,args,session));}
      else throw Error('unknown-action');
    }
    const nonce=await c.oauth.nonce(email,'caretaker');
    if(s.phase==='empty')body+=`<form method="post"><input type="hidden" name="nonce" value="${nonce}"><button name="action" value="register">Register GitHub App</button></form>`;
    else if(s.phase==='created')body+=`<p><a href="https://github.com/apps/${escape(s.slug)}/installations/new">Install App at GitHub</a></p><form method="post"><input type="hidden" name="nonce" value="${nonce}"><button name="action" value="verify">Verify installation</button></form>`;
    body+=`<p>MCP endpoint: <code>${resource(c.env,'caretaker')}</code></p>`;
    // Owner collaboration is explicit, schema-validated and protected by a one-use nonce.
    for(const tool of await c.env.CARETAKER.tools(['github:read','github:collaborate']))body+=toolForm(tool,nonce,route).replace('<input type="hidden" name="tool"','<input type="hidden" name="action" value="tool"><input type="hidden" name="tool"');
    return panel(body,cap.id,email);
}
