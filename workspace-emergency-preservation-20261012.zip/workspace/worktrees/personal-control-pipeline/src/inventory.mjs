export const inventory={
  "dependency_updates":{"state":"upstream constraint","package":"sharp (Wrangler development toolchain)","result":"Dependabot security_update_not_possible; validate an upstream-compatible toolchain update before changing the pinned build dependencies","run":"https://github.com/susanbeasles/personal-control/actions/runs/37698239989"},
  "unified_build": {"configured":false,"state":"Cloudflare Git integration cannot access personal-control (API 8000012); unified build is declared in infrastructure/build.json but not active"},
  "source_repository": "https://github.com/susanbeasles/personal-control",
  "owner_gate": "https://control.vespoli.me/owner",
  "oauth_issuer": "https://control.vespoli.me",
  "workers": [
    {
      "name": "backup-control",
      "schedules": [
        "*/5 * * * *"
      ],
      "source": "workers/backup-control/src/",
      "deployment": "node scripts/release.mjs backup-control",
      "previous_build_trigger": []
    },
    {
      "name": "backup-setup",
      "schedules": [],
      "source": "workers/backup-control/src/",
      "deployment": "node scripts/release.mjs backup-setup",
      "previous_build_trigger": []
    },
    {
      "name": "ghcaretaker",
      "schedules": [],
      "source": "workers/ghcaretaker/src/",
      "deployment": "node scripts/release.mjs ghcaretaker",
      "previous_build_trigger": [
        {
          "id": "106fb94c-42b8-4b42-9add-9d2e6fed9fd5",
          "repo": "ghcaretaker"
        }
      ]
    },
    {
      "name": "personal-control",
      "schedules": [
        "*/15 * * * *"
      ],
      "source": "src/",
      "deployment": "node scripts/release.mjs personal-control",
      "previous_build_trigger": []
    }
  ],
  "backup": {
    "workflow_repository": "susanbeasles/backup-control",
    "workflow": ".github/workflows/backup.yml",
    "dispatch": "paused",
    "restoration": "workers/backup-control/scripts/restore.py",
    "replication": "workers/backup-control/scripts/replicate.sh"
  },
  "secret_values_in_git": false
};
