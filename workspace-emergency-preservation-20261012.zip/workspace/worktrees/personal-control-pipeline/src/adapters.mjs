import {appJWT,scrub,redactText,safePath} from './security.mjs';
import {authorizeRequest} from './policy.mjs';
import {operations} from './cloudflare-catalog.mjs';

const compiled=operations.map(([path,methods,tag])=>({path,methods:methods.split(','),tag,re:new RegExp('^'+path.replace(/[.*+?^$()|[\]\\]/g,'\\$&').replace(/\{[^}]+\}/g,'[^/]+')+'$')}));
export function cfOperation(path,method){return compiled.find(o=>o.methods.includes(method.toLowerCase())&&o.re.test(path));}
export function catalog(q='',limit=30){q=String(q).toLowerCase();return compiled.filter(o=>(o.path+' '+o.tag).toLowerCase().includes(q)).slice(0,Math.min(100,limit)).map(({path,methods,tag})=>({path,methods,tag}));}
export function queryString(query={}){const s=new URLSearchParams();for(const [k,v] of Object.entries(query)){if(!/^[A-Za-z0-9_.\[\]-]{1,80}$/.test(k)||typeof v==='object'||String(v).length>1000)throw Error('invalid-query');s.set(k,String(v));}return s.size?'?'+s:'';}
export function selectionSet(value){if(typeof value!=='string'||value.length<1||value.length>12000||value.includes('"""')||value.includes('#')||value.includes('...')||value.includes('$'))throw Error('invalid-graphql-selection');let depth=0,quoted=false,escape=false;for(const char of value){if(quoted){if(escape)escape=false;else if(char==='\\')escape=true;else if(char==='"')quoted=false;continue;}if(char==='"'){quoted=true;continue;}if(char==='{')depth++;if(char==='}'&&--depth<0)throw Error('invalid-graphql-selection');}if(quoted||depth!==0)throw Error('invalid-graphql-selection');return value;}
export async function limited(response,limit=131072){const reader=response.body?.getReader();if(!reader)return {text:'',truncated:false};let n=0,parts=[],truncated=false;while(true){const {done,value}=await reader.read();if(done)break;const take=Math.min(value.length,limit-n);parts.push(value.slice(0,take));n+=take;if(n>=limit){truncated=true;await reader.cancel();break;}}const out=new Uint8Array(n);let p=0;for(const a of parts){out.set(a,p);p+=a.length;}return {text:redactText(new TextDecoder().decode(out)),truncated};}
export async function providerResult(response){const r=await limited(response);let data;try{data=scrub(JSON.parse(r.text));}catch{data=r.text;}return {status:response.status,ok:response.ok,data,truncated:r.truncated};}
export const standardCF=path=>/\/workers\/(scripts|services|domains|routes|observability|builds)(\/|$)/.test(path)||/\/(workflows|queues|r2\/buckets)(\/|$)/.test(path);
export const standardGH=path=>path==='/installation/repositories'||/^\/repos\/[^/]+\/[^/]+$/.test(path)||/\/(actions|check-runs|check-suites|deployments|releases|commits)(\/|$)/.test(path);
const readPermissions={actions:'read',checks:'read',contents:'read',deployments:'read',issues:'read',pull_requests:'read',metadata:'read',packages:'read'};
const scopePermission={'github.actions.write':'actions','github.contents.write':'contents','github.workflows.write':'workflows','github.issues.write':'issues','github.pulls.write':'pull_requests','github.administration.write':'administration','github.packages.write':'packages','github.checks.write':'checks','github.deployments.write':'deployments','github.statuses.write':'statuses','github.environments.write':'environments','github.discussions.write':'discussions','github.projects.write':'repository_projects','github.pages.write':'pages','github.security.write':'security_events','github.secrets.write':'secrets'};
export function cloudflareBody(value){
  if(value?.__encoding!=='multipart')return {body:value===undefined?undefined:JSON.stringify(value),contentType:'application/json'};
  if(!Array.isArray(value.parts)||value.parts.length<1||value.parts.length>20)throw Error('invalid-multipart');
  const form=new FormData();for(const part of value.parts){if(!/^[A-Za-z0-9_.-]{1,100}$/.test(part.name)||part.filename&&!/^[A-Za-z0-9_.-]{1,100}$/.test(part.filename)||!['application/json','application/javascript','application/javascript+module','text/plain','text/javascript'].includes(part.content_type)||typeof part.content!=='string')throw Error('invalid-multipart');form.append(part.name,new Blob([part.content],{type:part.content_type}),part.filename||part.name);}
  const metadata=value.parts.find(p=>p.name==='metadata');if(metadata){const m=JSON.parse(metadata.content);if(m.bindings?.some(b=>b.type==='durable_object_namespace'||b.type==='service'||b.type==='inherit'||b.bucket_name==='backup-webhooks'||b.script_name==='backup-setup'||b.type==='secret_text'))throw Error('protected-worker-binding');if(m.migrations||m.tags?.includes('personal-control'))throw Error('protected-worker-metadata');}
  return {body:form};
}
export class Providers {
  constructor(control){this.c=control;this.env=control.env;this.adapters=new Map([['cloudflare',{request:this.cloudflareRequest.bind(this)}],['github',{request:this.githubRequest.bind(this)}]]);}
  register(name,adapter){if(this.adapters.has(name)||typeof adapter?.request!=='function')throw Error('invalid-adapter');this.adapters.set(name,adapter);}
  async githubApp(profile){let app=await this.c.vault.get('credential:github:'+profile);if(!app&&profile==='standard'&&this.env.APP_CONFIG){const r=await this.env.APP_CONFIG.get(this.env.APP_CONFIG.idFromName('owner')).fetch('https://internal/config/internal');const v=await r.json();if(v.GITHUB_APP_ID&&v.GITHUB_INSTALLATION_ID)app={id:v.GITHUB_APP_ID,pem:v.GITHUB_APP_PRIVATE_KEY,installation:v.GITHUB_INSTALLATION_ID,webhook_secret:v.WEBHOOK_SECRET,legacy:true};}if(!app?.installation)throw Error('github-profile-not-connected');return app;}
  async githubToken(session,scope,path=''){const app=await this.githubApp(session.profile);let permissions;
    if(scope){const name=scope==='github.secrets.write'&&path.includes('/dependabot/secrets')?'dependabot_secrets':scope==='github.secrets.write'&&path.includes('/codespaces/secrets')?'codespaces_secrets':scopePermission[scope];if(!name)throw Error('unsupported-github-write-scope');permissions={[name]:'write',metadata:'read',...(scope==='github.workflows.write'?{contents:'write'}:{}),...(scope==='github.security.write'?{secret_scanning_alerts:'write',vulnerability_alerts:'write'}:{})};}
    else if(session.profile==='standard')permissions=app.legacy?{actions:'read',contents:'read',issues:'read',pull_requests:'read',metadata:'read',packages:'read'}:readPermissions;
    else permissions=Object.fromEntries(Object.keys(app.permissions||readPermissions).filter(k=>!['codespaces_secrets','workflows'].includes(k)).map(k=>[k,'read']));
    const resp=await fetch(`https://api.github.com/app/installations/${app.installation}/access_tokens`,{method:'POST',headers:{authorization:'Bearer '+await appJWT(app),'user-agent':'personal-control','x-github-api-version':'2022-11-28','content-type':'application/json',accept:'application/vnd.github+json'},body:JSON.stringify({permissions,...(!session.repos.includes(this.env.GITHUB_OWNER+'/*')?{repositories:session.repos.map(r=>r.split('/')[1])}:{})})});
    if(!resp.ok)throw Error('github-installation-token-'+resp.status);return (await resp.json()).token;
  }
  async request(session,provider,path,method='GET',query={},bodyValue,scope){safePath(path);authorizeRequest(session,session.profile,provider,path,method,this.env,{write:method!=='GET'});
    if(session.profile==='standard'&&!(provider==='github'?standardGH(path):standardCF(path)))throw Error('standard-visibility-boundary');
    const adapter=this.adapters.get(provider);if(!adapter)throw Error('unknown-provider');return adapter.request(session,path,method,query,bodyValue,scope);
  }
  async cloudflareRequest(session,path,method,query,bodyValue){
      if(!cfOperation(path,method))throw Error('unknown-cloudflare-operation');
      const token=await this.c.vault.get('credential:cloudflare:'+session.profile);if(!token)throw Error('cloudflare-profile-not-connected');
      if(method!=='GET'){
        const name=new URL(this.env.ORIGIN).hostname;for(const candidate of [bodyValue,bodyValue?.metadata,bodyValue?.settings]){if(candidate?.bindings?.some(b=>['durable_object_namespace','service','inherit'].includes(b.type)||b.bucket_name==='backup-webhooks'||b.script_name==='backup-setup'))throw Error('protected-worker-binding');}
        if(bodyValue?.name===name||bodyValue?.pattern?.includes(name)||bodyValue?.script==='personal-control'||JSON.stringify(bodyValue||{}).includes('"personal-control"'))throw Error('authorization-boundary-protected');
        if(/\/dns_records\/[^/]+$/.test(path)){const existing=await fetch('https://api.cloudflare.com/client/v4'+path,{headers:{authorization:'Bearer '+token},redirect:'manual'});if(!existing.ok)throw Error('dns-safety-check-unavailable');if((await existing.json()).result?.name===name)throw Error('authorization-boundary-protected');}
      }
      const encoded=cloudflareBody(bodyValue);return providerResult(await fetch('https://api.cloudflare.com/client/v4'+path+queryString(query),{method,headers:{authorization:'Bearer '+token,...(encoded.contentType?{'content-type':encoded.contentType}:{})},body:encoded.body,redirect:'manual'}));
  }
  async githubRequest(session,path,method,query,bodyValue,scope){
    const token=await this.githubToken(session,scope,path);const response=await fetch('https://api.github.com'+path+queryString(query),{method,headers:{authorization:'Bearer '+token,'user-agent':'personal-control',accept:'application/vnd.github+json','x-github-api-version':'2022-11-28','content-type':'application/json'},body:bodyValue===undefined?undefined:JSON.stringify(bodyValue),redirect:'manual'});
    if(method==='GET'&&response.status===302&&/\/actions\/(jobs|runs)\/\d+\/logs$/.test(path)){
      const destination=new URL(response.headers.get('location'));
      if(destination.protocol!=='https:'||destination.username||destination.password||!['.blob.core.windows.net','.actions.githubusercontent.com','.githubusercontent.com'].some(s=>destination.hostname.endsWith(s)))throw Error('untrusted-log-destination');
      // Never forward the installation credential to the signed storage URL.
      return providerResult(await fetch(destination,{redirect:'manual'}));
    }
    return providerResult(response);
  }
  async logs(session,args){authorizeRequest(session,session.profile,'cloudflare',`/accounts/${this.env.CF_ACCOUNT}/workers/observability/telemetry/query`,'GET',this.env);const token=await this.c.vault.get('credential:cloudflare:'+session.profile);if(!token)throw Error('cloudflare-profile-not-connected');const now=Date.now(),from=Number(args.from||now-3600000),to=Number(args.to||now);if(!Number.isFinite(from)||!Number.isFinite(to)||to<=from||to-from>86400000||to>now+60000)throw Error('invalid-log-window');return providerResult(await fetch(`https://api.cloudflare.com/client/v4/accounts/${this.env.CF_ACCOUNT}/workers/observability/telemetry/query`,{method:'POST',headers:{authorization:'Bearer '+token,'content-type':'application/json'},body:JSON.stringify({queryId:crypto.randomUUID(),timeframe:{from,to},view:'events',limit:Math.min(100,Math.max(1,Number(args.limit||30))),parameters:{needle:{value:String(args.worker||'').slice(0,128)}},dry:true}),redirect:'manual'}));}
  async graphql(session,provider,args){if(session.profile==='standard')throw Error('standard-visibility-boundary');const selection=selectionSet(args.selection);let url,token,query;
    if(provider==='cloudflare'){const zone=args.zone;const path=zone?'/zones/'+zone:'/accounts/'+this.env.CF_ACCOUNT;authorizeRequest(session,session.profile,provider,path,'GET',this.env);token=await this.c.vault.get('credential:cloudflare:'+session.profile);if(!token)throw Error('cloudflare-profile-not-connected');query=`query { viewer { ${zone?'zones(filter: {zoneTag: '+JSON.stringify(zone)+'})':'accounts(filter: {accountTag: '+JSON.stringify(this.env.CF_ACCOUNT)+'})'} { ${selection} } } }`;url='https://api.cloudflare.com/client/v4/graphql';}
    else {if(!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(args.repository))throw Error('invalid-repository');authorizeRequest(session,session.profile,provider,'/repos/'+args.repository,'GET',this.env);token=await this.githubToken(session);const [owner,name]=args.repository.split('/');query=`query { repository(owner:${JSON.stringify(owner)},name:${JSON.stringify(name)}) { ${selection} } }`;url='https://api.github.com/graphql';}
    return providerResult(await fetch(url,{method:'POST',headers:{authorization:'Bearer '+token,'content-type':'application/json','user-agent':'personal-control'},body:JSON.stringify({query}),redirect:'manual'}));
  }
}

