import {b64,unb64,random,appJWT} from './security.mjs';
const encoder=new TextEncoder();
export class CredentialVault {
  constructor(control){this.c=control;}
  async key(){if(!this.c.env.CREDENTIAL_KEK)throw Error('credential-vault-unavailable');return crypto.subtle.importKey('raw',unb64(this.c.env.CREDENTIAL_KEK),'AES-GCM',false,['encrypt','decrypt']);}
  async set(name,value){if(!name.startsWith('credential:'))throw Error('invalid-vault-record');const iv=crypto.getRandomValues(new Uint8Array(12));const ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:encoder.encode(name)},await this.key(),encoder.encode(JSON.stringify(value)));await this.c.storage.put(name,{vault:1,iv:b64(iv),ciphertext:b64(ciphertext)});}
  async get(name){const record=await this.c.storage.get(name);if(record===undefined)return undefined;if(record?.vault===1){return JSON.parse(new TextDecoder().decode(await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(record.iv),additionalData:encoder.encode(name)},await this.key(),unb64(record.ciphertext))));}await this.set(name,record);return record;}
  async migrate(){for(const [name] of await this.c.storage.list({prefix:'credential:',limit:100}))await this.get(name);}
}
// Called only after owner() has validated the Access signature, issuer, audience and identity.
export function requireFreshHardware(request,now=Date.now()){
  const jwt=request.headers.get('cf-access-jwt-assertion')||'';
  let claims;try{claims=JSON.parse(new TextDecoder().decode(unb64(jwt.split('.')[1])));}catch{throw Error('fresh-hardware-mfa-required');}
  if(!Array.isArray(claims.amr)||!claims.amr.includes('hwk')||!claims.amr.includes('mfa')||!Number.isFinite(claims.auth_time)||claims.auth_time>now/1000+30||now/1000-claims.auth_time>300)throw Error('fresh-hardware-mfa-required');
}
export class CredentialManager {
  constructor(control){this.c=control;}
  async revokeSessions(email){let count=0;for(const [key,s] of await this.c.storage.list({prefix:'session:',limit:10000})){if(s.owner===email&&!s.revoked){s.revoked=true;await this.c.storage.put(key,s);count++;}}await this.c.audit('session.revoke-all',{owner:email,count});return {revoked:count};}
  async rotateWebhook(profile,email){
    const name='credential:github:'+profile,app=await this.c.vault.get(name);
    if(!app?.installation)throw Error('dedicated-github-app-required');
    if(app.legacy)throw Error('legacy-shared-app-rotation-blocked');
    if(app.webhook_rotation?.state==='pending'||app.webhook_rotation?.state==='uncertain')throw Error('webhook-rotation-reconciliation-required');
    const candidate=random(),id=crypto.randomUUID();
    // Persist before the upstream update so a crash cannot lose the successor secret.
    app.webhook_rotation={id,state:'pending',candidate,created_at:Date.now()};await this.c.vault.set(name,app);
    await this.c.audit('credential.rotation-started',{provider:'github',kind:'webhook',profile,id,owner:email});
    let response;
    try{response=await fetch('https://api.github.com/app/hook/config',{method:'PATCH',redirect:'manual',headers:{authorization:'Bearer '+await appJWT(app),'user-agent':'personal-control-rotation',accept:'application/vnd.github+json','content-type':'application/json','x-github-api-version':'2022-11-28'},body:JSON.stringify({secret:candidate})});}
    catch{app.webhook_rotation.state='uncertain';await this.c.vault.set(name,app);throw Error('webhook-rotation-reconciliation-required');}
    if(!response.ok){app.webhook_rotation.state='uncertain';await this.c.vault.set(name,app);await this.c.audit('credential.rotation-uncertain',{profile,id,status:response.status});throw Error('webhook-rotation-reconciliation-required');}
    app.previous_webhook_secret={value:app.webhook_secret,expires:Date.now()+300000};app.webhook_secret=candidate;app.webhook_rotation={id,state:'switched-awaiting-delivery',switched_at:Date.now()};await this.c.vault.set(name,app);
    await this.c.audit('credential.rotation-switched',{provider:'github',kind:'webhook',profile,id,owner:email});return {id,state:'switched-awaiting-delivery',old_secret_grace_seconds:300};
  }
}

