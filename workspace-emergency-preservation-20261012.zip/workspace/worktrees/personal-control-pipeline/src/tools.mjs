import {catalog,cfOperation,cloudflareBody} from './adapters.mjs';
import {scrub,redactText,hash} from './security.mjs';
import {authorizeRequest,mutationScope} from './policy.mjs';
const string={type:'string'},integer={type:'integer'},query={type:'object',additionalProperties:{type:['string','number','boolean']}};
const define=(name,description,properties={},required=[],write=false)=>({name,description,inputSchema:{type:'object',properties,required,additionalProperties:false},annotations:{readOnlyHint:!write,destructiveHint:write,idempotentHint:!write,openWorldHint:true}});
const base=[
  define('connection_status','Provider connectivity, backup storage and current permission/session status.'),
  define('workers_list','List Cloudflare Worker deployments.'),
  define('worker_settings','Read bindings and configuration metadata. Secret values are not exported.',{worker:string},['worker']),
  define('worker_logs','Query Worker telemetry within a maximum 24-hour window; results are bounded.',{worker:string,from:integer,to:integer,limit:integer}),
  define('cloudflare_jobs','Inspect Cloudflare Workflows or Worker build jobs.',{path:string,query},['path']),
  define('github_repositories','List repositories accessible to this profile installation.',{page:integer}),
  define('github_actions_runs','List workflow runs for a granted repository.',{repository:string,workflow:string,page:integer},['repository']),
  define('github_actions_jobs','Read jobs and step outcomes for a workflow run.',{repository:string,run_id:integer},['repository','run_id']),
  define('github_job_log','Read a bounded job log without forwarding credentials to storage.',{repository:string,job_id:integer},['repository','job_id']),
  define('github_artifacts','List workflow run artifact metadata; signed download URLs are not generated.',{repository:string,run_id:integer},['repository','run_id']),
  define('webhook_deliveries','List retained GitHub webhook delivery metadata.',{prefix:string,cursor:string,limit:integer}),
  define('webhook_delivery','Read one retained webhook payload.',{key:string},['key']),
  define('backup_catalog','List tagged backup manifests and catalog entries in a selected bucket.',{bucket:{type:'string',enum:['git','canon','hot']},prefix:string,cursor:string,limit:integer},['bucket']),
  define('backup_manifest','Read a JSON backup manifest or tag record.',{bucket:{type:'string',enum:['git','canon','hot']},key:string},['bucket','key']),
  define('audit_entries','List immutable audit journal records.',{cursor:string,limit:integer}),
  define('audit_entry','Read one gateway audit record.',{key:string},['key']),
  define('current_session','Read profile, granted scopes/resources, expiry and approval requirements.'),
];
const deeper=[
  define('api_catalog','Search the Cloudflare endpoint catalogue or list GitHub adapter families.',{provider:{type:'string',enum:['cloudflare','github']},query:string,limit:integer},['provider']),
  define('cloudflare_read','Read any catalogued GET endpoint under the granted Cloudflare account or zones. Credential-export endpoints are blocked.',{path:string,query},['path']),
  define('github_read','Read a GitHub GET endpoint within the granted repositories or owner public metadata. Upstream installation permissions still apply.',{path:string,query},['path']),
  define('cloudflare_graphql','Read Cloudflare GraphQL analytics fields inside the granted account or selected zone. Supply a balanced field selection; the server constructs the read-only query.',{selection:string,zone:string},['selection']),
  define('github_graphql','Read GitHub GraphQL fields within one granted repository. Supply a balanced field selection; the server constructs the read-only query.',{repository:string,selection:string},['repository','selection']),
];
const writes=[define('write_plan','Create an immutable mutation plan for an explicitly granted scope. Returns an owner approval link when required.',{provider:{type:'string',enum:['github','cloudflare']},method:{type:'string',enum:['POST','PUT','PATCH','DELETE']},path:string,query,body:{},reason:string},['provider','method','path','reason'],true),define('write_execute','Execute a session-owned, approved mutation plan once. Ambiguous failures are not automatically retried.',{plan_id:string},['plan_id'],true)];
writes[0].annotations.destructiveHint=false;
writes.push(define('write_plan_status','Inspect status and bounded outcome of a mutation plan belonging to this session.',{plan_id:string},['plan_id']));
export function toolList(session){const hasRead=session.scopes.includes(session.profile==='standard'?'standard.read':'super.read');return [...(hasRead?base:base.filter(t=>t.name==='current_session')),...(hasRead&&session.profile!=='standard'?deeper:[]),...(session.profile==='write'&&session.scopes.some(x=>x.endsWith('.write'))?writes:[])];}
export function publicSession(s){return {id:s.id,profile:s.profile,scopes:s.scopes,accounts:s.accounts,zones:s.zones,repositories:s.repos,created_at:new Date(s.created).toISOString(),expires_at:s.expires===null?null:new Date(s.expires).toISOString(),indefinite:s.expires===null,per_action_approval:s.perAction,revoked:!!s.revoked};}
function repository(s,name,env){if(!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(name))throw Error('invalid-repository');authorizeRequest(s,s.profile,'github','/repos/'+name,'GET',env);return '/repos/'+name;}
const number=(v)=>{if(!Number.isSafeInteger(v)||v<1)throw Error('invalid-id');return v;};
const segment=v=>{if(!/^[A-Za-z0-9_.-]{1,128}$/.test(v))throw Error('invalid-name');return v;};
export async function callTool(c,s,name,a={}){
  if(!toolList(s).some(x=>x.name===name))throw Error('tool-not-granted');
  const p=c.providers,e=c.env;
  switch(name){
    case 'current_session':return publicSession(s);
    case 'connection_status':return c.status(s.profile);
    case 'workers_list':return p.request(s,'cloudflare',`/accounts/${e.CF_ACCOUNT}/workers/scripts`);
    case 'worker_settings':return p.request(s,'cloudflare',`/accounts/${e.CF_ACCOUNT}/workers/scripts/${segment(a.worker)}/settings`);
    case 'worker_logs':return p.logs(s,a);
    case 'cloudflare_jobs':if(!/^\/accounts\/[A-Za-z0-9_-]+\/(workflows|builds)(?:\/|$)/.test(a.path))throw Error('not-a-job-endpoint');return p.request(s,'cloudflare',a.path,'GET',a.query);
    case 'github_repositories':return p.request(s,'github','/installation/repositories','GET',{per_page:100,page:a.page||1});
    case 'github_actions_runs':return p.request(s,'github',repository(s,a.repository,e)+'/actions/'+(a.workflow?'workflows/'+segment(a.workflow)+'/runs':'runs'),'GET',{per_page:30,page:a.page||1});
    case 'github_actions_jobs':return p.request(s,'github',repository(s,a.repository,e)+`/actions/runs/${number(a.run_id)}/jobs`,'GET',{per_page:100});
    case 'github_job_log':return p.request(s,'github',repository(s,a.repository,e)+`/actions/jobs/${number(a.job_id)}/logs`);
    case 'github_artifacts':return p.request(s,'github',repository(s,a.repository,e)+`/actions/runs/${number(a.run_id)}/artifacts`);
    case 'webhook_deliveries':return c.listBucket(e.EVENTS,'events/',a,false);
    case 'webhook_delivery':return c.readBucket(e.EVENTS,a.key,'events/',false);
    case 'audit_entries':return c.listBucket(e.EVENTS,'events/control-audit/',a,true);
    case 'audit_entry':return c.readBucket(e.EVENTS,a.key,'events/control-audit/',true);
    case 'backup_catalog':return c.listBucket(c.bucket(a.bucket),'manifests/',a,true);
    case 'backup_manifest':return c.readBucket(c.bucket(a.bucket),a.key,'',true,true);
    case 'api_catalog':return a.provider==='cloudflare'?catalog(a.query,a.limit):{families:['repositories','actions/runs','actions/jobs','issues','pulls','contents','git','releases','deployments','checks','security alerts','environments','packages'],restriction:'Repository resources must belong to an explicitly granted installation and repository. Encrypted secret values are unavailable.'};
    case 'cloudflare_read':return p.request(s,'cloudflare',a.path,'GET',a.query);
    case 'github_read':return p.request(s,'github',a.path,'GET',a.query);
    case 'cloudflare_graphql':return p.graphql(s,'cloudflare',a);
    case 'github_graphql':return p.graphql(s,'github',a);
    case 'write_plan_status':{const plan=await c.storage.get('plan:'+a.plan_id);if(!plan||plan.session!==s.id)throw Error('plan-not-found');return {id:plan.id,status:plan.status,operation_hash:plan.hash,provider:plan.provider,method:plan.method,path:plan.path,scope:plan.scope,expires_at:new Date(plan.expires).toISOString(),result:plan.result};}
    case 'write_plan':{
      authorizeRequest(s,s.profile,a.provider,a.path,a.method,e,{write:true});if(a.provider==='cloudflare'){if(!cfOperation(a.path,a.method))throw Error('unknown-cloudflare-operation');cloudflareBody(a.body);}
      const plan={id:crypto.randomUUID(),session:s.id,provider:a.provider,path:a.path,method:a.method,query:a.query||{},body:a.body,reason:String(a.reason).slice(0,1000),scope:mutationScope(a.provider,a.path),created:Date.now(),expires:Math.min(Date.now()+600000,s.expires||Infinity),status:s.perAction?'pending':'approved'};
      // The hash covers the exact immutable operation shown on the owner approval page.
      plan.hash=await hash(JSON.stringify(plan));await c.audit('write.plan',{session:s.id,plan:plan.id,hash:plan.hash,provider:plan.provider,method:plan.method,path:plan.path,scope:plan.scope});await c.storage.put('plan:'+plan.id,plan);
      return {plan_id:plan.id,operation_hash:plan.hash,status:plan.status,expires_at:new Date(plan.expires).toISOString(),approval_url:s.perAction?e.ORIGIN+'/owner/approve?id='+plan.id:null};
    }
    case 'write_execute':{
      const plan=await c.storage.get('plan:'+a.plan_id);if(!plan||plan.session!==s.id||plan.status!=='approved'||plan.expires<=Date.now())throw Error('plan-not-approved-or-expired');
      authorizeRequest(s,s.profile,plan.provider,plan.path,plan.method,e,{write:true});
      await c.audit('write.started',{session:s.id,plan:plan.id,hash:plan.hash,provider:plan.provider,method:plan.method,path:plan.path});
      plan.status='executing';await c.storage.put('plan:'+plan.id,plan);
      try{const result=await p.request(s,plan.provider,plan.path,plan.method,plan.query,plan.body,plan.scope);plan.status=result.ok?'succeeded':'failed';plan.result=scrub(result);await c.storage.put('plan:'+plan.id,plan);await c.audit('write.finished',{session:s.id,plan:plan.id,status:plan.status,upstream_status:result.status});return {plan_id:plan.id,...result};}catch(err){plan.status='unknown';await c.storage.put('plan:'+plan.id,plan);await c.audit('write.unknown',{session:s.id,plan:plan.id,error:err.message});throw Error('write-outcome-unknown-check-provider-before-replanning');}
    }
  }
  throw Error('unknown-tool');
}

