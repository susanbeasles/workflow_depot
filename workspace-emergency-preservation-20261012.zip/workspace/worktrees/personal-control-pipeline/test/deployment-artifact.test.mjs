import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

test('legacy deploy entrypoints fail closed even when old credential variables are present',async()=>{
 for(const path of ['scripts/release.mjs','workers/ghcaretaker/scripts/deploy.mjs']){
  const source=(await readFile(path,'utf8')).replace(/^import .*;\n/gm,'');let effects=0;
  const effect=()=>{effects++;throw Error('unexpected deployment side effect');};
  assert.throws(()=>vm.runInNewContext(source,{process:{env:{CONTROL_PLANE_BUILD:'1',CLOUDFLARE_API_TOKEN:'synthetic-token'},argv:['node',path,'all'],execPath:'node'},execFileSync:effect,resolve:()=>'',config:effect,check:effect,console:{log(){}}}),/Central deployment is required/);
  assert.equal(effects,0);
 }
});
const config={compatibility_date:'2026-10-06',compatibility_flags:[],vars:{PUBLIC_ORIGIN:'https://control.vespoli.me'},r2_buckets:[{binding:'EVENTS',bucket_name:'backup-webhooks'}],services:[{binding:'CARETAKER',service:'ghcaretaker',entrypoint:'CaretakerCapability'}],durable_objects:{bindings:[{name:'CONTROL',class_name:'Control'}]}};
const metadata={main_module:'worker.mjs',compatibility_date:config.compatibility_date,compatibility_flags:[],bindings:[{name:'PUBLIC_ORIGIN',type:'plain_text',text:'https://control.vespoli.me'},{name:'EVENTS',type:'r2_bucket',bucket_name:'backup-webhooks'},{name:'CARETAKER',type:'service',service:'ghcaretaker',entrypoint:'CaretakerCapability'},{name:'CONTROL',type:'durable_object_namespace',namespace_id:'a'.repeat(32)}]};
test('offline packaging produces deterministic exact artifact and metadata digests',async()=>{
 const {packageArtifact}=await import('../scripts/package-deployment.mjs');
 const bundle='export default {fetch(){return new Response("synthetic")}}';
 const one=await packageArtifact({bundle,metadata,config}),two=await packageArtifact({bundle,metadata:structuredClone(metadata),config});
 assert.deepEqual(one,two);assert.match(one.artifactDigest,/^[a-f0-9]{64}$/);assert.match(one.metadataDigest,/^[a-f0-9]{64}$/);
 const artifact=JSON.parse(new TextDecoder().decode(one.bytes));assert.equal(artifact.schema,'workflow-depot-worker-artifact/v1');assert.equal(artifact.modules[0].content,bundle);assert.deepEqual(artifact.metadata,metadata);
 const changed=await packageArtifact({bundle:bundle+'\n',metadata,config});assert.notEqual(changed.artifactDigest,one.artifactDigest);assert.equal(changed.metadataDigest,one.metadataDigest);
});
test('packaging refuses missing or changed baseline bindings and unresolved namespace IDs',async()=>{
 const {packageArtifact}=await import('../scripts/package-deployment.mjs');
 for(const change of [m=>m.bindings.pop(),m=>{m.bindings[1].bucket_name='different-bucket';},m=>{m.bindings[3]={name:'CONTROL',type:'durable_object_namespace',class_name:'Control'};},m=>{m.compatibility_date='2026-10-12';},m=>{m.migrations=[];},m=>m.bindings.push({name:'NEW_AUTHORITY',type:'service',service:'other'})]){
  const candidate=structuredClone(metadata);change(candidate);await assert.rejects(packageArtifact({bundle:'export default {}',metadata:candidate,config}));
 }
 await assert.rejects(packageArtifact({bundle:'export default {}',config}),/reviewed-metadata-required/);
});
test('approved inherited secret names are preserved without accepting literal secret values',async()=>{
 const {packageArtifact}=await import('../scripts/package-deployment.mjs');
 const candidate=structuredClone(metadata);candidate.bindings.push({name:'EXISTING_SECRET',type:'inherit'});
 assert.match((await packageArtifact({bundle:'export default {}',metadata:candidate,config})).artifactDigest,/^[a-f0-9]{64}$/);
 candidate.bindings.at(-1).type='secret_text';candidate.bindings.at(-1).text='synthetic-secret';await assert.rejects(packageArtifact({bundle:'export default {}',metadata:candidate,config}));
});
