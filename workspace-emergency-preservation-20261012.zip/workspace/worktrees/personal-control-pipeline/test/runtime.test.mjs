import test from 'node:test';
import assert from 'node:assert/strict';
import {Miniflare,convertV4MiniflareOptions} from 'miniflare';
import {build} from 'esbuild';
import {readFile} from 'node:fs/promises';
test('real multi-worker runtime has one gate and private capability calls',async()=>{
 const bundled=async entry=>(await build({entryPoints:[entry],bundle:true,write:false,format:'esm',platform:'browser',external:['cloudflare:workers']})).outputFiles[0].text;
 const pair=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
 const jwk=await crypto.subtle.exportKey('jwk',pair.publicKey);jwk.kid='integration';
 const claims={iss:'https://vespoli.cloudflareaccess.com',aud:['owner-gate'],email:'owner@example.com',sub:'owner',nbf:Date.now()/1000-10,exp:Date.now()/1000+300};
 const tokenInput=Buffer.from(JSON.stringify({alg:'RS256',kid:'integration'})).toString('base64url')+'.'+Buffer.from(JSON.stringify(claims)).toString('base64url');
 const token=tokenInput+'.'+Buffer.from(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',pair.privateKey,new TextEncoder().encode(tokenInput))).toString('base64url');
 const core=JSON.parse(await readFile('wrangler.json','utf8')).vars;
 const sibling=await import('node:fs/promises');const base=await sibling.stat('workers/ghcaretaker').then(()=> 'workers/').catch(()=> '../');
 const workers=[
  {name:'gateway',modules:true,script:await bundled('src/worker.mjs'),compatibilityDate:'2026-10-06',bindings:{...core,ACCESS_AUD:'owner-gate',OWNER_EMAILS:'owner@example.com'},durableObjects:{CONTROL:{className:'Control',useSQLite:true},APP_CONFIG:{className:'Bootstrap',scriptName:'setup',useSQLite:true}},serviceBindings:{CARETAKER:{name:'caretaker',entrypoint:'CaretakerCapability'},BACKUP:{name:'backup',entrypoint:'BackupCapability'}},r2Buckets:['EVENTS','GIT','CANON','HOT'],outboundService:async request=>{assert.equal(request.url,'https://vespoli.cloudflareaccess.com/cdn-cgi/access/certs');return Response.json({keys:[jwk]});}},
  {name:'caretaker',modules:true,script:await bundled(base+'ghcaretaker/src/index.mjs'),compatibilityDate:'2026-10-05',bindings:{PUBLIC_ORIGIN:'https://mcp.vespoli.me',AUTH_ORIGIN:'https://control.vespoli.me',MCP_PATH:'/ghcaretaker',GITHUB_OWNER:'susanbeasles',GITHUB_OWNER_ID:'215839550'},durableObjects:{APP_VAULT:{className:'AppVault',useSQLite:true}},serviceBindings:{AUTH_GATEWAY:'gateway'},r2Buckets:['AUDIT_BUCKET'],d1Databases:['AUDIT_DB']},
  {name:'setup',modules:true,script:await bundled(base+'backup-control/src/setup-worker.mjs'),compatibilityDate:'2026-10-06',bindings:{AUTH_ORIGIN:'https://control.vespoli.me',BACKUP_ORIGIN:'https://backup-control.anthonyvespoli.workers.dev'},durableObjects:{BOOTSTRAP:{className:'Bootstrap',useSQLite:true}}},
  {name:'backup',modules:true,script:await bundled(base+'backup-control/src/index.mjs'),compatibilityDate:'2026-10-06',bindings:{GITHUB_OWNER:'susanbeasles',CONTROL_REPO:'susanbeasles/backup-control'},durableObjects:{OUTBOX:{className:'Outbox',useSQLite:true},APP_CONFIG:{className:'Bootstrap',scriptName:'setup',useSQLite:true}},r2Buckets:['EVENTS','GIT','CANON','HOT']},
 ];
 const mf=new Miniflare(convertV4MiniflareOptions({workers}));
 try{
  const gateway=await mf.getWorker('gateway'),setup=await mf.getWorker('setup'),caretaker=await mf.getWorker('caretaker');
  let r=await gateway.fetch('https://control.vespoli.me/owner',{redirect:'manual'});assert.equal(r.status,401);
  for(const route of ['/owner/apps/caretaker','/owner/apps/backups','/owner/apps/backups/setup/status']){r=await gateway.fetch('https://control.vespoli.me'+route,{headers:{'cf-access-jwt-assertion':token}});const body=await r.text();assert.equal(r.status,200,body);assert.match(body,/Control navigation/);assert.ok(!body.includes('PRIVATE KEY'));}
  r=await caretaker.fetch('https://mcp.vespoli.me/ghcaretaker/setup',{redirect:'manual'});assert.equal(r.status,303);assert.equal(r.headers.get('location'),'https://control.vespoli.me/owner/apps/caretaker');
  r=await setup.fetch('https://setup/start',{redirect:'manual'});assert.equal(r.status,303);assert.equal(r.headers.get('location'),'https://control.vespoli.me/owner/apps/backups/setup/start');
  r=await gateway.fetch('https://control.vespoli.me/mcp/caretaker',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/list'})});assert.equal(r.status,401);
  r=await gateway.fetch('https://control.vespoli.me/owner/apps/backups',{method:'POST',headers:{'cf-access-jwt-assertion':token,origin:'https://evil.example'}});assert.ok([400,403].includes(r.status));
 }finally{await mf.dispose();}
});
