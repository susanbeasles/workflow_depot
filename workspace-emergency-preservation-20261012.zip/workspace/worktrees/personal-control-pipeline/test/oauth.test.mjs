import test from 'node:test';
import assert from 'node:assert/strict';
import {OAuth,resource} from '../src/oauth.mjs';
import {hash} from '../src/security.mjs';
import {profileScopes} from '../src/policy.mjs';
const env={ORIGIN:'https://control.vespoli.me',CF_ACCOUNT:'account',CF_ZONES:'zone',GITHUB_OWNER:'susanbeasles'};
function fixture(){const data=new Map(),storage={get:async k=>structuredClone(data.get(k)),put:async(k,v)=>data.set(k,structuredClone(v)),delete:async k=>data.delete(k)};return {oauth:new OAuth({env,storage,audit:async()=>{}}),data,storage};}
const post=(path,v)=>new Request(env.ORIGIN+path,{method:'POST',body:new URLSearchParams(v)});
test('shared issuer binds PKCE, callback, profile, resources and single-use code',async()=>{
 const {oauth,storage,data}=fixture();const verifier='v'.repeat(43);
 const client=await (await oauth.register(new Request(env.ORIGIN+'/oauth/register',{method:'POST',body:JSON.stringify({redirect_uris:['https://chatgpt.com/callback']})}))).json();
 const params={client_id:client.client_id,redirect_uri:'https://chatgpt.com/callback',response_type:'code',resource:resource(env,'caretaker'),code_challenge:await hash(verifier),code_challenge_method:'S256',scope:'github:read',state:'client-state'};
 const response=await oauth.authorize(new Request(env.ORIGIN+'/oauth/authorize?'+new URLSearchParams(params)));assert.equal(response.status,302);
 const id=new URL(response.headers.get('location')).searchParams.get('id');const nonce=await oauth.nonce('owner@example.com','consent:'+id);
 const consent=await oauth.consent(post('/owner/consent?id='+id,{nonce,decision:'allow',scope:'github:read',repos:'susanbeasles/*',minutes:'10'}),'owner@example.com');assert.equal(consent.status,302);
 const redirect=new URL(consent.headers.get('location'));assert.equal(redirect.searchParams.get('state'),'client-state');assert.equal(redirect.searchParams.get('iss'),env.ORIGIN);
 const grant={grant_type:'authorization_code',code:redirect.searchParams.get('code'),client_id:client.client_id,redirect_uri:params.redirect_uri,resource:params.resource,code_verifier:verifier};
 assert.equal((await oauth.token(post('/oauth/token',{...grant,resource:resource(env,'write')}))).status,400);
 assert.equal((await oauth.token(post('/oauth/token',{...grant,code_verifier:'x'.repeat(43)}))).status,400);
 const token=await (await oauth.token(post('/oauth/token',grant))).json();assert.ok(token.access_token);
 assert.equal((await oauth.token(post('/oauth/token',grant))).status,400);
 const request=new Request(params.resource,{headers:{authorization:'Bearer '+token.access_token}});
 assert.equal((await oauth.authenticate(request,'caretaker')).profile,'caretaker');assert.equal(await oauth.authenticate(request,'write'),null);
 const refresh={grant_type:'refresh_token',refresh_token:token.refresh_token,client_id:client.client_id,resource:params.resource};
 const replacement=await (await oauth.token(post('/oauth/token',refresh))).json();assert.ok(replacement.access_token);
 assert.equal((await oauth.token(post('/oauth/token',refresh))).status,400);
 assert.equal(await oauth.authenticate(new Request(params.resource,{headers:{authorization:'Bearer '+replacement.access_token}}),'caretaker'),null);
});
test('profile grants never imply write or collaboration permissions',()=>{
 assert.deepEqual(profileScopes('standard'),['standard.read']);assert.deepEqual(profileScopes('super'),['super.read']);
 assert.ok(!profileScopes('caretaker').includes('github.contents.write'));assert.ok(!profileScopes('write').includes('github:collaborate'));
});
