# Central deployment consumer

This repository builds source and packages exact deployment artifacts. Its legacy
`npm run deploy` entrypoint and the bundled ghcaretaker deploy script fail closed,
including when old Cloudflare credential variables are present. They perform no
Worker upload, migration, or Access reconciliation. The historical Workers Build
configuration still points at that disabled entrypoint; this change does not
reconfigure the remote trigger.

After `npm run build`, package one existing component locally:

```sh
node scripts/package-deployment.mjs personal-control reviewed-metadata.json artifact.json
```

Supply explicit reviewed metadata with `main_module: "worker.mjs"`, the component's
exact compatibility date and flags, and its exact bindings. The package preserves
the bundle's bytes and prints its artifact and metadata SHA-256 digests. The output
path must not already exist. The shared validator rejects unsupported metadata,
literal secret bindings, unresolved namespace IDs, missing baseline bindings, or
changes to configured variables, resources, and services. Additional inherited
secret names require central policy approval and provider verification that those
secrets already exist; the local packager makes neither assertion.

The contract modules under `scripts/deployment-contract/` are exact source copies
from repoctl; the adjacent manifest records their content digests and local source
state. Packaging is offline and does not approve, sign, stage, or deploy an artifact.

## Unresolved configuration

No reviewed metadata is supplied here, because the checked-in Wrangler configs
identify Durable Objects by class and script rather than their existing namespace
IDs. Those exact existing IDs must be supplied independently:

| Component | Unresolved existing namespace bindings |
| --- | --- |
| personal-control | `CONTROL`, `APP_CONFIG` in backup-setup |
| ghcaretaker | `APP_VAULT` |
| backup-control | `OUTBOX`, `APP_CONFIG` in backup-setup |
| backup-setup | `BOOTSTRAP` |

The central artifact contract does not apply Durable Object or D1 migrations,
cron schedules, Access policies, observability settings, or Workers Build triggers.
Existing configuration must be independently reconciled and verified before an
operation is authorized; packaging does not drop or recreate those resources.

The baseline personal-control target uses `control.vespoli.me`. ghcaretaker uses
three path routes under `mcp.vespoli.me`, rather than a dedicated custom domain.
Both backup Workers still declare workers.dev exposure and no owned-domain route.
The first central deployment contract requires an exact owned custom domain and
disabled workers.dev/preview exposure. The latter three components therefore need
an approved ingress mapping and matching existing provider configuration before
they qualify. This source change invents no domain, namespace ID, credential, or
deployment authority.
