# Personal infrastructure control plane

Open https://control.vespoli.me/owner for the shared owner login, navigation and capability controls.

This is the canonical source for personal-control, ghcaretaker, backup-control and backup-setup, including configuration, pipelines, schemas, private interfaces, migrations and recovery tools. Authentication belongs to the gateway. Capabilities call its workflow instead of maintaining independent stacks.

- `src/gate.mjs`: sole owner identity gate and constrained login return paths.
- `src/oauth.mjs`: shared MCP issuer with separate resource grants.
- `src/capabilities.mjs`: navigation and capability registration.
- `src/capability-panes/`: focused pane workflows.
- `src/ui.mjs`: shared schema-driven forms and evidence views.
- `workers/`: complete component source, capture/restore tools and tests.
- `infrastructure/`: configuration, pipeline and storage evidence.
- `scripts/`: shared validation, builds and offline deployment packaging.

Run `npm test` and `npm run build` after installing locked build dependencies. Legacy direct deployment now fails closed; follow [central deployment](docs/CENTRAL-DEPLOYMENT.md) to package exact reviewed artifacts for workflow_depot and delivery_control. See [architecture](docs/architecture.md) for extension, source, state and credential boundaries.

Legacy caretaker clients must reconnect at `https://control.vespoli.me/mcp/caretaker`. Backups remain visibly paused until their execution policy is deliberately changed; successful capture is never inferred from connectivity.
