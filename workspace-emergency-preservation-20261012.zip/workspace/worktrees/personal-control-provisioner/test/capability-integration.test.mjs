import test from 'node:test';
import assert from 'node:assert/strict';
import {caretakerStatus,backupStatus,readCapabilityStatus} from '../src/capability-status.mjs';
import {caretakerWebhook} from '../src/caretaker-webhook.mjs';
import {caretakerPanel} from '../src/capability-panes/caretaker.mjs';
const ORIGIN='https://control.example';

test('status projects documented fields and never provider secrets or arbitrary errors',async()=>{
  const status=await readCapabilityStatus({status:async()=>({phase:'installed',app_id:12,installation_id:23,webhook_secret:'never-render',unexpected:{password:'never-render'},webhook:{configured:true,accepted_count:1,recent:[],last_delivery:{id:'delivery-1',event:'push',action:null,repository:'owner/repo',received_at:'2026-10-12T12:00:00.000Z',payload:'never-render'}}})},caretakerStatus);
  assert.equal(status.evidence.app_id,'12');assert.equal(status.evidence.webhook.last_delivery.repository,'owner/repo');
  assert.ok(!JSON.stringify(status).includes('never-render'));
  assert.deepEqual(await readCapabilityStatus({status:async()=>{throw Error('provider-secret');}},caretakerStatus),{state:'unavailable',reason:'capability-status-unavailable'});
  assert.equal((await readCapabilityStatus({status:()=>new Promise(()=>{})},caretakerStatus,{timeoutMs:5})).state,'unavailable');
});
test('backup connection evidence does not infer a successful capture and drops raw delivery errors',()=>{
  const result=backupStatus({service:'backup-control',dispatch_enabled:false,dispatch_state:'paused',outbox:{counts:[{status:'pending',count:4}],oldest_pending:[{last_error:'private-provider-response'}]}});
  assert.equal(result.dispatch_enabled,false);assert.equal(result.outbox.counts[0].count,4);assert.ok(!JSON.stringify(result).includes('private-provider-response'));assert.match(result.capture_evidence,/does not prove/);
});
test('gateway forwards exact signed raw bytes with machine headers only',async()=>{
  const raw=new Uint8Array([123,32,10,0,226,130,172,125]);let calls=0;
  const env={ORIGIN,CARETAKER:{webhook:async request=>{calls++;assert.equal(request.url,ORIGIN+'/webhooks/github/caretaker');assert.deepEqual(new Uint8Array(await request.arrayBuffer()),raw);assert.equal(request.headers.get('x-hub-signature-256'),'sha256=synthetic');for(const h of ['authorization','cookie','cf-access-jwt-assertion','origin'])assert.equal(request.headers.get(h),null);return Response.json({accepted:true},{status:202});}}};
  const response=await caretakerWebhook(new Request(ORIGIN+'/webhooks/github/caretaker',{method:'POST',headers:{'content-type':'application/json','x-hub-signature-256':'sha256=synthetic',authorization:'Bearer discarded',cookie:'discarded','cf-access-jwt-assertion':'discarded',origin:'https://foreign.example'},body:raw}),env);
  assert.equal(response.status,202);assert.equal(calls,1);
  assert.equal((await caretakerWebhook(new Request(ORIGIN),env)).status,405);assert.equal(calls,1);
  assert.equal((await caretakerWebhook(new Request(ORIGIN,{method:'POST'}),{ORIGIN})).status,503);
});
test('suspended installation offers explicit verification in the shared pane',async()=>{
  const c={env:{ORIGIN,CARETAKER:{status:async()=>({phase:'installation-review-required',slug:'test-app'}),tools:async()=>[]}},oauth:{nonce:async()=> 'one-use-nonce'}};
  const response=await caretakerPanel(c,new Request(ORIGIN+'/owner/apps/caretaker'),'owner@example.com',{id:'caretaker',title:'Caretaker',description:'GitHub controls'});
  assert.match(await response.text(),/Verify installation/);
});
