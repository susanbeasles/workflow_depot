import test from 'node:test';
import assert from 'node:assert/strict';
import {existsSync,readFileSync} from 'node:fs';
import {createProvisioner,profileDigest,provisionerAdmission} from '../src/provisioner.mjs';
import {Miniflare,convertV4MiniflareOptions} from 'miniflare';
import {build} from 'esbuild';

const origin='https://provisioner.vespoli.me',ownerOrigin='https://control.vespoli.me';
const prefix='/owner/apps/provisioner/',moduleURL=new URL('../infra/provisioner-ingress/worker.mjs',import.meta.url);
async function adapter(){assert.ok(existsSync(moduleURL),'the deployable ingress adapter exists');return (await import(moduleURL.href)).default;}
function request(path='submit',options={}){return new Request(origin+prefix+path,{method:'POST',headers:{origin:ownerOrigin},...options});}
function environment(fetch){return {ENABLED:'true',PROVISIONER_ADMISSION:{fetch}};}
function json(value,status=200){return Response.json(value,{status});}
function unreadRequest(headers={}){let pulls=0;const body=new ReadableStream({pull(){pulls++;throw Error('body must remain unread');}},{highWaterMark:0});return {request:request('submit',{headers:{origin:ownerOrigin,...headers},body,duplex:'half'}),pulls:()=>pulls};}
const encoder=new TextEncoder(),base64=value=>Buffer.from(value).toString('base64url');
async function syntheticFixture(){
 const keys=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
 const raw=await crypto.subtle.exportKey('raw',keys.publicKey),keyId=Buffer.from(await crypto.subtle.digest('SHA-256',raw)).toString('hex');
 const owner='owner@example.invalid',sign=async value=>base64(await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},keys.privateKey,encoder.encode(value)));
 const profile={id:'b2-ingress-fixture',provider:'b2',operation:'generate-api-key',codeRevision:'fixture-code',manifestRevision:'fixture-manifest',policyRevision:'fixture-policy',sourceRecord:'op://input/login',inputFields:{username:'op://input/login/user',password:'op://input/login/pass'},outputVault:'output',constraints:{secretUrl:'https://provider.invalid/keys','1passwordRecordUrl':'op://input/login',generatedCredentialType:'application-key',generatedCredentialName:'b2-ingress-fixture',permissions:[]},manifest:{version:1,qualified:true},kv:{destination:'fixture',encryptionKeyId:'fixture'},recovery:{destination:'fixture',encryptionKeyId:'fixture'}};
 const trust={keyID:keyId,ownerID:1,ownerEmail:owner,publicKeyX963:Buffer.from(raw).toString('base64'),revoked:false,purposes:['credential-provisioning']};
 const env={ORIGIN:ownerOrigin,ACCESS_TEAM:'ingress-fixture',ACCESS_AUD:'owner',OWNER_EMAILS:owner,PROVISIONER_PRIVATE_ORIGIN:origin,PROVISIONER_OWNER_KEY_ID:keyId,PROVISIONER_SIGNER_EXTENSION_ID:'abcdefghijklmnopabcdefghijklmnop',PROVISIONER_PROFILES:JSON.stringify([profile]),PROVISIONER_DISPATCH_URL:'https://provisioner-executor.vespoli.me/v1/dispatch',PROVISIONER_DISPATCH_AUDIENCE:'fixture',PROVISIONER_DISPATCH_KEY:'SYNTHETIC-DISPATCH-NOT-CREDENTIAL'};
 const payload=JSON.stringify({operation:'generate-api-key',secretUrl:profile.constraints.secretUrl,'1passwordRecordUrl':profile.sourceRecord,generatedCredentialType:'application-key',generatedCredentialName:'b2-ingress-fixture',permissions:[]},null,2)+'\n';
 async function challenge(rawPayload=payload){const value={keyId,requestId:crypto.randomUUID(),issuedAt:Math.floor(Date.now()/1000),profileId:profile.id,payloadHash:base64(await crypto.subtle.digest('SHA-256',encoder.encode(rawPayload)))};value.signature=await sign(JSON.stringify(['provisioner.auth-request.v1',value.requestId,value.issuedAt,origin,keyId,await profileDigest(profile),value.payloadHash]));return value;}
 return {owner,profile,trust,env,payload,sign,challenge,keyId};
}
class FixtureStorage{
 data=new Map();tail=Promise.resolve();
 async get(key){return structuredClone(this.data.get(key));}
 async put(key,value){this.data.set(key,structuredClone(value));}
 async delete(key){this.data.delete(key);}
 async setAlarm(){}
 async transaction(callback){const result=this.tail.then(()=>callback(this));this.tail=result.catch(()=>{});return result;}
}

test('ingress source is disabled, unrouted, and bound only to the existing named admission entrypoint',()=>{
 const path=new URL('../infra/provisioner-ingress/wrangler.jsonc',import.meta.url);assert.ok(existsSync(path),'disabled deployment configuration exists');
 const config=JSON.parse(readFileSync(path,'utf8'));
 assert.equal(config.name,'personal-control-provisioner-ingress');assert.equal(config.main,'worker.mjs');
 assert.equal(config.vars.ENABLED,'false');assert.equal(config.workers_dev,false);assert.equal(config.preview_urls,false);
 assert.deepEqual(config.routes,[]);assert.deepEqual(config.services,[{binding:'PROVISIONER_ADMISSION',service:'personal-control',entrypoint:'ProvisionerAdmission'}]);
 assert.deepEqual(Object.keys(config.vars),['ENABLED']);assert.equal(config.observability.enabled,false);
});

test('disabled or missing binding never touches admission or the request body',async()=>{
 const worker=await adapter();let calls=0;const bound=environment(()=>{calls++;throw Error('must not forward');});
 for(const env of [{},{...bound,ENABLED:'false'},{...bound,ENABLED:true},{ENABLED:'true'}]){
  const fixture=unreadRequest();const response=await worker.fetch(fixture.request,env);
  assert.equal(response.status,503);assert.deepEqual(await response.json(),{error:'provisioner-ingress-disabled'});assert.equal(fixture.pulls(),0);
 }
 assert.equal(calls,0);
});

test('only exact owned HTTPS host, browser Origin, paths, and POST or OPTIONS reach the binding',async()=>{
 const worker=await adapter();let calls=0;const env=environment(()=>{calls++;return json({unexpected:true});});
 const values=[
  new Request('http://provisioner.vespoli.me'+prefix+'submit',{method:'POST',headers:{origin:ownerOrigin}}),
  new Request('https://other.vespoli.me'+prefix+'submit',{method:'POST',headers:{origin:ownerOrigin}}),
  new Request(origin+prefix+'submit?redirect=elsewhere',{method:'POST',headers:{origin:ownerOrigin}}),
  request('config'),request('submit/'),request('submit',{headers:{origin:'https://evil.invalid'}}),
  request('submit',{headers:{}}),request('submit',{headers:{origin:'null'}}),request('submit',{method:'GET'}),
 ];
 for(const value of values){const response=await worker.fetch(value,env);assert.ok([404,405].includes(response.status));assert.equal(response.headers.get('location'),null);}
 assert.equal(calls,0);
});

test('forwarding preserves the original Request and exact bytes, signatures, Access assertion and length header',async()=>{
 const worker=await adapter(),raw=' {\n "operation" : "generate-api-key", "label":"café"\n}\n';
 const incoming=request('submit',{headers:{origin:ownerOrigin,'x-provisioner-nonce':'n'.repeat(43),'x-provisioner-signature':'s'.repeat(86),'cf-access-jwt-assertion':'SYNTHETIC','content-length':'99999999'},body:raw});
 let calls=0;const response=await worker.fetch(incoming,environment(async(value,init)=>{
  calls++;assert.equal(value,incoming);assert.equal(value.bodyUsed,false);assert.equal(init.redirect,'manual');assert.ok(init.signal instanceof AbortSignal);
  assert.equal(value.headers.get('content-length'),'99999999');assert.equal(value.headers.get('cf-access-jwt-assertion'),'SYNTHETIC');
  assert.equal(value.headers.get('x-provisioner-nonce'),'n'.repeat(43));assert.equal(value.headers.get('x-provisioner-signature'),'s'.repeat(86));
  assert.deepEqual(new Uint8Array(await value.arrayBuffer()),new TextEncoder().encode(raw));return json({id:'synthetic',state:'accepted'},202);
 }));
 assert.equal(calls,1);assert.equal(response.status,202);assert.deepEqual(await response.json(),{id:'synthetic',state:'accepted'});
 assert.equal(response.headers.get('cache-control'),'no-store');assert.equal(response.headers.get('access-control-allow-origin'),ownerOrigin);
});

test('downstream authentication denial does not read a submit stream even with an excessive advertised length',async()=>{
 const worker=await adapter(),fixture=unreadRequest({'content-length':'99999999'});let calls=0;
 const response=await worker.fetch(fixture.request,environment(value=>{calls++;assert.equal(value,fixture.request);return json({error:'authorization-invalid'},403);}));
 assert.equal(calls,1);assert.equal(fixture.pulls(),0);assert.equal(response.status,403);assert.deepEqual(await response.json(),{error:'authorization-invalid'});
});

test('preflight reaches the same named admission binding and preserves its exact CORS contract',async()=>{
 const worker=await adapter();let calls=0;const incoming=request('challenge',{method:'OPTIONS',headers:{origin:ownerOrigin,'access-control-request-method':'POST','access-control-request-headers':'content-type,x-provisioner-nonce,x-provisioner-signature'}});
 const response=await worker.fetch(incoming,environment(value=>{calls++;assert.equal(value,incoming);return new Response(null,{status:204,headers:{'access-control-allow-origin':ownerOrigin,'access-control-allow-credentials':'true','access-control-allow-methods':'POST','access-control-allow-headers':'content-type,x-provisioner-nonce,x-provisioner-signature','access-control-max-age':'0'}});}));
 assert.equal(calls,1);assert.equal(response.status,204);assert.equal(response.headers.get('access-control-allow-methods'),'POST');
 assert.equal(response.headers.get('access-control-allow-headers'),'content-type,x-provisioner-nonce,x-provisioner-signature');assert.equal(response.headers.get('access-control-max-age'),'0');
});

test('response overrun, redirects, non-JSON and internal errors produce bounded static failures without forwarding cookies',async()=>{
 const worker=await adapter();let cancelled=0;
 const oversized=new Response(new ReadableStream({start(c){c.enqueue(new Uint8Array(65536));c.enqueue(new Uint8Array(1));},cancel(){cancelled++;}}),{headers:{'content-type':'application/json'}});
 for(const response of [oversized,new Response(null,{status:302,headers:{location:'https://untrusted.invalid/collect'}}),new Response('PRIVATE HTML'),json({ok:true},200)]){
  response.headers.set('set-cookie','UNEXPECTED=private');
  const result=await worker.fetch(request(),environment(()=>response));
  if(response===oversized||response.status===302||!response.headers.get('content-type')?.includes('application/json')){assert.equal(result.status,502);assert.deepEqual(await result.json(),{error:'provisioner-admission-unavailable'});}
  else assert.deepEqual(await result.json(),{ok:true});
  assert.equal(result.headers.get('set-cookie'),null);assert.equal(result.headers.get('location'),null);
 }
 assert.equal(cancelled,1);
 const failed=await worker.fetch(request(),environment(()=>{throw Error('PRIVATE FAILURE');}));assert.equal(failed.status,502);assert.ok(!(await failed.text()).includes('PRIVATE'));
});

test('forwarding deadline aborts admission and returns a static ambiguous-outcome error without retry',async t=>{
 const worker=await adapter();t.mock.timers.enable({apis:['setTimeout']});let calls=0,signal;
 const pending=worker.fetch(request(),environment((_request,init)=>{calls++;signal=init.signal;return new Promise(()=>{});}));
 await Promise.resolve();t.mock.timers.tick(15000);const response=await pending;
 assert.equal(response.status,504);assert.deepEqual(await response.json(),{error:'provisioner-admission-timeout'});assert.equal(signal.aborted,true);assert.equal(calls,1);
});

test('already aborted requests do not initiate admission and late timed-out responses are cancelled',async t=>{
 const worker=await adapter();let calls=0;const controller=new AbortController();controller.abort();
 const denied=await worker.fetch(request('submit',{signal:controller.signal}),environment(()=>{calls++;return json({unexpected:true});}));
 assert.equal(denied.status,502);assert.equal(calls,0);
 t.mock.timers.enable({apis:['setTimeout']});let resolve,cancelled=0;
 const pending=worker.fetch(request(),environment(()=>new Promise(done=>{resolve=done;})));
 await Promise.resolve();t.mock.timers.tick(15000);assert.equal((await pending).status,504);
 resolve(new Response(new ReadableStream({cancel(){cancelled++;}},{highWaterMark:0}),{headers:{'content-type':'application/json'}}));
 await new Promise(done=>setImmediate(done));assert.equal(cancelled,1);
});

test('real admission core behind ingress authenticates before reading and burns the nonce before payload validation',async()=>{
 const worker=await adapter(),fixture=await syntheticFixture(),storage=new FixtureStorage();
 const c={storage,env:{...fixture.env,PROVISIONER_EXECUTOR:{fetch:async()=>new Response(null,{status:503})},PROVISIONER_TRUST:{current:async()=>fixture.trust},PROVISIONER_HARDWARE:{verify:async()=>({keyID:fixture.keyId,hardwareVerified:true,revoked:false,proofDigest:'a'.repeat(64),validUntil:Math.floor(Date.now()/1000)+60})}}};
 const env=environment(value=>provisionerAdmission(c,value,fixture.owner));
 const admitted=await worker.fetch(request('challenge',{headers:{origin:ownerOrigin,'content-type':'application/json'},body:JSON.stringify(await fixture.challenge())}),env);
 assert.equal(admitted.status,200);const challenge=await admitted.json();
 const nonceRecord=()=>[...storage.data].find(([key])=>key.startsWith('provisioner:nonce:'))?.[1];
 const bad=unreadRequest({'x-provisioner-nonce':challenge.nonce,'x-provisioner-signature':await fixture.sign('not-the-nonce'),'content-length':'99999999'});
 assert.equal((await worker.fetch(bad.request,env)).status,403);assert.equal(bad.pulls(),0);assert.equal(nonceRecord().state,'issued');
 let reads=0;const body=new ReadableStream({pull(controller){reads++;assert.equal(nonceRecord().state,'consumed');controller.enqueue(encoder.encode('{}'));controller.close();}},{highWaterMark:0});
 const headers={origin:ownerOrigin,'x-provisioner-nonce':challenge.nonce,'x-provisioner-signature':await fixture.sign(challenge.nonce)};
 const mismatch=await worker.fetch(request('submit',{headers,body,duplex:'half'}),env);
 assert.equal(mismatch.status,400);assert.deepEqual(await mismatch.json(),{error:'payload-hash-mismatch'});assert.equal(reads,1);assert.equal(nonceRecord().state,'consumed');
 const replay=unreadRequest(headers);assert.equal((await worker.fetch(replay.request,env)).status,409);assert.equal(replay.pulls(),0);
 const service=createProvisioner({storage,profiles:[fixture.profile],audience:origin,trust:c.env.PROVISIONER_TRUST,hardware:c.env.PROVISIONER_HARDWARE});
 assert.equal((await service.status(fixture.owner,challenge.jobId)).state,'rejected');
});

test('actual Workerd ingress composes with ProvisionerAdmission and Control owner verification for the signed two-request flow',async()=>{
 const fixture=await syntheticFixture();
 const bundled=(await build({entryPoints:['src/worker.mjs'],bundle:true,write:false,format:'esm',platform:'browser',external:['cloudflare:workers']})).outputFiles[0].text;
 const issuer=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
 const jwk=await crypto.subtle.exportKey('jwk',issuer.publicKey);jwk.kid='ingress-fixture';
 const signed=base64(encoder.encode(JSON.stringify({alg:'RS256',kid:jwk.kid})))+'.'+base64(encoder.encode(JSON.stringify({iss:'https://ingress-fixture.cloudflareaccess.com',aud:['owner'],email:fixture.owner,exp:Math.floor(Date.now()/1000)+300})));
 const assertion=signed+'.'+base64(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',issuer.privateKey,encoder.encode(signed)));
 const trustScript=`import {WorkerEntrypoint} from 'cloudflare:workers';export class Trust extends WorkerEntrypoint{current(){return ${JSON.stringify(fixture.trust)};}}export class Hardware extends WorkerEntrypoint{verify(){return {keyID:'${fixture.keyId}',hardwareVerified:true,revoked:false,proofDigest:'${'b'.repeat(64)}',validUntil:Math.floor(Date.now()/1000)+60};}}export default{fetch(){return new Response(null,{status:404});}};`;
 // Miniflare's external proxy rejects foreign Origin headers. Only this test
 // facade supplies the browser's fixed Origin inside workerd, before real ingress.
 const facade=`export default{fetch(request,env){const url=new URL(request.url);url.protocol='https:';url.host='provisioner.vespoli.me';const headers=new Headers(request.headers);headers.set('origin','${ownerOrigin}');return env.INGRESS.fetch(new Request(url,{method:request.method,headers,body:request.body}));}};`;
 let providerEffects=0;
 const common={modules:true,compatibilityDate:'2026-10-08'};
 const mf=new Miniflare(convertV4MiniflareOptions({cf:false,workers:[
  {...common,name:'facade',script:facade,serviceBindings:{INGRESS:'ingress'}},
  {...common,name:'ingress',script:readFileSync(moduleURL,'utf8'),bindings:{ENABLED:'true'},serviceBindings:{PROVISIONER_ADMISSION:{name:'control',entrypoint:'ProvisionerAdmission'}}},
  {...common,name:'control',script:bundled,bindings:fixture.env,durableObjects:{CONTROL:{className:'Control',useSQLite:true}},serviceBindings:{PROVISIONER_EXECUTOR:'trust',PROVISIONER_TRUST:{name:'trust',entrypoint:'Trust'},PROVISIONER_HARDWARE:{name:'trust',entrypoint:'Hardware'}},outboundService:async value=>{if(value.url==='https://ingress-fixture.cloudflareaccess.com/cdn-cgi/access/certs')return Response.json({keys:[jwk]});providerEffects++;return new Response(null,{status:503});}},
  {...common,name:'trust',script:trustScript},
 ]}));
 try{
  const send=(path,options={})=>mf.dispatchFetch(origin+prefix+path,{method:'POST',...options});
  const auth={'cf-access-jwt-assertion':assertion};
  const preflight=await send('challenge',{method:'OPTIONS'});assert.equal(preflight.status,204);assert.equal(preflight.headers.get('access-control-allow-origin'),ownerOrigin);
  assert.equal((await send('challenge',{body:'{}'})).status,403);
  async function challenge(){const response=await send('challenge',{headers:{...auth,'content-type':'application/json'},body:JSON.stringify(await fixture.challenge())});assert.equal(response.status,200,await response.clone().text());return response.json();}
  const approved=await challenge();
  const headers={...auth,'x-provisioner-nonce':approved.nonce,'x-provisioner-signature':await fixture.sign(approved.nonce)};
  assert.equal((await send('submit',{headers:{...headers,'x-provisioner-signature':await fixture.sign('invalid')},body:fixture.payload})).status,403);
  const accepted=await send('submit',{headers,body:fixture.payload});assert.equal(accepted.status,202);assert.equal((await accepted.json()).state,'accepted');
  assert.equal((await send('submit',{headers,body:fixture.payload})).status,409);
  const bad=await challenge(),badHeaders={...auth,'x-provisioner-nonce':bad.nonce,'x-provisioner-signature':await fixture.sign(bad.nonce)};
  const mismatch=await send('submit',{headers:badHeaders,body:'{}'});assert.equal(mismatch.status,400);assert.equal((await mismatch.json()).error,'payload-hash-mismatch');
  assert.equal((await send('submit',{headers:badHeaders,body:fixture.payload})).status,409);
  const control=await mf.getWorker('control');assert.equal((await control.fetch(ownerOrigin+prefix+'submit',{method:'POST',headers:auth,body:fixture.payload})).status,404);
  assert.equal((await send('config')).status,404);assert.equal(providerEffects,0);
 }finally{await mf.dispose();}
});
