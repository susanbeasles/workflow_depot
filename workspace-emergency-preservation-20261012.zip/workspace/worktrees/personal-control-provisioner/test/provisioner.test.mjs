import test from 'node:test';
import assert from 'node:assert/strict';
import * as p from '../src/provisioner.mjs';

const enc=new TextEncoder();
const b64=v=>Buffer.from(v).toString('base64url');
const sha=async v=>b64(await crypto.subtle.digest('SHA-256',enc.encode(v)));
class Store {
  data=new Map(); tail=Promise.resolve();
  async get(k){return structuredClone(this.data.get(k));}
  async put(k,v){this.data.set(k,structuredClone(v));}
  async delete(k){this.data.delete(k);}
  async list({prefix,limit=100}){return new Map([...this.data].filter(([k])=>k.startsWith(prefix)).slice(0,limit));}
  async transaction(fn){const next=this.tail.then(()=>fn(this));this.tail=next.catch(()=>{});return next;}
}
async function fixture(){
  const keys=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
  const raw=new Uint8Array(await crypto.subtle.exportKey('raw',keys.publicKey));
  const keyId=Buffer.from(await crypto.subtle.digest('SHA-256',raw)).toString('hex');
  const owner='owner@example.com',audience='https://provisioner.vespoli.me';
  const profile={id:'b2-test',title:'B2 fixture',provider:'b2',operation:'generate-api-key',codeRevision:'test-code',manifestRevision:'test-manifest',policyRevision:'test-policy',sourceRecord:'op://input/login',inputFields:{username:'op://input/login/username',password:'op://input/login/password'},outputVault:'output',itemTitle:'b2-backup-key',constraints:{loginUrl:'https://provider.example/login',secretUrl:'https://provider.example/keys',"1passwordRecordUrl":'op://input/login',generatedCredentialType:'application-key',generatedCredentialName:'b2-fixture-key',permissions:[{fieldDomId:'read',value:true}]},manifest:{version:1,qualified:true},kv:{destination:'test-kv',encryptionKeyId:'wrap-test'},recovery:{destination:'test-recovery',encryptionKeyId:'recovery-test'}};
  let time=1000,revoked=false,hardware=true;
  const storage=new Store();
  const service=p.createProvisioner({storage,profiles:[profile],audience,clock:()=>time,trust:{current:async id=>id===keyId?{keyID:keyId,ownerID:1,ownerEmail:owner,publicKeyX963:Buffer.from(raw).toString('base64'),revoked,purposes:['credential-provisioning']}:null},hardware:{verify:async()=>({keyID:keyId,hardwareVerified:hardware,revoked:false,proofDigest:'1'.repeat(64),validUntil:time+30})}});
  const sign=async bytes=>b64(await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},keys.privateKey,enc.encode(bytes)));
  const payload={operation:'generate-api-key',secretUrl:profile.constraints.secretUrl,'1passwordRecordUrl':profile.sourceRecord,generatedCredentialType:'application-key',generatedCredentialName:'b2-fixture-key',permissions:[{fieldDomId:'read',value:true}]};
  async function challenge(rawPayload=JSON.stringify(payload)){
    const request={keyId,requestId:crypto.randomUUID(),issuedAt:time,profileId:profile.id,payloadHash:await sha(rawPayload)};
    request.signature=await sign(JSON.stringify(['provisioner.auth-request.v1',request.requestId,request.issuedAt,audience,keyId,await p.profileDigest(profile),request.payloadHash]));
    const result=await service.challenge(owner,request);
    return {...result,request,rawPayload,signature:await sign(result.nonce)};
  }
  return {service,storage,profile,owner,keyId,payload,challenge,sign,setTime:v=>time=v,revoke:()=>revoked=true,disableHardware:()=>hardware=false};
}
test('provisioner API is present',()=>assert.equal(typeof p.createProvisioner,'function'));
test('owner config exposes only a validated extension ID and blocks absent or malformed signer configuration',async()=>{
 const f=await fixture(),extensionId='abcdefghijklmnopabcdefghijklmnop';let hardwareCalls=0;
 const env={PROVISIONER_PRIVATE_ORIGIN:'https://provisioner.vespoli.me',PROVISIONER_OWNER_KEY_ID:f.keyId,PROVISIONER_TRUST:{current:async()=>({ownerEmail:f.owner,revoked:false,purposes:['credential-provisioning']})},PROVISIONER_HARDWARE:{verify(){hardwareCalls++;throw Error('readiness must not request signing');}},PROVISIONER_DISPATCH_URL:'https://runner.vespoli.me/dispatch',PROVISIONER_DISPATCH_KEY:'synthetic-not-for-public-config',PROVISIONER_DISPATCH_AUDIENCE:'synthetic-runner',PROVISIONER_PROFILES:JSON.stringify([f.profile])};
 for(const value of [undefined,'',extensionId.slice(1),extensionId+'a','x'.repeat(32),extensionId.toUpperCase(),[extensionId]]){
  const config=await p.provisionerPanelConfig({env:{...env,PROVISIONER_SIGNER_EXTENSION_ID:value}},f.owner);
  assert.equal(config.ready,false);assert.equal(config.signerExtensionId,null);assert.ok(config.blockers.includes('signer-extension-not-configured'));
 }
 const missing=await p.provisionerPanelConfig({env:{...env,PROVISIONER_SIGNER_EXTENSION_ID:extensionId}},f.owner);
 assert.equal(missing.ready,false);assert.ok(missing.blockers.includes('runner-not-configured'));
 const config=await p.provisionerPanelConfig({env:{...env,PROVISIONER_SIGNER_EXTENSION_ID:extensionId,PROVISIONER_EXECUTOR:{fetch:async()=>{throw Error('readiness must not dispatch');}}}},f.owner);
 assert.equal(config.signerExtensionId,extensionId);assert.equal(config.ready,true);assert.ok(!config.blockers.includes('signer-extension-not-configured'));
 assert.equal(hardwareCalls,0);assert.ok(!JSON.stringify(config).includes(env.PROVISIONER_DISPATCH_KEY));
});
test('signed hash then nonce-only signature admits an immutable job and outbox',async()=>{
  const f=await fixture(),c=await f.challenge();
  assert.equal(c.expiresAt,1120);
  const job=await f.service.submit(f.owner,c.nonce,c.signature,()=>Promise.resolve(enc.encode(c.rawPayload)));
  assert.equal(job.state,'accepted');
  const stored=await f.storage.get('provisioner:job:'+job.id);
  assert.equal(stored.rawPayload,c.rawPayload);
  assert.equal(stored.payload.KV,undefined);
  assert.equal(p.validatePayload(stored.payload,f.profile).KV,true);
  assert.equal(stored.context.ownerKeyId,f.keyId);
  assert.equal((await f.storage.get('provisioner:outbox:'+job.id)).state,'pending');
  assert.ok(!('payload' in job));
});
test('valid signature burns nonce before reading, even when digest mismatches',async()=>{
  const f=await fixture(),c=await f.challenge();let read=false;
  await assert.rejects(f.service.submit(f.owner,c.nonce,c.signature,async()=>{read=true;return enc.encode('{}');}),{message:'payload-hash-mismatch'});
  assert.equal(read,true);
  await assert.rejects(f.service.submit(f.owner,c.nonce,c.signature,async()=>{throw Error('must not read');}),{message:'nonce-unavailable'});
  assert.equal((await f.service.status(f.owner,c.jobId)).state,'rejected');
});
test('schema errors consume nonce and return only static field/code errors',async()=>{
  const f=await fixture(),c=await f.challenge(JSON.stringify({...f.payload,secretValue:'SYNTHETIC-DO-NOT-ECHO'}));
  await assert.rejects(f.service.submit(f.owner,c.nonce,c.signature,async()=>enc.encode(c.rawPayload)),e=>e.message==='payload-invalid'&&JSON.stringify(e.fields)==='[{"field":"$","code":"unknown-field"}]');
  const state=await f.service.status(f.owner,c.jobId);
  assert.ok(!JSON.stringify(state).includes('SYNTHETIC'));
  await assert.rejects(f.service.submit(f.owner,c.nonce,c.signature,async()=>enc.encode(c.rawPayload)),{message:'nonce-unavailable'});
});
test('invalid auth or signature neither reads body nor consumes nonce',async()=>{
  const f=await fixture(),c=await f.challenge();const noRead=()=>{throw Error('body-read');};
  await assert.rejects(f.service.submit('stranger@example.com',c.nonce,c.signature,noRead),{message:'authorization-invalid'});
  await assert.rejects(f.service.submit(f.owner,c.nonce,await f.sign('wrong'),noRead),{message:'authorization-invalid'});
  assert.equal((await f.service.submit(f.owner,c.nonce,c.signature,async()=>enc.encode(c.rawPayload))).state,'accepted');
});
test('nonce expiry, first request replay, revoked trust and absent hardware fail closed',async()=>{
  const f=await fixture(),c=await f.challenge();
  await assert.rejects(f.service.challenge(f.owner,c.request),{message:'request-replayed'});
  f.setTime(c.expiresAt);
  await assert.rejects(f.service.submit(f.owner,c.nonce,c.signature,async()=>enc.encode(c.rawPayload)),{message:'nonce-unavailable'});
  const d=await f.challenge();f.revoke();
  await assert.rejects(f.service.submit(f.owner,d.nonce,d.signature,async()=>enc.encode(d.rawPayload)),{message:'authorization-invalid'});
  const g=await fixture();g.disableHardware();await assert.rejects(g.challenge(),{message:'authorization-invalid'});
});
test('concurrent submissions admit exactly once',async()=>{
  const f=await fixture(),c=await f.challenge();
  const results=await Promise.allSettled(Array.from({length:8},()=>f.service.submit(f.owner,c.nonce,c.signature,async()=>enc.encode(c.rawPayload))));
  assert.equal(results.filter(x=>x.status==='fulfilled').length,1);
  assert.equal([...f.storage.data.keys()].filter(x=>x.startsWith('provisioner:outbox:')).length,1);
});
test('signed duplicate JSON fields and unsupported rotations burn nonce',async()=>{
  for(const raw of ['{"operation":"generate-api-key","operation":"rotate-password"}',JSON.stringify({operation:'rotate-password'})]){
    const f=await fixture(),c=await f.challenge(raw);
    await assert.rejects(f.service.submit(f.owner,c.nonce,c.signature,async()=>enc.encode(raw)),{message:'payload-invalid'});
    assert.equal((await f.service.status(f.owner,c.jobId)).state,'rejected');
  }
});
test('signed invalid UTF8 burns nonce without decoding or reflecting bytes',async()=>{
 const f=await fixture(),seed=await f.challenge(),bytes=Uint8Array.of(0xff,0xfe);
 const request={...seed.request,requestId:crypto.randomUUID(),payloadHash:await p.digestBytes(bytes)};
 request.signature=await f.sign(JSON.stringify(['provisioner.auth-request.v1',request.requestId,request.issuedAt,'https://provisioner.vespoli.me',f.keyId,await p.profileDigest(f.profile),request.payloadHash]));
 const c=await f.service.challenge(f.owner,request),signature=await f.sign(c.nonce);
 await assert.rejects(f.service.submit(f.owner,c.nonce,signature,async()=>bytes),e=>e.message==='payload-invalid'&&e.fields[0].code==='invalid-utf8');
 assert.equal((await f.service.status(f.owner,c.jobId)).state,'rejected');
});
test('profile changes after signature fail before nonce consumption; KV default requires encryption',async()=>{
  const f=await fixture(),c=await f.challenge();f.profile.outputVault='different';
  await assert.rejects(f.service.submit(f.owner,c.nonce,c.signature,async()=>enc.encode(c.rawPayload)),{message:'authorization-invalid'});
  const g=await fixture();delete g.profile.kv;
  const d=await g.challenge();
  await assert.rejects(g.service.submit(g.owner,d.nonce,d.signature,async()=>enc.encode(d.rawPayload)),e=>e.message==='payload-invalid'&&e.fields.some(x=>x.field==='KV'));
});
test('field constraints forbid destinations, selectors, permissions and scope outside profile',async()=>{
  for(const delta of [{secretUrl:'https://evil.example'},{toVault:'unapproved'},{uDomId:'arbitrary'},{permissions:[{fieldDomId:'admin',value:true}]},{duration:999999}]){
    const f=await fixture(),c=await f.challenge(JSON.stringify({...f.payload,...delta}));
    await assert.rejects(f.service.submit(f.owner,c.nonce,c.signature,async()=>enc.encode(c.rawPayload)),{message:'payload-invalid'});
  }
});
test('existing enrollment trust bindings are reused without creating enrollment',async()=>{
  const calls=[];
  const env={PROVISIONER_OWNER_BINDINGS:JSON.stringify([{keyId:'a'.repeat(64),ownerID:42,ownerEmail:'owner@example.com'}]),ENROLLMENT_TRUST:{fetch:async(url,options)=>{calls.push({url,body:JSON.parse(options.body)});return Response.json({keyID:'a'.repeat(64),ownerID:42,revoked:false,publicKeyX963:'PUBLIC-ONLY'});}},ENROLLMENT_HARDWARE:{fetch:async()=>Response.json({hardwareVerified:true})}};
  const bindings=p.enrollmentBindings(env),key=await bindings.trust.current('a'.repeat(64));
  assert.equal(key.ownerEmail,'owner@example.com');assert.equal(key.publicKeyX963,'PUBLIC-ONLY');
  assert.deepEqual(key.purposes,['credential-provisioning']);
  assert.equal(calls[0].url,'https://internal/v1/enrollment/trust');
  assert.deepEqual(calls[0].body,{keyID:'a'.repeat(64)});
});
test('oversized payload and interrupted reads leave irreversible rejection',async()=>{
 const f=await fixture(),c=await f.challenge();
 await assert.rejects(f.service.submit(f.owner,c.nonce,c.signature,async()=>new Uint8Array(32769)),{message:'payload-too-large'});
 assert.equal((await f.service.status(f.owner,c.jobId)).state,'rejected');
 const d=await f.challenge();await assert.rejects(f.service.submit(f.owner,d.nonce,d.signature,async()=>{throw Error('UNTRUSTED SECRET ERROR');}),{message:'admission-failed'});
 assert.ok(!JSON.stringify(await f.service.status(f.owner,d.jobId)).includes('UNTRUSTED'));
});
test('expired challenges and request tombstones are pruned without reopening consumed jobs',async()=>{
 const f=await fixture(),c=await f.challenge();await f.service.submit(f.owner,c.nonce,c.signature,async()=>enc.encode(c.rawPayload));
 await p.cleanupProvisioner(f.storage,2000);
 assert.equal([...f.storage.data.keys()].filter(k=>k.startsWith('provisioner:nonce:')||k.startsWith('provisioner:request:')).length,0);
 assert.equal((await f.service.status(f.owner,c.jobId)).state,'accepted');
});
test('stalled request streams time out without accepting a truncated body',async()=>{
 let cancelled=false;const request={body:new ReadableStream({cancel(){cancelled=true;}})};
 await assert.rejects(p.readBytes(request,32768,15),{message:'admission-failed'});
 assert.equal(cancelled,true);
});
test('B2 refuses an invalid generic provider label before admitting a job',async()=>{
 const f=await fixture();const body={...f.payload,generatedCredentialName:'Provisioner secret #test'};const c=await f.challenge(JSON.stringify(body));
 await assert.rejects(f.service.submit(f.owner,c.nonce,c.signature,async()=>enc.encode(c.rawPayload)),e=>e.message==='payload-invalid'&&e.fields.some(x=>x.field==='generatedCredentialName'));
});
