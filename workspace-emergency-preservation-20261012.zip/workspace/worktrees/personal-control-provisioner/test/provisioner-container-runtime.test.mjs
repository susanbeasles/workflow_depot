import test from 'node:test';
import assert from 'node:assert/strict';
import {createPublicKey,createHash,X509Certificate} from 'node:crypto';
import {rootCertificates} from 'node:tls';
import {mkdtemp,readFile,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const runtime=await import('../infra/provisioner/runtime-adapters.mjs').catch(()=>({}));
const server=await import('../infra/provisioner/container-server.mjs').catch(()=>({}));
const bootstrap=await import('../infra/provisioner/bootstrap.mjs').catch(()=>({}));
const digest=x=>createHash('sha256').update(x).digest('base64url');
const keys=rootCertificates.map(x=>new X509Certificate(x).publicKey).filter(k=>k.asymmetricKeyType==='rsa'&&k.asymmetricKeyDetails.modulusLength>=3072).slice(0,2);
// Built-in public CA certificates are public-only synthetic wrapping fixtures; no private key is read or generated.
const recipient=(key,n)=>({destination:n==='recovery'?'r2://recovery/capture/':'cloudflare-kv://output/copy/',keyId:n+'-key',fingerprint:digest(key.export({type:'spki',format:'der'})),publicKeyPem:key.export({type:'spki',format:'pem'})});
function fixture(){const recovery=recipient(keys[0],'recovery'),kv=recipient(keys[1],'output');return {job:{id:'fixture-job',payloadHash:digest('fixture'),payload:{}},config:{profile:{recovery:{destination:recovery.destination,encryptionKeyId:recovery.keyId},kv:{destination:kv.destination,encryptionKeyId:kv.keyId}},infrastructure:{transport:'cloudflare-bindings-v1',recovery,kv}},callbackToken:'synthetic-job-capability',deadline:Date.now()+60000};}
const response=x=>Response.json(x);
test('runtime envelopes encrypt with existing pinned public recipients and bind purpose/job, without private unwrap material',async()=>{
 assert.equal(typeof runtime.envelopeEncrypt,'function');const f=fixture();const envelope=JSON.parse(await runtime.envelopeEncrypt({credential:{apiToken:'SYNTHETIC-ONLY-SECRET'},jobId:f.job.id,payloadHash:f.job.payloadHash,recipient:f.config.infrastructure.recovery,purpose:'recovery'}));
 assert.equal(envelope.algorithm,'RSA-OAEP-256+A256GCM');assert.equal(envelope.fingerprint,f.config.infrastructure.recovery.fingerprint);assert.deepEqual(envelope.context,{jobId:f.job.id,payloadHash:f.job.payloadHash,purpose:'recovery'});assert.equal(Buffer.from(envelope.iv,'base64').length,12);assert.equal(Buffer.from(envelope.tag,'base64').length,16);assert.equal(Buffer.from(envelope.encryptedDataKey,'base64').length,keys[0].asymmetricKeyDetails.modulusLength/8);assert(!JSON.stringify(envelope).includes('SYNTHETIC'));assert(!JSON.stringify(envelope).includes('PRIVATE'));
 await assert.rejects(runtime.envelopeEncrypt({credential:{},jobId:f.job.id,payloadHash:f.job.payloadHash,recipient:{...f.config.infrastructure.recovery,fingerprint:'wrong'},purpose:'recovery'}),/recipient/);
});
test('binding callbacks have exact fixed destinations, supervisor bearer, redacted receipts and ciphertext-only bodies',async()=>{
 assert.equal(typeof runtime.createRuntimeAdapters,'function');const f=fixture(),calls=[];
 const adapters=await runtime.createRuntimeAdapters({...f,fetchImpl:async(url,options)=>{const body=JSON.parse(options.body);calls.push({url,options,body});if(url.endsWith('/reserve'))return response({reserved:true});if(url.endsWith('/update'))return response({updated:true});return response({id:f.config.infrastructure[url.endsWith('/recovery')?'recovery':'kv'].destination+f.job.id+(url.endsWith('/recovery')?'.json':''),digest:body.digest});}});
 assert.equal(await adapters.journal.reserve({jobId:f.job.id,payloadHash:f.job.payloadHash}),true);
 await adapters.journal.update({jobId:f.job.id,payloadHash:f.job.payloadHash,state:'captured',recoveryId:'r2://recovery/capture/fixture-job.json',password:'NEVER-SEND'});
 await adapters.recovery.capture({jobId:f.job.id,payloadHash:f.job.payloadHash,credential:{apiToken:'SYNTHETIC-SECRET'}});
 await adapters.kv.putEncrypted({jobId:f.job.id,payloadHash:f.job.payloadHash,credential:{apiToken:'SYNTHETIC-SECRET'}});
 assert(calls.every(c=>c.url.startsWith('https://provisioner.internal/v1/')));assert(calls.every(c=>c.options.headers.authorization==='Bearer synthetic-job-capability'&&c.options.redirect==='error'));assert(!JSON.stringify(calls).includes('SYNTHETIC-SECRET'));assert(!JSON.stringify(calls).includes('NEVER-SEND'));assert.deepEqual(calls[1].body.receipt,{recoveryId:'r2://recovery/capture/fixture-job.json'});assert.equal(calls[2].body.digest,digest(calls[2].body.envelope));
});
test('runtime denies destination/key reuse, expired identity, wrong acknowledgements and ambiguous transport without retry',async()=>{
 const f=fixture();let calls=0;const fetchImpl=async()=>{calls++;throw Error('PRIVATE-REMOTE-BODY');};
 for(const mutate of [g=>g.config.infrastructure.transport='aws',g=>g.config.infrastructure.kv={...g.config.infrastructure.recovery},g=>g.config.profile.recovery.encryptionKeyId='different',g=>g.deadline=1]) {const g=fixture();mutate(g);await assert.rejects(runtime.createRuntimeAdapters({...g,fetchImpl}));}assert.equal(calls,0);
 const adapters=await runtime.createRuntimeAdapters({...f,fetchImpl});await assert.rejects(adapters.journal.reserve({jobId:'wrong',payloadHash:f.job.payloadHash}));assert.equal(calls,0);await assert.rejects(adapters.recovery.capture({jobId:f.job.id,payloadHash:f.job.payloadHash,credential:{token:'SYNTHETIC'}}),e=>!e.message.includes('PRIVATE'));assert.equal(calls,1);
 const bad=await runtime.createRuntimeAdapters({...f,fetchImpl:async()=>response({id:'r2://wrong/path',digest:'wrong'})});await assert.rejects(bad.recovery.capture({jobId:f.job.id,payloadHash:f.job.payloadHash,credential:{token:'SYNTHETIC'}}),/acknowledgement/);
});
test('container handoff admits one bounded request, retains no raw child response, and never retries',async()=>{
 assert.equal(typeof server.createContainerHandler,'function');let calls=0,release;const pending=new Promise(resolve=>release=resolve);
 const handler=server.createContainerHandler({bootstrapImpl:async input=>{calls++;assert.equal(input.serviceAccountToken,'SYNTHETIC-OP');await pending;return {state:'succeeded'};}});
 const body={job:{id:'fixture-job'},config:{},configDigest:digest('{}'),baseConfigSha256:digest('{}'),serviceAccountToken:'SYNTHETIC-OP',callbackToken:'synthetic-job-capability',deadline:Date.now()+60000};
 const request=()=>new Request('http://container/start',{method:'POST',body:JSON.stringify(body),headers:{'content-type':'application/json'}});
 assert.equal((await handler(request())).status,202);assert.equal((await handler(request())).status,409);assert.equal(calls,1);release();await handler.done();assert(!(await (await handler(new Request('http://container/status'))).text()).includes('SYNTHETIC'));
 const tooLarge=server.createContainerHandler({maxBodyBytes:32,bootstrapImpl:async()=>{throw Error('must not run');}});assert.equal((await tooLarge(request())).status,413);
 const throwing=server.createContainerHandler({bootstrapImpl:async()=>{throw Error('SYNTHETIC-SECRET');}});assert.equal((await throwing(request())).status,202);await throwing.done();assert.equal((await throwing(request())).status,409);
});
test('bootstrap composes only immutable base plus approved profile and rejects before spawning on mismatch',async()=>{
 assert.equal(typeof bootstrap.validateHandoff,'function');const base={codeDigest:digest('code'),infrastructure:{transport:'cloudflare-bindings-v1'},platform:{provider:'cloudflare-containers',qualified:true,qualificationDigest:digest('reviewed-platform')}};
 const profile={id:'fixture-profile',manifest:{version:2,qualified:false}},config={...base,profile,manifestDigest:digest(JSON.stringify(profile.manifest))};
 // An unqualified profile cannot reach process creation even with internally consistent digests.
 const job={id:'fixture-job',state:'accepted',context:{profileDigest:digest(JSON.stringify(profile)),codeDigest:base.codeDigest},rawPayload:'{}',payload:{},payloadHash:digest('{}')};
 const handoff={job,config,configDigest:digest(JSON.stringify(config)),baseConfigSha256:digest(JSON.stringify(base)),serviceAccountToken:'SYNTHETIC-OP',callbackToken:'synthetic-job-capability',deadline:Date.now()+60000};
 assert.throws(()=>bootstrap.validateHandoff({handoff,baseConfigBytes:JSON.stringify(base)}));
 assert.throws(()=>bootstrap.validateHandoff({handoff:{...handoff,config:{...config,codeDigest:'foreign'}},baseConfigBytes:JSON.stringify(base)}));
});
function approvedHandoff(){
 const f=fixture(),profile={id:'fixture-profile',provider:'b2',operation:'generate-api-key',sourceRecord:'op://'+('a'.repeat(26))+'/'+('b'.repeat(26)),inputFields:{username:'op://'+('a'.repeat(26))+'/'+('b'.repeat(26))+'/username',password:'op://'+('a'.repeat(26))+'/'+('b'.repeat(26))+'/password'},outputVault:'c'.repeat(26),itemTitle:'fixture-backup-key',allowedOrigins:['https://provider.test'],constraints:{secretUrl:'https://provider.test/keys','1passwordRecordUrl':'op://'+('a'.repeat(26))+'/'+('b'.repeat(26)),generatedCredentialType:'application-key',generatedCredentialName:'fixture-key',permissions:[]},manifest:{version:1,qualified:true,login:[],prepare:[{action:'fill',selector:'#name',value:'credentialName'}],submit:{action:'click',selector:'#create'},capture:{keyId:{selector:'#keyid',read:'text'},applicationKey:{selector:'#key',read:'text'}}},recovery:f.config.profile.recovery,kv:f.config.profile.kv};
 const base={codeDigest:digest('fixture-code'),infrastructure:f.config.infrastructure,platform:{provider:'cloudflare-containers',qualified:true,qualificationDigest:digest('reviewed-platform')},browser:{proxy:{server:'http://127.0.0.1:18888'}}};
 const stable=x=>JSON.stringify(sort(x));function sort(x){return Array.isArray(x)?x.map(sort):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,sort(x[k])])):x;}
 const config={...base,profile,manifestDigest:digest(stable(profile.manifest))},payload={operation:'generate-api-key',...profile.constraints},rawPayload=JSON.stringify(payload);
 const job={id:'fixture-job',owner:'fixture-owner',state:'accepted',rawPayload,payload,payloadHash:digest(rawPayload),context:{profileId:profile.id,profileDigest:digest(stable(profile)),codeDigest:base.codeDigest,manifestDigest:config.manifestDigest}};
 return {baseConfigBytes:JSON.stringify(base),handoff:{job,config,configDigest:digest(stable(config)),baseConfigSha256:digest(JSON.stringify(base)),serviceAccountToken:'SYNTHETIC-OP',callbackToken:'synthetic-job-capability',deadline:Date.now()+60000}};
}
test('bootstrap sends private credentials through actual FD3/FD4 pipes only and removes tmpfs handoff files',async()=>{
 const {spawn}=await import('node:child_process');const f=approvedHandoff(),dir=await mkdtemp(join(tmpdir(),'cf-runtime-'));let spawned=0;
 try{
 const receipt=await bootstrap.bootstrap(f.handoff,{readBaseConfig:async()=>f.baseConfigBytes,verifyBundle:async()=>true,tempRoot:dir,startProxy:async()=>({close:async()=>{}}),spawnProcess:(executable,args,options)=>{
  spawned++;assert.equal(executable,'/usr/bin/node');assert(!JSON.stringify(args).includes('SYNTHETIC'));assert(!JSON.stringify(options.env).includes('SYNTHETIC'));assert.equal(options.env.NODE_EXTRA_CA_CERTS,'/etc/cloudflare/certs/cloudflare-containers-ca.crt');assert.deepEqual(options.stdio,['ignore','pipe','pipe','pipe','pipe']);
  const script=`import {readTokenFromFD} from ${JSON.stringify(new URL('../runner/run.mjs',import.meta.url).href)};const [op,callback]=await Promise.all([readTokenFromFD(3),readTokenFromFD(4)]);if(op!=='SYNTHETIC-OP'||JSON.parse(callback).callbackToken!=='synthetic-job-capability')process.exit(2);process.stdout.write(JSON.stringify({jobId:'fixture-job',state:'succeeded',itemId:'${'d'.repeat(26)}',vaultId:'${'c'.repeat(26)}'}));`;
  return spawn(process.execPath,['--input-type=module','-e',script],{...options,env:{...options.env,NODE_EXTRA_CA_CERTS:undefined}});
 }});assert.equal(receipt.state,'succeeded');assert.equal(spawned,1);assert.equal(f.handoff.serviceAccountToken,undefined);assert.equal(f.handoff.callbackToken,undefined);await assert.rejects(readFile(join(dir,'job.json')),{code:'ENOENT'});await assert.rejects(readFile(join(dir,'runner.json')),{code:'ENOENT'});
 }finally{await rm(dir,{recursive:true,force:true});}
});
test('deadline advancing during bundle verification prevents spawn and any credential pipe',async()=>{
 const f=approvedHandoff();let time=Date.now(),spawns=0;f.handoff.deadline=time+1000;
 await assert.rejects(bootstrap.bootstrap(f.handoff,{now:()=>time,readBaseConfig:async()=>f.baseConfigBytes,verifyBundle:async()=>{time+=1001;},spawnProcess:()=>{spawns++;throw Error();}}),/expired/);assert.equal(spawns,0);
});
test('browser helper denies wrong UID, capabilities or privilege escalation before importing browser code',async()=>{
 const boundary=await import('../runner/browser-boundary.mjs').catch(()=>({}));assert.equal(typeof boundary.verifyBrowserBoundary,'function');
 const status='Uid:\t10001\t10001\t10001\t10001\nGid:\t10001\t10001\t10001\t10001\nCapInh:\t0000000000000000\nCapPrm:\t0000000000000000\nCapEff:\t0000000000000000\nCapBnd:\t0000000000000000\nCapAmb:\t0000000000000000\nNoNewPrivs:\t1\n';
 assert.equal(boundary.verifyBrowserBoundary(status),true);for(const altered of [status.replace('10001','0'),status.replace('CapBnd:\t0000000000000000','CapBnd:\t0000000000000001'),status.replace('NoNewPrivs:\t1','NoNewPrivs:\t0')])assert.throws(()=>boundary.verifyBrowserBoundary(altered));
});
test('Cloudflare egress proxy routes only exact approved HTTPS host through platform DNS, without direct-IP fallback',async()=>{
 const {resolveProxyTarget}=await import('../infra/provisioner/egress-proxy.mjs');let lookedUp=false;
 assert.deepEqual(await resolveProxyTarget({authority:'provider.test:443',allowedOrigins:['https://provider.test'],lookup:async()=>{lookedUp=true;return [{address:'100.64.0.1'}];}}),{host:'provider.test',port:443});assert.equal(lookedUp,false);
 for(const authority of ['169.254.169.254:443','provisioner.internal:443','provider.test:80','evil.test:443'])await assert.rejects(resolveProxyTarget({authority,allowedOrigins:['https://provider.test']}));
});
test('trusted base opOrigins passes preflight while foreign callback/config URLs remain forbidden',async()=>{
 const f=fixture();f.config.infrastructure.opOrigins=['https://my.1password.com'];const adapters=await runtime.createRuntimeAdapters({...f,fetchImpl:async()=>response({reserved:true})});assert.equal(await adapters.journal.reserve({jobId:f.job.id,payloadHash:f.job.payloadHash}),true);
 for(const origin of ['http://my.1password.com','https://provisioner.internal','https://my.1password.com/path','https://127.0.0.1']){const g=fixture();g.config.infrastructure.opOrigins=[origin];await assert.rejects(runtime.createRuntimeAdapters(g));}
});
test('supervisor gives callback capability only to runtime adapters and checks expiry before op creation',async()=>{
 const {runPinnedJob}=await import('../runner/run.mjs'),f=approvedHandoff();let created=0,seen;
 const binding={callbackToken:'synthetic-job-capability',deadline:Date.now()+10000};
 const bytes=JSON.stringify(f.handoff.config);const args={configBytes:bytes,expectedConfigDigest:digest(bytes),jobBytes:JSON.stringify(f.handoff.job),verifyBundle:async()=>true,readRuntimeBinding:async()=>binding,readToken:async()=>{binding.deadline=Date.now()-1;return 'SYNTHETIC-OP';},adapterFactory:async value=>{seen=value;return {};},opFactory:async()=>{created++;return {};}};
 await assert.rejects(runPinnedJob(args),/runtime-expired/);assert.equal(created,0);assert.equal(seen.callbackToken,'synthetic-job-capability');
});
test('oversized callback bodies are discarded and disabled KV never sends a request',async()=>{
 const f=fixture();f.job.payload.KV=false;delete f.config.infrastructure.kv;let calls=0;
 const adapters=await runtime.createRuntimeAdapters({...f,fetchImpl:async()=>{calls++;return new Response('PRIVATE-RESPONSE'.repeat(2000));}});
 await assert.rejects(adapters.journal.reserve({jobId:f.job.id,payloadHash:f.job.payloadHash}),e=>e.message==='runtime_callback_unavailable');assert.equal(calls,1);
 assert.throws(()=>adapters.kv.putEncrypted({jobId:f.job.id,payloadHash:f.job.payloadHash,credential:{}}),/kv_disabled/);assert.equal(calls,1);
});
test('concurrent container requests cannot race asynchronous body receipt into two starts',async()=>{
 let finish,calls=0;const f=approvedHandoff();const request=new Request('http://container/start',{method:'POST',headers:{'content-type':'application/json'},body:new ReadableStream({start(controller){finish=()=>{controller.enqueue(new TextEncoder().encode(JSON.stringify(f.handoff)));controller.close();};}}),duplex:'half'});
 const handler=server.createContainerHandler({bootstrapImpl:async()=>{calls++;}}),first=handler(request);
 assert.equal((await handler(new Request('http://container/start',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(f.handoff)}))).status,409);finish();assert.equal((await first).status,202);await handler.done();assert.equal(calls,1);
});
test('child stdout and stderr are bounded, never exposed, and an ambiguous child is never restarted',async()=>{
 const {spawn}=await import('node:child_process'),f=approvedHandoff(),dir=await mkdtemp(join(tmpdir(),'cf-runtime-overflow-'));let calls=0,updates=[];
 try{
 await assert.rejects(bootstrap.bootstrap(f.handoff,{readBaseConfig:async()=>f.baseConfigBytes,verifyBundle:async()=>true,tempRoot:dir,startProxy:async()=>({close:async()=>{}}),fetchImpl:async(url,options)=>{updates.push(JSON.parse(options.body));return response({updated:true});},spawnProcess:(_,args,options)=>{calls++;return spawn(process.execPath,['-e',"process.stderr.write('SYNTHETIC-PRIVATE'.repeat(2048));setTimeout(()=>{},10000)"],{...options,env:{...options.env,NODE_EXTRA_CA_CERTS:undefined}});}}),e=>e.message==='bootstrap_failed');
 assert.equal(calls,1);assert.deepEqual(updates,[{jobId:f.handoff.job.id,payloadHash:f.handoff.job.payloadHash,state:'uncertain',receipt:{}}]);
 }finally{await rm(dir,{recursive:true,force:true});}
});
test('actual Cloudflare controller and Node adapters agree on immutable handoff, public envelope, receipts and cleanup',async()=>{
 const {createJobController,canonical}=await import('../infra/provisioner/launcher.mjs'),f=approvedHandoff(),base=JSON.parse(f.baseConfigBytes);base.infrastructure.opOrigins=['https://my.1password.com'];f.handoff.job.context.audience='https://admission.test';
 const config={owner:f.handoff.job.owner,audience:'fixture-dispatch',admissionAudience:'https://admission.test',codeDigest:base.codeDigest,approvedProfileDigests:[f.handoff.job.context.profileDigest],runnerConfig:base,qualified:true,schedulingPolicy:'default',imageDigest:'sha256:'+'1'.repeat(64),baseConfigSha256:digest(JSON.stringify(base)),deadlineSeconds:60};
 const records=new Map(),objects=new Map(),kv=new Map();let submitted,props,destroyed=false;
 const storage={get:async key=>structuredClone(records.get(key)),put:async(key,value)=>records.set(key,structuredClone(value)),setAlarm:async()=>{},deleteAlarm:async()=>{},transaction:async fn=>fn(storage)};
 const container={running:false,start(){this.running=true;},setInactivityTimeout:async()=>{},interceptOutboundHttps:async()=>{},monitor:()=>new Promise(()=>{}),inspect:async()=>container.running?{image:config.imageDigest}:null,destroy:async()=>{destroyed=true;container.running=false;},getTcpPort:()=>({fetch:async(url,options)=>{if(url.endsWith('/ready'))return response({ready:true});submitted=JSON.parse(options.body);return Response.json({accepted:true},{status:202});}})};
 const controller=createJobController({storage,container,config,containerId:'fixture-container',machineKey:async()=> 'fixture-machine-key-'.repeat(3),serviceToken:async()=> 'SYNTHETIC-OP',interceptor:p=>{props=p;return {};},recovery:{put:async(k,v,options)=>{assert.equal(options.onlyIf.etagDoesNotMatch,'*');if(!objects.has(k))objects.set(k,v);},get:async k=>({text:async()=>objects.get(k)})},output:{put:async(k,v)=>kv.set(k,v),get:async k=>kv.get(k)}});
 assert.equal((await controller.dispatch({job:f.handoff.job,profile:f.handoff.config.profile,nonce:'fixture-dispatch-nonce'})).state,'running');assert.equal(submitted.configDigest,digest(canonical(submitted.config)));assert.equal(submitted.serviceAccountToken,'SYNTHETIC-OP');
 const adapters=await runtime.createRuntimeAdapters({...submitted,fetchImpl:async(url,options)=>controller.outbound(new Request(url,options),props)}),identity={jobId:submitted.job.id,payloadHash:submitted.job.payloadHash};
 assert.equal(await adapters.journal.reserve(identity),true);assert.equal(await adapters.journal.reserve(identity),false);
 const recovery=await adapters.recovery.capture({...identity,credential:{token:'SYNTHETIC-CAPTURE'}});await adapters.journal.update({...identity,state:'captured',recoveryId:recovery.id});
 await adapters.journal.update({...identity,state:'vault-saved',itemId:'d'.repeat(26),vaultId:'c'.repeat(26)});const saved=await adapters.kv.putEncrypted({...identity,credential:{token:'SYNTHETIC-CAPTURE'}});await adapters.journal.update({...identity,state:'succeeded',itemId:'d'.repeat(26),vaultId:'c'.repeat(26),kvId:saved.id});
 assert(!JSON.stringify([...objects.values(),...kv.values(),...records.values()]).includes('SYNTHETIC'));assert.equal(destroyed,false);await controller.alarm();assert.equal(destroyed,true);assert.equal((await controller.status()).state,'succeeded');
});
