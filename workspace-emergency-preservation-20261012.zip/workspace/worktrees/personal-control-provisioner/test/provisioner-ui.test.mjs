import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import vm from 'node:vm';

const clientPath=new URL('../src/provisioner-client.mjs',import.meta.url);
const panelPath=new URL('../src/capability-panes/provisioner.mjs',import.meta.url);
const enc=new TextEncoder();
const b64=value=>Buffer.from(value).toString('base64url');
const payload=()=>({operation:'generate-api-key',secretUrl:'https://secure.backblaze.com/app_keys.htm','1passwordRecordUrl':'op://synthetic-input/test-login',generatedCredentialType:'key',KV:true,permissions:[{fieldDomId:'scope',value:'test-only'},{fieldDomId:'count',value:2},{fieldDomId:'read',value:true}]});
const config=()=>({ready:true,blockers:[],privateOrigin:'https://provisioner.vespoli.me',audience:'provisioner-test',keyId:'a'.repeat(64),signerExtensionId:'a'.repeat(32),profiles:[{id:'b2-test',digest:'b'.repeat(64),title:'B2 test profile',defaults:{generatedCredentialType:'key'},display:{provider:'b2'}}]});

test('provisioner panel exposes the requested form immediately and scopes its CSP',async()=>{
 const {provisionerPanel}=await import(panelPath);
 const {panes}=await import('../src/panes.mjs');
 const {capabilities}=await import('../src/capabilities.mjs');
 assert.ok(capabilities.some(c=>c.id==='provisioner'&&c.title==='Provision'));
 const c={env:{PROVISIONER_PRIVATE_ORIGIN:'https://provisioner.vespoli.me'}};
 const response=await panes(c,new Request('https://control.vespoli.me/owner/apps/provisioner'),'owner@example.com');
 const html=await response.text();
 assert.equal(response.status,200);
 for(const name of ['operation','secretUrl','1passwordRecordUrl','generatedCredentialType','uDomId','pwdDomId','otpDomId','loginUrl','recordType','generatedCredentialName','duration','KV','toVault'])assert.match(html,new RegExp(`name="${name}"`));
 assert.match(html,/name="KV"[^>]*checked/);
 assert.match(html,/name="secretUrl"[^>]*required/);
 assert.match(html,/name="1passwordRecordUrl"[^>]*required/);
 assert.match(html,/name="generatedCredentialType"[^>]*required/);
 for(const op of ['rotate-password','rotate-recovery-codes','rotate-totp','manage-passkey'])assert.match(html,new RegExp(`value="${op}" disabled[^>]*>[^<]*not enabled`));
 assert.match(html,/id="provision-submit"[^>]*disabled/);
 assert.match(html,/src="\/owner\/apps\/provisioner\/client.js"/);
 assert.match(response.headers.get('content-security-policy'),/script-src 'self'/);
 assert.match(response.headers.get('content-security-policy'),/connect-src 'self' https:\/\/provisioner\.vespoli\.me/);
 assert.doesNotMatch(html,/type="password"|localStorage|sessionStorage/);
 const unsafe=await provisionerPanel({env:{PROVISIONER_PRIVATE_ORIGIN:"https://evil.example; connect-src *"}},new Request('https://control.vespoli.me/owner/apps/provisioner'),'owner@example.com',{id:'provisioner'});
 assert.doesNotMatch(unsafe.headers.get('content-security-policy'),/evil|connect-src \*/);
 assert.equal(await panes(c,new Request('https://control.vespoli.me/owner/apps/provisioner/unknown'),'owner@example.com'),null);
});

test('client signs the bound first request then only the nonce, submitting the frozen UTF8 bytes',async()=>{
 const {createProvisionerClient}=await import(clientPath);
 const pair=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
 const calls=[],signatures=[],original=payload();original.generatedCredentialName='synthetic-ключ';
 const raw=JSON.stringify(original),settings=config(),nonce=b64(new Uint8Array(32).fill(9));
 const signer={async sign(request){
   signatures.push(request);
   original.permissions[0].value='changed-after-freeze';original.secretUrl='https://evil.example/';
   return b64(await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},pair.privateKey,Buffer.from(request.bytes,'base64url')));
 }};
 const client=createProvisionerClient({crypto,signer,now:()=>1_800_000_000_000,uuid:()=> 'c7f17eb1-827f-429b-9db7-dd0ac898ee65',fetch:async(url,options)=>{
   calls.push({url,options});
   if(calls.length===1){
     const auth=JSON.parse(options.body);
     assert.deepEqual(Object.keys(auth).sort(),['issuedAt','keyId','payloadHash','profileId','requestId','signature']);
     assert.equal(auth.issuedAt,1_800_000_000);
     assert.equal(auth.payloadHash,b64(await crypto.subtle.digest('SHA-256',enc.encode(raw))));
     const bytes=enc.encode(JSON.stringify(['provisioner.auth-request.v1',auth.requestId,auth.issuedAt,settings.audience,settings.keyId,settings.profiles[0].digest,auth.payloadHash]));
     assert.equal(signatures[0].bytes,b64(bytes));
     assert.equal(await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},pair.publicKey,Buffer.from(auth.signature,'base64url'),bytes),true);
     return Response.json({nonce,expiresAt:1_800_000_120,jobId:'job-test'});
   }
   assert.deepEqual(Object.keys(options.headers).sort(),['x-provisioner-nonce','x-provisioner-signature']);
   assert.equal(Buffer.from(options.body).toString('utf8'),raw);
   assert.equal(options.headers['x-provisioner-nonce'],nonce);
   assert.equal(signatures[1].bytes,b64(enc.encode(nonce)));
   assert.equal(await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},pair.publicKey,Buffer.from(options.headers['x-provisioner-signature'],'base64url'),enc.encode(nonce)),true);
   return Response.json({id:'job-test',state:'accepted',provider:'b2',operation:'generate-api-key'});
 }});
 const job=await client.submit({config:settings,profileId:'b2-test',payload:original});
 assert.equal(job.state,'accepted');assert.equal(calls.length,2);
 assert.equal(calls[0].url,settings.privateOrigin+'/owner/apps/provisioner/challenge');
 assert.equal(calls[1].url,settings.privateOrigin+'/owner/apps/provisioner/submit');
 for(const {options} of calls){assert.equal(options.credentials,'include');assert.equal(options.redirect,'error');assert.equal(options.cache,'no-store');}
 assert.equal(signatures[0].purpose,'provisioner.auth-request.v1');assert.equal(signatures[1].purpose,'provisioner.nonce.v1');
});

test('client rejects unsafe configuration, absent signer and malformed signatures before network use',async()=>{
 const {createProvisionerClient,provisionerPrivateOrigin}=await import(clientPath);
 for(const origin of ['http://provisioner.vespoli.me','https://vespoli.me.evil.example','https://vespoli.me','https://provisioner.vespoli.me:8443','https://user@provisioner.vespoli.me','https://provisioner.vespoli.me/path','https://provisioner.vespoli.me?x=1'])assert.equal(provisionerPrivateOrigin(origin),null,origin);
 assert.equal(provisionerPrivateOrigin('https://private.anthonyvespoli.com'),'https://private.anthonyvespoli.com');
 let calls=0;const fetch=async()=>{calls++;throw Error('must not fetch');};
 const missing=createProvisionerClient({crypto,fetch});
 await assert.rejects(missing.submit({config:config(),profileId:'b2-test',payload:payload()}),{code:'signer-unavailable'});
 const malformed=createProvisionerClient({crypto,fetch,signer:{sign:async()=> 'not-a-p1363-signature'}});
 await assert.rejects(malformed.submit({config:config(),profileId:'b2-test',payload:payload()}),{code:'invalid-signer-response'});
 await assert.rejects(malformed.submit({config:{...config(),ready:false},profileId:'b2-test',payload:payload()}),{code:'setup-required'});
 await assert.rejects(malformed.submit({config:config(),profileId:'unapproved',payload:payload()}),{code:'profile-unavailable'});
 assert.equal(calls,0);
});

test('client treats submission transport failure as unknown and preserves job reference without retry',async()=>{
 const {createProvisionerClient}=await import(clientPath);
 let calls=0,jobId;
 const client=createProvisionerClient({crypto,signer:{sign:async()=> b64(new Uint8Array(64))},onJob:id=>{jobId=id;},fetch:async()=>{
   calls++;if(calls===1)return Response.json({nonce:b64(new Uint8Array(32)),expiresAt:Math.floor(Date.now()/1000)+120,jobId:'job-unknown'});
   throw Error('network could include sensitive details');
 }});
 await assert.rejects(client.submit({config:config(),profileId:'b2-test',payload:payload()}),{code:'submission-unknown'});
 assert.equal(calls,2);assert.equal(jobId,'job-unknown');
});

test('browser source loads in a VM, shows missing-signer setup, and never starts mutation',async()=>{
 const {provisionerClientSource,provisionerClientResponse}=await import(clientPath);
 const nodes=new Map();
 const node=id=>nodes.get(id)||nodes.set(id,{id,textContent:'',value:'',hidden:false,disabled:true,children:[],dataset:{},append(...children){this.children.push(...children);},replaceChildren(...children){this.children=children;},addEventListener(){},querySelectorAll(){return [];},setAttribute(){}}).get(id);
 node('provision-form').elements={namedItem:node};
 const document={getElementById:node,createElement:()=>node('created-'+nodes.size),querySelectorAll:()=>[]};
 let calls=0;
 const context=vm.createContext({document,window:{},URL,TextEncoder,Uint8Array,crypto,atob,btoa,setTimeout,clearTimeout,fetch:async()=>{calls++;return Response.json(config());}});
 vm.runInContext(provisionerClientSource(),context);
 await new Promise(resolve=>setImmediate(resolve));
 assert.equal(calls,1);
 assert.match(node('provision-status').textContent,/signing extension is unavailable/);
 assert.equal(node('provision-submit').disabled,true);
 const response=provisionerClientResponse();
 assert.match(response.headers.get('content-type'),/javascript/);
 assert.equal(response.headers.get('cache-control'),'no-store');
 assert.equal(await response.text(),provisionerClientSource());
 const source=await readFile(clientPath,'utf8');assert.doesNotMatch(source,/localStorage|sessionStorage|console\.(?:log|error)|navigator\.credentials|window\.personalControlSigner/);
});

test('client expires challenges after approval and rejects malformed nonce bytes without submission',async()=>{
 const {createProvisionerClient}=await import(clientPath);
 for(const scenario of ['expired','bad-nonce']){
   let calls=0,signatures=0,clock=1_800_000_000_000;
   const client=createProvisionerClient({crypto,now:()=>clock,signer:{async sign(){signatures++;if(signatures===2)clock+=121000;return b64(new Uint8Array(64));}},fetch:async()=>{
     calls++;return Response.json({nonce:scenario==='bad-nonce'?'bad':b64(new Uint8Array(32)),expiresAt:1_800_000_120,jobId:'job-expiry'});
   }});
   await assert.rejects(client.submit({config:config(),profileId:'b2-test',payload:payload()}),{code:scenario==='expired'?'challenge-expired':'invalid-server-response'});
   assert.equal(calls,1);assert.equal(signatures,scenario==='expired'?2:1);
 }
});

test('client prevents overlapping approvals and rejects literal secret fields or oversized bytes',async()=>{
 const {createProvisionerClient}=await import(clientPath);
 let release,signatures=0;const gate=new Promise(resolve=>{release=resolve;});
 const client=createProvisionerClient({crypto,signer:{async sign(){signatures++;await gate;throw Error('declined');}},fetch:async()=>assert.fail('no network request expected')});
 await assert.rejects(client.submit({config:config(),profileId:'b2-test',payload:{...payload(),password:'synthetic-canary'}}),{code:'invalid-payload'});
 await assert.rejects(client.submit({config:config(),profileId:'b2-test',payload:{...payload(),generatedCredentialName:'😀'.repeat(10000)}}),{code:'payload-too-large'});
 const first=client.submit({config:config(),profileId:'b2-test',payload:payload()});
 await new Promise(resolve=>setTimeout(resolve,10));
 await assert.rejects(client.submit({config:config(),profileId:'b2-test',payload:payload()}),{code:'request-in-progress'});
 release();await assert.rejects(first,{code:'signer-declined'});assert.equal(signatures,1);
});

test('status returns only nonsecret public fields and rejects invalid job references',async()=>{
 const {createProvisionerClient}=await import(clientPath);
 let calls=0;
 const client=createProvisionerClient({crypto,fetch:async(url,options)=>{
   calls++;assert.equal(url,'/owner/apps/provisioner/jobs/job-status');assert.equal(options.credentials,'same-origin');
   return Response.json({id:'job-status',state:'running',provider:'b2',operation:'generate-api-key',credential:'synthetic-secret-canary',error:{message:'untrusted-provider-detail'}});
 }});
 assert.deepEqual(await client.status('job-status'),{id:'job-status',state:'running',provider:'b2',operation:'generate-api-key'});
 await assert.rejects(client.status('../elsewhere'),{code:'invalid-job-reference'});assert.equal(calls,1);
});

test('submission HTTP 500 remains unknown instead of inviting a duplicate job',async()=>{
 const {createProvisionerClient}=await import(clientPath);
 let calls=0;
 const client=createProvisionerClient({crypto,signer:{sign:async()=>b64(new Uint8Array(64))},fetch:async()=>{
   calls++;if(calls===1)return Response.json({nonce:b64(new Uint8Array(32)),expiresAt:Math.floor(Date.now()/1000)+120,jobId:'job-server-error'});
   return Response.json({error:'synthetic-sensitive-internal-detail'},{status:500});
 }});
 await assert.rejects(client.submit({config:config(),profileId:'b2-test',payload:payload()}),{code:'submission-unknown'});assert.equal(calls,2);
});

test('server field diagnostics expose approved field paths and fixed codes without values',async()=>{
 const {createProvisionerClient}=await import(clientPath);
 const client=createProvisionerClient({crypto,signer:{sign:async()=>b64(new Uint8Array(64))},fetch:async()=>Response.json({error:'payload-invalid',fields:[{field:'permissions[0]',code:'not-approved',value:'synthetic-secret-canary'},{field:'$',code:'profile-incomplete'},{field:'password:synthetic-secret-canary',code:'required'},{field:'secretUrl',code:'synthetic-secret-canary'}]},{status:400})});
 await assert.rejects(client.submit({config:config(),profileId:'b2-test',payload:payload()}),failure=>{
   assert.equal(failure.code,'request-rejected');assert.deepEqual(failure.fields,[{field:'permissions[0]',code:'not-approved'},{field:'$',code:'profile-incomplete'}]);assert.doesNotMatch(JSON.stringify(failure),/synthetic-secret-canary/);return true;
 });
});
