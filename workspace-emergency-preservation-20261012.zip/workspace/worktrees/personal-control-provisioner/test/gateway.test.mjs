import test from 'node:test';
import assert from 'node:assert/strict';
import {loginTarget,ownerGate} from '../src/gate.mjs';
import {capabilities,capabilityForPath} from '../src/capabilities.mjs';
import {navigation,fields} from '../src/ui.mjs';

const env={ORIGIN:'https://control.vespoli.me'};
test('login returns only to registered control panes',()=>{
  assert.equal(loginTarget('/owner/apps/backups?view=pending',env),'https://control.vespoli.me/owner/apps/backups?view=pending');
  assert.equal(loginTarget('/owner/job-stack?grant=existing',env),'https://control.vespoli.me/owner/job-stack?grant=existing');
  for(const path of ['https://evil.example','//evil.example','/ownerish','/owner/../oauth/token','/owner/%2e%2e/oauth/token','/owner/unknown','/owner\\evil'])assert.throws(()=>loginTarget(path,env));
});
test('one gate verifies identity then rejects cross-origin mutations',async()=>{
  let calls=0;const verify=async()=>{calls++;return 'owner@example.com';};
  assert.equal(await ownerGate(new Request(env.ORIGIN+'/owner'),env,verify),'owner@example.com');
  await assert.rejects(ownerGate(new Request(env.ORIGIN+'/owner',{method:'POST',headers:{origin:'https://evil.example'}}),env,verify));
  assert.equal(calls,2);
  await assert.rejects(ownerGate(new Request(env.ORIGIN+'/owner'),env,async()=>{throw Error('owner-login-required');}));
});
test('capability routes are exact and all panes share navigation',()=>{
  for(const capability of capabilities){assert.equal(capabilityForPath('/owner/apps/'+capability.id).id,capability.id);assert.match(navigation(capability.id),new RegExp('/owner/apps/'+capability.id));}
  assert.equal(capabilityForPath('/owner/apps/caretaker-evil'),undefined);
});
test('schema-driven forms escape untrusted provider labels',()=>{
  const result=fields({properties:{name:{type:'string',description:'<script>alert(1)</script>'},count:{type:'integer'},data:{type:'object'}},required:['name']});
  assert.ok(!result.includes('<script>'));assert.match(result,/&lt;script&gt;/);assert.match(result,/required/);
});
