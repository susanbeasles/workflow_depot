import test from 'node:test';
import assert from 'node:assert/strict';
import {Miniflare,convertV4MiniflareOptions} from 'miniflare';
import {build} from 'esbuild';
import {profileDigest} from '../src/provisioner.mjs';
const enc=new TextEncoder(),base64=value=>Buffer.from(value).toString('base64url');
test('private service binding exercises pinned signatures, durable nonce burn and job status in workerd',async()=>{
 const bundled=(await build({entryPoints:['src/worker.mjs'],bundle:true,write:false,format:'esm',platform:'browser',external:['cloudflare:workers']})).outputFiles[0].text;
 const owner='owner@example.com',origin='https://control.vespoli.me',privateOrigin='https://provisioner.vespoli.me';
 const keys=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
 const raw=await crypto.subtle.exportKey('raw',keys.publicKey),keyId=Buffer.from(await crypto.subtle.digest('SHA-256',raw)).toString('hex');
 const sign=async text=>base64(await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},keys.privateKey,enc.encode(text)));
 const issuer=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
 const jwk=await crypto.subtle.exportKey('jwk',issuer.publicKey);jwk.kid='provisioner-fixture';
 const claims={iss:'https://fixture.cloudflareaccess.com',aud:['owner'],email:owner,exp:Date.now()/1000+300};
 const input=base64(enc.encode(JSON.stringify({alg:'RS256',kid:jwk.kid})))+'.'+base64(enc.encode(JSON.stringify(claims)));
 const token=input+'.'+base64(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',issuer.privateKey,enc.encode(input)));
 const profile={id:'b2-fixture',provider:'b2',operation:'generate-api-key',codeRevision:'code-fixture',manifestRevision:'manifest-fixture',policyRevision:'fixture',sourceRecord:'op://input/login',inputFields:{username:'op://input/login/user',password:'op://input/login/pass'},outputVault:'output',constraints:{secretUrl:'https://provider.example/keys','1passwordRecordUrl':'op://input/login',generatedCredentialType:'application-key',generatedCredentialName:'b2-fixture-key',permissions:[]},manifest:{version:1,qualified:true},kv:{destination:'fixture',encryptionKeyId:'fixture'},recovery:{destination:'fixture',encryptionKeyId:'fixture'}};
 const trusted={keyID:keyId,ownerID:1,ownerEmail:owner,publicKeyX963:Buffer.from(raw).toString('base64'),revoked:false,purposes:['credential-provisioning']};
 const trustScript=`import {WorkerEntrypoint} from 'cloudflare:workers'; export class Trust extends WorkerEntrypoint {current(){return ${JSON.stringify(trusted)};}} export class Hardware extends WorkerEntrypoint {verify(){return {keyID:'${keyId}',hardwareVerified:true,revoked:false,proofDigest:'${'a'.repeat(64)}',validUntil:Math.floor(Date.now()/1000)+60};}} export default {fetch(){return new Response('Not found',{status:404});}};`;
 // The facade supplies Origin inside workerd because Miniflare's external proxy
 // rejects non-local browser Origin headers before reaching tested Worker code.
 const privateScript=`export default {fetch(request,env){const u=new URL(request.url);u.host='provisioner.vespoli.me';const headers=new Headers(request.headers);headers.set('origin','${origin}');return env.ADMISSION.fetch(new Request(u,{method:request.method,headers,body:request.body}));}};`;
 const mf=new Miniflare(convertV4MiniflareOptions({workers:[
  {name:'gateway',modules:true,script:bundled,compatibilityDate:'2026-10-06',bindings:{ORIGIN:origin,ACCESS_TEAM:'fixture',ACCESS_AUD:'owner',OWNER_EMAILS:owner,PROVISIONER_PRIVATE_ORIGIN:privateOrigin,PROVISIONER_OWNER_KEY_ID:keyId,PROVISIONER_SIGNER_EXTENSION_ID:'abcdefghijklmnopabcdefghijklmnop',PROVISIONER_PROFILES:JSON.stringify([profile]),PROVISIONER_DISPATCH_URL:'https://provisioner-executor.vespoli.me/dispatch',PROVISIONER_DISPATCH_AUDIENCE:'fixture',PROVISIONER_DISPATCH_KEY:'SYNTHETIC-DISPATCH-KEY-NOT-CREDENTIAL'},durableObjects:{CONTROL:{className:'Control',useSQLite:true}},serviceBindings:{PROVISIONER_EXECUTOR:'trust',PROVISIONER_TRUST:{name:'trust',entrypoint:'Trust'},PROVISIONER_HARDWARE:{name:'trust',entrypoint:'Hardware'}},outboundService:async request=>request.url.endsWith('/cdn-cgi/access/certs')?Response.json({keys:[jwk]}):new Response('Fixture dispatcher unavailable',{status:503})},
  {name:'trust',modules:true,script:trustScript,compatibilityDate:'2026-10-06'},
  {name:'private',modules:true,script:privateScript,compatibilityDate:'2026-10-06',serviceBindings:{ADMISSION:{name:'gateway',entrypoint:'ProvisionerAdmission'}}},
 ]}));
 try{
  const privateWorker=await mf.getWorker('private'),gateway=await mf.getWorker('gateway');
  const headers={'cf-access-jwt-assertion':token};
  const payload=JSON.stringify({operation:'generate-api-key',secretUrl:profile.constraints.secretUrl,'1passwordRecordUrl':profile.sourceRecord,generatedCredentialType:'application-key',generatedCredentialName:'b2-fixture-key',permissions:[]});
  async function challenge(rawPayload){
   const request={keyId,requestId:crypto.randomUUID(),issuedAt:Math.floor(Date.now()/1000),profileId:profile.id,payloadHash:base64(await crypto.subtle.digest('SHA-256',enc.encode(rawPayload)))};
   request.signature=await sign(JSON.stringify(['provisioner.auth-request.v1',request.requestId,request.issuedAt,privateOrigin,keyId,await profileDigest(profile),request.payloadHash]));
   const response=await privateWorker.fetch(privateOrigin+'/owner/apps/provisioner/challenge',{method:'POST',headers:{...headers,'content-type':'application/json'},body:JSON.stringify(request)});
   assert.equal(response.status,200,await response.clone().text());return response.json();
  }
  const c=await challenge(payload),signature=await sign(c.nonce);
  const submit=(body,sig=signature)=>privateWorker.fetch(privateOrigin+'/owner/apps/provisioner/submit',{method:'POST',headers:{...headers,'x-provisioner-nonce':c.nonce,'x-provisioner-signature':sig},body});
  assert.equal((await submit(payload,await sign('invalid'))).status,403);
  const outcomes=await Promise.all([submit(payload),submit(payload)]);assert.deepEqual(outcomes.map(r=>r.status).sort(),[202,409]);
  const status=await gateway.fetch(origin+'/owner/apps/provisioner/jobs/'+c.jobId,{headers});assert.equal(status.status,200);assert.equal((await status.json()).state,'accepted');
  const bad=await challenge(payload);const badHeaders={...headers,'x-provisioner-nonce':bad.nonce,'x-provisioner-signature':await sign(bad.nonce)};
  const rejected=await privateWorker.fetch(privateOrigin+'/owner/apps/provisioner/submit',{method:'POST',headers:badHeaders,body:'{}'});assert.equal((await rejected.json()).error,'payload-hash-mismatch');
  assert.equal((await privateWorker.fetch(privateOrigin+'/owner/apps/provisioner/submit',{method:'POST',headers:badHeaders,body:payload})).status,409);
  assert.equal((await gateway.fetch(origin+'/owner/apps/provisioner/challenge',{method:'POST',headers,body:'{}'})).status,404);
  assert.equal((await privateWorker.fetch(privateOrigin+'/owner/apps/provisioner/challenge',{method:'POST',body:'{}'})).status,403);
 }finally{await mf.dispose();}
});
