import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createProvisioner,profileDigest} from '../src/provisioner.mjs';
import {createProvisionerClient} from '../src/provisioner-client.mjs';
import {runProvisioningJob} from '../runner/provisioner.mjs';
import {createOpAdapter} from '../runner/op-adapter.mjs';

test('one synthetic job crosses the actual client, authorizer, executor and op-adapter contracts',async()=>{
 const profile=JSON.parse(await readFile('runner/b2.candidate-profile.json','utf8'));
 profile.manifest.qualified=true;profile.codeRevision='synthetic-bundle';
 const keys=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
 const raw=await crypto.subtle.exportKey('raw',keys.publicKey),keyId=Buffer.from(await crypto.subtle.digest('SHA-256',raw)).toString('hex');
 const owner='fixture@example.test',audience='https://provisioner.vespoli.me',records=new Map();
 const storage={get:async key=>structuredClone(records.get(key)),put:async(key,value)=>records.set(key,structuredClone(value)),delete:async key=>records.delete(key)};
 storage.transaction=fn=>fn(storage);
 const service=createProvisioner({storage,profiles:[profile],audience,trust:{current:async()=>({keyID:keyId,ownerID:1,ownerEmail:owner,publicKeyX963:Buffer.from(raw).toString('base64'),revoked:false,purposes:['credential-provisioning']})},hardware:{verify:async()=>({keyID:keyId,hardwareVerified:true,revoked:false,proofDigest:'0'.repeat(64),validUntil:Math.floor(Date.now()/1000)+60})}});
 const client=createProvisionerClient({crypto,signer:{sign:async({bytes})=>Buffer.from(await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},keys.privateKey,Buffer.from(bytes,'base64url'))).toString('base64url')},fetch:async(url,options)=>{
  if(url.endsWith('/challenge'))return Response.json(await service.challenge(owner,JSON.parse(options.body)));
  return Response.json(await service.submit(owner,options.headers['x-provisioner-nonce'],options.headers['x-provisioner-signature'],async()=>options.body),{status:202});
 }});
 const publicJob=await client.submit({config:{ready:true,privateOrigin:audience,audience,keyId,profiles:[{id:profile.id,digest:await profileDigest(profile)}]},profileId:profile.id,payload:{operation:'generate-api-key',...profile.constraints,KV:true}});
 const job=await storage.get('provisioner:job:'+publicJob.id);assert.equal(job.state,'accepted');
 let created,mutations=0,reserved=false;
 const op=await createOpAdapter({serviceAccountToken:'SYNTHETIC-ONLY',run:async({args,input})=>{
  if(args[0]==='read')return args[1].endsWith('/username')?'synthetic-user':'synthetic-password';
  if(args[1]==='create'){created=JSON.parse(input);return JSON.stringify({id:'d'.repeat(26),vault:{id:profile.outputVault}});}
  return JSON.stringify({id:'d'.repeat(26),vault:{id:profile.outputVault},fields:created.fields});
 }});
 const result=await runProvisioningJob({job,profile,codeDigest:profile.codeRevision,op,browserFactory:async()=>({perform:async step=>{if(step===profile.manifest.submit)mutations++;},capture:async()=>({keyId:'synthetic-key-id',applicationKey:'synthetic-application-key'}),close:async()=>{}}),journal:{reserve:async()=>{assert.equal(reserved,false);reserved=true;return true;},update:async()=>{}},recovery:{encrypted:true,durable:true,destination:profile.recovery.destination,capture:async()=>({id:'recovery-fixture'})},kv:{encrypted:true,unwrapSeparate:true,destination:profile.kv.destination,putEncrypted:async()=>({id:'kv-fixture'})}});
 assert.equal(result.state,'succeeded');assert.equal(result.itemId,'d'.repeat(26));assert.equal(mutations,1);
 assert.ok(!JSON.stringify(result).includes('synthetic-application-key'));assert.equal(created.title,'b2-backup-key');
});
