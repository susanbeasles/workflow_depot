import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash,X509Certificate} from 'node:crypto';
import {rootCertificates} from 'node:tls';
import {mkdtemp,readFile,rm,mkdir} from 'node:fs/promises';
import {tmpdir,endianness} from 'node:os';
import {join} from 'node:path';
import {execFileSync,spawnSync} from 'node:child_process';
import {prepareSigner,validateSignerConfig} from '../signer/prepare.mjs';

// Public fixtures only: no private key is created, loaded or used by packaging tests.
const extensionDer=new X509Certificate(rootCertificates[0]).publicKey.export({format:'der',type:'spki'});
const extensionPublicKey=extensionDer.toString('base64');
const extensionId=createHash('sha256').update(extensionDer).digest('hex').slice(0,32).replace(/[0-9a-f]/g,n=>String.fromCharCode(97+parseInt(n,16)));
function config(){
 const raw=Buffer.from('04'+'60fed4ba255a9d31c961eb74c6356d68c049b8923b61fa6ce669622e60f29fb6'+'7903fe1008b8bc99a41ae9e95628bc64f2f1b20c2d7e9f5177a3c294d4462299','hex');
 return {version:1,extensionId,ownerOrigin:'https://control.vespoli.me',audience:'https://private.vespoli.me',keyId:createHash('sha256').update(raw).digest('hex'),publicKeyX963:raw.toString('base64url'),serial:12345678,slot:'9c',profileDigests:[Buffer.alloc(32,1).toString('base64url')],pinentryPath:'/usr/local/bin/pinentry-mac',pinentrySha256:'1'.repeat(64)};
}
test('signer package pins origin, extension, key and local launcher without installing',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'provisioner-sign-package-'));
 try{
  const value=config(),out=join(dir,'reviewable package');
  const result=await prepareSigner({extensionPublicKey,config:value,outputDir:out,pythonPath:'/opt/provisioner-signer/bin/python3'});
  const manifest=JSON.parse(await readFile(join(out,'extension/manifest.json')));
  assert.deepEqual(manifest.externally_connectable,{matches:[value.ownerOrigin+'/*']});
  assert.deepEqual(manifest.permissions,['nativeMessaging']);
  assert.equal(manifest.key,extensionPublicKey);
  assert.equal(manifest.content_scripts,undefined);
  const host=JSON.parse(await readFile(join(out,'me.vespoli.provisioner.json')));
  assert.deepEqual(host.allowed_origins,['chrome-extension://'+value.extensionId+'/']);
  assert.equal(host.path,join(out,'native/launch'));
  assert.deepEqual(JSON.parse(await readFile(join(out,'native/host-config.json'))),value);
  const launch=await readFile(host.path,'utf8');
  assert.match(launch,/exec '\/opt\/provisioner-signer\/bin\/python3' -I /);
  assert.match(launch,/host\.py' "\$@"/);
  assert.equal(result.installed,false);
  await assert.rejects(prepareSigner({extensionPublicKey,config:value,outputDir:out,pythonPath:'/bin/python3'}),/output-exists/);
 }finally{await rm(dir,{recursive:true,force:true});}
});
test('signer configuration rejects swapped public key, wildcard origin and credential fields',()=>{
 for(const change of [{keyId:'0'.repeat(64)},{ownerOrigin:'https://*.vespoli.me'},{audience:'https://private.vespoli.me/path'},{extensionId:'x'.repeat(32)},{publicKeyX963:'A'.repeat(87)},{profileDigests:['A'.repeat(42)]},{pin:'123456'},{pinentryPath:'pinentry'},{slot:'generate'},{serial:0}]){
  assert.throws(()=>validateSignerConfig({...config(),...change}),/invalid-signer-config/);
 }
});
test('package paths reject shell control characters and preserve existing destinations',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'provisioner-sign-package-'));
 try{
  const existing=join(dir,'existing');await mkdir(existing);
  await assert.rejects(prepareSigner({extensionPublicKey,config:config(),outputDir:existing,pythonPath:'/bin/python3'}),/output-exists/);
  await assert.rejects(prepareSigner({extensionPublicKey,config:config(),outputDir:join(dir,'new'),pythonPath:'/bin/python3\nmalicious'}),/invalid-runtime-path/);
 }finally{await rm(dir,{recursive:true,force:true});}
});

test('package requires the public identity of the configured extension',async()=>{
 await assert.rejects(prepareSigner({config:config(),outputDir:'/tmp/unused-signer-package',pythonPath:'/bin/python3',extensionPublicKey:'AAAA'}),/extension-public-key-mismatch/);
});

test('packaged isolated native host answers its real framed handshake without hardware dependencies or signing',async()=>{
 // Execute only under our private workspace ancestors. This sandbox's shared
 // /tmp is owned by an unmapped UID and is deliberately rejected by the host.
 const dir=await mkdtemp(join(process.cwd(),'.provisioner-native-launch-'));
 try{
  const value=config(),out=join(dir,'package'),python=execFileSync('python3',['-c','import sys; print(sys.executable)'],{encoding:'utf8'}).trim();
  await prepareSigner({extensionPublicKey,config:value,outputDir:out,pythonPath:python});
  const id='00000000-0000-4000-8000-000000000001',hello=Buffer.from(JSON.stringify({version:1,id,action:'hello',origin:value.ownerOrigin,keyId:value.keyId})),header=Buffer.alloc(4);
  if(endianness()==='LE')header.writeUInt32LE(hello.length);else header.writeUInt32BE(hello.length);
  const child=spawnSync(join(out,'native/launch'),['chrome-extension://'+value.extensionId+'/'],{input:Buffer.concat([header,hello]),timeout:5000,maxBuffer:16384,env:{PATH:'/usr/bin:/bin',HOME:dir,LANG:'C.UTF-8'}});
  assert.equal(child.error,undefined);assert.equal(child.status,0);assert.equal(child.stderr.length,0);
  const length=endianness()==='LE'?child.stdout.readUInt32LE(0):child.stdout.readUInt32BE(0);
  assert.equal(child.stdout.length,length+4);
  assert.deepEqual(JSON.parse(child.stdout.subarray(4).toString('utf8')),{version:1,id,ok:true,keyId:value.keyId});
 }finally{await rm(dir,{recursive:true,force:true});}
});
