import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdtemp, readFile, writeFile, rm, readdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
const engine = await import('../runner/provisioner.mjs').catch(() => ({}));
const adapters = await import('../runner/op-adapter.mjs').catch(() => ({}));
const browser = await import('../runner/browser.mjs').catch(() => ({}));
const bundle = await import('../runner/verify-bundle.mjs').catch(() => ({}));
const cli = await import('../runner/run.mjs').catch(() => ({}));
const isolated = await import('../runner/isolated-browser.mjs').catch(() => ({}));
const authorizer = await import('../src/provisioner.mjs');
const digest = value => createHash('sha256').update(value).digest('base64url');
const stable = value => JSON.stringify(sort(value));
function sort(value) { return Array.isArray(value) ? value.map(sort) : value && typeof value === 'object' ? Object.fromEntries(Object.keys(value).sort().map(k => [k, sort(value[k])])) : value; }
function fixture() {
  const profile = {
    id:'b2-fixture', provider:'b2', operation:'generate-api-key', sourceRecord:'op://aaaaaaaaaaaaaaaaaaaaaaaaaa/bbbbbbbbbbbbbbbbbbbbbbbbbb',
    inputFields:{username:'op://aaaaaaaaaaaaaaaaaaaaaaaaaa/bbbbbbbbbbbbbbbbbbbbbbbbbb/username',password:'op://aaaaaaaaaaaaaaaaaaaaaaaaaa/bbbbbbbbbbbbbbbbbbbbbbbbbb/password'},
    outputVault:'cccccccccccccccccccccccccc', itemTitle:'b2-backup-key', allowedOrigins:['https://provider.test'],
    constraints:{loginUrl:'https://provider.test/login',secretUrl:'https://provider.test/keys',
      '1passwordRecordUrl':'op://aaaaaaaaaaaaaaaaaaaaaaaaaa/bbbbbbbbbbbbbbbbbbbbbbbbbb',uDomId:'username',pwdDomId:'password',
      generatedCredentialType:'application-key',generatedCredentialName:'fixture-backup-key',permissions:[{fieldDomId:'bucket',value:'backup'}]},
    manifest:{version:1,qualified:true,login:[{action:'goto',url:'loginUrl'},{action:'fill',selector:'#username',input:'username'},
      {action:'fill',selector:'#password',input:'password'},{action:'click',selector:'#login'}],
      prepare:[{action:'goto',url:'secretUrl'},{action:'fill',selector:'#name',value:'credentialName'},
        {action:'select',selector:'#bucket',permission:'bucket'}],submit:{action:'click',selector:'#issue'},
      capture:{keyId:{selector:'#key-id',read:'text'},applicationKey:{selector:'#application-key',read:'text'}}},
    kv:{destination:'fixture-kv',encryptionKeyId:'output-key'},recovery:{destination:'fixture-recovery',encryptionKeyId:'recovery-key'},
    codeRevision:'fixture-code',manifestRevision:'fixture-v1'
  };
  const payload = {operation:'generate-api-key',...profile.constraints};
  const rawPayload = JSON.stringify(payload);
  const job = {id:'job-1',owner:'owner@example.test',payload,rawPayload,payloadHash:digest(rawPayload),context:{profileId:profile.id,
    profileDigest:digest(stable(profile)),codeDigest:'fixture-code-digest',manifestDigest:digest(stable(profile.manifest))}};
  return {profile,job};
}
function repin(f) { f.job.rawPayload = JSON.stringify(f.job.payload); f.job.payloadHash = digest(f.job.rawPayload); f.job.context.profileDigest = digest(stable(f.profile)); f.job.context.manifestDigest = digest(stable(f.profile.manifest)); return f; }
function genericFixture() {
  const f=fixture();f.profile.provider='example-cloud';f.profile.id='example-cloud-token';f.job.context.profileId=f.profile.id;
  delete f.profile.constraints.generatedCredentialName;delete f.job.payload.generatedCredentialName;
  f.profile.namePolicy={allowedCharacters:'printable-ascii',maxLength:128};
  f.profile.outputFields=[{capture:'apiToken',id:'api_token',label:'API token',type:'CONCEALED'}];
  f.profile.constraints.uDomId='email-field';f.job.payload.uDomId='email-field';
  f.profile.manifest={version:2,qualified:true,locators:{
    email:{kind:'css',value:'input[name="email-field"]'},next:{kind:'role',role:'button',name:'Next'},
    password:{kind:'label',value:'Password'},login:{kind:'role',role:'button',name:'Sign in'},
    name:{kind:'label',value:'Token name'},bucket:{kind:'label',value:'Project'},
    issue:{kind:'role',role:'button',name:'Create token'},token:{kind:'css',value:'output[data-secret="token"]'}
  },login:[{action:'goto',url:'loginUrl'},{action:'fill',locator:'email',input:'username'},{action:'click',locator:'next'},
    {action:'wait',locator:'password'},{action:'fill',locator:'password',input:'password'},{action:'click',locator:'login'}],
  prepare:[{action:'goto',url:'secretUrl'},{action:'fill',locator:'name',value:'credentialName'},{action:'select',locator:'bucket',permission:'bucket'}],
  submit:{action:'click',locator:'issue'},capture:{apiToken:{locator:'token',read:'text'}}};
  return repin(f);
}
function dependencies(events = []) {
  let reserved = false;
  const credential = {keyId:'synthetic-key-id',applicationKey:'SYNTHETIC-PRIVATE-APPLICATION-KEY'};
  return {
    codeDigest:'fixture-code-digest',
    op:{readInputs:async () => {events.push('read');return {username:'synthetic-user',password:'SYNTHETIC-PASSWORD'};},
      saveCredential:async value => {events.push('save');assert.deepEqual(value.credential,credential);return {itemId:'dddddddddddddddddddddddddd',vaultId:'cccccccccccccccccccccccccc'};},close:async () => events.push('op-close')},
    browserFactory:async () => ({perform:async step => events.push(step.action),capture:async () => {events.push('capture');return credential;},close:async () => events.push('browser-close')}),
    recovery:{encrypted:true,durable:true,destination:'fixture-recovery',capture:async () => {events.push('recover');return {id:'recovery-id'};}},
    kv:{encrypted:true,unwrapSeparate:true,destination:'fixture-kv',putEncrypted:async () => {events.push('kv');return {id:'kv-id'};}},
    journal:{reserve:async () => {events.push('reserve');if(reserved)return false;reserved=true;return true;},update:async value => events.push(value.state)}
  };
}
test('runner exports a executable declarative B2 job boundary', () => assert.equal(typeof engine.runProvisioningJob,'function'));
test('runner persists capture before output and emits only nonsecret receipt', async () => {
  const events=[];const result=await engine.runProvisioningJob({...fixture(),...dependencies(events)});
  assert.equal(result.state,'succeeded');assert.equal(result.itemId,'dddddddddddddddddddddddddd');
  assert(events.indexOf('reserve')<events.lastIndexOf('click'));assert(events.indexOf('recover')<events.indexOf('save'));
  assert(events.indexOf('save')<events.indexOf('kv'));assert(events.includes('browser-close'));assert(events.includes('op-close'));
  assert(!JSON.stringify(result).includes('SYNTHETIC'));assert(!JSON.stringify(result).includes('applicationKey'));
});
test('exact raw payload digest, profile and manifest pins checked before secret read', async () => {
  for(const tamper of [f=>{f.job.rawPayload+=' ';},f=>{f.job.payload.permissions[0].value='all';},f=>{f.profile.outputVault='another';},f=>{f.job.context.manifestDigest='wrong';},f=>{f.job.context.codeDigest='wrong';}]) {
    const f=fixture();const events=[];tamper(f);await assert.rejects(engine.runProvisioningJob({...f,...dependencies(events)}));assert(!events.includes('read'));
  }
});
test('qualifications and unsupported operations fail closed before secrets', async () => {
  for(const operation of ['rotate-password','rotate-recovery-codes','rotate-totp','create-passkey','arbitrary']) {
    const f=fixture();f.job.payload.operation=operation;repin(f);await assert.rejects(engine.runProvisioningJob({...f,...dependencies()}));
  }
  const f=fixture();f.profile.manifest.qualified=false;repin(f);
  await assert.rejects(engine.runProvisioningJob({...f,...dependencies()}),/manifest-unqualified/);
});
test('caller selectors, extra keys, destinations and permission changes rejected', async () => {
  for(const change of [{secretUrl:'https://evil.test'},{uDomId:'other'},{toVault:'evil'},{permissions:[{fieldDomId:'bucket',value:'all'}]}, {evaluate:'secret'}, {KV:'false'}]) {
    const f=fixture();Object.assign(f.job.payload,change);repin(f);await assert.rejects(engine.runProvisioningJob({...f,...dependencies()}));
  }
});
test('KV is on by default and requires encryption and separate unwrap capability', async () => {
  for(const overrides of [{kv:undefined},{kv:{encrypted:false}},{kv:{encrypted:true,unwrapSeparate:false}}]) {
    const events=[];await assert.rejects(engine.runProvisioningJob({...fixture(),...dependencies(events),...overrides}),/encrypted-kv-required/);assert(!events.includes('read'));
  }
  const f=fixture();f.job.payload.KV=false;repin(f);const deps=dependencies();deps.kv=undefined;
  assert.equal((await engine.runProvisioningJob({...f,...deps})).state,'succeeded');
});
test('durable recovery is mandatory even with KV disabled', async () => {
  const f=fixture();f.job.payload.KV=false;repin(f);
  await assert.rejects(engine.runProvisioningJob({...f,...dependencies(),recovery:{encrypted:true,durable:false}}),/durable-recovery-required/);
});
test('ambiguous issue failure never retries and records uncertain state without secrets', async () => {
  const events=[];const deps=dependencies(events);let issues=0;
  deps.browserFactory=async()=>({perform:async s=>{if(s.selector==='#issue'){issues++;throw Error('SYNTHETIC-SECRET');}},close:async()=>events.push('browser-close')});
  const result=await engine.runProvisioningJob({...fixture(),...deps});
  assert.equal(result.state,'uncertain');assert.equal(issues,1);assert(!JSON.stringify(result).includes('SYNTHETIC'));assert(events.includes('uncertain'));assert(events.includes('browser-close'));
  const rerun=await engine.runProvisioningJob({...fixture(),...deps});assert.equal(rerun.state,'blocked');assert.equal(issues,1);
});
test('output failure leaves recovery checkpoint and never claims success', async () => {
  const events=[];const deps=dependencies(events);deps.op.saveCredential=async()=>{throw Error('SYNTHETIC-PRIVATE-APPLICATION-KEY');};
  const result=await engine.runProvisioningJob({...fixture(),...deps});
  assert.equal(result.state,'recovery-required');assert(events.includes('recover'));assert(!events.includes('kv'));assert(!JSON.stringify(result).includes('SYNTHETIC'));
});
test('missing capture and malformed output receipts cannot produce success', async () => {
  const deps=dependencies();deps.browserFactory=async()=>({perform:async()=>{},capture:async()=>({keyId:'key'}),close:async()=>{}});
  assert.equal((await engine.runProvisioningJob({...fixture(),...deps})).state,'uncertain');
  const deps2=dependencies();deps2.op.saveCredential=async()=>({itemId:'item',vaultId:'wrong'});
  assert.equal((await engine.runProvisioningJob({...fixture(),...deps2})).state,'recovery-required');
});
test('profile action schema never accepts scripts, arbitrary URLs or unsupported reads', async () => {
  for(const step of [{action:'evaluate',script:'alert(1)'},{action:'goto',url:'https://evil.test'},{action:'fill',selector:'#x',value:'anything'}, {action:'shell',command:'op read'}]) {
    const f=fixture();f.profile.manifest.prepare.push(step);repin(f);await assert.rejects(engine.runProvisioningJob({...f,...dependencies()}));
  }
});
test('approved name and duration must each have one executable prepare binding before secrets are read',async()=>{
  for(const create of [fixture,genericFixture])for(const problem of ['missing-name','duplicate-name','missing-duration','duplicate-duration']){
    const f=create(),events=[],prepare=f.profile.manifest.prepare;
    const name=prepare.find(step=>step.value==='credentialName');
    if(problem==='missing-name')f.profile.manifest.prepare=prepare.filter(step=>step!==name);
    if(problem==='duplicate-name')prepare.push({...name});
    if(problem.includes('duration')){
      f.profile.constraints.duration=3600;f.job.payload.duration=3600;
      if(problem==='duplicate-duration'){
        if(f.profile.manifest.version===2)f.profile.manifest.locators.duration={kind:'label',value:'Lifetime'};
        const binding={action:'fill',...(f.profile.manifest.version===2?{locator:'duration'}:{selector:'#duration'}),value:'duration'};
        prepare.push(binding,{...binding});
      }
    }
    repin(f);await assert.rejects(engine.runProvisioningJob({...f,...dependencies(events)}),/manifest-value-(?:missing|duplicate)/,problem);
    assert(!events.includes('read'));assert(!events.includes('reserve'));
  }
  for(const create of [fixture,genericFixture]){
    const f=create();f.profile.constraints.duration=3600;f.job.payload.duration=3600;
    if(f.profile.manifest.version===2)f.profile.manifest.locators.duration={kind:'label',value:'Lifetime'};
    f.profile.manifest.prepare.push({action:'fill',...(f.profile.manifest.version===2?{locator:'duration'}:{selector:'#duration'}),value:'duration'});repin(f);
    assert.doesNotThrow(()=>engine.validateJobProfile({...f,codeDigest:'fixture-code-digest'}));
  }
});
test('an omitted payload duration cannot inherit an invalid approved default',async()=>{
  for(const duration of [0,-1,1.5,'3600',true,null,Number.MAX_SAFE_INTEGER+1]){
    const f=fixture(),events=[];f.profile.constraints.duration=duration;
    f.profile.manifest.prepare.push({action:'fill',selector:'#lifetime',value:'duration'});repin(f);
    assert.throws(()=>authorizer.validatePayload(f.job.payload,f.profile),/payload-invalid/);
    await assert.rejects(engine.runProvisioningJob({...f,...dependencies(events)}),/duration-invalid/);
    assert(!events.includes('read'));
  }
});
test('prepare writes cannot overwrite an approved name or permission through duplicate locator targets',async()=>{
  for(const create of [fixture,genericFixture])for(const alias of ['name-duration','permission-name']){
    const f=create(),events=[],name=f.profile.manifest.prepare.find(step=>step.value==='credentialName');
    if(alias==='name-duration'){
      f.profile.constraints.duration=3600;f.job.payload.duration=3600;
      if(f.profile.manifest.version===2){f.profile.manifest.locators.duration={...f.profile.manifest.locators.name};f.profile.manifest.prepare.push({action:'fill',locator:'duration',value:'duration'});}
      else f.profile.manifest.prepare.push({...name,value:'duration'});
    }else{
      const permission=f.profile.manifest.prepare.find(step=>step.permission==='bucket');
      if(f.profile.manifest.version===2)f.profile.manifest.locators.bucket={...f.profile.manifest.locators.name};
      else permission.selector=name.selector;
      // v1 binds permission IDs to selectors, so use the existing approved name
      // target as its approved permission ID too.
      if(f.profile.manifest.version===1){permission.permission='name';f.profile.constraints.permissions=[{fieldDomId:'name',value:'backup'}];f.job.payload.permissions=f.profile.constraints.permissions;}
    }
    repin(f);await assert.rejects(engine.runProvisioningJob({...f,...dependencies(events)}),/manifest-target-reused/);
    assert(!events.includes('read'));assert(!events.includes('reserve'));
  }
});
test('approved explicit B2 name default is used; output item title stays separate', async () => {
  const f=fixture();delete f.job.payload.generatedCredentialName;repin(f);const deps=dependencies();const values=[];
  deps.browserFactory=async()=>({perform:async(s,c)=>values.push(c.credentialName),capture:async()=>({keyId:'synthetic-key-id',applicationKey:'SYNTHETIC-PRIVATE-APPLICATION-KEY'}),close:async()=>{}});
  const original=deps.op.saveCredential;deps.op.saveCredential=async value=>{assert.equal(value.title,'b2-backup-key');return original(value);};
  await engine.runProvisioningJob({...f,...deps});assert(values.every(v=>v==='fixture-backup-key'));
});
test('B2 refuses omitted or invalid provider names before reading any login fields', async () => {
  for(const name of [undefined,'Provisioner secret #job-1','space name','a'.repeat(101)]) {
    const f=fixture();delete f.profile.constraints.generatedCredentialName;
    if(name===undefined)delete f.job.payload.generatedCredentialName;else f.job.payload.generatedCredentialName=name;
    repin(f);const events=[];await assert.rejects(engine.runProvisioningJob({...f,...dependencies(events)}),/provider-name-invalid/);assert(!events.includes('read'));
  }
});
test('op adapter reads only explicit fields and sends item secrets through stdin', async () => {
  assert.equal(typeof adapters.createOpAdapter,'function');
  const calls=[];let stored;
  const adapter=await adapters.createOpAdapter({serviceAccountToken:'SYNTHETIC-SERVICE-TOKEN',run:async request=>{
    calls.push(request);
    if(request.args[0]==='read')return request.args[1].endsWith('/username')?'user':'password';
    if(request.args[1]==='create'){stored=JSON.parse(request.input);return JSON.stringify({id:'dddddddddddddddddddddddddd',vault:{id:'cccccccccccccccccccccccccc'}});}
    return JSON.stringify({id:'dddddddddddddddddddddddddd',vault:{id:'cccccccccccccccccccccccccc'},fields:stored.fields});
  }});
  const f=fixture();await adapter.readInputs(f.profile);
  const receipt=await adapter.saveCredential({vault:'cccccccccccccccccccccccccc',title:'b2-backup-key',credential:{keyId:'SYNTHETIC-KEY-ID',applicationKey:'SYNTHETIC-SECRET'}});
  assert.deepEqual(receipt,{itemId:'dddddddddddddddddddddddddd',vaultId:'cccccccccccccccccccccccccc'});
  assert.equal(calls.filter(c=>c.args[0]==='read').length,2);assert(calls.every(c=>c.executable==='/usr/local/bin/op'));
  assert(calls.every(c=>!c.args.join(' ').includes('SYNTHETIC')));assert(calls.some(c=>c.input?.includes('SYNTHETIC-SECRET')));
  assert(calls.every(c=>c.env.OP_SERVICE_ACCOUNT_TOKEN==='SYNTHETIC-SERVICE-TOKEN'));
  assert(calls.every(c=>!('AWS_ACCESS_KEY_ID' in c.env)&&!('NODE_OPTIONS' in c.env)&&!('OP_CONNECT_TOKEN' in c.env)));
  const home=calls[0].env.HOME;await adapter.close();await assert.rejects(readdir(home));
});
test('op adapter verifies saved field values and rejects cross-vault read mappings', async () => {
  const adapter=await adapters.createOpAdapter({serviceAccountToken:'synthetic',run:async r=>JSON.stringify({id:'item',vault:{id:'cccccccccccccccccccccccccc'},fields:[]})});
  try {
    const f=fixture();f.profile.inputFields.password='op://other/item/password';await assert.rejects(adapter.readInputs(f.profile),/input-reference/);
    await assert.rejects(adapter.saveCredential({vault:'cccccccccccccccccccccccccc',title:'key',credential:{keyId:'id',applicationKey:'secret'}}),/op-verification-failed/);
  } finally {await adapter.close();}
});
test('bounded child process discards stderr and never interpolates a shell', async () => {
  assert.equal(typeof adapters.boundedExec,'function');
  assert.equal(await adapters.boundedExec({executable:process.execPath,args:['-e','process.stdout.write(process.argv[1])','$(touch /tmp/provisioner-shell-test)'],env:{},input:'',timeoutMs:2000,maxBytes:4096}),'$(touch /tmp/provisioner-shell-test)');
  await assert.rejects(adapters.boundedExec({executable:process.execPath,args:['-e','process.stderr.write("SECRET");process.exit(1)'],env:{},timeoutMs:2000,maxBytes:4096}),e=>e.message==='op-command-failed');
  await assert.rejects(adapters.boundedExec({executable:process.execPath,args:['-e','process.stdout.write("x".repeat(5000))'],env:{},timeoutMs:2000,maxBytes:1024}),/op-output-limit/);
  await assert.rejects(adapters.boundedExec({executable:process.execPath,args:['-e','setTimeout(()=>{},10000)'],env:{},timeoutMs:20,maxBytes:1024}),/op-timeout/);
});
test('browser launch enables sandbox, isolates env and permits only provider origin', async () => {
  assert.equal(typeof browser.createBrowserFactory,'function');
  const observed={};const handlers={};
  const page={setDefaultTimeout(){},on(){},url:()=> 'https://provider.test/login',goto:async()=>{},locator:()=>({count:async()=>1,fill:async()=>{}})};
  const context={route:async(p,fn)=>{handlers.route=fn;},routeWebSocket:async(p,fn)=>{handlers.socket=fn;},on(){},pages:()=>[page],newPage:async()=>page,close:async()=>{}};
  const chromium={launch:async opts=>{observed.options=opts;return {newContext:async opts=>{observed.context=opts;return context;},close:async()=>{}};}};
  const f=fixture();const instance=await browser.createBrowserFactory({chromium,executablePath:'/usr/bin/chromium'})(f.profile);
  assert.equal(observed.options.chromiumSandbox,true);assert(!observed.options.args.includes('--no-sandbox'));
  assert(!('OP_SERVICE_ACCOUNT_TOKEN' in observed.options.env));assert.equal(observed.context.serviceWorkers,'block');assert.equal(observed.context.acceptDownloads,false);
  let aborted=false,continued=false;
  await handlers.route({request:()=>({url:()=> 'https://evil.test/steal',redirectedFrom:()=>null,resourceType:()=> 'fetch'}),abort:async()=>{aborted=true;},continue:async()=>{continued=true;}});
  assert.equal(aborted,true);assert.equal(continued,false);
  await assert.rejects(instance.perform({action:'goto',url:'loginUrl'},{payload:f.job.payload}),/browser-egress-blocked/);
  await instance.close();
});
test('redirect responses are blocked before following Location, even for same origin', async () => {
  let handler,continued=false,fetchOptions,aborted=false;
  const page={setDefaultTimeout(){},on(){},url:()=> 'about:blank'};
  const context={route:async(p,fn)=>{handler=fn;},routeWebSocket:async()=>{},on(){},newPage:async()=>page,close:async()=>{}};
  const instance=await browser.createBrowserFactory({chromium:{launch:async()=>({newContext:async()=>context,close:async()=>{}})}})(fixture().profile);
  await handler({request:()=>({url:()=> 'https://provider.test/redirect',redirectedFrom:()=>null,resourceType:()=> 'document'}),
    continue:async()=>{continued=true;},fetch:async options=>{fetchOptions=options;return {status:()=>302};},abort:async()=>{aborted=true;}});
  assert.equal(continued,false);assert.equal(fetchOptions.maxRedirects,0);assert.equal(fetchOptions.maxRetries,0);assert.equal(aborted,true);
  await instance.close();
});
test('installed bundle verifier rejects changed runtime files before token retrieval', async () => {
  assert.equal(typeof bundle.verifyInstalledBundle,'function');
  const dir=await mkdtemp(join(tmpdir(),'provisioner-bundle-'));
  try {
    const {mkdir}=await import('node:fs/promises');
    for(const name of bundle.REQUIRED_BUNDLE_FILES){await mkdir(join(dir,name,'..'),{recursive:true});await writeFile(join(dir,name),'synthetic bytes');}
    const files=await bundle.collectBundleFiles(dir),manifest={version:1,files};
    await writeFile(join(dir,'bundle-manifest.json'),JSON.stringify(manifest));
    const codeDigest=digest(stable(manifest));
    assert.equal(await bundle.verifyInstalledBundle({root:dir,codeDigest}),true);
    await writeFile(join(dir,'runner/browser.mjs'),'changed');
    await assert.rejects(bundle.verifyInstalledBundle({root:dir,codeDigest}),/bundle-file-mismatch/);
  } finally {await rm(dir,{recursive:true,force:true});}
});
test('CLI rejects config mismatch without reading credential pipe or starting adapters', async () => {
  assert.equal(typeof cli.runPinnedJob,'function');let read=false;
  await assert.rejects(cli.runPinnedJob({configBytes:'{}',expectedConfigDigest:'wrong',jobBytes:'{}',readToken:async()=>{read=true;return 'synthetic';}}),/config-digest-mismatch/);
  assert.equal(read,false);
});
test('CLI refuses nonaccepted job and unqualified profile before reading token pipe', async () => {
  const f=fixture();f.job.state='accepted';f.profile.manifest.qualified=false;repin(f);
  const configBytes=JSON.stringify({profile:f.profile,codeDigest:'fixture-code-digest',manifestDigest:f.job.context.manifestDigest});let read=false;
  await assert.rejects(cli.runPinnedJob({configBytes,expectedConfigDigest:digest(configBytes),jobBytes:JSON.stringify(f.job),verifyBundle:async()=>true,readToken:async()=>{read=true;return 'synthetic';}}),/manifest-unqualified/);
  assert.equal(read,false);
});
test('optional payload fields resolve trusted defaults and toVault cannot redirect output', async () => {
  const f=fixture();f.profile.constraints.toVault='futuretarget';f.job.payload.toVault='futuretarget';delete f.job.payload.loginUrl;delete f.job.payload.uDomId;delete f.job.payload.pwdDomId;repin(f);
  const deps=dependencies();let effective;
  deps.browserFactory=async()=>({perform:async(s,v)=>{effective=v.payload;},capture:async()=>({keyId:'synthetic-key-id',applicationKey:'SYNTHETIC-PRIVATE-APPLICATION-KEY'}),close:async()=>{}});
  assert.equal((await engine.runProvisioningJob({...f,...deps})).state,'succeeded');assert.equal(effective.loginUrl,f.profile.constraints.loginUrl);assert.equal(f.job.payload.loginUrl,undefined);
});
test('whole Playwright driver runs in isolated UID with bounded private IPC', async () => {
  assert.equal(typeof isolated.createIsolatedBrowserFactory,'function');
  const {EventEmitter}=await import('node:events');let invocation;
  const child=new EventEmitter();child.connected=true;child.kill=()=>{child.connected=false;};child.send=(request,callback)=>{callback?.();queueMicrotask(()=>child.emit('message',{id:request.id,result:request.action==='capture'?{keyId:'synthetic-key-id',applicationKey:'SYNTHETIC-SECRET'}:{ok:true}}));};
  const factory=isolated.createIsolatedBrowserFactory({spawnProcess:(executable,args,options)=>{invocation={executable,args,options};return child;}});
  const session=await factory(fixture().profile);await session.perform({action:'click',selector:'#issue'},{inputs:{password:'SYNTHETIC-PASSWORD'}});
  assert.equal((await session.capture({})).applicationKey,'SYNTHETIC-SECRET');await session.close();
  assert.equal(invocation.executable,'/usr/bin/setpriv');assert(invocation.args.includes('--reuid=10001'));assert.equal(invocation.options.env.OP_SERVICE_ACCOUNT_TOKEN,undefined);
  assert.deepEqual(invocation.options.stdio,['ignore','ignore','ignore','ipc']);assert(!JSON.stringify(invocation).includes('SYNTHETIC'));
});
test('private token reader handles the actual subprocess fd3 pipe without reopening it', async () => {
  assert.equal(typeof cli.readTokenFromFD,'function');
  const {spawn}=await import('node:child_process');
  const script="import {readTokenFromFD} from './runner/run.mjs';const token=await readTokenFromFD();process.stdout.write(token==='synthetic-pipe-token'?'verified':'wrong');";
  const child=spawn(process.execPath,['--input-type=module','-e',script],{stdio:['ignore','pipe','pipe','pipe']});
  let output='',errors='';child.stdout.on('data',chunk=>output+=chunk);child.stderr.on('data',chunk=>errors+=chunk);child.stdio[3].end('synthetic-pipe-token');
  const code=await new Promise(resolve=>child.on('close',resolve));assert.equal(code,0,errors);assert.equal(output,'verified');
});
test('qualified profiles require distinct immutable input/output vault IDs and explicit output title', async () => {
  for(const change of [f=>{f.profile.outputVault='mutable-name';},f=>{f.profile.outputVault='a'.repeat(26);},f=>{delete f.profile.itemTitle;},f=>{f.profile.sourceRecord='op://name/item';}]) {
    const f=fixture();change(f);repin(f);await assert.rejects(engine.runProvisioningJob({...f,...dependencies()}));
  }
});
test('unsupported output item categories fail closed before credential reads', async () => {
  const f=fixture();f.profile.constraints.recordType='Login';f.job.payload.recordType='Login';repin(f);
  await assert.rejects(engine.runProvisioningJob({...f,...dependencies()}),/record-type-disabled/);
});
test('preflight rejection closes an already-created credential adapter', async () => {
  const f=fixture();f.job.payloadHash='invalid';const events=[];
  await assert.rejects(engine.runProvisioningJob({...f,...dependencies(events)}));assert.deepEqual(events,['op-close']);
});
test('generic v2 provider preserves email-first sequence, named capture and approved output fields', async () => {
  const f=genericFixture(),deps=dependencies(),steps=[];let saved;
  deps.browserFactory=async()=>({perform:async(step,values)=>{steps.push(step);assert.equal(values.credentialName,'Provisioner secret #job-1');},
    capture:async()=>({apiToken:'SYNTHETIC-GENERIC-TOKEN'}),close:async()=>{}});
  deps.op.saveCredential=async value=>{saved=value;return {itemId:'d'.repeat(26),vaultId:'c'.repeat(26)};};
  assert.equal((await engine.runProvisioningJob({...f,...deps})).state,'succeeded');
  assert.deepEqual(steps.slice(1,5).map(s=>[s.action,s.locator]),[['fill','email'],['click','next'],['wait','password'],['fill','password']]);
  assert.deepEqual(saved.credential,{apiToken:'SYNTHETIC-GENERIC-TOKEN'});assert.deepEqual(saved.outputFields,f.profile.outputFields);
  assert.doesNotThrow(()=>authorizer.validatePayload(f.job.payload,f.profile));
});
test('unreviewed, null, unknown or executable locators fail before any credential read', async () => {
  for(const invalid of [null,{kind:'xpath',value:'//input'},{kind:'css',value:'xpath=//input'},
    {kind:'css',value:'#x >> text=Secret'},{kind:'role',role:'button',name:'.*',regex:true},{kind:'css',value:'button:has-text("Create")'}]) {
    const f=genericFixture();f.profile.manifest.locators.password=invalid;repin(f);const events=[];
    await assert.rejects(engine.runProvisioningJob({...f,...dependencies(events)}),/manifest-locator/);assert(!events.includes('read'));
  }
  const f=genericFixture();f.profile.manifest.submit.locator='unreviewed';repin(f);
  await assert.rejects(engine.runProvisioningJob({...f,...dependencies()}),/manifest-locator/);
});
test('generic output schema must account for every capture and conceal at least one field', async () => {
  for(const change of [f=>{delete f.profile.outputFields;},f=>{f.profile.outputFields[0].capture='wrong';},f=>{f.profile.outputFields[0].type='STRING';},f=>{f.profile.outputFields.push({...f.profile.outputFields[0]});}]) {
    const f=genericFixture();change(f);repin(f);await assert.rejects(engine.runProvisioningJob({...f,...dependencies()}),/output-fields-invalid/);
  }
});
test('generic provider name policy is explicit and authorizer agrees with runner', async () => {
  const f=genericFixture();f.profile.namePolicy={allowedCharacters:'alphanumeric-hyphen',maxLength:20};repin(f);
  await assert.rejects(engine.runProvisioningJob({...f,...dependencies()}),/provider-name-invalid/);assert.throws(()=>authorizer.validatePayload(f.job.payload,f.profile));
  f.job.payload.generatedCredentialName='approved-token';repin(f);
  assert.doesNotThrow(()=>engine.validateJobProfile({...f,codeDigest:'fixture-code-digest'}));assert.doesNotThrow(()=>authorizer.validatePayload(f.job.payload,f.profile));
});
test('op adapter stores generic capture fields through stdin and verifies them privately', async () => {
  let stored;const adapter=await adapters.createOpAdapter({serviceAccountToken:'synthetic',run:async request=>{
    if(request.args[1]==='create')stored=JSON.parse(request.input);
    return JSON.stringify({id:'d'.repeat(26),vault:{id:'c'.repeat(26)},fields:stored.fields});
  }});
  try {
    const receipt=await adapter.saveCredential({vault:'c'.repeat(26),title:'example-token',credential:{apiToken:'SYNTHETIC-GENERIC-TOKEN'},outputFields:genericFixture().profile.outputFields});
    assert.equal(receipt.itemId,'d'.repeat(26));assert.deepEqual(stored.fields,[{id:'api_token',label:'API token',type:'CONCEALED',value:'SYNTHETIC-GENERIC-TOKEN'}]);
  } finally {await adapter.close();}
});
test('browser resolves approved CSS, role and label locators and waits for email-first fields', async () => {
  let phase='email';const observed=[];const target=(kind,value,options)=>({
    count:async()=>1,waitFor:async()=>{if(value==='Password'&&phase!=='password')throw Error('password-not-ready');},
    getAttribute:async()=>value.includes('email')?'email-field':value==='Password'?'password':null,
    fill:async text=>{if(value==='Password'&&phase!=='password')throw Error('wrong-order');observed.push([kind,value,options,text]);},
    click:async()=>{if(value==='Next')phase='password';observed.push([kind,value,options]);}
  });
  const page={setDefaultTimeout(){},on(){},url:()=> 'https://provider.test/login',goto:async()=>{},
    locator:value=>target('css',value),getByRole:(role,options)=>target(role,options.name,options),getByLabel:(value,options)=>target('label',value,options)};
  const context={route:async()=>{},routeWebSocket:async()=>{},on(){},newPage:async()=>page,close:async()=>{}};
  const f=genericFixture();const session=await browser.createBrowserFactory({chromium:{launch:async()=>({newContext:async()=>context,close:async()=>{}})}})(f.profile);
  try {for(const step of f.profile.manifest.login)await session.perform(step,{payload:f.job.payload,inputs:{username:'synthetic-user',password:'synthetic-password'}});}
  finally {await session.close();}
  assert.equal(phase,'password');assert(observed.some(([kind,value,options])=>kind==='button'&&value==='Next'&&options.exact===true));
  assert(observed.some(([kind,value,options])=>kind==='label'&&value==='Password'&&options.exact===true));
  assert(observed.some(([kind,value])=>kind==='css'&&value==='css=input[name="email-field"]'));
});
test('sandboxed Chromium executes the synthetic B2 form without live provider access', async t => {
  const {chromium}=await import('../runner/node_modules/playwright-core/index.mjs');
  let launched;
  try {launched=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,chromiumSandbox:true});}
  catch(error) {
    if(process.env.PROVISIONER_REQUIRE_BROWSER==='1')throw error;
    if(/sandbox helper|Failed to move to new namespace|No usable sandbox/.test(error.message)){t.skip('Host Chromium sandbox unavailable; PROVISIONER_REQUIRE_BROWSER=1 makes this a required check.');return;}
    throw error;
  }
  const html=await readFile(new URL('../runner/fixtures/b2.html',import.meta.url),'utf8');
  const observed=[];
  const syntheticChromium={launch:async()=>({close:()=>launched.close(),newContext:async options=>{
    const context=await launched.newContext(options),realRoute=context.route.bind(context);
    context.route=async(pattern,handler)=>realRoute(pattern,route=>handler({request:()=>route.request(),abort:code=>route.abort(code),
      fetch:async options=>{assert.equal(options.maxRedirects,0);observed.push(route.request().url());return {status:()=>200,dispose:async()=>{}};},
      fulfill:async()=>route.fulfill({contentType:'text/html',body:html})}));
    return context;
  }})};
  const deps=dependencies();deps.browserFactory=browser.createBrowserFactory({chromium:syntheticChromium,executablePath:'/usr/bin/chromium'});
  const result=await engine.runProvisioningJob({...fixture(),...deps});
  assert.equal(result.state,'succeeded');assert(observed.length>=2);assert(observed.every(url=>new URL(url).origin==='https://provider.test'));
});
test('runner supports all 32 admitted permission fields without silently dropping any',()=>{
 const f=fixture();f.profile.constraints.permissions=Array.from({length:32},(_,i)=>({fieldDomId:'permission'+i,value:'fixture'}));f.job.payload.permissions=f.profile.constraints.permissions;f.profile.manifest.prepare=[{action:'fill',selector:'#name',value:'credentialName'},...f.profile.constraints.permissions.map(p=>({action:'fill',selector:'#'+p.fieldDomId,permission:p.fieldDomId}))];repin(f);
 assert.doesNotThrow(()=>engine.validateJobProfile({...f,codeDigest:'fixture-code-digest'}));
});
