import base64
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import struct
import subprocess
import sys
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch, Mock

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'signer/native'))
from protocol import HostSession, validate_config, strict_json, b64url, HostError
from framing import encode_frame, read_frame
import protocol

# Public RFC6979 P-256 test vector, never a live enrolled key.
PUBLIC=bytes.fromhex('04'+'60fed4ba255a9d31c961eb74c6356d68c049b8923b61fa6ce669622e60f29fb6'+'7903fe1008b8bc99a41ae9e95628bc64f2f1b20c2d7e9f5177a3c294d4462299')
KEY=hashlib.sha256(PUBLIC).hexdigest()
PROFILE=b64url(bytes(range(32)))
NOW=1900000000
def config():
    return dict(version=1,extensionId='a'*32,ownerOrigin='https://control.vespoli.me',audience='https://private.vespoli.me',keyId=KEY,publicKeyX963=b64url(PUBLIC),serial=123456,slot='9c',profileDigests=[PROFILE],pinentryPath='/usr/bin/pinentry-qt',pinentrySha256='1'*64)
def request(action='hello',number=1,**fields):
    return dict(version=1,id=f'00000000-0000-4000-8000-{number:012d}',action=action,origin=config()['ownerOrigin'],keyId=KEY,**fields)
def auth(number=2,request_number=20,**changes):
    parts=['provisioner.auth-request.v1',f'00000000-0000-4000-8000-{request_number:012d}',NOW,config()['audience'],KEY,PROFILE,b64url(b'p'*32)]
    parts[changes.get('index',0)]=changes.get('value',parts[changes.get('index',0)])
    return request('sign',number,purpose='provisioner.auth-request.v1',bytes=b64url(json.dumps(parts,separators=(',',':')).encode()))
def nonce(number=3):
    return request('sign',number,purpose='provisioner.nonce.v1',bytes=b64url(b64url(b'n'*32).encode()))
class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.clock=patch('protocol.time.time',return_value=NOW);self.clock.start();self.addCleanup(self.clock.stop)
        self.hardware=patch('protocol.bounded_sign',return_value=b's'*64);self.sign=self.hardware.start();self.addCleanup(self.hardware.stop)
        self.host=HostSession(config(),'chrome-extension://'+'a'*32+'/')
    def test_hello_uses_no_hardware(self):
        self.assertEqual(self.host.handle(request()),dict(version=1,id=request()['id'],ok=True,keyId=KEY));self.sign.assert_not_called()
    def test_two_exact_messages_in_order_and_single_nonce(self):
        a=auth();n=nonce();self.assertTrue(self.host.handle(a)['ok']);self.assertTrue(self.host.handle(n)['ok'])
        self.assertEqual([c.args[1] for c in self.sign.call_args_list],[base64.urlsafe_b64decode(a['bytes']+'=='),base64.urlsafe_b64decode(n['bytes']+'==')])
        self.assertEqual(self.host.handle(nonce(4))['error'],'approval-order-invalid')
    def test_no_pending_nonce_or_second_auth(self):
        self.assertEqual(self.host.handle(nonce())['error'],'approval-order-invalid')
        self.assertTrue(self.host.handle(auth())['ok'])
        self.assertEqual(self.host.handle(auth(4,21))['error'],'approval-order-invalid');self.assertEqual(self.sign.call_count,1)
    def test_auth_context_drift_and_old_timestamp_reject_before_hardware(self):
        for i,value in [(0,'arbitrary.sign'),(1,'bad-id'),(2,NOW-31),(3,'https://other.vespoli.me'),(4,'f'*64),(5,b64url(b'z'*32)),(6,'invalid')]:
            with self.subTest(index=i):
                host=HostSession(config(),'chrome-extension://'+'a'*32+'/');self.assertFalse(host.handle(auth(index=i,value=value))['ok'])
        self.sign.assert_not_called()
    def test_strict_fields_and_origins(self):
        for mutation in [dict(pin='forbidden'),dict(origin='https://evil.test'),dict(keyId='f'*64),dict(version=True),dict(id='not-uuid'),dict(action='export')]:
            with self.subTest(mutation=mutation):
                host=HostSession(config(),'chrome-extension://'+'a'*32+'/');r=request();r.update(mutation);self.assertFalse(host.handle(r)['ok'])
        with self.assertRaises(HostError):HostSession(config(),'chrome-extension://'+'b'*32+'/')
        self.sign.assert_not_called()
    def test_nonce_consumed_before_decline_and_pending_expiry(self):
        self.host.handle(auth());self.sign.side_effect=HostError('signer-declined')
        self.assertEqual(self.host.handle(nonce())['error'],'signer-declined');self.assertEqual(self.host.handle(nonce(4))['error'],'approval-order-invalid')
        self.sign.side_effect=None;self.host.handle(auth(5,22))
        with patch('protocol.time.time',return_value=NOW+121):self.assertEqual(self.host.handle(nonce(6))['error'],'approval-expired')
    def test_signature_response_size_and_errors_are_fixed(self):
        self.sign.return_value=b'bad';self.assertEqual(self.host.handle(auth())['error'],'invalid-signer-response')
        self.sign.side_effect=RuntimeError('SECRET diagnostics');response=self.host.handle(auth(4,21));self.assertEqual(response['error'],'signer-unavailable');self.assertNotIn('SECRET',json.dumps(response))
    def test_noncanonical_payload_duplicate_json_and_nonce_encoding_rejected(self):
        with self.assertRaises(HostError):strict_json(b'{"version":1,"version":1}')
        with self.assertRaises(HostError):strict_json(b'{"n":NaN}')
        a=auth();a['bytes']=b64url(base64.urlsafe_b64decode(a['bytes']+'==')+b' ');self.assertFalse(self.host.handle(a)['ok'])
        self.assertTrue(self.host.handle(auth(4,21))['ok']);n=nonce(5);n['bytes']=b64url(b'n'*32);self.assertFalse(self.host.handle(n)['ok'])
    def test_pinned_public_key_config_and_extra_fields(self):
        self.assertEqual(validate_config(config()),config())
        for mutation in [dict(keyId='0'*64),dict(publicKeyX963=b64url(b'\x04'+b'\0'*64)),dict(slot='9a'),dict(pin='123456'),dict(profileDigests=[PROFILE,PROFILE])]:
            c=config();c.update(mutation)
            with self.assertRaises(HostError):validate_config(c)

class FramingTests(unittest.TestCase):
    def test_native_endian_length_and_exact_utf8_json(self):
        data=encode_frame(request());self.assertEqual(struct.unpack('=I',data[:4])[0],len(data)-4);self.assertEqual(read_frame(io.BytesIO(data)),request())
    def test_oversize_truncated_duplicate_and_extra_bytes(self):
        for data in [struct.pack('=I',8193),b'\x00',struct.pack('=I',2)+b'{',struct.pack('=I',7)+b'{"a":1}']:
            if data.endswith(b'{"a":1}'):continue
            with self.assertRaises(HostError):read_frame(io.BytesIO(data))
        with self.assertRaises(HostError):read_frame(io.BytesIO(struct.pack('=I',13)+b'{"a":1,"a":2}'))

class HardwareTests(unittest.TestCase):
    def setUp(self):
        from cryptography.hazmat.primitives.asymmetric import ec, utils
        # RFC6979 published signature for SHA256("sample"). No private key or signing.
        self.r=int('efd48b2aacb6a8fd1140dd9cd45e81d69d2c877b56aaf991c34d0ea84eaf3716',16)
        self.s=int('f7cb1c942d657c41d436c7a1b6e29f65f3e900dbb9aff4064dc4ab2f843acda8',16)
        self.metadata=SimpleNamespace(key_type=17,generated=True,pin_policy=3,touch_policy=2,public_key=ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(),PUBLIC))
        self.session=Mock();self.session.get_slot_metadata.return_value=self.metadata
        self.session.sign.return_value=utils.encode_dss_signature(self.r,self.s)
        self.connection=Mock();self.connection.__enter__=Mock(return_value=self.connection);self.connection.__exit__=Mock(return_value=False)
        self.device=Mock();self.device.open_connection.return_value=self.connection
        self.devices=Mock(return_value=[(self.device,SimpleNamespace(serial=123456))])
        modules={'ykman.device':SimpleNamespace(list_all_devices=self.devices),
          'yubikit.core.smartcard':SimpleNamespace(SmartCardConnection='smartcard'),
          'yubikit.piv':SimpleNamespace(PivSession=Mock(return_value=self.session),SLOT=SimpleNamespace(SIGNATURE=156),KEY_TYPE=SimpleNamespace(ECCP256=17),PIN_POLICY=SimpleNamespace(ALWAYS=3),TOUCH_POLICY=SimpleNamespace(ALWAYS=2))}
        p=patch.dict(sys.modules,modules);p.start();self.addCleanup(p.stop)
        self.pin=bytearray(b'123456')
        p=patch('protocol._pinentry',return_value=self.pin);self.prompt=p.start();self.addCleanup(p.stop)
    def test_existing_exact_hardware_key_and_rfc_signature(self):
        signature=protocol.hardware_sign(config(),b'sample')
        self.assertEqual(signature,self.r.to_bytes(32,'big')+self.s.to_bytes(32,'big'))
        self.assertEqual(self.session.sign.call_args.args[:3],(156,17,b'sample'))
        self.assertEqual(self.session.verify_pin.call_count,1);self.assertEqual(self.pin,bytearray(6))
    def test_wrong_metadata_serial_or_public_key_never_prompts(self):
        for field,value in [('generated',False),('key_type',20),('pin_policy',2),('touch_policy',3),('public_key',object())]:
            with self.subTest(field=field):
                previous=getattr(self.metadata,field);setattr(self.metadata,field,value)
                with self.assertRaises(HostError):protocol.hardware_sign(config(),b'sample')
                setattr(self.metadata,field,previous)
        self.devices.return_value=[]
        with self.assertRaises(HostError):protocol.hardware_sign(config(),b'sample')
        self.prompt.assert_not_called();self.session.verify_pin.assert_not_called();self.session.sign.assert_not_called()
    def test_pin_decline_is_once_pin_buffer_cleared_and_never_signs(self):
        self.session.verify_pin.side_effect=RuntimeError('private diagnostics')
        with self.assertRaisesRegex(HostError,'signer-declined'):protocol.hardware_sign(config(),b'sample')
        self.assertEqual(self.session.verify_pin.call_count,1);self.session.sign.assert_not_called();self.assertEqual(self.pin,bytearray(6))
    def test_wrong_message_signature_is_not_returned(self):
        with self.assertRaisesRegex(HostError,'invalid-signer-response'):protocol.hardware_sign(config(),b'other')

class ProcessTests(unittest.TestCase):
    def test_failed_watchdog_creation_never_releases_hardware(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]/'signer') as directory:
            touched=Path(directory)/'hardware';original_fork=os.fork;calls=0
            def fork():
                nonlocal calls
                calls+=1
                if calls==2:raise OSError('synthetic fork failure')
                return original_fork()
            def synthetic(*_):touched.write_text('unexpected');return b's'*64
            with patch('protocol.os.fork',side_effect=fork),patch('protocol.hardware_sign',side_effect=synthetic):
                with self.assertRaises(OSError):protocol.bounded_sign(config(),b'sample')
            self.assertFalse(touched.exists())
    def test_hardware_waits_for_watchdog_readiness(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]/'signer') as directory:
            waiting=Path(directory)/'waiting';touched=Path(directory)/'hardware'
            source=Path(__file__).resolve().parents[1]/'signer/native'
            code='\n'.join(['import sys,os,time',f'sys.path.insert(0,{str(source)!r})','import protocol','original_fork=os.fork','calls=0',
              'def fork():','    global calls','    calls+=1','    if calls==2:',f'        open({str(waiting)!r},"w").write("ready")','        time.sleep(5)','    return original_fork()',
              'def synthetic(*args):',f'    open({str(touched)!r},"w").write("unexpected")','    return b"s"*64',
              'protocol.os.fork=fork','protocol.hardware_sign=synthetic',f'protocol.bounded_sign({config()!r},b"sample")'])
            parent=subprocess.Popen([sys.executable,'-B','-I','-c',code],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            try:
                for _ in range(100):
                    if waiting.exists():break
                    time.sleep(.01)
                self.assertTrue(waiting.exists());parent.kill();parent.wait(timeout=1);time.sleep(.05)
                self.assertFalse(touched.exists())
            finally:
                if parent.poll() is None:parent.kill();parent.wait()
                parent.stdout.close();parent.stderr.close()
    def test_bounded_worker_returns_only_signature_or_static_error(self):
        with patch('protocol.hardware_sign',return_value=b's'*64):self.assertEqual(protocol.bounded_sign(config(),b'sample'),b's'*64)
        with patch('protocol.hardware_sign',side_effect=RuntimeError('SECRET')):
            with self.assertRaisesRegex(HostError,'^signer-unavailable$'):protocol.bounded_sign(config(),b'sample')
    def test_timeout_and_disconnection_cancel_child(self):
        def wait(*_):time.sleep(5)
        with patch('protocol.hardware_sign',side_effect=wait),patch('protocol.SIGN_TIMEOUT',.1):
            start=time.monotonic()
            with self.assertRaisesRegex(HostError,'signer-timeout'):protocol.bounded_sign(config(),b'sample')
            self.assertLess(time.monotonic()-start,1)
        read_fd,write_fd=os.pipe();os.close(write_fd)
        try:
            with patch('protocol.hardware_sign',side_effect=wait),patch('protocol.transport_fd',read_fd):
                with self.assertRaisesRegex(HostError,'native-disconnected'):protocol.bounded_sign(config(),b'sample')
        finally:os.close(read_fd)
    def test_parent_death_cancels_worker_and_helper(self):
        self._parent_death(False)
        self._parent_death(True)
    def _parent_death(self,kill_group):
        # Real pipes/processes, synthetic sleeper only. Never imports a hardware SDK.
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]/'signer') as directory:
            marker=Path(directory)/'pids'
            source=Path(__file__).resolve().parents[1]/'signer/native'
            code='\n'.join(['import sys,os,time,subprocess,json',f'sys.path.insert(0,{str(source)!r})','import protocol',
              'def synthetic(*args):',"    child=subprocess.Popen(['/bin/sleep','5'])",f'    open({str(marker)!r},"w").write(str(os.getpid())+" "+str(child.pid))','    time.sleep(5)',
              'protocol.hardware_sign=synthetic',f'protocol.bounded_sign({config()!r},b"sample")'])
            parent=subprocess.Popen([sys.executable,'-B','-I','-c',code],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
            pids=[]
            try:
                for _ in range(100):
                    if marker.exists():
                        pids=[int(n) for n in marker.read_text().split()]
                        if len(pids)==2:break
                    time.sleep(.01)
                self.assertEqual(len(pids),2)
                if kill_group:os.killpg(parent.pid,signal.SIGKILL)
                else:parent.kill()
                parent.wait(timeout=1)
                # A zombie has exited and no longer holds a hardware/PIN operation.
                def alive(pid):
                    try:
                        status=Path(f'/proc/{pid}/stat')
                        if status.exists():return status.read_text().split()[2]!='Z'
                        os.kill(pid,0);return True
                    except ProcessLookupError:return False
                for _ in range(100):
                    if not any(alive(pid) for pid in pids):break
                    time.sleep(.01)
                self.assertFalse(any(alive(pid) for pid in pids))
            finally:
                if parent.poll() is None:parent.kill();parent.wait()
                parent.stdout.close();parent.stderr.close()
                if pids:
                    try:os.killpg(pids[0],signal.SIGKILL)
                    except ProcessLookupError:pass

class PinentryTests(unittest.TestCase):
    def setUp(self):
        self.directory=tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parents[1]/'signer');self.addCleanup(self.directory.cleanup)
        self.path=Path(self.directory.name)/'pinentry-qt'
        self.marker=Path(self.directory.name)/'process'
    def fixture(self,reply='print("D 123456");print("OK")',startup=''):
        source='\n'.join(['#!/usr/bin/python3','import sys,os,time,json',f'open({str(self.marker)!r},"w").write(json.dumps({{"pid":os.getpid(),"env":sorted(os.environ),"argv":sys.argv}}))',startup,'print("OK ready",flush=True)','for line in sys.stdin:',
          '    if line.strip()=="GETPIN":','        '+reply,'    else:print("OK")','    sys.stdout.flush()',''])
        self.path.write_text(source);self.path.chmod(0o700)
        return dict(config(),pinentryPath=str(self.path),pinentrySha256=hashlib.sha256(source.encode()).hexdigest())
    def test_pinned_private_pipe_gui_fixture_no_secret_env_or_arguments(self):
        c=self.fixture()
        with patch.dict(os.environ,{'SYNTHETIC_SECRET_TOKEN':'never forward','LD_PRELOAD':'not-forwarded'}):pin=protocol._pinentry(c,b'sample')
        self.assertEqual(pin,bytearray(b'123456'))
        marker=json.loads(self.marker.read_text());self.assertNotIn('SYNTHETIC_SECRET_TOKEN',marker['env']);self.assertNotIn('LD_PRELOAD',marker['env']);self.assertEqual(marker['argv'],[str(self.path)])
        with self.assertRaises(ProcessLookupError):os.kill(marker['pid'],0)
    def test_decline_does_not_retry_and_exits_helper(self):
        c=self.fixture('print("ERR 83886179 canceled")')
        with self.assertRaisesRegex(HostError,'signer-declined'):protocol._pinentry(c,b'sample')
        with self.assertRaises(ProcessLookupError):os.kill(json.loads(self.marker.read_text())['pid'],0)
    def test_timeout_reaps_helper(self):
        c=self.fixture(startup='time.sleep(5)')
        with patch('protocol.PIN_TIMEOUT',.1):
            with self.assertRaisesRegex(HostError,'signer-timeout'):protocol._pinentry(c,b'sample')
        with self.assertRaises(ProcessLookupError):os.kill(json.loads(self.marker.read_text())['pid'],0)
    def test_hash_mismatch_or_unsafe_mode_never_starts_process(self):
        c=self.fixture();c['pinentrySha256']='0'*64
        with self.assertRaises(HostError):protocol._pinentry(c,b'sample')
        self.assertFalse(self.marker.exists())
        c=self.fixture();self.path.chmod(0o777)
        with self.assertRaises(HostError):protocol._pinentry(c,b'sample')
        self.assertFalse(self.marker.exists())
    def test_malformed_pin_and_assuan_inquire_are_rejected(self):
        for reply in ['print("D 123%ZZ");print("OK")','print("INQUIRE SECRET")','print("D 123%0a456");print("OK")']:
            with self.subTest(reply=reply):
                with self.assertRaises(HostError):protocol._pinentry(self.fixture(reply),b'sample')

if __name__=='__main__':unittest.main()
