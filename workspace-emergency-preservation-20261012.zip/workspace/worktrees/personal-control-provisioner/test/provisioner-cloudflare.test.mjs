import test from 'node:test';
import assert from 'node:assert/strict';
import {createHash,createHmac} from 'node:crypto';
const api=await import('../infra/provisioner/launcher.mjs');
const hash=value=>createHash('sha256').update(value).digest('base64url');
const canon=value=>JSON.stringify(value,(_,v)=>v&&Object.getPrototypeOf(v)===Object.prototype?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
const fixed=1900000000000,key='synthetic-machine-key-at-least-32-characters';
function fixture(){
 const profile={id:'fixture',manifest:{version:1,qualified:true},allowedOrigins:['https://console.example.test'],recovery:{destination:'r2://recovery/capture/',encryptionKeyId:'recovery-key'},kv:{destination:'cloudflare-kv://output/ciphertext/',encryptionKeyId:'output-key'}};
 const runnerConfig={codeDigest:hash('reviewed code'),platform:{provider:'cloudflare-containers',qualified:true,qualificationDigest:hash('fixture-qualification')},infrastructure:{transport:'cloudflare-bindings-v1',opOrigins:['https://vault.1password.com'],recovery:{destination:profile.recovery.destination,keyId:'recovery-key',fingerprint:hash('recovery-key'),publicKeyPem:'synthetic-public-key'},kv:{destination:profile.kv.destination,keyId:'output-key',fingerprint:hash('output-key'),publicKeyPem:'synthetic-output-key'}}};
 const config={owner:'owner@example.test',audience:'provisioner',admissionAudience:'https://private.example.test',approvedProfileDigests:[hash(canon(profile))],codeDigest:runnerConfig.codeDigest,deadlineSeconds:300,qualified:true,schedulingPolicy:'default',imageDigest:'sha256:'+'a'.repeat(64),runnerConfig,baseConfigSha256:hash(canon(runnerConfig))};
 const rawPayload='{"operation":"generate-api-key","KV":false}',job={id:'fixture-job-001',owner:config.owner,state:'accepted',rawPayload,payload:JSON.parse(rawPayload),payloadHash:hash(rawPayload),context:{profileId:profile.id,profileDigest:hash(canon(profile)),codeDigest:config.codeDigest,manifestDigest:hash(canon(profile.manifest)),audience:config.admissionAudience}};
 const records=new Map(),events=[],starts=[],requests=[],objects=new Map();let time=fixed,queue=Promise.resolve();
 const storage={async get(k){return structuredClone(records.get(k));},async put(k,v){records.set(k,structuredClone(v));},async setAlarm(t){events.push(['alarm',t]);},async deleteAlarm(){events.push(['deleteAlarm']);},transaction(fn){const p=queue.then(()=>fn(storage));queue=p.catch(()=>{});return p;}};
 const container={running:false,start(options){events.push(['start']);starts.push(options);this.running=true;},async inspect(){return this.running?{image:'registry.invalid/image@'+config.imageDigest,labels:{}}:null;},async destroy(){events.push(['destroy']);this.running=false;},monitor(){return new Promise(()=>{});},async setInactivityTimeout(){},async interceptOutboundHttp(host){events.push(['http',host]);},async interceptOutboundHttps(host){events.push(['https',host]);},getTcpPort(port){assert.equal(port,8080);return {fetch:async(url,options)=>{requests.push({url,options});return new Response('{}',{status:options?.method==='POST'?202:200});}};}};
 const bucket={async put(k,v,opts){assert.equal(opts.onlyIf.etagDoesNotMatch,'*');if(objects.has(k))return null;objects.set(k,v);return {key:k};},async get(k){return objects.has(k)?{text:async()=>objects.get(k)}:null;}};
 const options={storage,container,config,containerId:'fixture-container',machineKey:()=>key,serviceToken:()=> 'synthetic-op-token',interceptor:props=>({props}),waitUntil:()=>{},recovery:bucket,output:{async put(){},async get(){return null;}},now:()=>time,sleep:async()=>{}};
 const envelope=(nonce='nonce-fixture-001')=>({version:1,audience:config.audience,sentAt:time,nonce,job:structuredClone(job),profile:structuredClone(profile)});
 return {options,config,job,profile,records,events,starts,requests,objects,container,envelope,setTime:v=>time=v};
}
test('Cloudflare control exposes durable lifecycle and unchanged envelope authentication',()=>{
 assert.equal(typeof api.createJobController,'function');const f=fixture(),raw=JSON.stringify(f.envelope()),signature=createHmac('sha256',key).update(raw).digest('base64url');
 assert.deepEqual(api.verifyEnvelope({raw,signature,key,audience:f.config.audience,now:fixed}),f.envelope());
 for(const changes of [{raw:raw+' '},{signature:'bad'},{now:fixed+61000},{audience:'other'}])assert.throws(()=>api.verifyEnvelope({raw,signature,key,audience:f.config.audience,now:fixed,...changes}));
});
test('one immutable reservation installs exact intercepts before one private container start',async()=>{
 assert.equal(typeof api.createJobController,'function');const f=fixture(),c=api.createJobController(f.options);
 const results=await Promise.all(Array.from({length:8},(_,i)=>c.dispatch(f.envelope('nonce-fixture-'+i))));
 assert.ok(results.every(r=>['launching','running'].includes(r.state)));assert.equal(f.starts.length,1);assert.deepEqual(f.starts[0],{enableInternet:false});
 assert.ok(f.events.findIndex(x=>x[0]==='alarm')<f.events.findIndex(x=>x[0]==='start'));assert.ok(f.events.findIndex(x=>x[0]==='https'&&x[1]==='provisioner.internal')<f.events.findIndex(x=>x[0]==='start'));
 const body=JSON.parse(f.requests.find(x=>x.options?.method==='POST').options.body);assert.equal(body.job.id,f.job.id);assert.equal(body.serviceAccountToken,'synthetic-op-token');assert.match(body.callbackToken,/^[A-Za-z0-9_-]{43}$/);
 assert.equal(JSON.stringify([...f.records]).includes('synthetic-op-token'),false);assert.equal(JSON.stringify([...f.records]).includes(body.callbackToken),false);
 await assert.rejects(c.dispatch(f.envelope('nonce-fixture-0')),/replay/);assert.equal(f.starts.length,1);
});
test('unqualified configuration, changed bytes and immutable job reuse fail before start',async()=>{
 assert.equal(typeof api.createJobController,'function');for(const change of [f=>f.config.qualified=false,f=>f.config.schedulingPolicy='durable_object',f=>f.job.rawPayload+=' ',f=>f.job.context.codeDigest='other',f=>f.profile.allowedOrigins=['https://evil.example.test']]){const f=fixture();change(f);await assert.rejects(api.createJobController(f.options).dispatch(f.envelope()));assert.equal(f.starts.length,0);}
 const f=fixture(),c=api.createJobController(f.options);await c.dispatch(f.envelope());f.job.rawPayload='{"KV":false,"operation":"generate-api-key"}';f.job.payloadHash=hash(f.job.rawPayload);await assert.rejects(c.dispatch(f.envelope('nonce-fixture-new')),/immutable/);assert.equal(f.starts.length,1);
});
test('ambiguous container submission is never started or submitted again after eviction',async()=>{
 assert.equal(typeof api.createJobController,'function');const f=fixture();f.container.getTcpPort=()=>({fetch:async(url,opts)=>{if(opts?.method==='POST'){f.requests.push(opts);throw Error('secret network detail');}return new Response('{}');}});
 assert.equal((await api.createJobController(f.options).dispatch(f.envelope())).state,'uncertain');assert.equal((await api.createJobController(f.options).dispatch(f.envelope('nonce-after-eviction'))).state,'uncertain');assert.equal(f.starts.length,1);assert.equal(f.requests.length,1);
});
test('private mutation reservation is single use and rejects missing token or wrong container identity',async()=>{
 assert.equal(typeof api.createJobController,'function');const f=fixture(),c=api.createJobController(f.options);await c.dispatch(f.envelope());const body=JSON.parse(f.requests.find(x=>x.options?.method==='POST').options.body),record=f.records.get('job');
 const props={jobId:f.job.id,containerId:'fixture-container',identity:record.identity},invoke=(auth='Bearer '+body.callbackToken,p=props)=>c.callback('/v1/journal/reserve',{jobId:f.job.id,payloadHash:f.job.payloadHash},auth,p);
 await assert.rejects(invoke('Bearer invalid'));await assert.rejects(invoke(undefined,{...props,containerId:'foreign'}));assert.deepEqual(await invoke(),{reserved:true});assert.deepEqual(await invoke(),{reserved:false});
});
test('deadline destroys independently and reserved mutation remains uncertain without relaunch',async()=>{
 assert.equal(typeof api.createJobController,'function');const f=fixture(),c=api.createJobController(f.options);await c.dispatch(f.envelope());const body=JSON.parse(f.requests.find(x=>x.options?.method==='POST').options.body),record=f.records.get('job');
 await c.callback('/v1/journal/reserve',{jobId:f.job.id,payloadHash:f.job.payloadHash},'Bearer '+body.callbackToken,{jobId:f.job.id,containerId:'fixture-container',identity:record.identity});f.setTime(fixed+301000);await api.createJobController(f.options).alarm();assert.equal(f.container.running,false);assert.equal((await c.status()).state,'uncertain');assert.equal(f.starts.length,1);
});
test('encrypted recovery is immutable and receipt survives uncertain cleanup without false success',async()=>{
 const f=fixture(),c=api.createJobController(f.options);await c.dispatch(f.envelope());const start=JSON.parse(f.requests.find(x=>x.options?.method==='POST').options.body),record=f.records.get('job'),props={jobId:f.job.id,containerId:'fixture-container',identity:record.identity};
 const call=(path,data)=>c.callback(path,{jobId:f.job.id,payloadHash:f.job.payloadHash,...data},'Bearer '+start.callbackToken,props);
 await call('/v1/journal/reserve',{});
 const e={version:1,algorithm:'RSA-OAEP-256+A256GCM',keyId:'recovery-key',fingerprint:hash('recovery-key'),context:{jobId:f.job.id,payloadHash:f.job.payloadHash,purpose:'recovery'},encryptedDataKey:Buffer.alloc(384,1).toString('base64'),iv:Buffer.alloc(12,2).toString('base64'),tag:Buffer.alloc(16,3).toString('base64'),ciphertext:Buffer.from('synthetic encrypted bytes').toString('base64')};
 const envelope=canon(e),capture=await call('/v1/recovery',{envelope,digest:hash(envelope)});assert.equal(capture.id,f.profile.recovery.destination+f.job.id+'.json');
 await assert.rejects(call('/v1/recovery',{envelope:canon({...e,iv:Buffer.alloc(12,4).toString('base64')}),digest:hash(canon({...e,iv:Buffer.alloc(12,4).toString('base64')}))}),/collision/);
 await call('/v1/journal/update',{state:'captured',receipt:{recoveryId:capture.id}});await call('/v1/journal/update',{state:'vault-saved',receipt:{itemId:'a'.repeat(26),vaultId:'b'.repeat(26)}});await call('/v1/journal/update',{state:'succeeded',receipt:{}});
 assert.equal((await c.status()).state,'running');f.container.destroy=async()=>{throw Error('private diagnostic');};await c.alarm();const ambiguous=await c.status();assert.equal(ambiguous.state,'uncertain');assert.equal(ambiguous.receipt.recoveryId,capture.id);assert.equal(ambiguous.receipt.itemId,'a'.repeat(26));
 f.container.destroy=async()=>{f.container.running=false;};await c.alarm();assert.equal((await c.status()).state,'succeeded');assert.equal(f.starts.length,1);
});
test('private dispatch rejects untrusted HMAC before lifecycle and signs nonce-bound safe responses',async()=>{
 assert.equal(typeof api.createDispatchHandler,'function');const f=fixture(),c=api.createJobController(f.options);let requests=0;
 const handler=api.createDispatchHandler({config:f.config,keyProvider:()=>key,jobProvider:()=>{requests++;return c;},now:()=>fixed});
 const body=JSON.stringify(f.envelope()),url='https://provisioner.vespoli.me/v1/dispatch';
 assert.equal((await handler(new Request(url,{method:'POST',headers:{'content-type':'application/json','x-provisioner-signature':'bad'},body}))).status,401);assert.equal(requests,0);
 const response=await handler(new Request(url,{method:'POST',headers:{'content-type':'application/json','x-provisioner-signature':createHmac('sha256',key).update(body).digest('base64url')},body})),raw=await response.text();
 assert.equal(response.status,200);assert.equal(JSON.parse(raw).requestNonce,f.envelope().nonce);assert.equal(response.headers.get('x-provisioner-signature'),createHmac('sha256',key).update(raw).digest('base64url'));assert.equal(raw.includes('synthetic-op-token'),false);
});
test('outbound interception is exact-origin and callback authority is unavailable to browser traffic',async()=>{
 const f=fixture();let calls=0;f.options.fetcher=async()=>{calls++;return new Response('safe');};const c=api.createJobController(f.options);await c.dispatch(f.envelope());const record=f.records.get('job'),props={jobId:f.job.id,containerId:'fixture-container',identity:record.identity};
 assert.equal((await c.outbound(new Request('https://console.example.test/login'),props)).status,200);assert.equal(calls,1);
 for(const url of ['https://evil.example.test/','http://console.example.test/','https://console.example.test:444/','https://127.0.0.1/'])await assert.rejects(c.outbound(new Request(url),props));
 await assert.rejects(c.outbound(new Request('https://provisioner.internal/v1/journal/reserve',{method:'POST',body:JSON.stringify({jobId:f.job.id,payloadHash:f.job.payloadHash})}),props));assert.equal(calls,1);
});
test('runtime platform qualification is checked before reservation or secret retrieval',async()=>{
 for(const platform of [undefined,{provider:'cloudflare-containers',qualified:false,qualificationDigest:null},{provider:'other',qualified:true,qualificationDigest:hash('test')},{provider:'cloudflare-containers',qualified:true,qualificationDigest:'invalid'}]){
  const f=fixture();f.config.runnerConfig.platform=platform;let secrets=0;f.options.serviceToken=()=>{secrets++;return 'synthetic-token';};
  await assert.rejects(api.createJobController(f.options).dispatch(f.envelope()));assert.equal(secrets,0);assert.equal(f.starts.length,0);assert.equal(f.records.size,0);
 }
});
test('expiry during interception or durable launch reservation prevents container startup',async()=>{
 for(const stage of ['intercept','reservation']){
  const f=fixture();let secrets=0;f.options.serviceToken=()=>{secrets++;return 'synthetic-token';};
  if(stage==='intercept')f.container.interceptOutboundHttps=async()=>{f.setTime(fixed+300001);};
  else {const put=f.options.storage.put;f.options.storage.put=async(k,r)=>{await put(k,r);if(r.phase==='booting')f.setTime(fixed+300001);};}
  await api.createJobController(f.options).dispatch(f.envelope());assert.equal(f.starts.length,0,stage);assert.equal(secrets,0,stage);assert.equal(f.requests.length,0,stage);
 }
});
test('expiry during token retrieval or durable submission reservation prevents private handoff',async()=>{
 for(const stage of ['token','reservation']){
  const f=fixture();if(stage==='token')f.options.serviceToken=async()=>{f.setTime(fixed+300001);return 'synthetic-token';};
  else {const put=f.options.storage.put;f.options.storage.put=async(k,r)=>{await put(k,r);if(r.submitted)f.setTime(fixed+300001);};}
  await api.createJobController(f.options).dispatch(f.envelope());assert.equal(f.starts.length,1,stage);assert.equal(f.requests.filter(r=>r.options?.method==='POST').length,0,stage);
 }
});
async function reservedFixture(){
 const f=fixture();let keyHook=async()=>{};f.options.machineKey=async()=>{await keyHook();return key;};const c=api.createJobController(f.options);await c.dispatch(f.envelope());const body=JSON.parse(f.requests.find(r=>r.options?.method==='POST').options.body),props={jobId:f.job.id,containerId:'fixture-container',identity:f.records.get('job').identity};
 const call=(path,data={})=>c.callback(path,{jobId:f.job.id,payloadHash:f.job.payloadHash,...data},'Bearer '+body.callbackToken,props);await call('/v1/journal/reserve');
 const envelope=canon({version:1,algorithm:'RSA-OAEP-256+A256GCM',keyId:'recovery-key',fingerprint:hash('recovery-key'),context:{jobId:f.job.id,payloadHash:f.job.payloadHash,purpose:'recovery'},encryptedDataKey:Buffer.alloc(384,1).toString('base64'),iv:Buffer.alloc(12,2).toString('base64'),tag:Buffer.alloc(16,3).toString('base64'),ciphertext:Buffer.from('synthetic encrypted bytes').toString('base64')});
 return {...f,c,call,ciphertext:{envelope,digest:hash(envelope)},setKeyHook:fn=>keyHook=fn};
}
test('expired or destroyed callbacks cannot create output or promote the journal after authentication awaits',async()=>{
 for(const kind of ['output','journal']){
  const f=await reservedFixture();f.setKeyHook(async()=>{f.setTime(fixed+300001);await f.c.alarm();});
  await assert.rejects(kind==='output'?f.call('/v1/recovery',f.ciphertext):f.call('/v1/journal/update',{state:'failed',receipt:{}}));assert.equal(f.objects.size,0);assert.equal(f.records.get('job').cleanup,'destroyed');assert.equal(f.records.get('job').execution,'uncertain');
 }
});
test('output reservation finishing after deadline cannot start a remote write',async()=>{
 const f=await reservedFixture(),put=f.options.storage.put;f.options.storage.put=async(k,r)=>{await put(k,r);if(r.outputs.recovery)f.setTime(fixed+300001);};
 await assert.rejects(f.call('/v1/recovery',f.ciphertext));assert.equal(f.objects.size,0);
});
test('an already dispatched recovery write that completes after cleanup retains the durable receipt',async()=>{
 const f=await reservedFixture(),put=f.options.recovery.put;f.options.recovery.put=async(...args)=>{f.setTime(fixed+300001);await f.c.alarm();return put(...args);};
 const receipt=await f.call('/v1/recovery',f.ciphertext);assert.equal(f.objects.size,1);assert.equal(f.records.get('job').cleanup,'destroyed');assert.equal((await f.c.status()).receipt.recoveryId,receipt.id);assert.equal((await f.c.status()).state,'recovery-required');
});
test('actual executor public fetch denies dispatch even when enabled',async()=>{
 const {build}=await import('esbuild'),{Miniflare,convertV4MiniflareOptions}=await import('miniflare');
 const bundled=(await build({entryPoints:['infra/provisioner/handler.mjs'],bundle:true,write:false,format:'esm',platform:'browser',external:['cloudflare:workers','node:*']})).outputFiles[0].text;
 const f=fixture(),common={modules:true,script:bundled,compatibilityDate:'2026-10-08',compatibilityFlags:['nodejs_compat']};
 const mf=new Miniflare(convertV4MiniflareOptions({cf:false,workers:[{...common,name:'executor',bindings:{ENABLED:'true',PROVISIONER_CONFIG_JSON:JSON.stringify(f.config),PROVISIONER_DISPATCH_KEY:key},durableObjects:{PROVISIONER_JOBS:{className:'ProvisionerJob',useSQLite:true}}},{...common,name:'disabled',bindings:{ENABLED:'false'}}]}));
 try {for(const name of ['executor','disabled']){const worker=await mf.getWorker(name);for(const path of ['/v1/dispatch','/v1/journal/reserve','/'])assert.equal((await worker.fetch('https://fixture.test'+path,{method:'POST',body:'{}'})).status,404);}}finally{await mf.dispose();}
});
test('actual Control outbox reaches the private executor and job DO without public fetch or provider effects',async()=>{
 const {build}=await import('esbuild'),{Miniflare,convertV4MiniflareOptions}=await import('miniflare'),{readFileSync}=await import('node:fs');
 const declared=JSON.parse(readFileSync('wrangler.json','utf8')).services.find(value=>value.binding==='PROVISIONER_EXECUTOR');
 assert.deepEqual(declared,{binding:'PROVISIONER_EXECUTOR',service:'personal-control-provisioner-executor',entrypoint:'ProvisionerDispatch'});
 const f=fixture(),job=f.job;
 // Only test facades seed/read synthetic records. Production classes and their
 // alarm, binding, authentication and durable reservation paths run unchanged.
 const gatewaySource=`import {Control as ActualControl} from './src/worker.mjs';
 export class FixtureControl extends ActualControl {async fetch(){const job=${JSON.stringify(job)};if(!await this.storage.get('provisioner:job:'+job.id)){await this.storage.put('provisioner:job:'+job.id,job);await this.storage.put('provisioner:outbox:'+job.id,{jobId:job.id,state:'pending'});}await this.alarm();return Response.json({job:await this.storage.get('provisioner:job:'+job.id),outbox:await this.storage.get('provisioner:outbox:'+job.id)});}}
 export default {fetch(request,env){return env.CONTROL.getByName('fixture-control').fetch(request);}};`;
 const executorSource=`import executor,{ProvisionerJob as ActualJob,ProvisionerDispatch,ProvisionerEgress} from './infra/provisioner/handler.mjs';export {ProvisionerDispatch,ProvisionerEgress};
 export class ProvisionerJob extends ActualJob {async fixtureStatus(){const r=await this.ctx.storage.get('job');return r?{exists:true,phase:r.phase,nonces:Object.keys(r.nonces).length}:{exists:false};}}
 export default {fetch(request,env){if(new URL(request.url).pathname==='/fixture/status')return env.PROVISIONER_JOBS.getByName('${job.id}').fixtureStatus().then(Response.json);return executor.fetch(request,env);}};`;
 const bundle=async contents=>(await build({stdin:{contents,resolveDir:process.cwd()},bundle:true,write:false,format:'esm',platform:'browser',external:['cloudflare:workers','node:*']})).outputFiles[0].text;
 const [gateway,executor]=await Promise.all([bundle(gatewaySource),bundle(executorSource)]);
 let networkCalls=0;const common={modules:true,compatibilityDate:'2026-10-08',compatibilityFlags:['nodejs_compat'],outboundService:async()=>{networkCalls++;return new Response(null,{status:503});}};
 const endpoint='https://provisioner-executor.vespoli.me/v1/dispatch',bindings={ENABLED:'true',PROVISIONER_CONFIG_JSON:JSON.stringify(f.config),PROVISIONER_DISPATCH_KEY:key};
 const relay=`export default {fetch(request,env){return env.EXECUTOR.fetch(request);}};`;
 const mf=new Miniflare(convertV4MiniflareOptions({cf:false,workers:[
  {...common,name:'gateway',script:gateway,bindings:{PROVISIONER_PROFILES:JSON.stringify([f.profile]),PROVISIONER_DISPATCH_URL:endpoint,PROVISIONER_DISPATCH_AUDIENCE:f.config.audience,PROVISIONER_DISPATCH_KEY:key},durableObjects:{CONTROL:{className:'FixtureControl',useSQLite:true}},serviceBindings:{PROVISIONER_EXECUTOR:{name:declared.service,entrypoint:declared.entrypoint}}},
  {...common,name:declared.service,script:executor,bindings,durableObjects:{PROVISIONER_JOBS:{className:'ProvisionerJob',useSQLite:true}}},
  {...common,name:'disabled',script:executor,bindings:{ENABLED:'false'}},
  {...common,name:'unqualified',script:executor,bindings:{...bindings,PROVISIONER_CONFIG_JSON:JSON.stringify({...f.config,qualified:false})},durableObjects:{PROVISIONER_JOBS:{className:'ProvisionerJob',useSQLite:true}}},
  ...[[declared.service,'private'],['disabled','private-disabled'],['unqualified','private-unqualified']].map(([name,caller])=>({...common,name:caller,script:relay,serviceBindings:{EXECUTOR:{name,entrypoint:declared.entrypoint}}})),
 ]}));
 try{
  const control=await mf.getWorker('gateway'),worker=await mf.getWorker(declared.service);
  for(let attempt=1;attempt<=2;attempt++){
   const result=await (await control.fetch('https://fixture.test/fixture/drain')).json();
   assert.equal(result.job.state,'uncertain');assert.equal(result.job.error,undefined);assert.equal(result.outbox.attempts,attempt);
   // No container is attached: the actual DO retains an uncertain reservation.
   assert.deepEqual(await (await worker.fetch('https://fixture.test/fixture/status')).json(),{exists:true,phase:'uncertain',nonces:attempt});
  }
  const body=JSON.stringify({...f.envelope(),sentAt:Date.now()}),headers={'content-type':'application/json','x-provisioner-signature':createHmac('sha256',key).update(body).digest('base64url')};
  assert.equal((await worker.fetch(endpoint,{method:'POST',headers,body})).status,404);
  const privateWorker=await mf.getWorker('private'),disabled=await mf.getWorker('private-disabled'),unqualified=await mf.getWorker('private-unqualified');
  assert.equal((await privateWorker.fetch(endpoint,{method:'POST',headers:{'content-type':'application/json'},body})).status,401);
  assert.equal((await privateWorker.fetch(endpoint.replace('/v1/dispatch','/v1/journal/reserve'),{method:'POST',headers,body})).status,404);
  assert.equal((await disabled.fetch(endpoint,{method:'POST',headers,body})).status,503);
  const denied=await unqualified.fetch(endpoint,{method:'POST',headers,body}),raw=await denied.text();assert.equal(denied.status,200);assert.equal(JSON.parse(raw).state,'blocked');assert.equal(denied.headers.get('x-provisioner-signature'),createHmac('sha256',key).update(raw).digest('base64url'));
  assert.equal(networkCalls,0);
 }finally{await mf.dispose();}
});
