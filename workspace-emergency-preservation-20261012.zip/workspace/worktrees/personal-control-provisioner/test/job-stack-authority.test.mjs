import test from 'node:test';
import assert from 'node:assert/strict';
import {createJobStackAuthority,jobStackOwnerProof,jobStackPolicy,parseOwnerRead,inputDigest,revokeJobStackSessions,cleanupJobStack} from '../src/job-stack/authority.mjs';
import {CONTRACT,validateInvocation} from '../src/job-stack/shared-contract.mjs';
const ORIGIN='https://control.vespoli.me',EMAIL='synthetic@example.invalid',ROOT='/owner/job-stack';
const TARGET=ROOT+'/api/operations/job_stack_records?kind=opportunity';

async function fixture({originalExpiry=1300}={}){
  let now=1000000,queue=Promise.resolve();const rows=new Map();
  const storage={get:async key=>structuredClone(rows.get(key)),put:async(key,value)=>{rows.set(key,structuredClone(value));},delete:async key=>rows.delete(key),list:async({prefix,limit=100})=>new Map([...rows].filter(([key])=>key.startsWith(prefix)).slice(0,limit))};
  storage.transaction=fn=>{const next=queue.then(()=>fn(storage));queue=next.catch(()=>{});return next;};
  const scopes=['job-stack.session.read','job-stack.records.read','job-stack.version.read','job-stack.protection.read'];
  const cap={version:1,kind:'job-stack-workspace-capability',id:'cap_fixture',revision:1,issuerPrincipalId:'access-owner:'+EMAIL,workspace:{ownerId:'owner_fixture',workspaceId:'workspace_fixture'},namespace:'namespace_fixture',initialEpochId:'epoch_fixture',state:'active',scopes,contract:CONTRACT,preparationFormat:'bound-primary-v1',packageFormat:'recovery-package-v1',runtime:'production'};
  const grant={version:2,kind:'job-stack-workspace',id:'grant_fixture',revision:1,issuerPrincipalId:cap.issuerPrincipalId,principalId:'client:client_fixture',clientId:'client_fixture',issuer:ORIGIN,audience:ORIGIN+'/mcp',capabilityId:cap.id,capabilityRevision:1,scopes,resources:[{provider:'job-stack',kind:'workspace',id:'workspace_fixture',ownerId:'owner_fixture'}],createdAtMs:now-1000,expiresAtMs:now+300000,revokedAtMs:null,delegation:{allowed:false},consentId:'consent_fixture'};
  const env={ORIGIN,ACCESS_AUD:'fixture-owner-gate',JOB_STACK_POLICY_JSON:JSON.stringify({contract:'job-stack.owner-policy.v1',enabled:true,qualificationDigest:'a'.repeat(64),maxLeaseMs:60000}),JOB_STACK:{invokeCore:async()=>{},ownerAsset:async()=>new Response('fixture')}};
  const claims={iss:'https://fixture.cloudflareaccess.com',sub:'synthetic-owner',email:EMAIL,amr:['hwk','mfa'],auth_time:1000,exp:originalExpiry};
  // Pure proof projection assumes ownerGate already verified this synthetic JWT.
  const request=new Request(ORIGIN+ROOT,{headers:{'cf-access-jwt-assertion':'header.'+Buffer.from(JSON.stringify(claims)).toString('base64url')+'.fixture'}});
  const proof=await jobStackOwnerProof(request,EMAIL,env,now);
  const c={env,storage};let authority;
  env.JOB_STACK.invokeCore=async read=>{const result=await authority.revalidate({contract:CONTRACT,invocationId:read.invocationId,operationId:read.operationId,inputDigest:await inputDigest(read.operationId,read.input),stage:'read'});validateInvocation(result.invocation);return {items:[],nextCursor:null};};
  // Provide both binding methods before the policy check above.
  await storage.put('job-stack:grant:'+grant.id,grant);await storage.put('job-stack:capability:'+cap.id,cap);
  authority=createJobStackAuthority(c,{clock:()=>now});
  const establish=async()=>authority.establish(grant.id,proof,await authority.nonce(grant.id,proof,'establish',ROOT+'/session/establish'));
  return {c,rows,authority,grant,cap,proof,request,establish,now:()=>now,advance:ms=>{now+=ms;}};
}

test('an explicit lease plus nonce invokes exact selected read and canonical reciprocal authority',async()=>{
  const f=await fixture();await f.establish();const nonce=await f.authority.nonce(f.grant.id,f.proof,'read',TARGET);
  assert.deepEqual(await f.authority.invoke(f.grant.id,f.proof,TARGET,nonce),{items:[],nextCursor:null});
  await assert.rejects(f.authority.invoke(f.grant.id,f.proof,TARGET,nonce));
  assert.equal((await f.c.storage.list({prefix:'job-stack:invocation:'})).size,0);
});
test('owner session output uses bounded lease and never calls Product',async()=>{
  const f=await fixture(),lease=await f.establish();let calls=0;f.c.env.JOB_STACK.invokeCore=async()=>{calls++;throw Error('should-not-call');};
  const target=ROOT+'/api/operations/job_stack_session',nonce=await f.authority.nonce(f.grant.id,f.proof,'read',target);
  const result=await f.authority.invoke(f.grant.id,f.proof,target,nonce);assert.equal(result.expiresAtMs,lease.expiresAtMs);assert.equal(result.grantId,f.grant.id);assert.equal(calls,0);
});
test('selected authority never comes from broad sessions, foreign owners or caller workspace selectors',async()=>{
  const f=await fixture();await assert.rejects(f.authority.current('super',f.proof.principal));
  await assert.rejects(f.authority.current(f.grant.id,'access-owner:foreign@example.invalid'));
  await assert.rejects(f.authority.nonce(f.grant.id,f.proof,'read',TARGET));
  for(const target of [TARGET+'&workspaceId=foreign',TARGET+'&kind=claim',TARGET+'&entityId=one&cursor=two',ROOT+'/api/operations/job_stack_claim_add',ROOT+'/api/operations/job_stack_profile'])assert.throws(()=>parseOwnerRead(target,'workspace_fixture'));
});
test('a nonce is atomically consumed once and wrong-target attempts burn it',async()=>{
  const f=await fixture();await f.establish();let nonce=await f.authority.nonce(f.grant.id,f.proof,'read',TARGET);
  const concurrent=await Promise.allSettled([f.authority.invoke(f.grant.id,f.proof,TARGET,nonce),f.authority.invoke(f.grant.id,f.proof,TARGET,nonce)]);assert.equal(concurrent.filter(x=>x.status==='fulfilled').length,1);
  nonce=await f.authority.nonce(f.grant.id,f.proof,'read',TARGET);await assert.rejects(f.authority.invoke(f.grant.id,f.proof,TARGET.replace('opportunity','claim'),nonce));await assert.rejects(f.authority.invoke(f.grant.id,f.proof,TARGET,nonce));
});
test('lease establishment is explicit, never extended by reads or refresh, expiry is terminal',async()=>{
  const f=await fixture(),lease=await f.establish();f.advance(10000);assert.equal((await f.establish()).expiresAtMs,lease.expiresAtMs);
  f.advance(50000);await assert.rejects(f.establish());await assert.rejects(f.authority.leaseCurrent(f.grant.id,f.proof));
});
test('revocation survives establish races and cannot be undone with the same proof',async()=>{
  const f=await fixture(),start=await f.authority.nonce(f.grant.id,f.proof,'establish',ROOT+'/session/establish');
  await f.authority.revoke(f.grant.id,f.proof,await f.authority.nonce(f.grant.id,f.proof,'revoke',ROOT+'/session/revoke'));
  await assert.rejects(f.authority.establish(f.grant.id,f.proof,start));
});
test('revoked grants, capability revisions and disabled assurance invalidate before-ack',async()=>{
  for(const change of ['grant','capability','policy','revoke-all']){
    const f=await fixture();await f.establish();const nonce=await f.authority.nonce(f.grant.id,f.proof,'read',TARGET);
    f.c.env.JOB_STACK.invokeCore=async()=>{
      if(change==='grant')await f.c.storage.put('job-stack:grant:'+f.grant.id,{...f.grant,revokedAtMs:f.now()});
      if(change==='capability')await f.c.storage.put('job-stack:capability:'+f.cap.id,{...f.cap,revision:2});
      if(change==='policy')f.c.env.JOB_STACK_POLICY_JSON='{}';
      if(change==='revoke-all')await revokeJobStackSessions(f.c.storage,EMAIL);
      return {items:[],nextCursor:null};
    };
    await assert.rejects(f.authority.invoke(f.grant.id,f.proof,TARGET,nonce),undefined,change);
  }
});
test('unqualified hardware policy and bare signed identity fail closed',async()=>{
  const f=await fixture();assert.throws(()=>jobStackPolicy({...f.c.env,JOB_STACK_POLICY_JSON:'{}'}));
  await assert.rejects(jobStackOwnerProof(new Request(ORIGIN),EMAIL,f.c.env,f.now()));
  const noHardware=new Request(ORIGIN,{headers:{'cf-access-jwt-assertion':'h.'+Buffer.from(JSON.stringify({email:EMAIL,sub:'owner',exp:1300,auth_time:1000,amr:['mfa']})).toString('base64url')+'.s'}});
  await assert.rejects(jobStackOwnerProof(noHardware,EMAIL,f.c.env,f.now()));
});
test('Access token refresh cannot revive an expired or revoked authentication context',async()=>{
  for(const terminal of ['expired','revoked']){
    const f=await fixture();await f.establish();
    if(terminal==='expired')f.advance(60000);else await revokeJobStackSessions(f.c.storage,EMAIL);
    const claims=JSON.parse(Buffer.from(f.request.headers.get('cf-access-jwt-assertion').split('.')[1],'base64url').toString());
    const reissued=new Request(ORIGIN,{headers:{'cf-access-jwt-assertion':'different-header.'+Buffer.from(JSON.stringify({...claims,iat:1060,exp:1400,jti:'new-token'})).toString('base64url')+'.new-signature'}});
    const proof=await jobStackOwnerProof(reissued,EMAIL,f.c.env,f.now());assert.equal(proof.context,f.proof.context);
    await cleanupJobStack(f.c.storage,f.now());
    const nonce=await f.authority.nonce(f.grant.id,proof,'establish',ROOT+'/session/establish');await assert.rejects(f.authority.establish(f.grant.id,proof,nonce));
  }
});
test('terminal tombstones survive a short JWT expiry and cleanup before token reissue',async()=>{
  for(const terminal of ['expired','revoked']){
    const f=await fixture({originalExpiry:1030});await f.establish();
    if(terminal==='revoked')await revokeJobStackSessions(f.c.storage,EMAIL);
    f.advance(40000);await cleanupJobStack(f.c.storage,f.now());
    assert.equal((await f.c.storage.list({prefix:'job-stack:lease:'})).size,1);
    const oldClaims=JSON.parse(Buffer.from(f.request.headers.get('cf-access-jwt-assertion').split('.')[1],'base64url').toString());
    const reissued=new Request(ORIGIN,{headers:{'cf-access-jwt-assertion':'h.'+Buffer.from(JSON.stringify({...oldClaims,iat:1040,exp:1300,jti:'refreshed'})).toString('base64url')+'.s'}});
    const proof=await jobStackOwnerProof(reissued,EMAIL,f.c.env,f.now());assert.equal(proof.context,f.proof.context);
    const nonce=await f.authority.nonce(f.grant.id,proof,'establish',ROOT+'/session/establish');await assert.rejects(f.authority.establish(f.grant.id,proof,nonce));
  }
});
