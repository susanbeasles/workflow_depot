import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createNativeProvisionerSigner} from '../src/provisioner-client.mjs';

const extensionPath=new URL('../signer/extension/transport.js',import.meta.url);
const ownerOrigin='https://control.vespoli.me',keyId='a'.repeat(64),extensionId='a'.repeat(32);
const uuid='792732b6-d53b-45ac-b3d5-1557a0ffebbe';
const b64=bytes=>Buffer.from(bytes).toString('base64url');
const authBytes=b64(Buffer.from(JSON.stringify(['provisioner.auth-request.v1',uuid,1_800_000_000,'https://provisioner.vespoli.me',keyId,'p'.repeat(43),'h'.repeat(43)])));
const nonceBytes=b64(Buffer.from(b64(new Uint8Array(32))));
function event(){const listeners=new Set();return {addListener:fn=>listeners.add(fn),removeListener:fn=>listeners.delete(fn),emit:(...args)=>{for(const fn of [...listeners])fn(...args);}};}
function port(extra={}){return {name:'provisioner-v1',...extra,onMessage:event(),onDisconnect:event(),sent:[],closed:false,postMessage(message){this.sent.push(message);},disconnect(){if(this.closed)return;this.closed=true;this.onDisconnect.emit();}};}
function sender(overrides={}){return {origin:ownerOrigin,url:ownerOrigin+'/owner/apps/provisioner',tab:{id:7},frameId:0,documentId:uuid,documentLifecycle:'active',...overrides};}
function setup(config={}){const nativePorts=[];const runtime={onConnectExternal:event(),connectNative(name){assert.equal(name,'me.vespoli.provisioner');const result=port();nativePorts.push(result);return result;}};return {chrome:{runtime},nativePorts,config:{OWNER_ORIGIN:ownerOrigin,KEY_ID:keyId,NATIVE_HOST:'me.vespoli.provisioner',...config}};}
const message=(action,id=crypto.randomUUID(),extra={})=>({version:1,id,action,origin:ownerOrigin,keyId,...extra});
function approve(native){const request=native.sent.at(-1);native.onMessage.emit({version:1,id:request.id,ok:true,keyId,...(request.action==='sign'?{signature:b64(new Uint8Array(64))}:{})});}

test('extension permits exact owner top frame and forwards hello plus both signatures over one native port',async()=>{
 const {installProvisionerTransport}=await import(extensionPath),fixture=setup();installProvisionerTransport(fixture.chrome,fixture.config);
 const page=port({sender:sender()});fixture.chrome.runtime.onConnectExternal.emit(page);
 assert.equal(fixture.nativePorts.length,1);const native=fixture.nativePorts[0];
 for(const request of [message('hello'),message('sign',undefined,{purpose:'provisioner.auth-request.v1',bytes:authBytes}),message('sign',undefined,{purpose:'provisioner.nonce.v1',bytes:nonceBytes})]){
   page.onMessage.emit(request);assert.deepEqual(native.sent.at(-1),request);approve(native);assert.equal(page.sent.at(-1).id,request.id);assert.equal(page.sent.at(-1).ok,true);
 }
 assert.equal(fixture.nativePorts.length,1);assert.equal(native.sent.length,3);
 page.onMessage.emit(message('sign',undefined,{purpose:'provisioner.nonce.v1',bytes:nonceBytes}));
 assert.equal(native.sent.length,3);assert.equal(page.sent.at(-1).error,'approval-order-invalid');assert.equal(native.closed,true);
});

test('extension rejects other origins, subframes, absent documents, duplicate tabs and invalid template configuration',async()=>{
 const {installProvisionerTransport}=await import(extensionPath),fixture=setup();installProvisionerTransport(fixture.chrome,fixture.config);
 for(const bad of [sender({origin:'https://evil.example'}),sender({url:'https://evil.example/path'}),sender({origin:'null'}),sender({frameId:1}),sender({tab:undefined}),sender({documentId:undefined}),sender({documentLifecycle:'prerender'})]){
   const page=port({sender:bad});fixture.chrome.runtime.onConnectExternal.emit(page);assert.equal(page.closed,true);
 }
 assert.equal(fixture.nativePorts.length,0);
 const first=port({sender:sender()}),second=port({sender:sender()});fixture.chrome.runtime.onConnectExternal.emit(first);fixture.chrome.runtime.onConnectExternal.emit(second);
 assert.equal(second.closed,true);assert.equal(fixture.nativePorts.length,1);first.disconnect();assert.equal(fixture.nativePorts[0].closed,true);
 const third=port({sender:sender({documentId:crypto.randomUUID()})});fixture.chrome.runtime.onConnectExternal.emit(third);assert.equal(fixture.nativePorts.length,2);third.disconnect();
 const blocked=setup({OWNER_ORIGIN:'https://unconfigured.invalid',KEY_ID:'UNCONFIGURED'});installProvisionerTransport(blocked.chrome,blocked.config);const page=port({sender:sender()});blocked.chrome.runtime.onConnectExternal.emit(page);assert.equal(page.closed,true);assert.equal(blocked.nativePorts.length,0);
});

test('extension rejects unknown fields, wrong key, wrong purpose and malformed encoded nonce before native forwarding',async()=>{
 const {installProvisionerTransport}=await import(extensionPath);
 for(const mutation of [request=>({...request,shell:'anything'}),request=>({...request,keyId:'b'.repeat(64)}),request=>({...request,purpose:'arbitrary-sign'}),request=>({...request,bytes:b64(Buffer.from('x'.repeat(2049)))})]){
   const fixture=setup();installProvisionerTransport(fixture.chrome,fixture.config);const page=port({sender:sender()});fixture.chrome.runtime.onConnectExternal.emit(page);const native=fixture.nativePorts[0];page.onMessage.emit(message('hello'));approve(native);
   page.onMessage.emit(mutation(message('sign',undefined,{purpose:'provisioner.auth-request.v1',bytes:authBytes})));assert.equal(native.sent.length,1);assert.equal(page.closed,true);
 }
 for(const bytes of [b64(Buffer.from('a'.repeat(42))),b64(Buffer.from('!'.repeat(43))),b64(Buffer.from('a'.repeat(43))),nonceBytes+'=']){
   const fixture=setup();installProvisionerTransport(fixture.chrome,fixture.config);const page=port({sender:sender()});fixture.chrome.runtime.onConnectExternal.emit(page);const native=fixture.nativePorts[0];page.onMessage.emit(message('hello'));approve(native);page.onMessage.emit(message('sign',undefined,{purpose:'provisioner.auth-request.v1',bytes:authBytes}));approve(native);
   page.onMessage.emit(message('sign',undefined,{purpose:'provisioner.nonce.v1',bytes}));assert.equal(native.sent.length,2);assert.equal(page.closed,true);
 }
});

test('extension tears down on overlapping requests, malformed native responses, disconnect and timeout',async()=>{
 const {installProvisionerTransport}=await import(extensionPath);
 for(const scenario of ['overlap','wrong-id','oversize','bad-signature','disconnect','timeout']){
   let timer;const fixture=setup();installProvisionerTransport(fixture.chrome,fixture.config,{setTimer:fn=>{timer=fn;return 1;},clearTimer:()=>{}});
   const page=port({sender:sender()});fixture.chrome.runtime.onConnectExternal.emit(page);const native=fixture.nativePorts[0];const request=message('hello');page.onMessage.emit(request);
   if(scenario==='overlap')page.onMessage.emit(message('hello'));
   if(scenario==='wrong-id')native.onMessage.emit({version:1,id:crypto.randomUUID(),ok:true,keyId});
   if(scenario==='oversize')native.onMessage.emit({version:1,id:request.id,ok:true,keyId,unexpected:'x'.repeat(5000)});
   if(scenario==='bad-signature'){approve(native);page.onMessage.emit(message('sign',undefined,{purpose:'provisioner.auth-request.v1',bytes:authBytes}));native.onMessage.emit({version:1,id:native.sent.at(-1).id,ok:true,keyId,signature:'DER-is-not-p1363'});}
   if(scenario==='disconnect')native.disconnect();if(scenario==='timeout')timer();
   assert.equal(page.closed,true,scenario);assert.equal(native.closed,true,scenario);assert.equal(page.sent.at(-1).ok,false,scenario);
 }
});

test('browser transport handshakes without signing and pins extension, origin and key over a persistent port',async()=>{
 const page=port();let connections=0;
 const runtime={connect(id,options){connections++;assert.equal(id,extensionId);assert.deepEqual(options,{name:'provisioner-v1'});return page;}};
 const pending=createNativeProvisionerSigner({chrome:{runtime},config:{signerExtensionId:extensionId,keyId},origin:ownerOrigin,crypto});
 const hello=page.sent[0];assert.deepEqual(Object.keys(hello).sort(),['action','id','keyId','origin','version']);assert.equal(hello.action,'hello');assert.equal(hello.origin,ownerOrigin);
 page.onMessage.emit({version:1,id:hello.id,ok:true,keyId});const signer=await pending;
 for(const [purpose,bytes] of [['provisioner.auth-request.v1',authBytes],['provisioner.nonce.v1',nonceBytes]]){
   const signing=signer.sign({purpose,bytes,keyId});const request=page.sent.at(-1);assert.equal(request.action,'sign');assert.equal(request.bytes,bytes);page.onMessage.emit({version:1,id:request.id,ok:true,keyId,signature:b64(new Uint8Array(64))});assert.equal(await signing,b64(new Uint8Array(64)));
 }
 assert.equal(connections,1);assert.equal(signer.state,'complete');signer.close();assert.equal(page.closed,true);
});

test('browser transport fails closed on missing extension, handshake mismatch, timeout and disconnect without reconnect',async()=>{
 await assert.rejects(createNativeProvisionerSigner({chrome:{},config:{signerExtensionId:extensionId,keyId},origin:ownerOrigin,crypto}),{code:'signer-extension-unavailable'});
 await assert.rejects(createNativeProvisionerSigner({chrome:{},config:{keyId},origin:ownerOrigin,crypto}),{code:'signer-extension-not-configured'});
 for(const scenario of ['mismatch','timeout','disconnect','extra']){
   const page=port();let timer,connections=0;
   const promise=createNativeProvisionerSigner({chrome:{runtime:{connect(){connections++;return page;}}},config:{signerExtensionId:extensionId,keyId},origin:ownerOrigin,crypto,setTimer:fn=>{timer=fn;return 1;},clearTimer:()=>{}});
   if(scenario==='mismatch')page.onMessage.emit({version:1,id:page.sent[0].id,ok:true,keyId:'b'.repeat(64)});
   if(scenario==='extra')page.onMessage.emit({version:1,id:page.sent[0].id,ok:true,keyId,debug:'synthetic-private-value'});
   if(scenario==='timeout')timer();if(scenario==='disconnect')page.disconnect();
   await assert.rejects(promise,error=>{assert.ok(['invalid-signer-response','signer-timeout','native-disconnected'].includes(error.code));assert.doesNotMatch(JSON.stringify(error),/synthetic-private-value/);return true;});assert.equal(connections,1);assert.equal(page.closed,true);
 }
});

test('extension manifest has only nativeMessaging permission and no content or arbitrary origin access',async()=>{
 const manifest=JSON.parse(await readFile(new URL('../signer/extension/manifest.json',import.meta.url),'utf8'));
 assert.equal(manifest.manifest_version,3);assert.deepEqual(manifest.permissions,['nativeMessaging']);assert.equal(manifest.background.type,'module');assert.equal(manifest.content_scripts,undefined);assert.equal(manifest.host_permissions,undefined);assert.equal(manifest.externally_connectable.ids,undefined);assert.deepEqual(manifest.externally_connectable.matches,['https://unconfigured.invalid/*']);
 const serviceWorker=await readFile(new URL('../signer/extension/service-worker.js',import.meta.url),'utf8');assert.match(serviceWorker,/installProvisionerTransport/);
});
