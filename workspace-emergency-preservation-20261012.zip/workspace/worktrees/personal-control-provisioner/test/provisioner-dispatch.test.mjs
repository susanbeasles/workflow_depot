import test from 'node:test';
import assert from 'node:assert/strict';
import * as dispatcher from '../src/provisioner-dispatch.mjs';
import {profileDigest,canonical} from '../src/provisioner.mjs';
const encoder=new TextEncoder(),key='SYNTHETIC-DISPATCH-KEY-NOT-A-CREDENTIAL';
const mac=async text=>Buffer.from(await crypto.subtle.sign('HMAC',await crypto.subtle.importKey('raw',encoder.encode(key),{name:'HMAC',hash:'SHA-256'},false,['sign']),encoder.encode(text))).toString('base64url');
function store(){const values=new Map();const access={get:async k=>structuredClone(values.get(k)),put:async(k,v)=>values.set(k,structuredClone(v)),delete:async k=>values.delete(k)};return {...access,list:async({prefix,limit,startAfter})=>new Map([...values].filter(([k])=>k.startsWith(prefix)&&(!startAfter||k>startAfter)).sort(([a],[b])=>a.localeCompare(b)).slice(0,limit)),transaction:async fn=>fn(access),setAlarm:async()=>{},values};}
async function fixture(){const profile={id:'test',manifest:{qualified:true},codeRevision:'pinned-code'};const job={id:crypto.randomUUID(),owner:'owner@example.com',state:'accepted',rawPayload:'{}',payload:{},payloadHash:'hash',context:{profileId:'test',profileDigest:await profileDigest(profile)}};const storage=store();await storage.put('provisioner:job:'+job.id,job);await storage.put('provisioner:outbox:'+job.id,{jobId:job.id,state:'pending',createdAt:1});return {storage,job,profile,env:{PROVISIONER_PROFILES:canonical([profile]),PROVISIONER_DISPATCH_URL:'https://provisioner-executor.vespoli.me/dispatch',PROVISIONER_DISPATCH_AUDIENCE:'provisioner-executor-v1',PROVISIONER_DISPATCH_KEY:key}};}
async function drainWith(f,fetch){f.env.PROVISIONER_EXECUTOR={fetch};return dispatcher.drainProvisionerOutbox(f);}
test('dispatcher API exists',()=>assert.equal(typeof dispatcher.drainProvisionerOutbox,'function'));
test('dispatch requires the private executor binding and never falls back to global fetch',async t=>{
 let networkCalls=0;t.mock.method(globalThis,'fetch',async()=>{networkCalls++;throw Error('network must not be used');});
 for(const binding of [undefined,{}, {fetch:null}]){const f=await fixture();f.env.PROVISIONER_EXECUTOR=binding;await assert.rejects(dispatcher.dispatchAcceptedJob(f.env,f.job,f.profile),/runner-not-configured/);}
 assert.equal(networkCalls,0);
});
test('dispatch uses the configured private binding with its receiver and verifies its signed response',async t=>{
 const f=await fixture();let privateCalls=0;t.mock.method(globalThis,'fetch',async()=>{throw Error('network must not be used');});
 f.env.PROVISIONER_EXECUTOR={async fetch(url,options){assert.equal(this,f.env.PROVISIONER_EXECUTOR);privateCalls++;assert.equal(url,f.env.PROVISIONER_DISPATCH_URL);const request=JSON.parse(options.body),body=JSON.stringify({jobId:f.job.id,state:'blocked',requestNonce:request.nonce});return new Response(body,{headers:{'x-provisioner-signature':await mac(body)}});}};
 assert.deepEqual(await dispatcher.dispatchAcceptedJob(f.env,f.job,f.profile),{state:'blocked'});assert.equal(privateCalls,1);
});
test('authenticated dispatcher signs exact immutable job and verifies nonce-bound response',async()=>{
 const f=await fixture();let seen;
 const fetcher=async(url,options)=>{seen=JSON.parse(options.body);assert.equal(options.headers['x-provisioner-signature'],await mac(options.body));assert.equal(seen.job.rawPayload,'{}');assert.equal(options.redirect,'manual');const body=JSON.stringify({jobId:f.job.id,state:'running',requestNonce:seen.nonce});return new Response(body,{headers:{'x-provisioner-signature':await mac(body)}});};
 await drainWith(f,fetcher);
 assert.equal((await f.storage.get('provisioner:job:'+f.job.id)).state,'running');
 assert.equal((await f.storage.get('provisioner:outbox:'+f.job.id)).state,'pending');
});
test('response tampering is uncertain, retained for idempotent reconciliation',async()=>{
 const f=await fixture();await drainWith(f,async()=>Response.json({jobId:f.job.id,state:'succeeded',receipt:{secret:'NEVER-REFLECT'}}));
 const job=await f.storage.get('provisioner:job:'+f.job.id);assert.equal(job.state,'uncertain');assert.equal(job.error,'dispatch-outcome-unknown');assert.ok(!JSON.stringify(job).includes('NEVER-REFLECT'));
 assert.equal((await f.storage.get('provisioner:outbox:'+f.job.id)).state,'pending');
});
test('even a signed redirect response is rejected without following another destination',async()=>{
 const f=await fixture();let calls=0;
 f.env.PROVISIONER_EXECUTOR={async fetch(url,options){calls++;assert.equal(options.redirect,'manual');const input=JSON.parse(options.body),body=JSON.stringify({jobId:f.job.id,state:'running',requestNonce:input.nonce});return new Response(body,{status:302,headers:{location:'https://unapproved.invalid/dispatch','x-provisioner-signature':await mac(body)}});}};
 await assert.rejects(dispatcher.dispatchAcceptedJob(f.env,f.job,f.profile),/dispatch-outcome-unknown/);assert.equal(calls,1);
});
test('changed approved profile prevents dispatch',async()=>{
 const f=await fixture();f.env.PROVISIONER_PROFILES=JSON.stringify([{...f.profile,codeRevision:'new-code'}]);
 await drainWith(f,async()=>{throw Error('must-not-dispatch');});
 assert.equal((await f.storage.get('provisioner:job:'+f.job.id)).state,'blocked');
});
test('receipt whitelist never publishes unexpected response fields',async()=>{
 const f=await fixture();const fetcher=async(url,options)=>{const input=JSON.parse(options.body),body=JSON.stringify({jobId:f.job.id,state:'succeeded',requestNonce:input.nonce,receipt:{jobId:f.job.id,provider:'b2',state:'succeeded',outputItemId:'a'.repeat(26),secret:'SYNTHETIC-SECRET'}});return new Response(body,{headers:{'x-provisioner-signature':await mac(body)}});};
 await drainWith(f,fetcher);
 assert.ok(!JSON.stringify(await f.storage.get('provisioner:job:'+f.job.id)).includes('SYNTHETIC-SECRET'));
});
test('completed outbox entries cannot starve later pending jobs',async()=>{
 const f=await fixture();for(let i=0;i<20;i++)await f.storage.put('provisioner:outbox:0000'+i,{jobId:'old'+i,state:'done'});
 let calls=0;const fetcher=async(url,options)=>{calls++;const input=JSON.parse(options.body),body=JSON.stringify({jobId:f.job.id,state:'failed',requestNonce:input.nonce});return new Response(body,{headers:{'x-provisioner-signature':await mac(body)}});};
 await drainWith(f,fetcher);await drainWith(f,fetcher);
 assert.equal(calls,1);assert.equal((await f.storage.get('provisioner:job:'+f.job.id)).state,'failed');
 assert.equal(await f.storage.get('provisioner:outbox:'+f.job.id),undefined);
});
test('pending jobs beyond the first batch receive dispatch even while earlier jobs are unresolved',async()=>{
 const f=await fixture(),seen=new Set();
 for(let i=0;i<20;i++){const id='00000000-0000-0000-0000-'+String(i).padStart(12,'0');await f.storage.put('provisioner:job:'+id,{...f.job,id});await f.storage.put('provisioner:outbox:'+id,{jobId:id,state:'pending',createdAt:1});}
 const fetcher=async(url,options)=>{const input=JSON.parse(options.body);seen.add(input.job.id);const body=JSON.stringify({jobId:input.job.id,state:'running',requestNonce:input.nonce});return new Response(body,{headers:{'x-provisioner-signature':await mac(body)}});};
 await drainWith(f,fetcher);await drainWith(f,fetcher);
 assert.equal(seen.size,21);assert.ok(seen.has(f.job.id));
});
