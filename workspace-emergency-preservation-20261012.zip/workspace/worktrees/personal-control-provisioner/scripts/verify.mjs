import {execFileSync} from 'node:child_process';
import {readdirSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
function source(dir){for(const entry of readdirSync(dir,{withFileTypes:true})){const p=join(dir,entry.name);if(entry.isDirectory())source(p);else if(p.endsWith('.mjs'))execFileSync(process.execPath,['--check',p],{stdio:'inherit'});}}
source('src');source('scripts');source('test');
const allowed=new Set(['actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1','actions/setup-node@820762786026740c76f36085b0efc47a31fe5020']);
for(const f of readdirSync('.github/workflows')){const s=readFileSync('.github/workflows/'+f,'utf8');if(/pull_request_target:/.test(s))throw Error('Privileged PR execution prohibited');for(const m of s.matchAll(/\buses:\s*([^\s#]+)/g))if(!allowed.has(m[1]))throw Error('Unpinned workflow action');}
execFileSync(process.execPath,['--test',...readdirSync('test').filter(f=>f.endsWith('.test.mjs')).map(f=>'test/'+f)],{stdio:'inherit'});
execFileSync('python3',['-B','-I','test/provisioner-native.test.py','-v'],{stdio:'inherit',timeout:60000,killSignal:'SIGKILL'});
execFileSync('npm',['run','check'],{cwd:'workers/ghcaretaker',stdio:'inherit'});
execFileSync('npm',['test'],{cwd:'workers/ghcaretaker',stdio:'inherit'});
execFileSync(process.execPath,['--test',...readdirSync('workers/backup-control/tests').filter(f=>f.endsWith('.test.mjs')).map(f=>'workers/backup-control/tests/'+f)],{stdio:'inherit'});
execFileSync('python3',['-m','unittest','discover','-s','tests','-p','test_*.py','-v'],{cwd:'workers/backup-control',stdio:'inherit'});
console.log('All capability, authentication and backup checks passed.');
