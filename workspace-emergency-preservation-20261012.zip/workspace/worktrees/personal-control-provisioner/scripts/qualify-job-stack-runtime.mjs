// Local synthetic composition only. No uploaded source, provider calls, durable
// production grants, owner enrollment or deployment are performed by this check.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {build} from 'esbuild';
import {Miniflare,convertV4MiniflareOptions} from 'miniflare';
const productDir=resolve(process.argv[2]||'../prosrus-completion');
const {applyMigrations}=await import(pathToFileURL(resolve(productDir,'scripts/runtime-migrations.mjs')));
assert.equal(await readFile('src/job-stack/shared-contract.mjs','utf8'),await readFile(resolve(productDir,'integration/shared-contract.mjs'),'utf8'),'shared contract drift');
process.env.CLOUDFLARE_CF_FETCH_ENABLED='false';
const bundle=async(contents,resolveDir=process.cwd())=>(await build({stdin:{contents,resolveDir},bundle:true,write:false,format:'esm',platform:'browser',target:'es2022',external:['cloudflare:workers','node:*']})).outputFiles[0].text;
const productScript=await bundle("export {default,JobStack,Coordinator} from './src/worker';",productDir);
const gatewayScript=await bundle(`
import gateway,{Control} from './src/worker.mjs';
import {JobStackAuthority as ActualAuthority} from './src/job-stack/entrypoint.mjs';
let mode='valid';const calls=[];
export class FixtureControl extends Control {
 async fetch(request){const path=new URL(request.url).pathname;
  if(path==='/__fixture_seed'){
   const input=await request.json();for(const prefix of ['job-stack:grant:','job-stack:capability:','job-stack:lease:','job-stack:invocation:','job-stack:nonce:'])for(const [key]of await this.storage.list({prefix}))await this.storage.delete(key);
   await this.storage.put('job-stack:grant:'+input.grant.id,input.grant);await this.storage.put('job-stack:capability:'+input.cap.id,input.cap);return new Response(null,{status:204});
  }
  if(path==='/__fixture_revoke'){const grant=await this.storage.get('job-stack:grant:grant_fixture');await this.storage.put('job-stack:grant:grant_fixture',{...grant,revokedAtMs:Date.now()});return new Response(null,{status:204});}
  return super.fetch(request);
 }
}
export class JobStackAuthority extends ActualAuthority {
 async revalidate(value){calls.push(value.stage);if(mode==='revoke-before-ack'&&value.stage==='before-ack')await this.env.CONTROL.get(this.env.CONTROL.idFromName('owner')).fetch(this.env.ORIGIN+'/__fixture_revoke');return super.revalidate(value);}
}
export default {async fetch(request,env){const path=new URL(request.url).pathname;
 // Miniflare's Node proxy protects itself from non-local browser Origins. This
 // synthetic-only driver reconstructs the intended request inside Workerd; the
 // actual gateway ownerGate still checks that Origin without any relaxation.
 if(request.headers.has('x-fixture-request-origin')){const headers=new Headers(request.headers);headers.set('origin',headers.get('x-fixture-request-origin'));headers.delete('x-fixture-request-origin');request=new Request(request,{headers});}
 if(path==='/__fixture_seed')return env.CONTROL.get(env.CONTROL.idFromName('owner')).fetch(request);
 if(path==='/__fixture_mode'){mode=new URL(request.url).searchParams.get('mode');calls.length=0;return new Response(null,{status:204});}
 if(path==='/__fixture_calls')return Response.json(calls);
 return gateway.fetch(request,env);
}};
`);
const ORIGIN='https://control.vespoli.me',email='synthetic@example.invalid',now=Date.now();
const pair=await crypto.subtle.generateKey({name:'RSASSA-PKCS1-v1_5',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['sign','verify']);
const jwk=await crypto.subtle.exportKey('jwk',pair.publicKey);jwk.kid='synthetic-owner';
const claims={iss:'https://fixture.cloudflareaccess.com',aud:['fixture-owner-gate'],email,sub:'fixture-owner',nbf:Math.floor(now/1000)-1,exp:Math.floor(now/1000)+300,auth_time:Math.floor(now/1000),amr:['hwk','mfa']};
const tokenInput=Buffer.from(JSON.stringify({alg:'RS256',kid:jwk.kid})).toString('base64url')+'.'+Buffer.from(JSON.stringify(claims)).toString('base64url');
const token=tokenInput+'.'+Buffer.from(await crypto.subtle.sign('RSASSA-PKCS1-v1_5',pair.privateKey,new TextEncoder().encode(tokenInput))).toString('base64url');
const scopes=['job-stack.session.read','job-stack.records.read'];
const cap={version:1,kind:'job-stack-workspace-capability',id:'cap_fixture',revision:1,issuerPrincipalId:'access-owner:'+email,workspace:{ownerId:'owner_fixture',workspaceId:'workspace_fixture'},namespace:'namespace_fixture',initialEpochId:'epoch_fixture',state:'active',scopes,contract:'job-stack.shared-auth.v1',preparationFormat:'bound-primary-v1',packageFormat:'recovery-package-v1',runtime:'production'};
const grant={version:2,kind:'job-stack-workspace',id:'grant_fixture',revision:1,issuerPrincipalId:cap.issuerPrincipalId,principalId:'client:fixture_client',clientId:'fixture_client',issuer:ORIGIN,audience:ORIGIN+'/mcp',capabilityId:cap.id,capabilityRevision:1,scopes,resources:[{provider:'job-stack',kind:'workspace',id:'workspace_fixture',ownerId:'owner_fixture'}],createdAtMs:now-1000,expiresAtMs:now+300000,revokedAtMs:null,delegation:{allowed:false},consentId:'consent_fixture'};
let externalEffects=0,assetReads=0;
const deny=()=>{externalEffects++;throw Error('unexpected-outbound');};
const common={modules:true,compatibilityDate:'2026-10-08',compatibilityFlags:['nodejs_compat'],cf:false};
const mf=new Miniflare(convertV4MiniflareOptions({cf:false,host:'127.0.0.1',outboundService:deny,workers:[
 {...common,name:'gateway',script:gatewayScript,bindings:{ORIGIN,ACCESS_TEAM:'fixture',ACCESS_AUD:'fixture-owner-gate',OWNER_EMAILS:email,JOB_STACK_POLICY_JSON:JSON.stringify({contract:'job-stack.owner-policy.v1',enabled:true,qualificationDigest:'a'.repeat(64),maxLeaseMs:60000})},durableObjects:{CONTROL:{className:'FixtureControl',useSQLite:true}},serviceBindings:{JOB_STACK:{name:'product',entrypoint:'JobStack'}},outboundService:request=>{assert.equal(request.url,'https://fixture.cloudflareaccess.com/cdn-cgi/access/certs');return Response.json({keys:[jwk]});}},
 {...common,name:'product',script:productScript,d1Databases:{DB:'synthetic'},durableObjects:{COORDINATOR:{className:'Coordinator',useSQLite:true}},serviceBindings:{CONTROL_AUTHORITY:{name:'gateway',entrypoint:'JobStackAuthority'},ASSETS:request=>{assetReads++;assert.equal(request.method,'GET');assert.equal(new URL(request.url).search,'');for(const key of ['cookie','authorization','cf-access-jwt-assertion','x-owner-nonce'])assert.equal(request.headers.get(key),null);return new Response('<!doctype html><p>Synthetic asset</p>',{headers:{'content-type':'text/html'}});}}},
]}));
try{
 const db=await mf.getD1Database('DB','product');const gatewayCwd=process.cwd();try{process.chdir(productDir);await applyMigrations(db);}finally{process.chdir(gatewayCwd);}const gateway=await mf.getWorker('gateway');
 const fetchOwner=(path,init={})=>{const headers=new Headers({'cf-access-jwt-assertion':token,...init.headers});if(headers.has('origin')){headers.set('x-fixture-request-origin',headers.get('origin'));headers.delete('origin');}return gateway.fetch(ORIGIN+path,{redirect:'manual',...init,headers});};
 await gateway.fetch(ORIGIN+'/__fixture_seed',{method:'POST',body:JSON.stringify({grant,cap})});
 assert.equal((await gateway.fetch(ORIGIN+'/owner/job-stack')).status,401);
 assert.equal((await gateway.fetch(ORIGIN+'/internal/job-stack/revalidate',{method:'POST'})).status,404);
 const establishPage=await fetchOwner('/owner/job-stack');assert.equal(establishPage.status,200);const html=await establishPage.text();const nonce=html.match(/name="nonce" value="([A-Za-z0-9_-]+)"/)?.[1];assert.ok(nonce);
 const foreign=await fetchOwner('/owner/job-stack/session/establish',{method:'POST',headers:{origin:'https://foreign.example','content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant:grant.id,nonce})});assert.equal(foreign.status,400);
 let response=await fetchOwner('/owner/job-stack/session/establish',{method:'POST',headers:{origin:ORIGIN,'content-type':'application/x-www-form-urlencoded'},body:new URLSearchParams({grant:grant.id,nonce})});assert.equal(response.status,303,await response.clone().text());
 response=await fetchOwner('/owner/job-stack?grant='+grant.id,{headers:{cookie:'synthetic=not-forwarded'}});assert.equal(response.status,200);assert.equal(assetReads,1);
 const target='/owner/job-stack/api/operations/job_stack_records?kind=opportunity';
 const invoke=async()=>{const r=await fetchOwner('/owner/job-stack/api/nonce?'+new URLSearchParams({grant:grant.id,target}));assert.equal(r.status,200);const n=(await r.json()).nonce;return fetchOwner(target+'&grant='+grant.id,{headers:{'x-owner-nonce':n}});};
 response=await invoke();assert.equal(response.status,200,await response.clone().text());assert.deepEqual(await response.json(),{items:[],nextCursor:null});
 assert.deepEqual(await (await gateway.fetch(ORIGIN+'/__fixture_calls')).json(),['read','read','before-ack']);
 await gateway.fetch(ORIGIN+'/__fixture_mode?mode=revoke-before-ack');response=await invoke();assert.equal(response.status,503);assert.deepEqual(await response.json(),{error:'job-stack-authority-unavailable'});
 assert.deepEqual(await (await gateway.fetch(ORIGIN+'/__fixture_calls')).json(),['read','read','before-ack']);
 assert.equal(externalEffects,0);for(const table of ['records','intents','recovery_versions'])assert.equal((await db.prepare('SELECT COUNT(*) n FROM '+table).first()).n,0);
 console.log('PASS: actual Control owner gate + lease/nonce + private authority + Product + Coordinator + D1 composition; reciprocal read/read/before-ack, revocation denial, sanitized assets; no provider effects. Synthetic identity and grants only.');
}finally{await mf.dispose();}
