// Offline synthetic owner-panel preview. No provider, vault, signer or mutation routes.
import {createServer} from 'node:http';
import {mkdir,writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {provisionerPanel} from '../src/capability-panes/provisioner.mjs';
import {provisionerClientResponse} from '../src/provisioner-client.mjs';

const context={env:{PROVISIONER_PRIVATE_ORIGIN:'https://provisioner.vespoli.me'}};
const config={ready:false,privateOrigin:context.env.PROVISIONER_PRIVATE_ORIGIN,audience:context.env.PROVISIONER_PRIVATE_ORIGIN,keyId:'a'.repeat(64),blockers:['owner-key-trust-not-configured','hardware-verifier-not-configured','runner-not-configured','provider-profile-not-qualified','encrypted-kv-not-configured'],profiles:[{id:'synthetic-b2-preview',digest:'S'.repeat(43),title:'B2 · synthetic preview',defaults:{secretUrl:'https://secure.backblaze.com/app_keys.htm','1passwordRecordUrl':'op://synthetic-input/provider-login',generatedCredentialType:'application-key',generatedCredentialName:'synthetic-backup-reader',duration:86400,permissions:[{fieldDomId:'read-files',value:true},{fieldDomId:'bucket-scope',value:'synthetic-backup'}]},display:{provider:'Backblaze B2 (synthetic)',outputVault:'synthetic-output',scope:'Read files in synthetic-backup',lifetime:'24 hours',kvDelivery:'Not configured — blocks live generation'}}]};
const page=async()=>{
  const response=await provisionerPanel(context,new Request('https://control.vespoli.me/owner/apps/provisioner'),'preview@example.invalid',{id:'provisioner'});
  const markup=(await response.text()).replace('<div class="provision-hero">','<p class="provision-help"><strong>Synthetic preview.</strong> No live account, vault or hardware signer is connected.</p><div class="provision-hero">');
  return new Response(markup,{headers:response.headers});
};
if(process.argv.includes('--write')){
  const index=process.argv.indexOf('--write'),directory=resolve(process.argv[index+1]||'/workspace/artifacts');
  await mkdir(directory,{recursive:true});
  const response=await page();
  const markup=(await response.text()).replace('<script src="/owner/apps/provisioner/client.js" defer></script>','').replace('Checking the approved profile, private service and hardware signer…','Setup required. This static preview has no live account, vault or hardware signer connected.');
  const path=resolve(directory,'provisioner-preview.html');await writeFile(path,markup);console.log(path);
}else{
  const server=createServer(async(req,res)=>{
    let response;
    if(req.method!=='GET')response=new Response('Preview has no mutation routes',{status:405});
    else if(req.url==='/owner/apps/provisioner/client.js')response=provisionerClientResponse();
    else if(req.url==='/owner/apps/provisioner/config')response=Response.json(config,{headers:{'cache-control':'no-store'}});
    else if(req.url==='/'||req.url==='/owner/apps/provisioner')response=await page();
    else response=new Response('Not found',{status:404});
    res.writeHead(response.status,Object.fromEntries(response.headers));res.end(await response.text());
  });
  server.listen(Number(process.env.PROVISIONER_DEMO_PORT||4178),'127.0.0.1',()=>console.log('Synthetic preview: http://127.0.0.1:'+server.address().port+'/owner/apps/provisioner'));
}
