import {spawn} from 'node:child_process';

/** The Playwright driver AND Chromium run under the network-restricted browser UID. */
export function createIsolatedBrowserFactory({spawnProcess=spawn,timeoutMs=25000}={}) {
  return async profile=>{
    const child=spawnProcess('/usr/bin/setpriv',['--reuid=10001','--regid=10001','--clear-groups','--no-new-privs','--bounding-set=-all','--inh-caps=-all','--ambient-caps=-all','/usr/bin/node','/opt/provisioner/runner/browser-helper.mjs'],{
      shell:false,env:{HOME:'/run/provisioner/browser',TMPDIR:'/run/provisioner/browser',LANG:'C.UTF-8',PATH:'/usr/bin:/bin',NODE_EXTRA_CA_CERTS:'/etc/cloudflare/certs/cloudflare-containers-ca.crt'},
      stdio:['ignore','ignore','ignore','ipc'],serialization:'json'
    });
    const pending=new Map();let nextID=0,closed=false;
    const fail=()=>{closed=true;for(const p of pending.values()){clearTimeout(p.timer);p.reject(new Error('browser-process-failed'));}pending.clear();child.kill('SIGKILL');};
    child.on('error',fail);child.on('exit',()=>{if(!closed)fail();});
    child.on('message',message=>{
      if(!message || Buffer.byteLength(JSON.stringify(message))>65536){fail();return;}
      const p=pending.get(message.id);if(!p){fail();return;}
      clearTimeout(p.timer);pending.delete(message.id);
      if(message.error)p.reject(new Error('browser-action-failed'));else p.resolve(message.result);
    });
    const call=(action,args)=>new Promise((resolve,reject)=>{
      if(closed){reject(new Error('browser-process-closed'));return;}
      const message={id:++nextID,action,args};
      if(Buffer.byteLength(JSON.stringify(message))>65536){reject(new Error('browser-message-limit'));return;}
      const timer=setTimeout(fail,timeoutMs);pending.set(message.id,{resolve,reject,timer});
      try{child.send(message,error=>{if(error)fail();});}catch{fail();}
    });
    try {await call('init',{profile});}catch {fail();throw new Error('browser-start-failed');}
    return {
      perform:(step,values)=>call('perform',{step,values}),
      capture:fields=>call('capture',{fields}),
      async close(){if(closed)return;try{await call('close',{});}finally{closed=true;child.kill('SIGTERM');}}
    };
  };
}
