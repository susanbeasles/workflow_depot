#!/usr/bin/env node
import {readFile} from 'node:fs/promises';
import {Socket} from 'node:net';
import {fileURLToPath} from 'node:url';
import {dirname,resolve} from 'node:path';
import {sha256,canonicalJSON,validateJobProfile,runProvisioningJob} from './provisioner.mjs';
import {verifyInstalledBundle} from './verify-bundle.mjs';
import {createOpAdapter} from './op-adapter.mjs';
import {createIsolatedBrowserFactory} from './isolated-browser.mjs';

const root=resolve(dirname(fileURLToPath(import.meta.url)),'..');
const parse=(bytes,code)=>{try{if(Buffer.byteLength(bytes)>1048576)throw new Error();return JSON.parse(bytes);}catch{throw new Error(code);}};
export async function runPinnedJob({configBytes,expectedConfigDigest,jobBytes,readToken,readRuntimeBinding,verifyBundle=verifyInstalledBundle,adapterFactory,opFactory=createOpAdapter,browserFactory}) {
  if(sha256(configBytes)!==expectedConfigDigest)throw new Error('config-digest-mismatch');
  const config=parse(configBytes,'config-invalid'),job=parse(jobBytes,'job-invalid');
  if(job?.state!=='accepted')throw new Error('accepted-job-required');
  if(config.manifestDigest!==sha256(canonicalJSON(config.profile?.manifest)))throw new Error('manifest-digest-mismatch');
  validateJobProfile({job,profile:config.profile,codeDigest:config.codeDigest});
  await verifyBundle({root,codeDigest:config.codeDigest});
  const createAdapters=adapterFactory || (await import('../infra/provisioner/runtime-adapters.mjs')).createRuntimeAdapters;
  const binding=readRuntimeBinding?await readRuntimeBinding():{};
  const runtime=await createAdapters({config,job,...binding});
  let op,token;
  try {
    if(!Number.isSafeInteger(binding.deadline)||Date.now()>=binding.deadline)throw Error('runtime-expired');
    token=await readToken();
    if(Date.now()>=binding.deadline)throw Error('runtime-expired');
    op=await opFactory({serviceAccountToken:token,tempRoot:'/run/provisioner'});token=undefined;
    return await runProvisioningJob({job,profile:config.profile,codeDigest:config.codeDigest,op,...runtime,browserFactory:browserFactory || createIsolatedBrowserFactory()});
  } finally {token=undefined;await op?.close?.();}
}

export function readTokenFromFD(fd=3) {
  return new Promise((resolve,reject)=>{
    let socket,settled=false,bytes=0;const chunks=[];
    const finish=error=>{if(settled)return;settled=true;clearTimeout(timer);socket?.destroy();
      if(error)reject(new Error('credential-pipe-invalid'));
      else {const buffer=Buffer.concat(chunks);resolve(buffer.toString('utf8'));buffer.fill(0);}
      for(const chunk of chunks)chunk.fill(0);chunks.length=0;
    };
    const timer=setTimeout(()=>finish(true),5000);
    try {socket=new Socket({fd,readable:true,writable:false});}catch{finish(true);return;}
    socket.on('data',chunk=>{bytes+=chunk.length;if(bytes>8192){chunk.fill(0);finish(true);}else chunks.push(chunk);});
    socket.on('error',()=>finish(true));socket.on('end',()=>finish(bytes===0));
  });
}
async function main() {
  const args=process.argv.slice(2),options={};
  if(args.length!==6)throw new Error('runner-arguments-invalid');
  for(let i=0;i<args.length;i+=2){if(!['--config','--config-sha256','--job'].includes(args[i])||Object.hasOwn(options,args[i]))throw new Error('runner-arguments-invalid');options[args[i]]=args[i+1];}
  const result=await runPinnedJob({configBytes:await readFile(options['--config'],'utf8'),expectedConfigDigest:options['--config-sha256'],jobBytes:await readFile(options['--job'],'utf8'),readToken:readTokenFromFD,readRuntimeBinding:async()=>{const value=parse(await readTokenFromFD(4),'runtime-binding-invalid');if(Object.keys(value).sort().join(',')!=='callbackToken,deadline')throw Error('runtime-binding-invalid');return value;}});
  process.stdout.write(JSON.stringify(result)+'\n');if(result.state!=='succeeded')process.exitCode=1;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(()=>{process.stdout.write('{"state":"failed","code":"runner-start-failed"}\n');process.exitCode=1;});
