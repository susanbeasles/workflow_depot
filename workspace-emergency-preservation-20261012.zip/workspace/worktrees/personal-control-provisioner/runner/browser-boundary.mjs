/** Checked before Playwright is loaded. No sandbox disable or privilege fallback. */
export function verifyBrowserBoundary(status) {
  const values=new Map();
  for(const line of status.split('\n')){const match=/^([A-Za-z]+):\s*(.*?)\s*$/.exec(line);if(match){if(values.has(match[1]))throw Error('browser_boundary_invalid');values.set(match[1],match[2]);}}
  for(const id of ['Uid','Gid'])if(values.get(id)?.split(/\s+/).join(',')!=='10001,10001,10001,10001')throw Error('browser_boundary_invalid');
  for(const capability of ['CapInh','CapPrm','CapEff','CapBnd','CapAmb'])if(!/^0{16}$/.test(values.get(capability)||''))throw Error('browser_boundary_invalid');
  if(values.get('NoNewPrivs')!=='1')throw Error('browser_boundary_invalid');
  return true;
}
