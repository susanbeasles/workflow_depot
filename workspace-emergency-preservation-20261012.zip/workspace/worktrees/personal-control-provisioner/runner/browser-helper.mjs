import {readFile} from 'node:fs/promises';
import {verifyBrowserBoundary} from './browser-boundary.mjs';
verifyBrowserBoundary(await readFile('/proc/self/status','utf8'));
const {chromium}=await import('playwright-core');
import {createBrowserFactory} from './browser.mjs';

// Only the fixed supervisor can access this IPC pipe. No op token or callback capability is inherited.
let session,busy=false;
process.on('disconnect',()=>{void session?.close().finally(()=>process.exit(0));});
process.on('message',async message=>{
  if(busy||!Number.isSafeInteger(message?.id)||Buffer.byteLength(JSON.stringify(message))>65536){process.exit(1);return;}
  busy=true;
  try {
    let result;
    switch(message.action) {
      case 'init':
        if(session)throw new Error('already-initialized');
        session=await createBrowserFactory({chromium,executablePath:'/usr/bin/chromium',tempRoot:'/run/provisioner/browser',proxy:{server:'http://127.0.0.1:18888'}})(message.args.profile);
        result={ok:true};break;
      case 'perform':await session.perform(message.args.step,message.args.values);result={ok:true};break;
      case 'capture':result=await session.capture(message.args.fields);break;
      case 'close':await session?.close();result={ok:true};break;
      default:throw new Error('unknown-action');
    }
    process.send({id:message.id,result});
  } catch {process.send({id:message.id,error:'browser-action-failed'});}
  finally {busy=false;}
});
