import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {validateLocator} from './provisioner.mjs';

/** Trusted selectors and data bindings only. No page evaluation, agent scripts, trace or screenshots. */
export function createBrowserFactory({chromium,executablePath='/usr/bin/chromium',tempRoot=tmpdir(),timeoutMs=15000,proxy}) {
  return async profile=>{
    const home=await mkdtemp(join(tempRoot,'provisioner-browser-'));
    let instance,context,page,fatal=false;
    const originAllowed=value=>{try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password&&profile.allowedOrigins.includes(url.origin);}catch{return false;}};
    const ensure=()=>{if(fatal)throw new Error('browser-egress-blocked');if(page?.url()!=='about:blank'&&!originAllowed(page?.url()))throw new Error('browser-origin-invalid');};
    const cleanup=async()=>{try{await context?.close();}finally{try{await instance?.close();}finally{await rm(home,{recursive:true,force:true});}}};
    try {
      instance=await chromium.launch({executablePath,headless:true,chromiumSandbox:true,env:{HOME:home,TMPDIR:home,LANG:'C.UTF-8'},...(proxy?{proxy}:{}),args:['--disable-background-networking','--disable-component-update','--force-webrtc-ip-handling-policy=disable_non_proxied_udp']});
      context=await instance.newContext({acceptDownloads:false,serviceWorkers:'block',permissions:[],ignoreHTTPSErrors:false,...(proxy?{proxy}:{})});
      await context.route('**/*',async route=>{
        const request=route.request();
        if(!originAllowed(request.url())||request.redirectedFrom()||['websocket','eventsource'].includes(request.resourceType())){fatal=true;await route.abort('blockedbyclient');return;}
        let response;
        try {
          // continue() can follow redirect chains outside the route handler. Fetch exactly
          // one hop, then fulfill locally; neither redirects nor network retries are allowed.
          response=await route.fetch({maxRedirects:0,maxRetries:0,timeout:timeoutMs});
          if(response.status()>=300&&response.status()<400){fatal=true;await route.abort('blockedbyclient');return;}
          await route.fulfill({response});
        } catch {fatal=true;try{await route.abort('blockedbyclient');}catch{}}
        finally {await response?.dispose?.();}
      });
      // HTTP routing does not intercept WebSocket handshakes.
      if(typeof context.routeWebSocket!=='function')throw new Error('browser-websocket-guard-required');
      await context.routeWebSocket('**/*',socket=>{fatal=true;socket.close();});
      context.on('page',opened=>{if(page&&opened!==page){fatal=true;void opened.close().catch(()=>{});}});
      page=await context.newPage();page.setDefaultTimeout(timeoutMs);page.setDefaultNavigationTimeout?.(timeoutMs);
      page.on('download',download=>{fatal=true;void download.cancel().catch(()=>{});});
      page.on('dialog',dialog=>{fatal=true;void dialog.dismiss().catch(()=>{});});
      const locate=async spec=>{
        ensure();let locator;
        if(profile.manifest?.version===2) {
          if(!Object.hasOwn(profile.manifest.locators,spec.locator))throw new Error('browser-locator-unreviewed');
          const approved=validateLocator(profile.manifest.locators[spec.locator]);
          if(approved.kind==='css')locator=page.locator('css='+approved.value);
          else if(approved.kind==='role')locator=page.getByRole(approved.role,{name:approved.name,exact:true});
          else locator=page.getByLabel(approved.value,{exact:true});
          await locator.waitFor({state:'visible'});
        } else locator=page.locator(spec.selector);
        if(await locator.count()!==1)throw new Error('browser-selector-not-unique');return locator;
      };
      return {
        async perform(step,values) {
          ensure();
          if(step.action==='goto') {
            const url=values.payload[step.url];if(!originAllowed(url))throw new Error('browser-origin-invalid');
            await page.goto(url,{waitUntil:'domcontentloaded'});
          } else {
            const target=await locate(step);
            if(profile.manifest?.version===2) {
              const expectedID=step.input?values.payload[{username:'uDomId',password:'pwdDomId',otp:'otpDomId'}[step.input]]:step.permission;
              if(expectedID!==undefined&&await target.getAttribute('id')!==expectedID)throw new Error('browser-dom-id-mismatch');
            }
            let value;
            if(step.input)value=values.inputs[step.input];
            else if(step.value)value=step.value==='credentialName'?values.credentialName:values.payload.duration;
            else if(step.permission)value=values.payload.permissions.find(p=>p.fieldDomId===step.permission)?.value;
            switch(step.action) {
              case 'fill':await target.fill(String(value));break;
              case 'select':await target.selectOption(String(value));break;
              case 'check':if(typeof value!=='boolean')throw new Error('browser-value-invalid');await target.setChecked(value);break;
              case 'click':await target.click();break;
              case 'wait':await target.waitFor({state:'visible'});break;
              default:throw new Error('browser-action-invalid');
            }
          }
          ensure();
        },
        async capture(fields) {
          ensure();const result={};
          for(const [name,spec] of Object.entries(fields)) {
            const target=await locate(spec);await target.waitFor({state:'visible'});
            result[name]=spec.read==='input'?await target.inputValue():(await target.textContent())?.trim();
          }
          ensure();return result;
        },
        close:cleanup
      };
    } catch {await cleanup();throw new Error('browser-start-failed');}
  };
}
