import {spawn} from 'node:child_process';
import {mkdtemp,mkdir,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {validateInputReferences,validateOutputFields} from './provisioner.mjs';

/** Captures bounded output in memory; never logs stderr or attaches secret output to errors. */
export function boundedExec({executable,args,env,input='',timeoutMs=20000,maxBytes=65536}) {
  return new Promise((resolve,reject)=>{
    let child,settled=false,size=0;const stdout=[];
    const done=(error)=>{if(settled)return;settled=true;clearTimeout(timer);if(error){child?.kill('SIGKILL');stdout.length=0;reject(new Error(error));}else{resolve(Buffer.concat(stdout).toString('utf8'));stdout.length=0;}};
    const timer=setTimeout(()=>done('op-timeout'),timeoutMs);
    try {child=spawn(executable,args,{env,stdio:['pipe','pipe','pipe'],shell:false,windowsHide:true});}catch {done('op-command-failed');return;}
    child.on('error',()=>done('op-command-failed'));
    child.stdout.on('data',chunk=>{size+=chunk.length;if(size>maxBytes)done('op-output-limit');else stdout.push(chunk);});
    child.stderr.on('data',chunk=>{size+=chunk.length;if(size>maxBytes)done('op-output-limit');});
    child.stdin.on('error',()=>done('op-command-failed'));
    child.on('close',code=>done(code===0?null:'op-command-failed'));
    child.stdin.end(input);
  });
}
const validID = value => typeof value==='string' && /^[A-Za-z0-9_-]{1,128}$/.test(value);
function parseJSON(value) {try{return JSON.parse(value);}catch{throw new Error('op-response-invalid');}}

export async function createOpAdapter({serviceAccountToken,run=boundedExec,tempRoot=tmpdir()}) {
  if(typeof serviceAccountToken!=='string'||!serviceAccountToken||serviceAccountToken.length>8192)throw new Error('op-token-required');
  const home=await mkdtemp(join(tempRoot,'provisioner-op-'));
  const config=join(home,'config'),runtime=join(home,'runtime');
  await mkdir(config,{mode:0o700});await mkdir(runtime,{mode:0o700});
  const env={PATH:'/usr/bin:/bin',HOME:home,OP_CONFIG_DIR:config,XDG_RUNTIME_DIR:runtime,LANG:'C.UTF-8',OP_SERVICE_ACCOUNT_TOKEN:serviceAccountToken,OP_CACHE:'false'};
  let closed=false;
  const command=async(args,input='')=>{if(closed)throw new Error('op-adapter-closed');try{return await run({executable:'/usr/local/bin/op',args,env,input,timeoutMs:20000,maxBytes:65536});}catch{throw new Error('op-command-failed');}};
  return {
    async readInputs(profile) {
      validateInputReferences(profile);
      const result={};
      for(const [field,ref] of Object.entries(profile.inputFields)) {
        const value=await command(['read',ref+(field==='otp'?'?attribute=otp':''),'--no-newline']);
        if(typeof value!=='string'||!value||value.length>8192)throw new Error('op-field-invalid');
        result[field]=value;
      }
      return result;
    },
    async saveCredential({vault,title,credential,outputFields=[{capture:'keyId',id:'key_id',label:'keyID',type:'STRING'},{capture:'applicationKey',id:'application_key',label:'applicationKey',type:'CONCEALED'}]}) {
      if(!validID(vault)||typeof title!=='string'||!title||title.length>128||/[\x00-\x1f\x7f]/.test(title)||!credential||typeof credential!=='object')throw new Error('op-output-invalid');
      validateOutputFields(outputFields,Object.keys(credential));
      if(!Object.values(credential).every(value=>typeof value==='string'&&value.length>0&&value.length<=4096&&!/[\x00-\x1f\x7f]/.test(value)))throw new Error('op-output-invalid');
      // A Secure Note with explicitly concealed custom fields is a supported JSON item template.
      const fields=outputFields.map(({capture,id,label,type})=>({id,label,type,value:credential[capture]}));
      const created=parseJSON(await command(['item','create','--vault',vault,'--format','json','-'],JSON.stringify({title,category:'SECURE_NOTE',fields})));
      if(!validID(created?.id)||created.vault?.id!==vault)throw new Error('op-create-receipt-invalid');
      const checked=parseJSON(await command(['item','get',created.id,'--vault',vault,'--format','json']));
      if(checked.id!==created.id||checked.vault?.id!==vault||!Array.isArray(checked.fields)||!fields.every(f=>checked.fields.some(actual=>actual.id===f.id&&actual.value===f.value&&actual.type===f.type)))throw new Error('op-verification-failed');
      return {itemId:created.id,vaultId:vault};
    },
    async close() {if(closed)return;closed=true;env.OP_SERVICE_ACCOUNT_TOKEN='';serviceAccountToken='';await rm(home,{recursive:true,force:true});}
  };
}
