import {lstat,readFile,readdir} from 'node:fs/promises';
import {join} from 'node:path';
import {canonicalJSON,sha256} from './provisioner.mjs';

export const REQUIRED_BUNDLE_FILES=Object.freeze([
  ...['run','provisioner','browser','op-adapter','verify-bundle','isolated-browser','browser-helper','browser-boundary'].map(n=>`runner/${n}.mjs`),
  'runner/package-lock.json',
  ...['runtime-adapters','launcher','bootstrap','container-server','egress-proxy','verify-toolchain'].map(n=>`infra/provisioner/${n}.mjs`),
  'infra/provisioner/boot.sh','infra/provisioner/chromium-wrapper','infra/provisioner/package-lock.json'
]);
export async function collectBundleFiles(root) {
  const files={};
  async function walk(relative) {
    const entries=await readdir(join(root,relative),{withFileTypes:true});
    for(const entry of entries.sort((a,b)=>a.name.localeCompare(b.name))) {
      if(['.bin','fixtures','config'].includes(entry.name)||entry.name==='bundle-manifest.json'||entry.name.endsWith('.md'))continue;
      const name=relative+'/'+entry.name;
      if(entry.isSymbolicLink())throw new Error('bundle-symlink-prohibited');
      if(entry.isDirectory())await walk(name);
      else if(entry.isFile())files[name]=sha256(await readFile(join(root,name)));
      else throw new Error('bundle-file-invalid');
    }
  }
  for(const dir of ['runner','infra/provisioner']) {
    if(!(await lstat(join(root,dir))).isDirectory())throw new Error('bundle-directory-invalid');
    await walk(dir);
  }
  return files;
}
export async function verifyInstalledBundle({root,codeDigest}) {
  const manifestPath=join(root,'bundle-manifest.json');
  if(!(await lstat(manifestPath)).isFile())throw new Error('bundle-manifest-invalid');
  let manifest;try{manifest=JSON.parse(await readFile(manifestPath,'utf8'));}catch{throw new Error('bundle-manifest-invalid');}
  if(manifest?.version!==1||!manifest.files||Object.keys(manifest).sort().join(',')!=='files,version'||sha256(canonicalJSON(manifest))!==codeDigest)throw new Error('bundle-digest-mismatch');
  if(!REQUIRED_BUNDLE_FILES.every(name=>Object.hasOwn(manifest.files,name)))throw new Error('bundle-file-missing');
  const actual=await collectBundleFiles(root);
  if(canonicalJSON(actual)!==canonicalJSON(manifest.files))throw new Error('bundle-file-mismatch');
  return true;
}
