import {createHash} from 'node:crypto';

export const KNOWN_OPERATIONS = Object.freeze(['generate-api-key','rotate-password','rotate-recovery-codes','rotate-totp','create-passkey','rotate-passkey']);
export const sha256 = value => createHash('sha256').update(value).digest('base64url');
export function canonicalJSON(value) {
  return JSON.stringify(order(value));
}
function order(value) { return Array.isArray(value) ? value.map(order) : value && typeof value === 'object' ? Object.fromEntries(Object.keys(value).sort().map(k => [k,order(value[k])])) : value; }
function requireValue(ok, code) { if(!ok) throw new Error(code); }
const id = value => typeof value === 'string' && /^[a-zA-Z0-9_-]{1,128}$/.test(value);
const label = value => typeof value === 'string' && value.length > 0 && value.length <= 128 && !/[\x00-\x1f\x7f]/.test(value);
const receiptID = value => typeof value === 'string' && value.length > 0 && value.length <= 2048 && !/[\x00-\x1f\x7f]/.test(value);
const selector = value => typeof value === 'string' && /^#[A-Za-z][A-Za-z0-9_:-]{0,127}$/.test(value);
const plain = value => value && Object.getPrototypeOf(value) === Object.prototype;
const payloadKeys = new Set(['operation','uDomId','pwdDomId','otpDomId','loginUrl','secretUrl','1passwordRecordUrl','recordType','generatedCredentialName','generatedCredentialType','duration','KV','toVault','permissions']);
const equal = (a,b) => canonicalJSON(a) === canonicalJSON(b);
const legacyFields=Object.freeze([{capture:'keyId',id:'key_id',label:'keyID',type:'STRING'},{capture:'applicationKey',id:'application_key',label:'applicationKey',type:'CONCEALED'}]);

export function validateLocator(locator) {
  requireValue(plain(locator),'manifest-locator-unreviewed');
  if(locator.kind==='css') {
    // Only simple native CSS compounds: no other selector engines or expressions.
    requireValue(Object.keys(locator).sort().join(',')==='kind,value' && typeof locator.value==='string' && locator.value.length>0 && locator.value.length<=256 && /^(?:[A-Za-z][A-Za-z0-9-]*)?(?:[.#][A-Za-z_][A-Za-z0-9_-]*|\[(?:id|name|type|role|aria-label|data-[a-z0-9-]+)="[A-Za-z0-9 _.\/:-]{1,128}"\])*$/.test(locator.value),'manifest-locator-invalid');
  } else if(locator.kind==='role') {
    requireValue(Object.keys(locator).sort().join(',')==='kind,name,role' && ['button','link','textbox','checkbox','combobox','option','tab','radio','heading','status','region'].includes(locator.role) && label(locator.name),'manifest-locator-invalid');
  } else if(locator.kind==='label')requireValue(Object.keys(locator).sort().join(',')==='kind,value' && label(locator.value),'manifest-locator-invalid');
  else throw new Error('manifest-locator-invalid');
  return locator;
}

export function validateOutputFields(outputFields,captures) {
  requireValue(Array.isArray(outputFields) && outputFields.length>0 && outputFields.length<=8 && Array.isArray(captures),'output-fields-invalid');
  const ids=new Set(),names=new Set();
  for(const field of outputFields) {
    requireValue(plain(field) && Object.keys(field).sort().join(',')==='capture,id,label,type' && id(field.capture) && id(field.id) && label(field.label) && ['STRING','CONCEALED'].includes(field.type) && captures.includes(field.capture) && !ids.has(field.id) && !names.has(field.capture),'output-fields-invalid');
    ids.add(field.id);names.add(field.capture);
  }
  requireValue(names.size===captures.length && outputFields.some(field=>field.type==='CONCEALED'),'output-fields-invalid');
  return outputFields;
}

function namePolicy(profile) {
  const policy=profile.namePolicy??(profile.manifest?.version===1&&profile.provider==='b2'?{allowedCharacters:'alphanumeric-hyphen',maxLength:100}:null);
  requireValue(plain(policy) && Object.keys(policy).sort().join(',')==='allowedCharacters,maxLength' && ['alphanumeric-hyphen','printable-ascii'].includes(policy.allowedCharacters) && Number.isSafeInteger(policy.maxLength) && policy.maxLength>=1 && policy.maxLength<=128,'provider-name-policy-required');
  return policy;
}

export function validateInputReferences(profile) {
  requireValue(/^op:\/\/[a-z0-9]{26}\/[a-z0-9]{26}$/.test(profile?.sourceRecord || ''),'input-reference-invalid');
  requireValue(plain(profile.inputFields) && typeof profile.inputFields.username==='string' && typeof profile.inputFields.password==='string','input-reference-invalid');
  for(const [name, ref] of Object.entries(profile.inputFields)) {
    requireValue(['username','password','otp'].includes(name) && typeof ref==='string' && ref.startsWith(profile.sourceRecord+'/'),'input-reference-invalid');
    const suffix=ref.slice(profile.sourceRecord.length+1);
    requireValue(/^[A-Za-z0-9_-]+(?:\/[A-Za-z0-9_-]+)?$/.test(suffix),'input-reference-invalid');
  }
}

function validateManifest(profile) {
  const manifest=profile.manifest;
  requireValue([1,2].includes(manifest?.version) && manifest.qualified===true,'manifest-unqualified');
  const generic=manifest.version===2;
  if(generic) {
    requireValue(plain(manifest.locators) && Object.keys(manifest.locators).length>0 && Object.keys(manifest.locators).length<=64,'manifest-locator-invalid');
    for(const [name,locator] of Object.entries(manifest.locators)){requireValue(id(name),'manifest-locator-invalid');validateLocator(locator);}
  }
  const targetKey=generic?'locator':'selector';
  const target=step=>{
    if(generic)requireValue(id(step.locator)&&Object.hasOwn(manifest.locators,step.locator),'manifest-locator-unreviewed');
    else requireValue(selector(step.selector),'manifest-selector-invalid');
  };
  requireValue(Array.isArray(manifest.login) && Array.isArray(manifest.prepare) && manifest.login.length<=20 && manifest.prepare.length<=64,'manifest-invalid');
  const permissions=new Map(profile.constraints.permissions.map(p=>[p.fieldDomId,p.value]));
  const applied=new Set();
  const values=new Set();
  const writes=new Set();
  for(const [phase,steps] of [['login',manifest.login],['prepare',manifest.prepare]]) {
    for(const step of steps) {
      requireValue(plain(step) && Object.keys(step).every(k=>['action',targetKey,'url','input','value','permission'].includes(k)),'manifest-action-invalid');
      requireValue(['goto','fill','select','check','click','wait'].includes(step.action),'manifest-action-invalid');
      if(step.action==='goto') {
        requireValue(['loginUrl','secretUrl'].includes(step.url) && !!profile.constraints[step.url] && Object.keys(step).length===2,'manifest-url-invalid');
        continue;
      }
      target(step);
      if(['click','wait'].includes(step.action)) { requireValue(Object.keys(step).length===2,'manifest-action-invalid');continue; }
      const sources=['input','value','permission'].filter(k=>Object.hasOwn(step,k));
      requireValue(sources.length===1 && Object.keys(step).length===3,'manifest-source-invalid');
      if(step.input) {
        requireValue(phase==='login' && step.action==='fill' && Object.hasOwn(profile.inputFields,step.input),'manifest-input-invalid');
        const dom={username:'uDomId',password:'pwdDomId',otp:'otpDomId'}[step.input];
        if(!generic&&profile.constraints[dom])requireValue(step.selector==='#'+profile.constraints[dom],'manifest-input-invalid');
      } else if(step.value) {
        requireValue(phase==='prepare' && step.action==='fill' && ['credentialName','duration'].includes(step.value),'manifest-value-invalid');
        if(step.value==='duration')requireValue(profile.constraints.duration!==undefined,'manifest-value-invalid');
        requireValue(!values.has(step.value),'manifest-value-duplicate');values.add(step.value);
      } else {
        requireValue(phase==='prepare' && permissions.has(step.permission) && (generic||step.selector==='#'+step.permission) && !applied.has(step.permission),'manifest-permission-invalid');
        requireValue(step.action==='check' ? typeof permissions.get(step.permission)==='boolean' : ['fill','select'].includes(step.action) && ['string','number'].includes(typeof permissions.get(step.permission)),'manifest-permission-invalid');
        applied.add(step.permission);
      }
      if(phase==='prepare'){
        const identity=generic?canonicalJSON(manifest.locators[step.locator]):step.selector;
        requireValue(!writes.has(identity),'manifest-target-reused');writes.add(identity);
      }
    }
  }
  requireValue(applied.size===permissions.size,'manifest-permission-missing');
  requireValue(values.has('credentialName') && (profile.constraints.duration===undefined || values.has('duration')),'manifest-value-missing');
  requireValue(manifest.submit?.action==='click' && Object.keys(manifest.submit).length===2,'manifest-submit-invalid');target(manifest.submit);
  requireValue(plain(manifest.capture) && Object.keys(manifest.capture).length>0 && Object.keys(manifest.capture).length<=8 && Object.keys(manifest.capture).every(id),'manifest-capture-invalid');
  if(!generic)requireValue(Object.keys(manifest.capture).sort().join(',')==='applicationKey,keyId','manifest-capture-invalid');
  for(const capture of Object.values(manifest.capture)){requireValue(plain(capture) && Object.keys(capture).length===2 && ['text','input'].includes(capture.read),'manifest-capture-invalid');target(capture);}
  return validateOutputFields(generic?profile.outputFields:legacyFields,Object.keys(manifest.capture));
}

export function validateJobProfile({job,profile,codeDigest}) {
  requireValue(plain(job) && id(job.id) && label(job.owner) && plain(job.payload) && typeof job.rawPayload==='string' && Buffer.byteLength(job.rawPayload)<=32768,'job-invalid');
  requireValue(sha256(job.rawPayload)===job.payloadHash,'payload-digest-mismatch');
  let parsed;try { parsed=JSON.parse(job.rawPayload); } catch { throw new Error('payload-invalid'); }
  requireValue(equal(parsed,job.payload),'payload-object-mismatch');
  requireValue(plain(profile) && typeof profile.provider==='string' && /^[a-z0-9][a-z0-9-]{0,63}$/.test(profile.provider) && (profile.manifest?.version===2||profile.provider==='b2') && profile.operation==='generate-api-key','provider-unqualified');
  requireValue(job.context?.profileId===profile.id && job.context.profileDigest===sha256(canonicalJSON(profile)),'profile-digest-mismatch');
  requireValue(typeof codeDigest==='string' && codeDigest.length>0 && job.context.codeDigest===codeDigest,'code-digest-mismatch');
  requireValue(job.context.manifestDigest===sha256(canonicalJSON(profile.manifest)),'manifest-digest-mismatch');
  const p=job.payload,c=profile.constraints;
  requireValue(p.operation==='generate-api-key','operation-disabled');
  requireValue(Object.keys(p).every(k=>payloadKeys.has(k)),'payload-field-invalid');
  requireValue(plain(c) && Array.isArray(c.permissions) && c.permissions.length<=32,'profile-constraints-invalid');
  requireValue(c.duration===undefined || Number.isSafeInteger(c.duration)&&c.duration>0,'duration-invalid');
  requireValue(Array.isArray(p.permissions) && equal(p.permissions,c.permissions),'permissions-not-approved');
  const ids=new Set();
  for(const permission of p.permissions) {
    requireValue(plain(permission) && Object.keys(permission).sort().join(',')==='fieldDomId,value' && id(permission.fieldDomId) && !ids.has(permission.fieldDomId),'permissions-invalid');
    requireValue(['string','number','boolean'].includes(typeof permission.value) && (typeof permission.value!=='number'||Number.isFinite(permission.value)),'permissions-invalid');
    ids.add(permission.fieldDomId);
  }
  for(const field of ['secretUrl','1passwordRecordUrl','generatedCredentialType'])requireValue(equal(p[field],c[field]),'payload-not-approved');
  for(const field of ['uDomId','pwdDomId','otpDomId','loginUrl','recordType','duration'])if(p[field]!==undefined)requireValue(equal(p[field],c[field]),'payload-not-approved');
  if(p.generatedCredentialName!==undefined)requireValue(label(p.generatedCredentialName) && (c.generatedCredentialName===undefined || p.generatedCredentialName===c.generatedCredentialName),'credential-name-invalid');
  // The generic requested label is deliberately not rewritten into a vendor-specific name.
  const credentialName=p.generatedCredentialName??c.generatedCredentialName??'Provisioner secret #'+job.id;
  const names=namePolicy(profile),characters=names.allowedCharacters==='alphanumeric-hyphen'?/^[A-Za-z0-9-]+$/:/^[\x20-\x7e]+$/;
  requireValue(typeof credentialName==='string' && credentialName.length<=names.maxLength && characters.test(credentialName),'provider-name-invalid');
  requireValue(typeof p.generatedCredentialType==='string' && typeof p.secretUrl==='string' && p['1passwordRecordUrl']===profile.sourceRecord,'profile-constraints-invalid');
  requireValue(p.KV===undefined || typeof p.KV==='boolean','kv-invalid');
  requireValue(/^[a-z0-9]{26}$/.test(profile.outputVault || '') && profile.outputVault!==profile.sourceRecord?.split('/')[2] && (p.toVault===undefined || p.toVault===c.toVault),'output-vault-not-approved');
  requireValue(label(profile.itemTitle),'output-title-required');
  requireValue(c.recordType===undefined || ['SECURE_NOTE','Secure Note'].includes(c.recordType),'record-type-disabled');
  requireValue(Array.isArray(profile.allowedOrigins) && profile.allowedOrigins.length>0 && profile.allowedOrigins.length<=8,'origin-policy-invalid');
  for(const origin of profile.allowedOrigins) {
    let url;try {url=new URL(origin);} catch {throw new Error('origin-policy-invalid');}
    requireValue(url.protocol==='https:' && url.origin===origin && !url.username && !url.password,'origin-policy-invalid');
  }
  for(const urlValue of [p.loginUrl??c.loginUrl,p.secretUrl].filter(v=>v!==undefined)) {
    let url;try{url=new URL(urlValue);}catch{throw new Error('url-not-approved');}
    requireValue(profile.allowedOrigins.includes(url.origin) && !url.username && !url.password && !url.hash,'url-not-approved');
  }
  validateInputReferences(profile);
  const outputFields=validateManifest(profile);
  return Object.freeze({kvEnabled:p.KV!==false,credentialName,itemTitle:profile.itemTitle,outputFields,payload:Object.freeze({...c,...p})});
}

function validCredential(credential,fields) {
  const names=fields.map(field=>field.capture).sort();
  return plain(credential) && equal(Object.keys(credential).sort(),names) && names.every(k=>typeof credential[k]==='string' && credential[k].length>0 && credential[k].length<=4096 && !/[\x00-\x1f\x7f]/.test(credential[k]));
}

/** No secret material escapes this boundary. On an ambiguous mutation the same job is never reissued. */
export async function runProvisioningJob({job,profile,browserFactory,op,kv,recovery,journal,codeDigest}) {
  let settings;
  try {
    settings=validateJobProfile({job,profile,codeDigest});
    requireValue(typeof browserFactory==='function' && typeof op?.readInputs==='function' && typeof op?.saveCredential==='function' && typeof journal?.reserve==='function' && typeof journal?.update==='function','runtime-unavailable');
    requireValue(profile.recovery?.destination && profile.recovery?.encryptionKeyId && recovery?.encrypted===true && recovery.durable===true && recovery.destination===profile.recovery.destination && typeof recovery.capture==='function','durable-recovery-required');
    if(settings.kvEnabled)requireValue(profile.kv?.destination && profile.kv?.encryptionKeyId && kv?.encrypted===true && kv.unwrapSeparate===true && kv.destination===profile.kv.destination && typeof kv.putEncrypted==='function','encrypted-kv-required');
  } catch(error) {try{await op?.close?.();}catch{}throw error;}
  let session,inputs,credential,reserved=false,recovered=false;
  const record={jobId:job.id,payloadHash:job.payloadHash};
  try {
    inputs=await op.readInputs(profile);
    requireValue(plain(inputs) && Object.keys(profile.inputFields).every(k=>typeof inputs[k]==='string' && inputs[k].length>0),'input-read-failed');
    session=await browserFactory(profile);
    const context={payload:settings.payload,inputs,credentialName:settings.credentialName};
    for(const step of [...profile.manifest.login,...profile.manifest.prepare])await session.perform(step,context);
    reserved=await journal.reserve(record);
    if(reserved!==true)return {jobId:job.id,state:'blocked',code:'mutation-already-reserved'};
    await session.perform(profile.manifest.submit,context);
    credential=await session.capture(profile.manifest.capture);
    requireValue(validCredential(credential,settings.outputFields),'credential-capture-invalid');
    const checkpoint=await recovery.capture({...record,credential});
    requireValue(receiptID(checkpoint?.id),'recovery-receipt-invalid');
    recovered=true;
    await journal.update({...record,state:'captured',recoveryId:checkpoint.id});
    const saved=await op.saveCredential({vault:profile.outputVault,title:settings.itemTitle,credential,outputFields:settings.outputFields});
    requireValue(id(saved?.itemId) && saved?.vaultId===profile.outputVault,'output-receipt-invalid');
    await journal.update({...record,state:'vault-saved',itemId:saved.itemId,vaultId:saved.vaultId});
    let copied;
    if(settings.kvEnabled) { copied=await kv.putEncrypted({...record,credential});requireValue(receiptID(copied?.id),'kv-receipt-invalid'); }
    const receipt={jobId:job.id,state:'succeeded',itemId:saved.itemId,vaultId:saved.vaultId,...(copied?{kvId:copied.id}:{})};
    await journal.update({...record,...receipt});
    return receipt;
  } catch {
    const state=reserved?(recovered?'recovery-required':'uncertain'):'failed';
    try {await journal.update({...record,state});}catch { /* The durable reservation still prevents reissue. */ }
    return {jobId:job.id,state,code:reserved?'manual-reconciliation-required':'execution-failed'};
  } finally {
    inputs=undefined;credential=undefined;
    try {await session?.close();}catch { /* Local session teardown never revokes the issued credential. */ }
    try {await op.close?.();}catch { /* Do not print subprocess errors or secret-bearing diagnostics. */ }
  }
}
