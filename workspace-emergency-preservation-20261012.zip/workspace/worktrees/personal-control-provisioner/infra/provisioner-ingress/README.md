# Provisioner admission ingress source

This adapter forwards only `POST` and `OPTIONS` for
`https://provisioner.vespoli.me/owner/apps/provisioner/challenge` and
`https://provisioner.vespoli.me/owner/apps/provisioner/submit` with the exact browser
Origin `https://control.vespoli.me`. Its sole destination is the declared private
`personal-control:ProvisionerAdmission` service binding. It has no public config,
status, arbitrary target, credential issuer or provider endpoint.

The adapter forwards the original request stream and headers without an application
body read, clone, parse, hash, buffer or Content-Length check. HTTP transport can
pull bytes while forwarding; this is not a claim that no transport buffering occurs.
Existing Control Access verification,
current signing trust, signatures and nonce state retain authority. In particular,
the submit byte limit is applied by Control after signature verification and atomic
nonce consumption. The adapter limits the response to 64 KiB and the forwarding
attempt to 15 seconds, strips unneeded response headers, rejects redirects and
never retries. A timeout is an ambiguous outcome: it does not establish that Control
rejected the request or that a nonce remains available. Use the existing owner job
status for reconciliation.

The checked-in Wrangler source is disabled (`ENABLED="false"`), has no routes,
and disables workers.dev, preview URLs and observability. No credentials or secret
bindings are added. The flag is an operator kill switch, **not** evidence of private
network, Access or device qualification. No configuration route can enable it.

Activation still requires independently reviewed owned-host routing and actual
Access/device/private-ingress policy, the existing Control Access audience and
assertion verification, exact matching `PROVISIONER_PRIVATE_ORIGIN`/`ORIGIN` in
Control, and the named entrypoint deployed under the reviewed service identity.
Unauthenticated browser preflight handling must be qualified with that policy;
the adapter delegates OPTIONS to the existing entrypoint and grants no authority.
No route, Access application, binding deployment or live qualification is implied
by this source or its synthetic local tests.

The forwarding mechanism uses Cloudflare's documented
[HTTP service binding](https://developers.cloudflare.com/workers/runtime-apis/bindings/service-bindings/http/).
Run the offline regression and actual Workerd composition with
`node --test test/provisioner-ingress.test.mjs` from the repository root.
