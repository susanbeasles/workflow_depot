// These are reviewed source identities, not caller-selected forwarding targets.
const ADMISSION_ORIGIN='https://provisioner.vespoli.me';
const OWNER_ORIGIN='https://control.vespoli.me';
const PATHS=new Set(['/owner/apps/provisioner/challenge','/owner/apps/provisioner/submit']);
const TIMEOUT_MS=15000,MAX_RESPONSE_BYTES=65536;
const CORS={
 'access-control-allow-origin':OWNER_ORIGIN,
 'access-control-allow-credentials':'true',
 'vary':'Origin',
};
function headers(){return new Headers({...CORS,'cache-control':'no-store','x-content-type-options':'nosniff'});}
function error(code,status){return Response.json({error:code},{status,headers:headers()});}

async function boundedResponse(response,signal){
 const cancelBody=()=>{void response.body?.cancel().catch(()=>{});};
 if(signal.aborted){cancelBody();signal.throwIfAborted();}
 if(response.status>=300&&response.status<400){cancelBody();throw Error('redirect-denied');}
 const outputHeaders=headers();
 if(response.status===204){
  for(const name of ['access-control-allow-methods','access-control-allow-headers','access-control-max-age']){
   const value=response.headers.get(name);if(value!==null)outputHeaders.set(name,value);
  }
  return new Response(null,{status:204,headers:outputHeaders});
 }
 if(!/^application\/json(?:\s*;|$)/i.test(response.headers.get('content-type')??'')){cancelBody();throw Error('response-type-invalid');}
 if(!response.body)throw Error('response-body-missing');
 const reader=response.body.getReader(),chunks=[];let size=0;
 const cancel=()=>{void reader.cancel().catch(()=>{});};
 signal.addEventListener('abort',cancel,{once:true});
 try{
  while(true){
   signal.throwIfAborted();const {done,value}=await reader.read();signal.throwIfAborted();
   if(done)break;
   size+=value.byteLength;if(size>MAX_RESPONSE_BYTES)throw Error('response-too-large');
   chunks.push(value);
  }
  const bytes=new Uint8Array(size);let offset=0;
  for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.byteLength;}
  outputHeaders.set('content-type','application/json; charset=utf-8');
  return new Response(bytes,{status:response.status,headers:outputHeaders});
 }catch(error){cancel();throw error;}
 finally{signal.removeEventListener('abort',cancel);reader.releaseLock();}
}

export default {
 async fetch(request,env){
  const url=new URL(request.url);
  if(url.origin!==ADMISSION_ORIGIN||!PATHS.has(url.pathname)||url.search||url.hash||url.username||url.password||request.headers.get('origin')!==OWNER_ORIGIN)return error('not-found',404);
  if(request.method!=='POST'&&request.method!=='OPTIONS')return error('method-not-allowed',405);
  if(env.ENABLED!=='true'||typeof env.PROVISIONER_ADMISSION?.fetch!=='function')return error('provisioner-ingress-disabled',503);
  const controller=new AbortController();let timer,timedOut=false;
  const cancel=()=>controller.abort();
  request.signal.addEventListener('abort',cancel,{once:true});
  if(request.signal.aborted)cancel();
  try{
   const abort=new Promise((_,reject)=>{
    if(controller.signal.aborted){reject(Error('request-aborted'));return;}
    controller.signal.addEventListener('abort',()=>reject(Error('request-aborted')),{once:true});
    timer=setTimeout(()=>{timedOut=true;controller.abort();},TIMEOUT_MS);
   });
   // Do not inspect Content-Length, pre-read, clone, parse, hash or buffer the
   // request. Control must authenticate and burn the nonce before reading it.
   const forward=async()=>{controller.signal.throwIfAborted();return boundedResponse(await env.PROVISIONER_ADMISSION.fetch(request,{redirect:'manual',signal:controller.signal}),controller.signal);};
   return await Promise.race([forward(),abort]);
  }catch{return error(timedOut?'provisioner-admission-timeout':'provisioner-admission-unavailable',timedOut?504:502);}
  finally{clearTimeout(timer);request.signal.removeEventListener('abort',cancel);}
 },
};
