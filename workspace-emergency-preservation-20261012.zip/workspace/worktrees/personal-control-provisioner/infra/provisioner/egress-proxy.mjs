import {createServer} from 'node:http';
import {connect,isIP} from 'node:net';
// Cloudflare intercept DNS supplies platform addresses. There is no raw-internet fallback:
// the qualified platform must disable Internet and intercept only these reviewed hosts.
export async function resolveProxyTarget({authority,allowedOrigins}) {
  if(typeof authority!=='string'||!/^([a-zA-Z0-9.-]+):443$/.test(authority))throw Error('proxy_target_rejected');
  const hostname=authority.slice(0,-4).toLowerCase();
  if(isIP(hostname)||hostname==='provisioner.internal'||!allowedOrigins.includes(`https://${hostname}`))throw Error('proxy_origin_rejected');
  return {host:hostname,port:443};
}
export async function startEgressProxy({allowedOrigins,port=18888}) {
  for(const origin of allowedOrigins){const u=new URL(origin);if(u.origin!==origin||u.protocol!=='https:'||u.port)throw Error('invalid_allowed_origin');}
  const sockets=new Set();
  const server=createServer((request,response)=>{response.writeHead(405);response.end();});
  server.maxHeadersCount=20;server.headersTimeout=5000;server.requestTimeout=15000;
  server.on('connection',socket=>{sockets.add(socket);socket.on('close',()=>sockets.delete(socket));socket.setTimeout(60000,()=>socket.destroy());});
  server.on('connect',async(request,client,head)=>{
    try{
      const target=await resolveProxyTarget({authority:request.url,allowedOrigins});
      if(client.destroyed)return;
      const upstream=connect(target);sockets.add(upstream);
      upstream.setTimeout(60000,()=>upstream.destroy());upstream.on('close',()=>sockets.delete(upstream));
      upstream.on('error',()=>client.destroy());client.on('error',()=>upstream.destroy());client.on('close',()=>upstream.destroy());
      upstream.once('connect',()=>{client.write('HTTP/1.1 200 Connection Established\r\n\r\n');if(head.length)upstream.write(head);upstream.pipe(client);client.pipe(upstream);});
    }catch{client.end('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n');}
  });
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
  return {async close(){for(const socket of sockets)socket.destroy();await new Promise(resolve=>server.close(resolve));}};
}
