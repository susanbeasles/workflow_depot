import {open,readFile} from 'node:fs/promises';
import {constants} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {resolve} from 'node:path';

export const requiredBinaries=Object.freeze(['/usr/bin/node','/usr/bin/chromium','/usr/lib/chromium/chromium','/usr/local/bin/op','/usr/bin/nft','/usr/bin/setpriv','/usr/bin/findmnt','/usr/sbin/update-ca-certificates']);
export async function verifyToolchain(manifest='/opt/provisioner/config/toolchain.sha256'){
 const file=await open(manifest,constants.O_RDONLY|constants.O_NOFOLLOW);
 let text;try{const stat=await file.stat();if(!stat.isFile()||stat.size<1||stat.size>16384)throw Error('toolchain-invalid');text=await file.readFile('utf8');}finally{await file.close();}
 const pins=new Map();
 for(const line of text.trimEnd().split('\n')){const m=/^([a-f0-9]{64})  (\/[A-Za-z0-9/_.-]+)$/.exec(line);if(!m||pins.has(m[2])||!requiredBinaries.includes(m[2]))throw Error('toolchain-invalid');pins.set(m[2],m[1]);}
 if(pins.size!==requiredBinaries.length)throw Error('toolchain-incomplete');
 for(const path of requiredBinaries){const bytes=await readFile(path);if(createHash('sha256').update(bytes).digest('hex')!==pins.get(path))throw Error('toolchain-mismatch');}
}
if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href)verifyToolchain().catch(()=>{process.exitCode=1;});
