import {createServer} from 'node:http';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';
import {bootstrap} from './bootstrap.mjs';
const json=(body,status=200)=>Response.json(body,{status,headers:{'cache-control':'no-store'}});
/** Private container port only. The platform interceptor and local UID firewall protect this boundary. */
export function createContainerHandler({bootstrapImpl=bootstrap,now=Date.now,maxBodyBytes=1048576}={}) {
  let latched=false,state='ready',completion=Promise.resolve();
  const handler=async request=>{
    const url=new URL(request.url);
    if(request.method==='GET'&&url.pathname==='/ready')return json({ready:!latched},latched?409:200);
    if(request.method==='GET'&&url.pathname==='/status')return json({state});
    if(request.method!=='POST'||url.pathname!=='/start'||url.search)return json({error:'not_found'},404);
    if(latched)return json({error:'already_started'},409);
    // Reserve the lifetime before reading an asynchronous body; concurrent requests cannot both launch.
    latched=true;state='receiving';
    let handoff,reader,total=0;const chunks=[];
    try {
      if(request.headers.get('content-type')?.split(';')[0]!=='application/json'||!request.body)throw Error();
      reader=request.body.getReader();
      for(;;){const {done,value}=await reader.read();if(done)break;total+=value.length;if(total>maxBodyBytes){state='failed';return json({error:'request_limit'},413);}chunks.push(Buffer.from(value));}
      handoff=JSON.parse(Buffer.concat(chunks).toString('utf8'));
      if(!handoff||Object.keys(handoff).sort().join(',')!=='baseConfigSha256,callbackToken,config,configDigest,deadline,job,serviceAccountToken'||!Number.isSafeInteger(handoff.deadline)||handoff.deadline<=now()||handoff.deadline-now()>3600000)throw Error();
      state='running';completion=Promise.resolve().then(()=>bootstrapImpl(handoff)).then(()=>{state='complete';},()=>{state='failed';}).finally(()=>{handoff.serviceAccountToken=undefined;handoff.callbackToken=undefined;handoff=undefined;});
      return json({accepted:true},202);
    } catch {state='failed';return json({error:'handoff_invalid'},400);}
    finally {for(const chunk of chunks)chunk.fill(0);if(reader){await reader.cancel().catch(()=>{});reader.releaseLock();}}
  };
  handler.done=()=>completion;return handler;
}
export async function startContainerServer({port=8080,host='0.0.0.0',handler=createContainerHandler()}={}) {
  const server=createServer(async(req,res)=>{
    try{const response=await handler(new Request('http://container'+req.url,{method:req.method,headers:req.headers,...(!['GET','HEAD'].includes(req.method)?{body:req,duplex:'half'}:{})}));res.writeHead(response.status,Object.fromEntries(response.headers));res.end(await response.text());}
    catch{res.writeHead(500,{'content-type':'application/json'});res.end('{"error":"request_failed"}');}
  });
  server.maxHeadersCount=16;server.headersTimeout=5000;server.requestTimeout=10000;server.timeout=15000;
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,host,resolve);});return server;
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))startContainerServer().catch(()=>{process.exitCode=1;});
