import {DurableObject,WorkerEntrypoint} from 'cloudflare:workers';
import {createJobController,createDispatchHandler} from './launcher.mjs';

function configuration(env){if(typeof env.PROVISIONER_CONFIG_JSON!=='string'||env.PROVISIONER_CONFIG_JSON.length>131072)throw Error('configuration_unavailable');return JSON.parse(env.PROVISIONER_CONFIG_JSON);}
const denied=()=>Response.json({error:'provisioner_unavailable'},{status:503,headers:{'cache-control':'no-store'}});

export default {fetch(){return new Response('Not found',{status:404,headers:{'cache-control':'no-store'}});}};

/** Fixed Control service binding only; HMAC and job policy remain mandatory. */
export class ProvisionerDispatch extends WorkerEntrypoint {
 async fetch(request){
  const env=this.env;
  if(env.ENABLED!=='true'||!env.PROVISIONER_JOBS)return denied();
  try{return await createDispatchHandler({config:configuration(env),keyProvider:()=>env.PROVISIONER_DISPATCH_KEY,jobProvider:id=>env.PROVISIONER_JOBS.getByName(id)})(request);}catch{return denied();}
 }
}

/** Only this Durable Object owns one job's immutable container lifecycle. */
export class ProvisionerJob extends DurableObject {
 constructor(ctx,env){
  super(ctx,env);
  this.controller=createJobController({storage:ctx.storage,container:ctx.container,containerId:ctx.id.toString(),config:configuration(env),machineKey:()=>env.PROVISIONER_DISPATCH_KEY,serviceToken:()=>env.OP_SERVICE_ACCOUNT_TOKEN,recovery:env.PROVISIONER_RECOVERY,output:env.PROVISIONER_OUTPUT,interceptor:props=>ctx.exports.ProvisionerEgress({props}),waitUntil:promise=>ctx.waitUntil(promise)});
  // Reattach observation after eviction. This never calls container.start().
  ctx.waitUntil(this.controller.resume().catch(()=>ctx.storage.setAlarm(Date.now()+1000)));
 }
 dispatch(envelope){return this.controller.dispatch(envelope);}
 alarm(){return this.controller.alarm();}
 outbound(request,props){return this.controller.outbound(request,props);}
}

/** Reachable only through job-bound container interception; no public route. */
export class ProvisionerEgress extends WorkerEntrypoint {
 async fetch(request){
  try{const props=this.ctx.props;if(!props||typeof props.jobId!=='string')return denied();return await this.env.PROVISIONER_JOBS.getByName(props.jobId).outbound(request,props);}catch{return denied();}
 }
}
