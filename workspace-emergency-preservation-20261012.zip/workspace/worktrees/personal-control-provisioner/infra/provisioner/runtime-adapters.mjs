import {randomBytes,createCipheriv,createPublicKey,publicEncrypt,constants} from 'node:crypto';
import {isIP} from 'node:net';
import {canonicalJSON as canonical,sha256 as digest} from '../../runner/provisioner.mjs';

export const CALLBACK_ORIGIN='https://provisioner.internal';
const hash=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{43}$/.test(value);
const identifier=value=>typeof value==='string'&&/^[A-Za-z0-9_:/.-]{1,512}$/.test(value)&&!value.split('/').includes('..');
const validJob=job=>job&&typeof job.id==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(job.id)&&hash(job.payloadHash);
const STATES=new Set(['reserved','started','submitting','submitted','captured','vault-saved','succeeded','recovery-required','failed','uncertain']);
export function validateRecipient(recipient) {
  try {
    if(!recipient||Object.keys(recipient).sort().join(',')!=='destination,fingerprint,keyId,publicKeyPem'||!identifier(recipient.destination)||!identifier(recipient.keyId)||!hash(recipient.fingerprint)||typeof recipient.publicKeyPem!=='string'||recipient.publicKeyPem.length>8192||!recipient.publicKeyPem.startsWith('-----BEGIN PUBLIC KEY-----'))throw Error();
    const key=createPublicKey(recipient.publicKeyPem);
    if(key.asymmetricKeyType!=='rsa'||key.asymmetricKeyDetails.modulusLength<3072||key.asymmetricKeyDetails.modulusLength>8192||key.asymmetricKeyDetails.publicExponent!==65537n||digest(key.export({type:'spki',format:'der'}))!==recipient.fingerprint)throw Error();
    return key;
  } catch {throw Error('recipient_not_approved');}
}
/** Public wrapping keys only. An independent process holds the corresponding unwrap key. */
export async function envelopeEncrypt({credential,jobId,payloadHash,recipient,purpose}) {
  const publicKey=validateRecipient(recipient);
  if(!validJob({id:jobId,payloadHash})||!['recovery','kv-output'].includes(purpose))throw Error('envelope_context_invalid');
  const plaintext=Buffer.from(canonical(credential));
  if(plaintext.length>65536){plaintext.fill(0);throw Error('credential_limit');}
  const key=randomBytes(32),iv=randomBytes(12);
  const header={version:1,algorithm:'RSA-OAEP-256+A256GCM',keyId:recipient.keyId,fingerprint:recipient.fingerprint,context:{jobId,payloadHash,purpose}};
  const aad=Buffer.from(canonical(header));
  try {
    const wrapped=publicEncrypt({key:publicKey,padding:constants.RSA_PKCS1_OAEP_PADDING,oaepHash:'sha256',oaepLabel:aad},key);
    const cipher=createCipheriv('aes-256-gcm',key,iv);cipher.setAAD(aad);
    const ciphertext=Buffer.concat([cipher.update(plaintext),cipher.final()]);
    return canonical({...header,encryptedDataKey:wrapped.toString('base64'),iv:iv.toString('base64'),tag:cipher.getAuthTag().toString('base64'),ciphertext:ciphertext.toString('base64')});
  } finally {key.fill(0);plaintext.fill(0);}
}
async function readBounded(response) {
  if(!response.ok||!response.body)throw Error('callback_not_acknowledged');
  const reader=response.body.getReader();let length=0;const chunks=[];
  try {for(;;){const {done,value}=await reader.read();if(done)break;length+=value.length;if(length>16384)throw Error('callback_response_limit');chunks.push(Buffer.from(value));}return JSON.parse(Buffer.concat(chunks).toString('utf8'));}
  finally {await reader.cancel().catch(()=>{});reader.releaseLock();}
}
export function createRuntimeTransport({job,callbackToken,deadline,fetchImpl=fetch,now=Date.now}) {
  if(!validJob(job)||typeof callbackToken!=='string'||!/^[A-Za-z0-9_-]{16,8192}$/.test(callbackToken)||!Number.isSafeInteger(deadline)||deadline<=now()||deadline-now()>3600000)throw Error('runtime_identity_invalid');
  return async (path,body)=>{
    if(!['/v1/journal/reserve','/v1/journal/update','/v1/recovery','/v1/kv'].includes(path)||body.jobId!==job.id||body.payloadHash!==job.payloadHash||now()>=deadline)throw Error('runtime_identity_mismatch');
    try {
      const result=await fetchImpl(CALLBACK_ORIGIN+path,{method:'POST',headers:{authorization:`Bearer ${callbackToken}`,'content-type':'application/json'},body:canonical(body),redirect:'error',signal:AbortSignal.timeout(Math.min(15000,deadline-now()))});
      return await readBounded(result);
    } catch {throw Error('runtime_callback_unavailable');} // Never retry a mutation or expose provider response bodies.
  };
}
export async function createRuntimeAdapters({config,job,callbackToken,deadline,fetchImpl=fetch,now=Date.now}) {
  const infra=config.infrastructure,profile=config.profile,kvEnabled=job.payload.KV!==false;
  if(infra?.transport!=='cloudflare-bindings-v1'||Object.keys(infra).some(k=>!['transport','recovery','kv','opOrigins'].includes(k)))throw Error('cloudflare_bindings_required');
  if(infra.opOrigins!==undefined){if(!Array.isArray(infra.opOrigins)||infra.opOrigins.length<1||infra.opOrigins.length>8)throw Error('op_origins_invalid');for(const origin of infra.opOrigins){let u;try{u=new URL(origin);}catch{throw Error('op_origins_invalid');}if(u.protocol!=='https:'||u.origin!==origin||u.port||isIP(u.hostname)||u.hostname==='provisioner.internal'||!u.hostname.includes('.'))throw Error('op_origins_invalid');}}
  validateRecipient(infra.recovery);
  if(!infra.recovery.destination.startsWith('r2://')||!infra.recovery.destination.endsWith('/')||profile.recovery?.destination!==infra.recovery.destination||profile.recovery.encryptionKeyId!==infra.recovery.keyId)throw Error('recovery_profile_mismatch');
  if(kvEnabled){validateRecipient(infra.kv);if(!infra.kv.destination.startsWith('cloudflare-kv://')||!infra.kv.destination.endsWith('/')||profile.kv?.destination!==infra.kv.destination||profile.kv.encryptionKeyId!==infra.kv.keyId)throw Error('kv_profile_mismatch');if(infra.recovery.keyId===infra.kv.keyId||infra.recovery.fingerprint===infra.kv.fingerprint)throw Error('independent_recovery_key_required');}
  const send=createRuntimeTransport({job,callbackToken,deadline,fetchImpl,now});
  const identity=args=>{if(args.jobId!==job.id||args.payloadHash!==job.payloadHash)throw Error('runtime_identity_mismatch');return {jobId:job.id,payloadHash:job.payloadHash};};
  const capture=async(args,purpose)=>{
    const body=identity(args),recipient=purpose==='recovery'?infra.recovery:infra.kv;
    const envelope=await envelopeEncrypt({...body,credential:args.credential,recipient,purpose});
    const expectedId=recipient.destination+job.id+(purpose==='recovery'?'.json':'');
    const expectedDigest=digest(envelope),ack=await send(purpose==='recovery'?'/v1/recovery':'/v1/kv',{...body,envelope,digest:expectedDigest});
    if(Object.keys(ack??{}).sort().join(',')!=='digest,id'||ack.id!==expectedId||ack.digest!==expectedDigest)throw Error('ciphertext_acknowledgement_invalid');
    return {id:expectedId};
  };
  return {
    journal:{
      async reserve(args){const ack=await send('/v1/journal/reserve',identity(args));if(Object.keys(ack??{}).join(',')!=='reserved'||typeof ack.reserved!=='boolean')throw Error('journal_acknowledgement_invalid');return ack.reserved;},
      async update(args){const body=identity(args);if(!STATES.has(args.state))throw Error('invalid_runtime_state');const receipt={};for(const [key,value] of Object.entries(args.receipt??args)){if(['itemId','vaultId','recoveryId','kvId'].includes(key)){if(!identifier(value))throw Error('invalid_receipt');receipt[key]=value;}}const ack=await send('/v1/journal/update',{...body,state:args.state,receipt});if(Object.keys(ack??{}).join(',')!=='updated'||ack.updated!==true)throw Error('journal_acknowledgement_invalid');}
    },
    recovery:{encrypted:true,durable:true,destination:infra.recovery.destination,capture:args=>capture(args,'recovery')},
    kv:{encrypted:true,unwrapSeparate:true,destination:infra.kv?.destination,putEncrypted:args=>{if(!kvEnabled)throw Error('kv_disabled');return capture(args,'kv-output');}}
  };
}
