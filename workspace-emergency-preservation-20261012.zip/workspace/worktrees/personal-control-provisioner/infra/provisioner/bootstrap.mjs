import {readFile,writeFile,rm} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {canonicalJSON as canonical,sha256 as digest,validateJobProfile} from '../../runner/provisioner.mjs';
import {startEgressProxy} from './egress-proxy.mjs';
import {verifyInstalledBundle} from '../../runner/verify-bundle.mjs';
import {createRuntimeTransport} from './runtime-adapters.mjs';

export const INTERCEPT_CA='/etc/cloudflare/certs/cloudflare-containers-ca.crt';
const check=(condition,code)=>{if(!condition)throw Error(code);};
const hash=x=>typeof x==='string'&&/^[A-Za-z0-9_-]{43}$/.test(x);
export function validateHandoff({handoff,baseConfigBytes,now=Date.now}) {
  check(handoff&&Object.keys(handoff).sort().join(',')==='baseConfigSha256,callbackToken,config,configDigest,deadline,job,serviceAccountToken','handoff_invalid');
  check(Number.isSafeInteger(handoff.deadline)&&handoff.deadline>now()&&handoff.deadline-now()<=3600000,'expired_handoff');
  check(typeof handoff.serviceAccountToken==='string'&&/^[\x21-\x7e]{1,8192}$/.test(handoff.serviceAccountToken)&&typeof handoff.callbackToken==='string'&&/^[A-Za-z0-9_-]{16,8192}$/.test(handoff.callbackToken),'handoff_credential_invalid');
  check(Buffer.byteLength(baseConfigBytes)<=1048576&&digest(baseConfigBytes)===handoff.baseConfigSha256,'base_configuration_mismatch');
  const base=JSON.parse(baseConfigBytes);
  check(!Object.hasOwn(base,'profile')&&!Object.hasOwn(base,'manifestDigest'),'base_configuration_invalid');
  check(base.platform?.provider==='cloudflare-containers'&&base.platform.qualified===true&&hash(base.platform.qualificationDigest),'platform_unqualified');
  const {job,config}=handoff;
  check(config&&config.profile&&canonical(config)===canonical({...base,profile:config.profile,manifestDigest:digest(canonical(config.profile.manifest))})&&digest(canonical(config))===handoff.configDigest,'runner_configuration_mismatch');
  check(job?.state==='accepted','job_not_accepted');validateJobProfile({job,profile:config.profile,codeDigest:base.codeDigest});
  check(config.browser?.proxy?.server==='http://127.0.0.1:18888','browser_proxy_required');
  return {job,config};
}
function receiptFromChild(bytes,job,code) {
  try {
    const receipt=JSON.parse(bytes);
    if(receipt.jobId!==job.id||!['succeeded','failed','blocked','uncertain','recovery-required'].includes(receipt.state)||Object.keys(receipt).some(k=>!['jobId','state','itemId','vaultId','kvId','code'].includes(k)))throw Error();
    if(receipt.code!==undefined&&!['manual-reconciliation-required','execution-failed','mutation-already-reserved'].includes(receipt.code))throw Error();
    if(receipt.state==='succeeded'){
      if(code!==0||!/^[a-z0-9]{26}$/.test(receipt.itemId)||!/^[a-z0-9]{26}$/.test(receipt.vaultId)||(receipt.kvId!==undefined&&!/^[A-Za-z0-9_:/.-]{1,512}$/.test(receipt.kvId)))throw Error();
    } else if(['itemId','vaultId','kvId'].some(k=>Object.hasOwn(receipt,k)))throw Error();
    return receipt;
  } catch {throw Error('supervisor_receipt_invalid');}
}
export async function bootstrap(handoff,{readBaseConfig=()=>readFile('/opt/provisioner/config/runner.json','utf8'),verifyBundle=verifyInstalledBundle,spawnProcess=spawn,startProxy=startEgressProxy,tempRoot='/run/provisioner',now=Date.now,fetchImpl=fetch}={}) {
  const {job,config}=validateHandoff({handoff,baseConfigBytes:await readBaseConfig(),now});
  await verifyBundle({root:'/opt/provisioner',codeDigest:config.codeDigest});
  check(now()<handoff.deadline,'expired_handoff');
  const send=createRuntimeTransport({job,callbackToken:handoff.callbackToken,deadline:handoff.deadline,fetchImpl,now});
  const jobPath=tempRoot+'/job.json',configPath=tempRoot+'/runner.json';let proxy;
  try {
    await writeFile(jobPath,canonical(job),{mode:0o600,flag:'wx'});
    await writeFile(configPath,canonical(config),{mode:0o600,flag:'wx'});
    proxy=await startProxy({allowedOrigins:config.profile.allowedOrigins});
    check(now()<handoff.deadline,'expired_handoff');
    return await new Promise((resolve,reject)=>{
      let output='',bytes=0,settled=false;
      const child=spawnProcess('/usr/bin/node',['/opt/provisioner/runner/run.mjs','--config',configPath,'--config-sha256',handoff.configDigest,'--job',jobPath],{shell:false,detached:true,env:{PATH:'/usr/bin:/bin',HOME:tempRoot+'/supervisor',TMPDIR:tempRoot+'/op',NODE_EXTRA_CA_CERTS:INTERCEPT_CA},stdio:['ignore','pipe','pipe','pipe','pipe']});
      const kill=()=>{try{process.kill(-child.pid,'SIGKILL');}catch{child.kill('SIGKILL');}};
      const finish=(error,value)=>{if(settled)return;settled=true;clearTimeout(timeout);if(error){kill();reject(Error('supervisor_failed'));}else resolve(value);};
      const timeout=setTimeout(()=>finish(true),Math.max(1,handoff.deadline-now()));
      child.on('error',()=>finish(true));
      for(const stream of [child.stdout,child.stderr])stream.on('data',chunk=>{bytes+=chunk.length;if(bytes>16384){finish(true);return;}if(stream===child.stdout)output+=chunk.toString('utf8');});
      child.on('close',code=>{try{finish(false,receiptFromChild(output,job,code));}catch{finish(true);}});
      child.stdio[3].on('error',()=>finish(true));child.stdio[4].on('error',()=>finish(true));
      if(now()>=handoff.deadline){finish(true);return;}
      child.stdio[3].end(handoff.serviceAccountToken);child.stdio[4].end(canonical({callbackToken:handoff.callbackToken,deadline:handoff.deadline}));
      handoff.serviceAccountToken=undefined;handoff.callbackToken=undefined;
    });
  } catch {
    try{await send('/v1/journal/update',{jobId:job.id,payloadHash:job.payloadHash,state:'uncertain',receipt:{}});}catch{}
    throw Error('bootstrap_failed');
  } finally {
    handoff.serviceAccountToken=undefined;handoff.callbackToken=undefined;
    await proxy?.close().catch(()=>{});await Promise.all([rm(jobPath,{force:true}),rm(configPath,{force:true})]);
  }
}
