#!/bin/bash
set -euo pipefail
umask 077
# Cloudflare destroys this job's container. No host poweroff, systemd, swap
# changes, snapshots, or persistent disk are requested by this entrypoint.
test "$(id -u)" = 0
test "$(id -u provisioner-browser)" = 10001
test "$(id -g provisioner-browser)" = 10001
ulimit -c 0
test "$(ulimit -c)" = 0
test "$(wc -l < /proc/swaps)" -eq 1
test "$(cat /proc/sys/fs/suid_dumpable)" = 0
test "$(/usr/bin/findmnt -n -o FSTYPE -T /dev/shm)" = tmpfs
test ! -e /run/provisioner
test ! -L /run/provisioner
test ! -e /dev/shm/provisioner
install -d -m 0711 /dev/shm/provisioner
ln -s /dev/shm/provisioner /run/provisioner
install -d -m 0700 /run/provisioner/op /run/provisioner/supervisor
install -d -m 0700 -o provisioner-browser -g provisioner-browser /run/provisioner/browser
/usr/bin/node /opt/provisioner/infra/provisioner/verify-toolchain.mjs
# Cloudflare injects this ephemeral CA when HTTPS interception is enabled.
# Trust it normally; never disable TLS certificate validation.
test -s /etc/cloudflare/certs/cloudflare-containers-ca.crt
cp /etc/cloudflare/certs/cloudflare-containers-ca.crt /usr/local/share/ca-certificates/cloudflare-containers-ca.crt
/usr/sbin/update-ca-certificates >/dev/null 2>&1
# Missing nftables privileges blocks boot. The browser cannot reach the
# supervisor port, internal callbacks, or another approved host directly.
nft -f - <<'NFT'
table inet provisioner {
  chain browser_output {
    type filter hook output priority -100; policy accept;
    meta skuid 10001 ip daddr 127.0.0.1 tcp dport 18888 accept
    meta skuid 10001 reject
  }
}
NFT
/usr/bin/setpriv --reuid=10001 --regid=10001 --clear-groups --no-new-privs --bounding-set=-all --inh-caps=-all --ambient-caps=-all /usr/bin/node --input-type=module <<'JS'
import {readFileSync} from 'node:fs';
const status=readFileSync('/proc/self/status','utf8');
if(process.getuid()!==10001||process.getgid()!==10001||!/^NoNewPrivs:\s+1$/m.test(status)||!['CapInh','CapPrm','CapEff','CapBnd','CapAmb'].every(n=>new RegExp('^'+n+':\\s+0+$','m').test(status)))process.exit(1);
JS
exec /usr/bin/env -i PATH=/usr/bin:/bin HOME=/run/provisioner/supervisor TMPDIR=/run/provisioner/op LANG=C.UTF-8 NODE_EXTRA_CA_CERTS=/etc/cloudflare/certs/cloudflare-containers-ca.crt /usr/bin/node /opt/provisioner/infra/provisioner/container-server.mjs
