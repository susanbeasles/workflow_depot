#!/bin/bash
# Image-build source only. Do not run on the control host or a live runner.
set -euo pipefail
test "${PROVISIONER_IMAGE_BUILD_ACK:-}" = 'disposable-image-builder'
test "$(id -u)" = 0
test -d /opt/provisioner/runner/node_modules/playwright-core
for executable in /usr/bin/node /usr/bin/chromium /usr/local/bin/op /usr/bin/nft /usr/bin/setpriv /usr/bin/findmnt /usr/sbin/update-ca-certificates; do test -x "$executable"; done
test -s /opt/provisioner/config/toolchain.sha256
# Reviewed public binary pins are input, never learned from installed binaries.
/usr/bin/node /opt/provisioner/infra/provisioner/verify-toolchain.mjs
if ! id provisioner-browser >/dev/null 2>&1; then
  groupadd --gid 10001 provisioner-browser
  useradd --uid 10001 --gid 10001 --no-create-home --home-dir /run/provisioner/browser --shell /usr/sbin/nologin provisioner-browser
fi
test "$(id -u provisioner-browser)" = 10001
test "$(id -g provisioner-browser)" = 10001
chown -R root:root /opt/provisioner
find /opt/provisioner -type d -exec chmod 0555 {} +
find /opt/provisioner -type f -exec chmod 0444 {} +
chmod 0555 /opt/provisioner/infra/provisioner/boot.sh /opt/provisioner/infra/provisioner/chromium-wrapper
chmod 0700 /opt/provisioner/config
chmod 0600 /opt/provisioner/config/runner.json /opt/provisioner/config/toolchain.sha256
printf 'Cloudflare image source prepared; platform and browser qualification is still required.\n'
