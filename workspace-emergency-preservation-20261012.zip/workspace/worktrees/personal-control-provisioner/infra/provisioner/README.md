# Cloudflare provisioner executor

Cloudflare is the required platform. The earlier AWS implementation was an implementation error; its Terraform module, Lambda packager and AWS adapters have been removed from this working tree. Existing old packages outside this directory are obsolete and were not rebuilt. This correction is local source and synthetic verification only: no image build, upload, deployment, credential issuance or provider action has run.

The executor is implemented, but deliberately disabled and not qualified for live use. `handler.mjs` connects a Worker to the `ProvisionerJob` Durable Object and its Cloudflare Container; `launcher.mjs` implements dispatch authentication, durable reservation, job lifecycle, approved egress, output storage and cleanup. These are executable adapters using Cloudflare APIs, not simulated production adapters. Tests substitute the platform and provider boundaries. `wrangler.provisioner.jsonc` has `ENABLED=false`, empty configuration, no public development endpoint and no invented resource IDs or image pins.

The authorizer remains on its existing Worker. Its exact two-step protocol is unchanged: the first P-256 signature binds the request tuple, complete approved profile and exact payload hash; the second signs only the returned nonce bytes. After owner/key signature authentication, nonce consumption precedes payload reading and hash/schema validation. Runtime vault choice, approved item title and generated-key naming remain profile/payload decisions. This executor receives the same HMAC-signed accepted-job envelope and returns HMAC-signed, nonce-bound status.

Control's `PROVISIONER_EXECUTOR` service binding targets `personal-control-provisioner-executor` / `ProvisionerDispatch`. Only that named private Worker entrypoint accepts dispatch; the executor's default public handler always returns 404, including when enabled. Control requires the binding for admission readiness and never falls back to a network request. The binding retains the existing HMAC envelope, audience, status signature and request nonce checks. Redirects are returned without following them and rejected. The browser ingress adapter is separate: it forwards only the two existing owner authorization requests to `ProvisionerAdmission`.

Before reading input secrets, the runner requires exactly one approved credential-name binding and, when configured, one positive integer lifetime binding. Prepare steps cannot reuse the same canonical write target for name, lifetime or permission controls. These static checks do not prove that different selectors address different real elements; recipe qualification must verify the actual provider form and submitted values.

## Execution and recovery

Each job has one durable reservation before any container launch. The controller pins the accepted profile, payload, code, base configuration and image digest. It does not resubmit a launch or start request after an ambiguous response. Durable alarms supervise the deadline and termination after completion or failure; retained reservations prevent replay. Public success requires a successful durable journal receipt and confirmed container destruction. An unconfirmed cleanup remains uncertain.

The container starts with `enableInternet:false` and Cloudflare's `default` scheduling policy. HTTPS interception admits only exact approved provider and 1Password origins plus a private job-bound callback origin. `ProvisionerEgress` is a named loopback Worker entrypoint, not a public route or an additional deployed service. Cloudflare's injected CA is trusted normally; certificate checks are never disabled. The local CONNECT proxy uses intercepted hostname routing rather than direct-IP fallback.

`boot.sh` checks tmpfs, disabled core dumps and absent swap, verifies approved binary hashes, and requires an effective nftables UID boundary. The browser helper and Chromium run as UID/GID 10001 with all capability sets empty and `NoNewPrivs=1`. Browser egress can reach only its local proxy; it cannot reach the supervisor's private port or callback directly. `durable_object` container scheduling is prohibited because its privilege behavior cannot provide this UID boundary. The browser's required sandbox remains enabled.

The existing `OP_SERVICE_ACCOUNT_TOKEN` passes through the private container handoff and FD3 into the Node supervisor. Its job callback capability uses FD4. Neither is placed in process arguments, browser environment, durable storage, image configuration or logs. The official `op` executable reads the approved input item and creates the approved output item through stdin, then checks it privately. Job and public configuration files live in private tmpfs and are removed on completion. JavaScript strings, process memory and platform RAM are not claimed to be perfectly erased.

Recovery is encrypted in the supervisor before the 1Password output write. The envelope uses an existing pinned RSA public recipient and AES-GCM with job, payload and purpose binding. The Durable Object writes ciphertext through the `PROVISIONER_RECOVERY` R2 binding and checks readback. Optional KV output uses `PROVISIONER_OUTPUT`, a distinct public recipient and an independent recovery boundary. No private unwrap key or Cloudflare API token is delivered to the job. Journal transitions retain IDs and state, not generated secret fields. Ambiguous provider submission is not retried.

## Reviewed configuration and image inputs

`config.disabled.json` illustrates the controller schema with deliberately invalid placeholders. The image's root-owned `/opt/provisioner/config/runner.json` contains the same profile-independent `runnerConfig` object. Its exact file bytes are pinned by `baseConfigSha256`. The controller adds the accepted `profile` and its `manifestDigest` for each job; changing an approved input/output vault does not require embedding credentials or vault choices in a new image.

The base configuration requires:

- `codeDigest`, the SHA-256 base64url digest of the installed bundle manifest.
- `browser.proxy.server` fixed to `http://127.0.0.1:18888`.
- `platform` with provider `cloudflare-containers`, a true qualification flag and the retained qualification digest before live activation.
- `infrastructure.transport` fixed to `cloudflare-bindings-v1` and exact approved HTTPS `opOrigins`.
- `infrastructure.recovery` containing `destination` (`r2://BUCKET/PREFIX/`), the existing approved `keyId`, SHA-256 base64url SPKI `fingerprint`, and `publicKeyPem` only. When KV is enabled, the analogous `kv` destination is `cloudflare-kv://NAMESPACE/PREFIX/` with a distinct key and fingerprint.

The approved profile must bind the same destinations and key IDs. Controller configuration additionally pins the existing owner, dispatch audience, private admission audience, approved complete profile digests, image digest and deadline. Bind the existing service-only `PROVISIONER_DISPATCH_KEY` and `OP_SERVICE_ACCOUNT_TOKEN`; configure the existing owned R2 and optional KV resources. `PROVISIONER_DISPATCH_URL` uses the existing owned domain and exact path `/v1/dispatch` as an HTTP request address delivered through the private service binding; it requires no public executor route or DNS registration. No secret values belong in Wrangler vars, image inputs or source files.

`Dockerfile` and its restrictive build-context allowlist describe a future authorized image build. Its base must be a reviewed immutable Cloudflare registry image containing pinned Node, Chromium, official `op`, nftables, setpriv and CA tooling. Supply only reviewed nonsecret `provisioner-image-inputs/runner.json` and `toolchain.sha256`. The latter lists SHA-256 hashes for every fixed path in `verify-toolchain.mjs`; hashes are approved inputs, never learned from the installed binaries. The build installs the locked runner dependency, prepares file ownership and generates the application bundle manifest. `prepare-image.sh` requires the explicit disposable-builder acknowledgement and must never run on the control host.

## Verification and live qualification

Local checks (no cloud or provider calls):

```sh
npm test --prefix infra/provisioner
node --test test/provisioner-runner.test.mjs test/provisioner.test.mjs test/provisioner-chain.test.mjs test/provisioner-dispatch.test.mjs test/provisioner-ui.test.mjs test/provisioner-extension.test.mjs
bash -n infra/provisioner/boot.sh infra/provisioner/prepare-image.sh
```

The combined synthetic test exercises the actual controller and Node adapters together: immutable handoff, one journal reservation, public-key encryption, R2/KV ciphertext acknowledgement, final receipt and confirmed cleanup. Separate child-process tests check FD3/FD4 delivery, absence from arguments/environment, bounded output, deadline failure and temporary-file cleanup. These do not prove Cloudflare's real container privileges, Chromium sandbox, injected-CA compatibility with Chromium/`op`, or a real provider UI.

`node --test test/provisioner-cloudflare.test.mjs test/provisioner-dispatch.test.mjs` also composes the actual Control alarm/outbox, named `ProvisionerDispatch` and job Durable Object in Workerd. Its test-only facade seeds a synthetic accepted job, confirms durable reconciliation with verified HMAC responses, and observes zero outbound network requests. With no container attached, the job correctly remains uncertain; this is private transport verification, not image or provider qualification.

Before activation, qualify and install the existing-key native signing transport on the intended client (see [signer instructions](../../signer/README.md)), supply the approved immutable image and public configuration/bindings, and qualify that image's UID/capability, nftables, browser sandbox, TLS/`op` and cleanup behavior on Cloudflare. The B2 candidate still has placeholder selectors and `qualified:false`; its real recipe needs qualification. If the actual platform cannot enforce the required boundaries, execution must remain blocked. This implementation has no alternate platform fallback.

The native signing host is implemented and tested offline; its hardware qualification and installation have not run. No hardware key is created, replaced or enrolled by this package. The extension and page transport preserve the existing enrolled-key protocol; a configured extension ID alone does not prove signing works.
