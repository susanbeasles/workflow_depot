import {createHash,createHmac,timingSafeEqual} from 'node:crypto';

export const digest=value=>createHash('sha256').update(value).digest('base64url');
export function canonical(value){if(Array.isArray(value))return `[${value.map(canonical).join(',')}]`;if(value&&typeof value==='object')return `{${Object.keys(value).sort().map(k=>`${JSON.stringify(k)}:${canonical(value[k])}`).join(',')}}`;return JSON.stringify(value);}
const requireValue=(value,code='provisioner_denied')=>{if(!value)throw Error(code);};
const exact=(value,keys)=>value&&Object.getPrototypeOf(value)===Object.prototype&&Object.keys(value).sort().join()===keys.slice().sort().join();
const hash=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{43}$/.test(value);
const terminal=new Set(['succeeded','failed','uncertain','recovery-required']);
export const INTERNAL_ORIGIN='https://provisioner.internal';
export function allowedOrigin(value){try{const u=new URL(value);return u.protocol==='https:'&&u.origin===value&&!u.username&&!u.password&&!u.port&&/^(?=.{1,253}$)[a-z0-9-]+(?:\.[a-z0-9-]+)+$/.test(u.hostname)&&!/^\d+\.\d+\.\d+\.\d+$/.test(u.hostname);}catch{return false;}}
export function verifyEnvelope({raw,signature,key,audience,now=Date.now()}){
 requireValue(typeof raw==='string'&&Buffer.byteLength(raw)<=131072,'invalid_envelope');requireValue(typeof key==='string'&&key.length>=32&&hash(signature),'invalid_authentication');
 const expected=createHmac('sha256',key).update(raw).digest(),provided=Buffer.from(signature,'base64url');requireValue(provided.length===expected.length&&timingSafeEqual(provided,expected),'invalid_authentication');
 const e=JSON.parse(raw);requireValue(exact(e,['version','audience','sentAt','nonce','job','profile'])&&e.version===1&&e.audience===audience,'invalid_audience');
 requireValue(Number.isSafeInteger(e.sentAt)&&Math.abs(now-e.sentAt)<=60000,'expired_envelope');requireValue(typeof e.nonce==='string'&&/^[A-Za-z0-9_-]{8,128}$/.test(e.nonce),'invalid_nonce');return e;
}
export function validateJob(job,profile,config){
 requireValue(exact(job,['id','owner','state','rawPayload','payload','payloadHash','context'])&&typeof job.id==='string'&&/^[A-Za-z0-9_-]{8,128}$/.test(job.id),'invalid_job');
 requireValue(job.state==='accepted'&&job.owner===config.owner&&typeof job.rawPayload==='string'&&Buffer.byteLength(job.rawPayload)<=65536,'job_not_accepted');
 requireValue(digest(job.rawPayload)===job.payloadHash&&canonical(JSON.parse(job.rawPayload))===canonical(job.payload),'payload_mismatch');
 const pd=digest(canonical(profile));requireValue(job.context?.profileDigest===pd&&config.approvedProfileDigests?.includes(pd)&&profile.manifest?.qualified===true,'profile_not_approved');
 requireValue(job.context.profileId===profile.id&&job.context.codeDigest===config.codeDigest&&config.runnerConfig?.codeDigest===config.codeDigest&&hash(config.codeDigest),'code_or_profile_mismatch');
 requireValue(job.context.manifestDigest===digest(canonical(profile.manifest))&&job.context.audience===config.admissionAudience,'context_mismatch');
 requireValue(config.qualified===true&&config.schedulingPolicy==='default'&&/^sha256:[a-f0-9]{64}$/.test(config.imageDigest??'')&&hash(config.baseConfigSha256),'runtime_unqualified');
 const platform=config.runnerConfig.platform;requireValue(exact(platform,['provider','qualified','qualificationDigest'])&&platform.provider==='cloudflare-containers'&&platform.qualified===true&&hash(platform.qualificationDigest),'runtime_unqualified');
 requireValue(Number.isInteger(config.deadlineSeconds)&&config.deadlineSeconds>=60&&config.deadlineSeconds<=3600,'invalid_deadline');
 const infra=config.runnerConfig.infrastructure;requireValue(infra?.transport==='cloudflare-bindings-v1'&&Array.isArray(infra.opOrigins)&&infra.opOrigins.length>0&&infra.opOrigins.length<=8,'transport_unconfigured');
 requireValue(Array.isArray(profile.allowedOrigins)&&profile.allowedOrigins.length>0&&profile.allowedOrigins.length<=8&&[...profile.allowedOrigins,...infra.opOrigins].every(v=>allowedOrigin(v)&&v!==INTERNAL_ORIGIN),'origin_policy_invalid');
 for(const kind of ['recovery',...(job.payload.KV!==false?['kv']:[])]){const target=infra[kind];requireValue(target&&profile[kind]?.destination===target.destination&&profile[kind].encryptionKeyId===target.keyId&&hash(target.fingerprint)&&typeof target.publicKeyPem==='string'&&target.publicKeyPem.length>0,'output_not_approved');requireValue(new RegExp('^'+(kind==='recovery'?'r2':'cloudflare-kv')+'://[a-z0-9-]+/[A-Za-z0-9_/-]+/$').test(target.destination),'invalid_destination');}
 if(job.payload.KV!==false)requireValue(infra.recovery.keyId!==infra.kv.keyId&&infra.recovery.fingerprint!==infra.kv.fingerprint,'independent_recovery_required');
}
function callbackToken(key,record){requireValue(typeof key==='string'&&key.length>=32,'machine_key_unavailable');return createHmac('sha256',key).update('provisioner-callback-v1\n'+record.job.id+'\n'+record.identity).digest('base64url');}
function safeReceipt(receipt){requireValue(receipt&&Object.getPrototypeOf(receipt)===Object.prototype&&Object.keys(receipt).every(k=>['itemId','vaultId','recoveryId','kvId'].includes(k)),'invalid_receipt');for(const [k,v] of Object.entries(receipt))requireValue(typeof v==='string'&&(k==='itemId'||k==='vaultId'?/^[a-z0-9]{26}$/:/^[A-Za-z0-9:/_.-]{1,512}$/).test(v),'invalid_receipt');return receipt;}
const publicStatus=record=>{let state=record.phase==='claimed'||record.phase==='booting'?'launching':record.phase==='uncertain'?'uncertain':'running';if(record.cleanup==='destroyed')state=record.execution??'failed';else if(record.cleanup==='unconfirmed')state='uncertain';return {jobId:record.job.id,state,...(Object.keys(record.receipt).length?{receipt:record.receipt}:{})};};

/** One durable record per DO. All external effects follow a persisted claim. */
export function createJobController({storage,container,config,containerId,machineKey,serviceToken,interceptor,waitUntil=()=>{},recovery,output,now=Date.now,sleep=ms=>new Promise(r=>setTimeout(r,ms)),fetcher=fetch}){
 const active=r=>requireValue(r&&!r.cleanup&&!terminal.has(r.execution)&&now()<r.deadline,'job_closed');
 const launchable=(r,phase)=>{active(r);requireValue(r.phase===phase&&!r.execution,'launch_already_reserved');};
 const edit=fn=>storage.transaction(async tx=>{const r=await tx.get('job');requireValue(r,'unknown_job');const result=await fn(r,tx);await tx.put('job',r);return result;});
 const status=async()=>{const r=await storage.get('job');requireValue(r,'unknown_job');return publicStatus(r);};
 const stop=async()=>{
  await edit(r=>{if(!terminal.has(r.execution))r.execution=r.receipt.recoveryId?'recovery-required':r.execution?'uncertain':r.phase==='uncertain'?'uncertain':'failed';r.cleanup='requested';});
  try{await container.destroy();requireValue(container.running===false&&await container.inspect()===null,'cleanup_unconfirmed');await edit(r=>{r.cleanup='destroyed';r.phase='stopped';});await storage.deleteAlarm();}
  catch{await edit(r=>{r.cleanup='unconfirmed';});await storage.setAlarm(now()+30000);}
 };
 async function alarm(){const r=await storage.get('job');if(!r)return;if(r.cleanup==='destroyed'){await storage.deleteAlarm();return;}if(terminal.has(r.execution)||r.deadline<=now()||r.cleanup){await stop();return;}await storage.setAlarm(r.deadline);}
 async function stopped(){const r=await storage.get('job');if(!r||r.cleanup==='destroyed')return;await stop();}
 async function dispatch(envelope){
  const {job,profile,nonce}=envelope;validateJob(job,profile,config);
  const identity=digest(canonical({job,profile,config}));let claimed=false;
  await storage.transaction(async tx=>{
   claimed=false;let r=await tx.get('job');if(r)requireValue(r.identity===identity,'immutable_job_conflict');
   else {r={job:structuredClone(job),profile:structuredClone(profile),identity,containerId,deadline:now()+config.deadlineSeconds*1000,phase:'claimed',execution:null,receipt:{},nonces:{},outputs:{}};claimed=true;}
   r.nonces=Object.fromEntries(Object.entries(r.nonces).filter(([,expiry])=>expiry>now()));requireValue(!Object.hasOwn(r.nonces,nonce),'envelope_replay');requireValue(Object.keys(r.nonces).length<128,'nonce_limit');r.nonces[nonce]=now()+120000;
   await tx.put('job',r);await tx.setAlarm(r.deadline);
  });
  if(!claimed){const r=await storage.get('job');if(r.deadline<=now()||terminal.has(r.execution)||r.cleanup)await alarm();else if(['running','uncertain'].includes(r.phase)&&!container.running)await stopped();return status();}
  try{
   requireValue(container&&!container.running,'container_already_used');const r=await storage.get('job'),props={jobId:job.id,containerId,identity},binding=interceptor(props);
   for(const origin of new Set([INTERNAL_ORIGIN,...profile.allowedOrigins,...config.runnerConfig.infrastructure.opOrigins]))await container.interceptOutboundHttps(new URL(origin).hostname,binding);
   await edit(r=>{launchable(r,'claimed');r.phase='booting';});
   launchable(await storage.get('job'),'booting');
   container.start({enableInternet:false});await container.setInactivityTimeout(Math.min(60000,Math.max(1,r.deadline-now())));
   waitUntil(container.monitor().then(stopped,stopped).catch(()=>{}));
   let ready=false;for(let i=0;i<40&&now()<r.deadline;i++){try{const response=await container.getTcpPort(8080).fetch('http://container/ready',{signal:AbortSignal.timeout(2000)});await response.body?.cancel();if(response.ok){ready=true;break;}}catch{}await sleep(250);}
   requireValue(ready&&now()<r.deadline,'container_not_ready');const info=await container.inspect();requireValue(info?.image===config.imageDigest||info?.image?.endsWith('@'+config.imageDigest),'container_image_mismatch');
   const fullConfig={...config.runnerConfig,profile,manifestDigest:digest(canonical(profile.manifest))};
   launchable(await storage.get('job'),'booting');
   const token=await serviceToken();requireValue(typeof token==='string'&&token.length>0&&token.length<=32768,'service_token_unavailable');
   const body=JSON.stringify({job,config:fullConfig,configDigest:digest(canonical(fullConfig)),baseConfigSha256:config.baseConfigSha256,serviceAccountToken:token,callbackToken:callbackToken(await machineKey(),r),deadline:r.deadline});requireValue(Buffer.byteLength(body)<=1024*1024,'startup_limit');
   // The start POST is never retried, even if its response is lost.
   await edit(r=>{launchable(r,'booting');requireValue(!r.submitted,'submission_already_reserved');r.submitted=true;});
   launchable(await storage.get('job'),'booting');
   const response=await container.getTcpPort(8080).fetch('http://container/start',{method:'POST',headers:{'content-type':'application/json'},body,signal:AbortSignal.timeout(10000)});await response.body?.cancel();requireValue(response.status===202,'submission_unknown');
   await edit(r=>{if(r.phase==='booting')r.phase='running';});
  }catch{await edit(r=>{if(!r.cleanup)r.phase='uncertain';});}
  return status();
 }
 async function bound(props){const r=await storage.get('job');requireValue(r&&exact(props,['jobId','containerId','identity'])&&props.jobId===r.job.id&&props.containerId===containerId&&r.containerId===containerId&&props.identity===r.identity&&!r.cleanup&&now()<r.deadline,'callback_identity_denied');return r;}
 async function callback(path,input,authorization,props){
  let r=await bound(props);const expected='Bearer '+callbackToken(await machineKey(),r);requireValue(typeof authorization==='string'&&Buffer.byteLength(authorization)===Buffer.byteLength(expected)&&timingSafeEqual(Buffer.from(authorization),Buffer.from(expected)),'callback_auth_denied');r=await bound(props);
  requireValue(input?.jobId===r.job.id&&input.payloadHash===r.job.payloadHash,'callback_job_denied');
  if(path==='/v1/journal/reserve'){
   requireValue(exact(input,['jobId','payloadHash']),'journal_schema');return edit(r=>{if(r.execution)return {reserved:false};requireValue(!r.cleanup&&now()<r.deadline,'job_closed');r.execution='reserved';return {reserved:true};});
  }
  if(path==='/v1/journal/update'){
   requireValue(exact(input,['jobId','payloadHash','state','receipt']),'journal_schema');const receipt=safeReceipt(input.receipt),next=input.state;
   return edit(async(r,tx)=>{
    requireValue(!r.cleanup&&now()<r.deadline,'job_closed');
    if(terminal.has(r.execution)){requireValue(r.execution===next&&Object.entries(receipt).every(([k,v])=>r.receipt[k]===v),'journal_terminal');return {updated:true};}
    const from=r.execution??'new',transitions={new:['failed','uncertain'],reserved:['captured','failed','uncertain','recovery-required'],captured:['vault-saved','recovery-required'], 'vault-saved':['succeeded','recovery-required']};requireValue(transitions[from]?.includes(next),'journal_transition');
    for(const k of ['recoveryId','kvId'])if(receipt[k]!==undefined)requireValue(r.receipt[k]===receipt[k],'output_receipt_unverified');
    if(['captured','vault-saved','succeeded','recovery-required'].includes(next))requireValue(r.receipt.recoveryId,'recovery_required');
    if(['vault-saved','succeeded'].includes(next))requireValue((receipt.itemId??r.receipt.itemId)&&(receipt.vaultId??r.receipt.vaultId),'vault_receipt_required');
    if(next==='succeeded'&&r.job.payload.KV!==false)requireValue(r.receipt.kvId,'kv_receipt_required');
    for(const [k,v] of Object.entries(receipt))requireValue(!r.receipt[k]||r.receipt[k]===v,'receipt_changed');r.receipt={...r.receipt,...receipt};r.execution=next;
    if(terminal.has(next))await tx.setAlarm(now()+1000);return {updated:true};
   });
  }
  if(path==='/v1/recovery'||path==='/v1/kv')return saveCiphertext(path.endsWith('/kv')?'kv':'recovery',input,r);
  throw Error('callback_route_denied');
 }
 async function saveCiphertext(kind,input,record){
  requireValue(exact(input,['jobId','payloadHash','envelope','digest'])&&typeof input.envelope==='string'&&Buffer.byteLength(input.envelope)<=131072&&digest(input.envelope)===input.digest,'ciphertext_schema');
  requireValue(record.execution&&(!terminal.has(record.execution))&&(kind!=='kv'||record.job.payload.KV!==false),'output_state_denied');
  const target=config.runnerConfig.infrastructure[kind],e=JSON.parse(input.envelope);requireValue(exact(e,['version','algorithm','keyId','fingerprint','context','encryptedDataKey','iv','tag','ciphertext'])&&e.version===1&&e.algorithm==='RSA-OAEP-256+A256GCM'&&e.keyId===target.keyId&&e.fingerprint===target.fingerprint&&exact(e.context,['jobId','payloadHash','purpose'])&&e.context.jobId===record.job.id&&e.context.payloadHash===record.job.payloadHash&&e.context.purpose===(kind==='kv'?'kv-output':'recovery'),'ciphertext_binding');
  for(const [name,min,max] of [['encryptedDataKey',384,1024],['iv',12,12],['tag',16,16],['ciphertext',1,65536]]){const value=e[name];requireValue(typeof value==='string'&&Buffer.from(value,'base64').toString('base64')===value&&Buffer.from(value,'base64').length>=min&&Buffer.from(value,'base64').length<=max,'ciphertext_encoding');}
  const targetURL=new URL(target.destination),objectKey=targetURL.pathname.slice(1)+record.job.id+(kind==='recovery'?'.json':''),id=target.destination+record.job.id+(kind==='recovery'?'.json':'');
  await edit(r=>{active(r);requireValue(r.execution,'output_state_denied');const old=r.outputs[kind];requireValue(!old||old.digest===input.digest,'ciphertext_collision');r.outputs[kind]??={digest:input.digest,key:objectKey,state:'reserved'};});
  active(await storage.get('job'));
  if(kind==='recovery'){requireValue(recovery,'recovery_unconfigured');await recovery.put(objectKey,input.envelope,{onlyIf:{etagDoesNotMatch:'*'},httpMetadata:{contentType:'application/json'}});const saved=await recovery.get(objectKey);requireValue(saved&&await saved.text()===input.envelope,'recovery_readback');}
  else {requireValue(output,'kv_unconfigured');await output.put(objectKey,input.envelope);requireValue(await output.get(objectKey)===input.envelope,'kv_readback');}
  await edit(r=>{requireValue(r.outputs[kind].digest===input.digest,'ciphertext_collision');r.outputs[kind].state='stored';r.receipt[kind==='recovery'?'recoveryId':'kvId']=id;if(kind==='recovery'&&terminal.has(r.execution)&&r.execution!=='succeeded')r.execution='recovery-required';});return {id,digest:input.digest};
 }
 async function outbound(request,props){
  const r=await bound(props),url=new URL(request.url);requireValue(url.protocol==='https:'&&!url.username&&!url.password&&!url.port&&!url.hash,'egress_denied');
  if(url.origin===INTERNAL_ORIGIN){requireValue(request.method==='POST'&&!url.search,'callback_route_denied');const input=await readJSON(request,131072);return Response.json(await callback(url.pathname,input,request.headers.get('authorization'),props),{headers:{'cache-control':'no-store'}});}
  requireValue([...r.profile.allowedOrigins,...config.runnerConfig.infrastructure.opOrigins].includes(url.origin)&&['GET','HEAD','POST','PUT','PATCH','DELETE','OPTIONS'].includes(request.method),'egress_denied');
  return fetcher(new Request(request,{redirect:'manual',signal:AbortSignal.timeout(Math.min(30000,Math.max(1,r.deadline-now())))}));
 }
 async function resume(){const r=await storage.get('job');if(!r){if(container?.running)await container.destroy();return;}if(r.cleanup==='destroyed')return;await storage.setAlarm(r.cleanup||terminal.has(r.execution)?now()+1000:r.deadline);if(container?.running){await container.setInactivityTimeout(Math.min(60000,Math.max(1,r.deadline-now())));waitUntil(container.monitor().then(stopped,stopped).catch(()=>{}));}}
 return {dispatch,status,callback,alarm,stopped,outbound,resume};
}
export async function readText(request,max){const reader=request.body?.getReader();requireValue(reader,'body_required');let length=0;const chunks=[];try{for(;;){const {done,value}=await reader.read();if(done)break;length+=value.length;requireValue(length<=max,'body_limit');chunks.push(value);}}finally{void reader.cancel().catch(()=>{});}return new TextDecoder('utf-8',{fatal:true}).decode(Buffer.concat(chunks,length));}
export async function readJSON(request,max){return JSON.parse(await readText(request,max));}
export function createDispatchHandler({config,keyProvider,jobProvider,now=Date.now}){
 return async request=>{
  const url=new URL(request.url);if(url.pathname!=='/v1/dispatch'||url.search)return new Response('Not found',{status:404});if(request.method!=='POST')return new Response('Method not allowed',{status:405});
  let key,envelope;try{requireValue(/^application\/json(?:\s*;|$)/i.test(request.headers.get('content-type')??''));key=await keyProvider();envelope=verifyEnvelope({raw:await readText(request,131072),signature:request.headers.get('x-provisioner-signature'),key,audience:config.audience,now:now()});}catch{return Response.json({error:'unauthorized'},{status:401,headers:{'cache-control':'no-store'}});}
  let result;try{validateJob(envelope.job,envelope.profile,config);result=await jobProvider(envelope.job.id).dispatch(envelope);}catch{result={jobId:envelope.job?.id,state:config.qualified===true?'uncertain':'blocked'};}
  const body=JSON.stringify({...result,requestNonce:envelope.nonce});return new Response(body,{headers:{'content-type':'application/json','cache-control':'no-store','x-content-type-options':'nosniff','x-provisioner-signature':createHmac('sha256',key).update(body).digest('base64url')}});
 };
}
