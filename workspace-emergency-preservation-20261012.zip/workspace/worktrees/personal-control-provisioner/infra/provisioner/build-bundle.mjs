#!/usr/bin/env node
import {writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {collectBundleFiles} from '../../runner/verify-bundle.mjs';
import {canonical,digest} from './launcher.mjs';
// Run AFTER npm ci in both isolated packages, on the final installed image tree.
const [root,output]=process.argv.slice(2);
if(!root||!output||process.argv.length!==4)throw Error('usage: build-bundle.mjs ROOT OUTPUT_MANIFEST');
const manifest={version:1,files:await collectBundleFiles(resolve(root))};
await writeFile(resolve(output),canonical(manifest)+'\n',{mode:0o644,flag:'wx'});
process.stdout.write(JSON.stringify({codeDigest:digest(canonical(manifest)),files:Object.keys(manifest.files).length})+'\n');
