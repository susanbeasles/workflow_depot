# Existing-key native signing transport

This package implements the Chromium extension, POSIX Python 3.11+ native messaging host and adapter for an existing YubiKey PIV signing key. It does not create, import, replace or enroll a key, register a native host, install an extension, or provide a production software-key fallback. Hardware and browser qualification remain separate from the offline tests.

The page uses `createNativeProvisionerSigner` and the validated `PROVISIONER_SIGNER_EXTENSION_ID`. The extension restricts the configured owner origin and top-level document, then opens one persistent native messaging port. A configured extension ID establishes neither installation nor successful hardware signing.

## Preserved signing protocol

The first P-256/SHA-256 signature covers the exact UTF-8 JSON tuple `['provisioner.auth-request.v1', requestId, issuedAt, audience, keyId, profileDigest, payloadHash]`. The second signature covers only the returned 43-character nonce string. Signatures use fixed-width P1363 encoding. `keyId` is lowercase SHA-256 hex of the existing 65-byte uncompressed P-256 X9.63 public key. The host validates the first message's freshness, audience, key and approved complete profile digest; it accepts a nonce only after that first signature and consumes the pending approval before attempting the second hardware operation.

`native/framing.py` bounds native-endian, length-prefixed UTF-8 JSON. `native/protocol.py` rejects unknown fields, duplicate JSON keys, wrong origin/key, malformed encodings and unsupported signing purposes. `native/host.py` loads only its adjacent approved public configuration under Python isolated mode. The hardware adapter uses the official Yubico PIV API and checks the selected device serial, slot 9c, P-256 public key and existing key policies before requesting a PIN. Returned DER signatures are verified against the pinned public key and converted to P1363. Failure messages contain fixed codes rather than SDK, PIN or device diagnostics.

The supported existing slot must report a generated P-256 key with PIN_ALWAYS and TOUCH_ALWAYS policy. Unsupported metadata or a policy mismatch blocks signing; this host never changes the device to satisfy those requirements. The PIN prompt uses the approved local GUI pinentry executable and its SHA-256 pin. PIN entry and hardware operations run in a bounded child with an independent parent-lifetime watchdog; cancellation, disconnect, parent loss or timeout stops that attempt without automatic retries. PINs are never accepted from the web page, configuration, arguments or environment. Mutable PIN buffers are cleared, but Python, SDK and OS memory are not claimed to be perfectly erased.

## Public package inputs

The offline packager requires these existing public values:

- Exact owner origin and private admission audience, existing enrolled key ID and X9.63 public key, YubiKey serial, slot `9c`, and the approved profile digests.
- Existing extension ID and public SPKI, which the packager checks against that ID.
- Approved local Python path with the pinned requirements available, plus the GUI pinentry absolute path and reviewed SHA-256.

Prepare a reviewable package with public files only:

```sh
node signer/prepare.mjs PUBLIC_CONFIG.json OUTPUT_DIR --python ABSOLUTE_PYTHON --extension-key PUBLIC_BASE64_SPKI_FILE
```

The output directory must not exist. The generated native manifest allows exactly the configured extension; the extension manifest allows exactly the configured owner origin. The launcher invokes the selected Python with `-I`. Preparation copies source and public configuration only and returns `installed:false`; registration and installation are not part of that command.

## Offline verification and limits

```sh
python3 -I test/provisioner-native.test.py -v
node --test test/provisioner-signer-package.test.mjs test/provisioner-extension.test.mjs test/provisioner-ui.test.mjs
```

Protocol and hardware-adapter tests use fixtures, and package tests use public-only key metadata. A subprocess test launches the actual packaged isolated host and verifies its framed handshake without accessing a device or signing. The normal repository verification command includes native tests with a time limit. No real PIN, signing operation, key enrollment or native installation is required by these tests.

Live activation still needs the matching existing hardware and policy to be checked on the intended client, a reviewed local dependency/pinentry runtime, and installation of the prepared native manifest and extension. Offline success does not establish that the user has that hardware connected or that the browser can access it. The Cloudflare executor and real provider recipe remain independently disabled until their qualification is complete.

References: [Chrome native messaging](https://developer.chrome.com/docs/extensions/develop/concepts/native-messaging), [Yubico PIV API](https://developers.yubico.com/yubikey-manager/API_Documentation/autoapi/yubikit/piv/index.html).
