import * as config from './config.js';
import {installProvisionerTransport} from './transport.js';

installProvisionerTransport(chrome,config);
