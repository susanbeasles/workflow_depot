// Inert source template. The reviewed bundle builder pins the real public values.
export const OWNER_ORIGIN='https://unconfigured.invalid';
export const KEY_ID='UNCONFIGURED';
export const NATIVE_HOST='me.vespoli.provisioner';
