// Chrome supplies the sender identity. Never accept it from a page message.
export function installProvisionerTransport(chrome,{OWNER_ORIGIN,KEY_ID,NATIVE_HOST},{setTimer=setTimeout,clearTimer=clearTimeout,requestTimeoutMs=120000}={}){
  const runtime=chrome.runtime,tabs=new Map(),encoder=new TextEncoder();
  const uuid=value=>typeof value==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
  const exact=(value,keys)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).sort().join(',')===keys.slice().sort().join(',');
  const bounded=value=>{try{return encoder.encode(JSON.stringify(value)).length<=4096;}catch{return false;}};
  const encoded=bytes=>btoa(String.fromCharCode(...bytes)).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
  const decoded=value=>{
    if(typeof value!=='string'||value.length>2731||!/^[A-Za-z0-9_-]+$/.test(value))return null;
    try{const bytes=Uint8Array.from(atob(value.replace(/-/g,'+').replace(/_/g,'/')),character=>character.charCodeAt(0));return encoded(bytes)===value?bytes:null;}catch{return null;}
  };
  const errors=new Set(['invalid-request','origin-denied','key-mismatch','signer-unavailable','signer-declined','invalid-signer-response','approval-order-invalid','approval-expired','signer-timeout','native-disconnected']);
  let configured=false;
  try{const url=new URL(OWNER_ORIGIN);configured=url.origin===OWNER_ORIGIN&&url.protocol==='https:'&&!url.port&&['.vespoli.me','.anthonyvespoli.com'].some(suffix=>url.hostname.endsWith(suffix))&&/^[a-f0-9]{64}$/.test(KEY_ID)&&NATIVE_HOST==='me.vespoli.provisioner';}catch{}
  const validSender=sender=>{
    try{return configured&&sender?.origin===OWNER_ORIGIN&&new URL(sender.url).origin===OWNER_ORIGIN&&Number.isSafeInteger(sender.tab?.id)&&sender.tab.id>=0&&sender.frameId===0&&uuid(sender.documentId)&&(!sender.documentLifecycle||sender.documentLifecycle==='active');}catch{return false;}
  };
  runtime.onConnectExternal.addListener(page=>{
    if(page.name!=='provisioner-v1'||!validSender(page.sender)||tabs.has(page.sender.tab.id)){page.disconnect();return;}
    const tabId=page.sender.tab.id,documentId=page.sender.documentId;
    let native,pending,closed=false,phase='hello';
    const send=value=>{try{page.postMessage(value);}catch{}};
    const close=()=>{
      if(closed)return;closed=true;if(pending)clearTimer(pending.timer);pending=null;
      if(tabs.get(tabId)?.documentId===documentId)tabs.delete(tabId);
      try{native?.disconnect();}catch{}try{page.disconnect();}catch{}
    };
    const fail=(code,id=pending?.id)=>{if(closed)return;if(uuid(id))send({version:1,id,ok:false,error:code});close();};
    tabs.set(tabId,{documentId});
    try{native=runtime.connectNative(NATIVE_HOST);}catch{close();return;}
    page.onDisconnect.addListener(()=>{void runtime.lastError;close();});
    native.onDisconnect.addListener(()=>{void runtime.lastError;fail('native-disconnected');});
    native.onMessage.addListener(response=>{
      if(closed)return;
      if(!pending||!bounded(response)||response.version!==1||response.id!==pending.id||typeof response.ok!=='boolean'){fail('invalid-signer-response');return;}
      if(response.ok===false){
        if(!exact(response,['version','id','ok','error'])||!errors.has(response.error)){fail('invalid-signer-response');return;}
        fail(response.error);return;
      }
      const signature=pending.action==='sign',bytes=signature?decoded(response.signature):null;
      if(!exact(response,signature?['version','id','ok','keyId','signature']:['version','id','ok','keyId'])||response.keyId!==KEY_ID||signature&&bytes?.length!==64){fail('invalid-signer-response');return;}
      clearTimer(pending.timer);phase=pending.next;pending=null;send(response);
    });
    page.onMessage.addListener(request=>{
      if(closed)return;
      if(!validSender(page.sender)||page.sender.tab.id!==tabId||page.sender.documentId!==documentId){fail('origin-denied',request?.id);return;}
      if(pending){fail('invalid-request',request?.id);return;}
      const signing=request?.action==='sign',keys=['version','id','action','origin','keyId',...(signing?['purpose','bytes']:[])];
      if(!bounded(request)||!exact(request,keys)||request.version!==1||!uuid(request.id)||!['hello','sign'].includes(request.action)){fail('invalid-request',request?.id);return;}
      if(request.origin!==OWNER_ORIGIN){fail('origin-denied',request.id);return;}
      if(request.keyId!==KEY_ID){fail('key-mismatch',request.id);return;}
      let next;
      if(request.action==='hello'){
        if(phase!=='hello'){fail('approval-order-invalid',request.id);return;}next='auth';
      }else{
        const bytes=decoded(request.bytes);
        if(request.purpose==='provisioner.auth-request.v1'){
          if(phase!=='auth'){fail('approval-order-invalid',request.id);return;}
          if(!bytes||bytes.length>2048){fail('invalid-request',request.id);return;}next='nonce';
        }else if(request.purpose==='provisioner.nonce.v1'){
          if(phase!=='nonce'){fail('approval-order-invalid',request.id);return;}
          const nonce=bytes&&String.fromCharCode(...bytes),nonceBytes=nonce&&decoded(nonce);
          if(bytes?.length!==43||nonceBytes?.length!==32){fail('invalid-request',request.id);return;}next='done';
        }else{fail('invalid-request',request.id);return;}
      }
      const timer=setTimer(()=>fail('signer-timeout'),request.action==='hello'?10000:requestTimeoutMs);
      pending={id:request.id,action:request.action,next,timer};
      try{native.postMessage({version:1,id:request.id,action:request.action,origin:OWNER_ORIGIN,keyId:KEY_ID,...(signing?{purpose:request.purpose,bytes:request.bytes}:{})});}catch{fail('native-disconnected');}
    });
  });
}
