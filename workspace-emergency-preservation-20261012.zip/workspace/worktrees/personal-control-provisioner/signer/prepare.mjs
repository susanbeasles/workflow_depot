// Offline package preparation only. Never registers a native host or installs an extension.
import {createHash,createPublicKey} from 'node:crypto';
import {mkdir,readFile,writeFile,readdir,copyFile,chmod} from 'node:fs/promises';
import {dirname,isAbsolute,join,resolve} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';

const source=dirname(fileURLToPath(import.meta.url));
const fail=code=>{throw new Error(code);};
const exactOrigin=value=>{
 try{const u=new URL(value);return u.protocol==='https:'&&u.origin===value&&/^[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(vespoli\.me|anthonyvespoli\.com)$/.test(u.hostname)&&!u.port;}catch{return false;}
};
const canonical=(value,size)=>typeof value==='string'&&/^[A-Za-z0-9_-]+$/.test(value)&&Buffer.from(value,'base64url').length===size&&Buffer.from(value,'base64url').toString('base64url')===value;
const absolutePath=value=>typeof value==='string'&&isAbsolute(value)&&!/[\x00-\x1f\x7f]/.test(value);

export function validateSignerConfig(config){
 const fields=['version','extensionId','ownerOrigin','audience','keyId','publicKeyX963','serial','slot','profileDigests','pinentryPath','pinentrySha256'];
 if(!config||Object.getPrototypeOf(config)!==Object.prototype||Object.keys(config).sort().join()!==fields.sort().join()||config.version!==1||!/^[a-p]{32}$/.test(config.extensionId??'')||!exactOrigin(config.ownerOrigin)||!exactOrigin(config.audience)||!/^[a-f0-9]{64}$/.test(config.keyId??'')||!canonical(config.publicKeyX963,65)||!Number.isSafeInteger(config.serial)||config.serial<=0||config.slot!=='9c'||!Array.isArray(config.profileDigests)||!config.profileDigests.length||config.profileDigests.length>32||new Set(config.profileDigests).size!==config.profileDigests.length||config.profileDigests.some(d=>!canonical(d,32))||!absolutePath(config.pinentryPath)||!/^[a-f0-9]{64}$/.test(config.pinentrySha256??''))fail('invalid-signer-config');
 const raw=Buffer.from(config.publicKeyX963,'base64url');
 if(raw[0]!==4||createHash('sha256').update(raw).digest('hex')!==config.keyId)fail('invalid-signer-config');
 try{createPublicKey({format:'jwk',key:{kty:'EC',crv:'P-256',x:raw.subarray(1,33).toString('base64url'),y:raw.subarray(33).toString('base64url')}});}catch{fail('invalid-signer-config');}
 return structuredClone(config);
}

export async function prepareSigner({config,outputDir,pythonPath,extensionPublicKey}){
 const validated=validateSignerConfig(config);
 if(!absolutePath(outputDir)||!absolutePath(pythonPath))fail('invalid-runtime-path');
 // An existing extension's public SPKI fixes its ID across unpacked install paths.
 // This is public metadata, never an extension signing private key.
 let extensionDer;
 try{
  if(typeof extensionPublicKey!=='string'||extensionPublicKey.length>8192||!/^[A-Za-z0-9+/]+={0,2}$/.test(extensionPublicKey))throw Error();
  extensionDer=Buffer.from(extensionPublicKey,'base64');
  if(extensionDer.toString('base64')!==extensionPublicKey)throw Error();
  createPublicKey({key:extensionDer,format:'der',type:'spki'});
  const extensionId=createHash('sha256').update(extensionDer).digest('hex').slice(0,32).replace(/[0-9a-f]/g,n=>String.fromCharCode(97+parseInt(n,16)));
  if(extensionId!==validated.extensionId)throw Error();
 }catch{fail('extension-public-key-mismatch');}
 // Resolve paths before writing a launcher; quote POSIX words without shell expansion.
 const dest=resolve(outputDir),python=resolve(pythonPath),quote=value=>"'"+value.replaceAll("'","'\\''")+"'";
 const manifest=JSON.parse(await readFile(join(source,'extension/manifest.json'),'utf8'));
 manifest.externally_connectable={matches:[validated.ownerOrigin+'/*']};
 manifest.key=extensionDer.toString('base64');
 const nativeFiles=(await readdir(join(source,'native'),{withFileTypes:true})).filter(entry=>entry.isFile()&&/^[a-z_]+\.py$/.test(entry.name)).map(entry=>entry.name);
 if(!['host.py','protocol.py','framing.py'].every(name=>nativeFiles.includes(name)))fail('native-host-source-missing');
 // Read the complete source package before creating the output directory.
 // A missing dependency file must not leave a seemingly usable partial package.
 const nativeSources=new Map();let requirements;
 try{
  for(const name of nativeFiles){const bytes=await readFile(join(source,'native',name));if(bytes.length===0||bytes.length>262144)fail('native-host-source-missing');nativeSources.set(name,bytes);}
  requirements=await readFile(join(source,'requirements.txt'));if(requirements.length===0||requirements.length>16384)fail('native-host-source-missing');
 }catch{fail('native-host-source-missing');}
 try{await mkdir(dest,{mode:0o700});}catch(error){if(error.code==='EEXIST')fail('output-exists');throw error;}
 await mkdir(join(dest,'extension'),{mode:0o700});await mkdir(join(dest,'native'),{mode:0o700});
 for(const name of await readdir(join(source,'extension'))){
  if(name==='manifest.json'||name==='config.js')continue;
  if(/^[a-z-]+\.(?:js|mjs)$/.test(name))await copyFile(join(source,'extension',name),join(dest,'extension',name));
 }
 for(const [name,bytes] of nativeSources)await writeFile(join(dest,'native',name),bytes,{mode:0o600});
 await writeFile(join(dest,'extension/manifest.json'),JSON.stringify(manifest,null,2)+'\n',{mode:0o600});
 await writeFile(join(dest,'extension/config.js'),`export const OWNER_ORIGIN=${JSON.stringify(validated.ownerOrigin)};\nexport const KEY_ID=${JSON.stringify(validated.keyId)};\nexport const NATIVE_HOST='me.vespoli.provisioner';\n`,{mode:0o600});
 await writeFile(join(dest,'native/host-config.json'),JSON.stringify(validated,null,2)+'\n',{mode:0o600});
 const launcher=join(dest,'native/launch');
 await writeFile(launcher,`#!/bin/sh\nexec ${quote(python)} -I ${quote(join(dest,'native/host.py'))} "$@"\n`,{mode:0o700});
 await chmod(launcher,0o700);
 await writeFile(join(dest,'me.vespoli.provisioner.json'),JSON.stringify({name:'me.vespoli.provisioner',description:'Existing PIV key for Personal Control provisioning',path:launcher,type:'stdio',allowed_origins:['chrome-extension://'+validated.extensionId+'/']},null,2)+'\n',{mode:0o600});
 await writeFile(join(dest,'requirements.txt'),requirements,{mode:0o600});
 return {outputDir:dest,installed:false,extensionId:validated.extensionId,keyId:validated.keyId};
}

if(process.argv[1]&&import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
 try{
  const [configPath,outputDir,option,pythonPath,keyOption,keyPath,...extra]=process.argv.slice(2);
  if(!configPath||!outputDir||option!=='--python'||!pythonPath||keyOption!=='--extension-key'||!keyPath||extra.length)fail('usage: node signer/prepare.mjs PUBLIC_CONFIG.json OUTPUT_DIR --python ABSOLUTE_PYTHON --extension-key PUBLIC_BASE64_SPKI_FILE');
  const bytes=await readFile(configPath);if(bytes.length>16384)fail('invalid-signer-config');
  const extensionPublicKey=(await readFile(keyPath,'utf8')).trim();
  console.log(JSON.stringify(await prepareSigner({config:JSON.parse(bytes.toString('utf8')),outputDir,pythonPath,extensionPublicKey})));
 }catch(error){console.error(['invalid-signer-config','invalid-runtime-path','output-exists','native-host-source-missing','extension-public-key-mismatch'].includes(error.message)||error.message.startsWith('usage:')?error.message:'signer-package-failed');process.exitCode=1;}
}
