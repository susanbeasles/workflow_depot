#!/usr/bin/env python3
"""POSIX Chrome native host. No command-line signing or secret configuration."""
import os
from pathlib import Path
import stat
import signal
import sys


def main():
    # -I deliberately excludes cwd and PYTHONPATH. Validate the fixed sibling
    # directory before adding only that directory for our two local imports.
    if os.name != "posix" or sys.version_info < (3, 11) or len(sys.argv) != 2:
        return 1
    directory = Path(__file__).resolve().parent
    for parent in (directory, *directory.parents):
        info = parent.stat()
        if parent == Path(parent.anchor):
            if not stat.S_ISDIR(info.st_mode) or info.st_mode & 0o022:
                return 1
            continue
        if info.st_uid not in (0, os.getuid()) or info.st_mode & 0o022:
            if parent == directory or info.st_uid != 0 or not info.st_mode & stat.S_ISVTX:
                return 1
    for name in ("host.py", "protocol.py", "framing.py"):
        path = directory / name
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid not in (0, os.getuid()) or info.st_mode & 0o022:
            return 1
    sys.path.insert(0, str(directory))
    import protocol
    from framing import encode_frame, read_frame
    def cancelled(_number, _frame):
        raise protocol.HostError("native-disconnected")
    for number in (signal.SIGTERM, signal.SIGHUP, signal.SIGINT):
        signal.signal(number, cancelled)
    protocol.trusted_file(directory / "host-config.json", private=True)
    with open(directory / "host-config.json", "rb") as config_file:
        config = protocol.strict_json(config_file.read(16385))
    session = protocol.HostSession(config, sys.argv[1])
    protocol.transport_fd = sys.stdin.fileno()
    # Avoid BufferedReader prefetch concealing an overlapping next request from
    # the signing parent's input-pipe cancellation monitor.
    input_stream = os.fdopen(sys.stdin.fileno(), "rb", buffering=0, closefd=False)
    while True:
        request = read_frame(input_stream)
        if request is None:
            return 0
        response = session.handle(request)
        sys.stdout.buffer.write(encode_frame(response))
        sys.stdout.buffer.flush()
        if response["ok"] is False:
            return 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception:
        # Never echo a request, PIN, SDK diagnostics, or local filesystem paths.
        sys.exit(1)
