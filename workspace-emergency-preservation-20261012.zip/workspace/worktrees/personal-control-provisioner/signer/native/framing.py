"""Bounded Chrome native messaging frames; stdout is reserved for these frames."""
import json
import struct

from protocol import HostError, strict_json

MAX_FRAME = 8192


def _read_exact(stream, count):
    parts = bytearray()
    while len(parts) < count:
        piece = stream.read(count - len(parts))
        if not piece:
            raise HostError("invalid-request")
        parts.extend(piece)
    return bytes(parts)


def read_frame(stream):
    first = stream.read(1)
    if not first:
        return None
    length = struct.unpack("=I", first + _read_exact(stream, 3))[0]
    if not 1 <= length <= MAX_FRAME:
        raise HostError("invalid-request")
    return strict_json(_read_exact(stream, length))


def encode_frame(value):
    try:
        raw = json.dumps(value, separators=(",", ":"), allow_nan=False).encode("utf-8")
    except (TypeError, ValueError, UnicodeError):
        raise HostError("invalid-request") from None
    if not 1 <= len(raw) <= MAX_FRAME:
        raise HostError("invalid-request")
    return struct.pack("=I", len(raw)) + raw
