"""Pinned PIV signing only. No private-key import, enrollment, or software signer."""
import base64
import hashlib
import json
import os
import re
import select
import signal
import stat
import subprocess
import time
from pathlib import Path

ERRORS = frozenset(("invalid-request", "origin-denied", "key-mismatch",
                   "signer-unavailable", "signer-declined", "invalid-signer-response",
                   "approval-order-invalid", "approval-expired", "signer-timeout",
                   "native-disconnected"))
AUTH = "provisioner.auth-request.v1"
NONCE = "provisioner.nonce.v1"
UUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}", re.I)
HEX = re.compile(r"[a-f0-9]{64}")
ORIGIN = re.compile(r"https://[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:vespoli\.me|anthonyvespoli\.com)")
P256_P = 0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff
P256_B = 0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b
P256_N = 0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551
SIGN_TIMEOUT = 90
PIN_TIMEOUT = 60
# Set only by host.py, never by page data. A closed Chrome input pipe cancels a prompt.
transport_fd = None


class HostError(Exception):
    def __init__(self, code):
        self.code = code if code in ERRORS else "signer-unavailable"
        super().__init__(self.code)


def b64url(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def decode64(value, size=None, maximum=2048):
    if not isinstance(value, str) or len(value) > (maximum * 4 + 2) // 3 or not re.fullmatch(r"[A-Za-z0-9_-]+", value):
        raise HostError("invalid-request")
    try:
        raw = base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))
    except (ValueError, TypeError):
        raise HostError("invalid-request") from None
    if b64url(raw) != value or len(raw) > maximum or size is not None and len(raw) != size:
        raise HostError("invalid-request")
    return raw


def strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise HostError("invalid-request")
            result[key] = value
        return result
    def invalid(_):
        raise HostError("invalid-request")
    try:
        if not isinstance(raw, bytes) or len(raw) > 16384:
            raise HostError("invalid-request")
        return json.loads(raw.decode("utf-8", "strict"), object_pairs_hook=pairs, parse_constant=invalid)
    except (ValueError, UnicodeError, RecursionError):
        raise HostError("invalid-request") from None


def _matches(pattern, value):
    return isinstance(value, str) and pattern.fullmatch(value) is not None


def validate_config(config):
    fields = {"version", "extensionId", "ownerOrigin", "audience", "keyId", "publicKeyX963",
              "serial", "slot", "profileDigests", "pinentryPath", "pinentrySha256"}
    if (type(config) is not dict or set(config) != fields or type(config["version"]) is not int or config["version"] != 1
            or not _matches(re.compile(r"[a-p]{32}"), config["extensionId"])
            or not _matches(ORIGIN, config["ownerOrigin"]) or not _matches(ORIGIN, config["audience"])
            or not _matches(HEX, config["keyId"]) or type(config["serial"]) is not int
            or not 0 < config["serial"] <= 9007199254740991 or config["slot"] != "9c"
            or type(config["profileDigests"]) is not list or not 1 <= len(config["profileDigests"]) <= 32
            or not isinstance(config["pinentryPath"], str) or not os.path.isabs(config["pinentryPath"])
            or re.search(r"[\x00-\x1f\x7f]", config["pinentryPath"])
            or not _matches(HEX, config["pinentrySha256"])):
        raise HostError("invalid-request")
    public = decode64(config["publicKeyX963"], 65)
    x, y = int.from_bytes(public[1:33], "big"), int.from_bytes(public[33:], "big")
    if (public[0] != 4 or x >= P256_P or y >= P256_P
            or (y * y - (x * x * x - 3 * x + P256_B)) % P256_P != 0
            or hashlib.sha256(public).hexdigest() != config["keyId"]):
        raise HostError("key-mismatch")
    for digest in config["profileDigests"]:
        decode64(digest, 32)
    if len(set(config["profileDigests"])) != len(config["profileDigests"]):
        raise HostError("invalid-request")
    return json.loads(json.dumps(config))


class HostSession:
    def __init__(self, config, caller):
        self.config = validate_config(config)
        # Chrome documents the origin without a slash; its manifest uses one.
        origin = "chrome-extension://" + self.config["extensionId"]
        if caller not in (origin, origin + "/"):
            raise HostError("origin-denied")
        self.pending = None
        self.used_ids = set()
        self.used_auth = set()
        self.completed = False

    def handle(self, request):
        response_id = request.get("id") if type(request) is dict else None
        if not _matches(UUID, response_id):
            response_id = "00000000-0000-4000-8000-000000000000"
        response = {"version": 1, "id": response_id}
        try:
            signature = self._handle(request)
            return {**response, "ok": True, "keyId": self.config["keyId"],
                    **({"signature": b64url(signature)} if signature is not None else {})}
        except HostError as error:
            return {**response, "ok": False, "error": error.code}
        except Exception:
            return {**response, "ok": False, "error": "signer-unavailable"}

    def _handle(self, request):
        fields = {"version", "id", "action", "origin", "keyId"}
        if type(request) is not dict:
            raise HostError("invalid-request")
        if request.get("action") == "sign":
            fields |= {"purpose", "bytes"}
        if (set(request) != fields or type(request["version"]) is not int or request["version"] != 1
                or not _matches(UUID, request["id"]) or request["action"] not in ("hello", "sign")):
            raise HostError("invalid-request")
        if request["origin"] != self.config["ownerOrigin"]:
            raise HostError("origin-denied")
        if request["keyId"] != self.config["keyId"]:
            raise HostError("key-mismatch")
        if request["id"].lower() in self.used_ids or len(self.used_ids) >= 64:
            raise HostError("approval-order-invalid")
        self.used_ids.add(request["id"].lower())
        if request["action"] == "hello":
            if self.pending is not None or self.completed:
                raise HostError("approval-order-invalid")
            return None
        raw = decode64(request["bytes"])
        if request["purpose"] == AUTH:
            if self.pending is not None or self.completed:
                raise HostError("approval-order-invalid")
            parts = strict_json(raw)
            if (type(parts) is not list or len(parts) != 7 or parts[0] != AUTH
                    or not _matches(UUID, parts[1]) or type(parts[2]) is not int
                    or abs(time.time() - parts[2]) > 30 or parts[3] != self.config["audience"]
                    or parts[4] != self.config["keyId"] or parts[5] not in self.config["profileDigests"]
                    or json.dumps(parts, separators=(",", ":"), ensure_ascii=False).encode("utf-8") != raw):
                raise HostError("invalid-request")
            decode64(parts[6], 32)
            if parts[1].lower() in self.used_auth:
                raise HostError("approval-order-invalid")
            self.used_auth.add(parts[1].lower())
            signature = bounded_sign(self.config, raw)
            if not isinstance(signature, bytes) or len(signature) != 64:
                raise HostError("invalid-signer-response")
            # Start the local allowance when the first approval finishes. The
            # independent server also enforces issuedAt and its nonce expiry.
            self.pending = (time.time() + 120, time.monotonic() + 120)
            return signature
        if request["purpose"] == NONCE:
            if self.pending is None or self.completed:
                raise HostError("approval-order-invalid")
            expires, monotonic_expires = self.pending
            self.pending = None  # Consume before parsing or any hardware attempt.
            if time.time() >= expires or time.monotonic() >= monotonic_expires:
                raise HostError("approval-expired")
            if len(raw) != 43:
                raise HostError("invalid-request")
            try:
                decode64(raw.decode("ascii"), 32)
            except UnicodeError:
                raise HostError("invalid-request") from None
            signature = bounded_sign(self.config, raw)
            if not isinstance(signature, bytes) or len(signature) != 64:
                raise HostError("invalid-signer-response")
            self.completed = True
            return signature
        raise HostError("invalid-request")


def trusted_file(path, *, private=False):
    """Require a locally installed, non-writable-by-others regular file."""
    target = Path(path)
    if not target.is_absolute() or target.is_symlink():
        raise HostError("signer-unavailable")
    info = target.stat()
    if not stat.S_ISREG(info.st_mode) or info.st_uid not in (0, os.getuid()) or info.st_mode & (0o077 if private else 0o022):
        raise HostError("signer-unavailable")
    for directory in target.resolve().parents:
        meta = directory.stat()
        if directory == Path(directory.anchor):
            # The mounted filesystem root is the existing OS trust anchor. UID
            # mappings can differ in a namespace; writable roots remain forbidden.
            if not stat.S_ISDIR(meta.st_mode) or meta.st_mode & 0o022:
                raise HostError("signer-unavailable")
            continue
        if meta.st_uid not in (0, os.getuid()) or meta.st_mode & 0o022:
            # A root-owned sticky /tmp ancestor is safe; the package itself is private.
            if directory == target.parent or meta.st_uid != 0 or not meta.st_mode & stat.S_ISVTX:
                raise HostError("signer-unavailable")
    return info


def _pinentry(config, message):
    path = config["pinentryPath"]
    if Path(path).name not in {"pinentry-mac", "pinentry-qt", "pinentry-qt5", "pinentry-qt6", "pinentry-gnome3", "pinentry-gtk-2"}:
        raise HostError("signer-unavailable")
    before = trusted_file(path)
    if not before.st_mode & 0o111 or before.st_size > 32 * 1024 * 1024:
        raise HostError("signer-unavailable")
    with open(path, "rb") as executable:
        if hashlib.file_digest(executable, "sha256").hexdigest() != config["pinentrySha256"]:
            raise HostError("signer-unavailable")
    after = trusted_file(path)
    if (before.st_dev, before.st_ino, before.st_mtime_ns, before.st_size) != (after.st_dev, after.st_ino, after.st_mtime_ns, after.st_size):
        raise HostError("signer-unavailable")
    env = {key: os.environ[key] for key in ("HOME", "DISPLAY", "WAYLAND_DISPLAY", "XAUTHORITY", "DBUS_SESSION_BUS_ADDRESS", "XDG_RUNTIME_DIR", "LANG") if key in os.environ}
    env["PATH"] = "/usr/bin:/bin"
    # No shell, secret arguments, inherited stderr, terminal input, or PIN cache.
    child = subprocess.Popen([path], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=subprocess.DEVNULL, env=env, close_fds=True, bufsize=0)
    deadline = time.monotonic() + PIN_TIMEOUT
    total = 0
    def line():
        nonlocal total
        value = bytearray()
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not select.select([child.stdout], [], [], remaining)[0]:
                raise HostError("signer-timeout")
            char = os.read(child.stdout.fileno(), 1)
            total += len(char)
            if not char or total > 8192 or len(value) > 1024:
                raise HostError("signer-unavailable")
            if char == b"\n":
                return bytes(value).rstrip(b"\r")
            value.extend(char)
    def ok():
        value = line()
        if value.startswith(b"ERR "):
            raise HostError("signer-declined")
        if value != b"OK" and not value.startswith(b"OK "):
            raise HostError("signer-unavailable")
    def command(value):
        child.stdin.write(value + b"\n")
        child.stdin.flush()
    pin = bytearray()
    try:
        ok()
        description = ("Approve provisioner request for " + config["audience"]
                       if message.startswith(b"[") else "Approve one-use provisioner nonce for " + config["audience"])
        description += ". SHA256 " + hashlib.sha256(message).hexdigest() + ". Touch the pinned YubiKey after PIN."
        for value in (b"SETTITLE Personal Control hardware approval", b"SETDESC " + description.encode("ascii"), b"SETPROMPT PIV PIN:", b"SETOK Sign"):
            command(value)
            ok()
        command(b"GETPIN")
        value = line()
        if value.startswith(b"ERR "):
            raise HostError("signer-declined")
        if not value.startswith(b"D "):
            raise HostError("signer-unavailable")
        encoded = value[2:]
        index = 0
        while index < len(encoded):
            if encoded[index] == 37:
                if index + 2 >= len(encoded) or not re.fullmatch(b"[0-9a-fA-F]{2}", encoded[index + 1:index + 3]):
                    raise HostError("signer-unavailable")
                pin.append(int(encoded[index + 1:index + 3], 16))
                index += 3
            else:
                pin.append(encoded[index])
                index += 1
        ok()
        if not 6 <= len(pin) <= 8 or any(char < 33 or char > 126 for char in pin):
            raise HostError("signer-declined")
        return pin
    except BaseException:
        pin[:] = b"\0" * len(pin)
        raise
    finally:
        child.stdin.close()
        child.stdout.close()
        if child.poll() is None:
            child.terminate()
        try:
            child.wait(timeout=0.25)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait()


def hardware_sign(config, message):
    """Only production signing path: an already provisioned, exactly pinned PIV slot."""
    from ykman.device import list_all_devices
    from yubikit.core.smartcard import SmartCardConnection
    from yubikit.piv import PivSession, SLOT, KEY_TYPE, PIN_POLICY, TOUCH_POLICY
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec, utils

    devices = [(device, info) for device, info in list_all_devices([SmartCardConnection])
               if info.serial == config["serial"]]
    if len(devices) != 1:
        raise HostError("signer-unavailable")
    with devices[0][0].open_connection(SmartCardConnection) as connection:
        session = PivSession(connection)
        metadata = session.get_slot_metadata(SLOT.SIGNATURE)
        if (metadata.key_type != KEY_TYPE.ECCP256 or metadata.generated is not True
                or metadata.pin_policy != PIN_POLICY.ALWAYS or metadata.touch_policy != TOUCH_POLICY.ALWAYS):
            raise HostError("key-mismatch")
        public = metadata.public_key
        if not isinstance(public, ec.EllipticCurvePublicKey) or not isinstance(public.curve, ec.SECP256R1):
            raise HostError("key-mismatch")
        if public.public_bytes(serialization.Encoding.X962, serialization.PublicFormat.UncompressedPoint) != decode64(config["publicKeyX963"], 65):
            raise HostError("key-mismatch")
        pin = _pinentry(config, message)
        try:
            try:
                session.verify_pin(pin.decode("ascii"))
            except Exception:
                # Never automatically retry a PIN: hardware retry counters are finite.
                raise HostError("signer-declined") from None
        finally:
            pin[:] = b"\0" * len(pin)
        signature = session.sign(SLOT.SIGNATURE, KEY_TYPE.ECCP256, message, hashes.SHA256())
        try:
            public.verify(signature, message, ec.ECDSA(hashes.SHA256()))
            r, s = utils.decode_dss_signature(signature)
            if not 0 < r < P256_N or not 0 < s < P256_N:
                raise ValueError()
        except Exception:
            raise HostError("invalid-signer-response") from None
        return r.to_bytes(32, "big") + s.to_bytes(32, "big")


def bounded_sign(config, message):
    """Private fork/pipe boundary, not a command-line arbitrary-signing endpoint."""
    if os.name != "posix" or not hasattr(os, "fork"):
        raise HostError("signer-unavailable")
    read_fd, write_fd = os.pipe()
    life_read, life_write = os.pipe()
    gate_read, gate_write = os.pipe()
    deadline = time.monotonic() + SIGN_TIMEOUT
    try:
        pid = os.fork()
    except BaseException:
        for fd in (read_fd, write_fd, life_read, life_write, gate_read, gate_write):
            os.close(fd)
        raise
    if pid == 0:
        try:
            os.close(read_fd)
            os.close(life_read)
            os.close(life_write)
            os.close(gate_write)
            os.setsid()  # pinentry inherits this group and dies on timeout/disconnect.
            # No hardware import, PIN helper, or SDK call before the independent
            # watchdog is detached and ready. Death before release yields EOF.
            if os.read(gate_read, 1) != b"G":
                os._exit(0)
            os.close(gate_read)
            import resource
            resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
            null = os.open(os.devnull, os.O_RDWR)
            for fd in (0, 1, 2):
                os.dup2(null, fd)
            if null > 2:
                os.close(null)
            try:
                signature = hardware_sign(config, message)
                if not isinstance(signature, bytes) or len(signature) != 64:
                    raise HostError("invalid-signer-response")
                result = b"S" + signature
            except HostError as error:
                result = b"E" + error.code.encode("ascii")
            except BaseException:
                result = b"Esigner-unavailable"
            os.write(write_fd, result)
        finally:
            os._exit(0)
    os.close(write_fd)
    os.close(gate_read)
    try:
        watchdog = os.fork()
    except BaseException:
        os.close(life_read)
        os.close(life_write)
        os.close(gate_write)
        os.close(read_fd)
        _kill_group(pid)
        os.waitpid(pid, 0)
        raise
    if watchdog == 0:
        try:
            os.close(life_write)
            os.close(read_fd)
            # A browser may terminate the native host's whole process group.
            # Detach BEFORE releasing the worker gate, so at least one guard
            # always survives that operation whenever hardware can run.
            os.setsid()
            null = os.open(os.devnull, os.O_RDWR)
            for fd in (0, 1, 2):
                os.dup2(null, fd)
            if null > 2:
                os.close(null)
            if select.select([life_read], [], [], 0)[0]:
                raise HostError("native-disconnected")
            os.write(gate_write, b"G")
            os.close(gate_write)
            # Native-parent death closes the ONLY writer, even after SIGKILL.
            # This independent process also bounds a blocked SDK call when the
            # parent is stopped. It cannot sign or access the PIN.
            select.select([life_read], [], [], max(0, deadline - time.monotonic()))
        finally:
            _kill_group(pid)
            os._exit(0)
    os.close(life_read)
    os.close(gate_write)
    poller = select.poll()
    poller.register(read_fd, select.POLLIN | select.POLLHUP | select.POLLERR)
    if transport_fd is not None:
        # Input readability also rejects overlapping browser messages, never consumes them.
        poller.register(transport_fd, select.POLLIN | select.POLLHUP | select.POLLERR)
    result = bytearray()
    try:
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise HostError("signer-timeout")
            events = poller.poll(max(1, min(1000, int(remaining * 1000))))
            if any(fd == transport_fd for fd, _ in events):
                raise HostError("native-disconnected")
            if not events:
                continue
            piece = os.read(read_fd, 128)
            result.extend(piece)
            if len(result) > 128:
                raise HostError("invalid-signer-response")
            if not piece:
                if time.monotonic() >= deadline:
                    raise HostError("signer-timeout")
                break
        if len(result) == 65 and result[0] == ord("S"):
            return bytes(result[1:])
        if result.startswith(b"E"):
            raise HostError(bytes(result[1:]).decode("ascii"))
        raise HostError("invalid-signer-response")
    finally:
        os.close(read_fd)
        # Stop hardware/helpers FIRST. Keep the watchdog alive until then so
        # parent death in cleanup still cannot strand an active signing worker.
        _kill_group(pid)
        # Reap the watchdog before the worker so its PID cannot be recycled while
        # the watchdog could still signal that worker's process group.
        try:
            os.kill(watchdog, signal.SIGKILL)
        except ProcessLookupError:
            pass
        os.waitpid(watchdog, 0)
        os.close(life_write)
        os.waitpid(pid, 0)


def _kill_group(pid):
    try:
        os.killpg(pid, signal.SIGKILL)
    except ProcessLookupError:
        # The forked child may not yet have executed setsid.
        try:
            os.kill(pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
