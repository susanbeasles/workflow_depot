# Personal infrastructure control plane

`control.vespoli.me/owner` is the human authentication and navigation entry point. One owner-only Cloudflare Access application protects `/owner`; `gate.mjs` verifies its signed identity and rejects cross-origin mutations. `/login` accepts only registered relative pane routes. No capability creates its own login cookie, bearer-token issuer or owner identity verifier.

The gateway owns OAuth registration, PKCE consent, resource grants, access tokens, refresh rotation and revocation. Standard, super, write and caretaker are distinct resource audiences under the same issuer. Tokens are never interchangeable between them. Clients using the old caretaker issuer must reconnect to `https://control.vespoli.me/mcp/caretaker`.

Capability code is reached through fixed private service/DO bindings after authentication. Caretaker exposes a narrow named RPC entrypoint; backup registration exposes an owner-bound setup workflow; backup status exposes a read-only RPC entrypoint. Public setup endpoints redirect to their gateway pane. Public worker health never exposes credentials. GitHub callbacks retain owner-bound, expiring state to prevent callback substitution; that is transaction protection, not another login stack.

Signed GitHub webhooks and pinned Actions OIDC claims remain machine identities at their existing ingestion boundaries. They do not create human sessions. The recovered backup worker pins immutable owner and repository IDs, preserves its paused dispatch state, and does not equate installation or connectivity with completed backups.

## Extension contract

1. Add a focused capability descriptor in `src/capabilities.mjs` with its title, route, tool IDs and required private binding.
2. Put specialized UI behavior in one `src/capability-panes/` module. Reuse `ui.mjs` for navigation, schema fields and result rendering, and `owner-session.mjs` for scoped owner sessions.
3. Expose only fixed capability methods through a named private entrypoint. Do not accept arbitrary destinations, create login stacks, export keys or trust public identity headers.
4. Register schemas once; the same schemas govern MCP tools and owner forms. Reads and changes retain policy, grants, nonces and immutable audit records. Exact infrastructure changes use plan -> owner approval -> execute once.
5. Add the component to the inventory, Wrangler configuration, shared build/validation/release scripts and runtime boundary tests.

## Credential and state boundaries

Git stores source, configuration, binding names, migrations, routes, schedules, workflow definitions, storage policies and deployment metadata. Provider secrets, Access sessions, encryption keys, private GitHub keys, refresh/access tokens and Durable Object records stay in platform storage. `CREDENTIAL_KEK` is retained in the existing worker secret store; deployment keeps existing secrets. Backup and caretaker private keys remain in their existing DO namespaces. No credential is exported to the developer machine.

The gateway preserves hardware-MFA checks for credential rotation. Cloudflare provider profiles require server-side scoped token provisioning; the UI reports missing connections instead of pretending a logged-in owner implies provider API authority.

## Source and pipelines

This repository contains the gateway plus both component source trees under `workers/`, including all worker entrypoints, SQL migrations, backup/capture/catalog/restore/replication scripts, tests and locked build dependencies. `infrastructure/baseline-*` records the inspected pre-migration deployment; `infrastructure/storage.json` records live retention/lifecycle rules. These are evidence, not secret backups.

GitHub Actions performs read-only validation with pinned actions and no deployment secret. Reviewed source now packages artifacts for workflow_depot authorization and the standalone delivery_control executor; see [central deployment](CENTRAL-DEPLOYMENT.md). Both legacy direct deploy scripts fail closed. This source change does not reconfigure existing Cloudflare Build triggers. The backup capture workflow remains in `susanbeasles/backup-control` because its repository and workflow identity are pinned by OIDC; its exact source is also included in this repository's component tree. Future edits must update that workflow repository deliberately, not silently change the trusted job identity.

`infrastructure/build.json` and `scripts/reconcile-build.mjs` retain historical Build integration configuration and reconciliation code. They are not invoked by the central release path. Any trigger retirement is a separate reviewed infrastructure action. Keep component mirrors synchronized with canonical source until the existing triggers are deliberately retired. Private binding dependencies determine staged deployment order; no release should recreate the existing Durable Object namespaces.

## Verification and recovery

Run `npm ci --ignore-scripts`, the explicit `npm rebuild esbuild workerd --ignore-scripts=false --foreground-scripts`, `npm test`, and `npm run build` in CI. Tests cover real multi-worker private RPC, missing owner identity, cross-origin denial, setup redirects, callback state, profile/resource binding, PKCE, code and refresh replay, webhook raw-byte HMAC, immutable OIDC identity and actual backup restoration.

Do not delete or rename the existing DO classes or namespaces during recovery. Git contains their binding topology and migration history; provider data and credentials must be retained separately in their platform stores. A source rollback requires reviewing whether it would reintroduce independent login stacks.

## Declarative Access reconciliation

`infrastructure/auth.json` pins the sole owner application, its audience, domain and exact owner allowlist, and identifies the retired component applications. `scripts/auth-plan.mjs` refuses a changed gate or broader owner policy; `scripts/reconcile-auth.mjs` applies only the planned retirement and is idempotent. Access reconciliation is a separate reviewed security change; central artifact deployment does not run it. Run without `--apply` to review that plan. Existing gate IDs and audiences are preserved rather than creating another login boundary.

The account enforces default deny on unmatched Access destinations (observed error 1050). `public_ingress` declares the protocol/redirect transport as a Bypass application; it issues no identities or sessions. The more-specific `/owner` application retains the sole owner login, and the gateway still verifies signed owner assertions. MCP tokens, webhooks and Actions OIDC retain their application authentication. Other hostnames are not exempted from account default deny.

Historical deployment evidence recorded successful Worker uploads and Access reconciliation, token-management error 9109, and repository-connection error 8000012. Those records do not establish current write authority. Fresh October 12, 2026 read-only checks confirm the existing Worker/resource topology; central deployment services and their service credential bindings still require commissioning. Connector read authentication is not deployment authorization.

Dependency security updates are monitored separately from validation. The inspected Dependabot job for transitive `sharp` in the Wrangler development toolchain reports `security_update_not_possible` under upstream constraints. This is shown in the pipeline inventory; validation passing does not claim the dependency alert is resolved.
