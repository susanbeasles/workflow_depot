# Central deployment consumer

This repository builds source and packages exact deployment artifacts. Its legacy
`npm run deploy` entrypoint and the bundled ghcaretaker deploy script fail closed,
including when old Cloudflare credential variables are present. They perform no
Worker upload, migration, or Access reconciliation. The historical Workers Build
configuration still points at that disabled entrypoint; this change does not
reconfigure the remote trigger.

After `npm run build`, package one existing component locally:

```sh
node scripts/package-deployment.mjs personal-control reviewed-metadata.json artifact.json
```

Supply explicit reviewed metadata with `main_module: "worker.mjs"`, the component's
exact compatibility date and flags, and its exact bindings. The package preserves
the bundle's bytes and prints its artifact and metadata SHA-256 digests. The output
path must not already exist. The shared validator rejects unsupported metadata,
literal secret bindings, unresolved namespace IDs, missing baseline bindings, or
changes to configured variables, resources, and services. Additional inherited
secret names require central policy approval and provider verification that those
secrets already exist; the local packager makes neither assertion.

The contract modules under `scripts/deployment-contract/` are exact source copies
from repoctl; the adjacent manifest records their content digests and local source
state. Packaging is offline and does not approve, sign, stage, or deploy an artifact.

## Existing resources and pending activation

Read-only Cloudflare API checks on October 12, 2026 resolved the existing Durable
Object namespace IDs below. Retain these resources; do not recreate them from
their class declarations. Refresh the metadata check before an authorized release.

| Component | Binding | Existing namespace ID |
| --- | --- | --- |
| personal-control | `CONTROL` | `70f7a8f053eb4f2dac117ef5105fa1de` |
| personal-control | `APP_CONFIG` in backup-setup | `1a609704979d46338b83f11bb031ac0f` |
| ghcaretaker | `APP_VAULT` | `e424c2894ede430fa1673a6197742e90` |
| backup-control | `OUTBOX` | `04d8ed537bfe48d6b8537c442a1b02ef` |
| backup-control | `APP_CONFIG` in backup-setup | `1a609704979d46338b83f11bb031ac0f` |
| backup-setup | `BOOTSTRAP` | `1a609704979d46338b83f11bb031ac0f` |

These identifiers establish resource identity, not deployment approval or provider
credential validity. Final metadata and artifact digests must still be reviewed
and bound by the central deployment policy.

The central artifact contract does not apply Durable Object or D1 migrations,
cron schedules, Access policies, observability settings, or Workers Build triggers.
Existing configuration must be independently reconciled and verified before an
operation is authorized; packaging does not drop or recreate those resources.

The baseline personal-control target uses `control.vespoli.me`. ghcaretaker uses
three path routes under `mcp.vespoli.me`, rather than a dedicated custom domain.
Both backup Workers still declare workers.dev exposure in source. Current API
reads also confirm an existing `backup.vespoli.me` custom domain for backup-control,
which is newer than this embedded source baseline. Its workers.dev exposure remains
enabled; backup-setup has no custom domain. Reconcile this source drift explicitly
in the reviewed activation plan. Existing Caretaker path routes must be preserved,
and backup-setup must not be assigned an invented domain merely to fit a deployer.
This source change creates no domain, namespace, credential, or deployment authority.
