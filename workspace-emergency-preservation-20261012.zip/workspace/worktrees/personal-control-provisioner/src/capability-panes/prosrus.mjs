import {panel,outcome} from '../ui.mjs';
import {prosrusStatus} from '../capability-status.mjs';

export async function prosrusPanel(c,request,email,cap){
  const path=new URL(request.url).pathname;
  if(request.method!=='GET'||!['/owner/apps/prosrus','/owner/apps/prosrus/'].includes(path))return new Response(null,{status:404});
  const status=prosrusStatus(c.env);
  return panel(`<h2>ProsRUs</h2><p>Job Stack uses the shared owner login and a separate, explicitly selected workspace grant.</p>
    ${status.state==='configured'?'<p><a href="/owner/job-stack">Choose workspace grant</a></p>':'<p>Workspace access needs the private Product binding and a qualified hardware-assurance policy. No workspace grant is inferred from your infrastructure session.</p>'}
    ${outcome(status)}`,'prosrus',email);
}
