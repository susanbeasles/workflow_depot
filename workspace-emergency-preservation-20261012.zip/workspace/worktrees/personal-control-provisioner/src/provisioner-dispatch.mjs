import {configuredProfiles,profileDigest,readBytes} from './provisioner.mjs';
import {b64,unb64} from './security.mjs';
const encoder=new TextEncoder(),states=new Set(['launching','running','succeeded','failed','blocked','uncertain','recovery-required']);
const terminal=new Set(['succeeded','failed','blocked','recovery-required']);
const safeURL=value=>{try{const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password&&!url.port&&!url.search&&!url.hash&&/^[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(vespoli\.me|anthonyvespoli\.com)$/.test(url.hostname)?url.href:null;}catch{return null;}};
async function macKey(secret){if(typeof secret!=='string'||secret.length<32)throw Error('runner-not-configured');return crypto.subtle.importKey('raw',encoder.encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign','verify']);}
export async function dispatchAcceptedJob(env,job,profile){
  const endpoint=safeURL(env.PROVISIONER_DISPATCH_URL);if(!endpoint||!env.PROVISIONER_DISPATCH_AUDIENCE||typeof env.PROVISIONER_EXECUTOR?.fetch!=='function')throw Error('runner-not-configured');
  const key=await macKey(env.PROVISIONER_DISPATCH_KEY),nonce=crypto.randomUUID();
  const accepted={id:job.id,owner:job.owner,state:'accepted',rawPayload:job.rawPayload,payload:job.payload,payloadHash:job.payloadHash,context:job.context};
  const body=JSON.stringify({version:1,audience:env.PROVISIONER_DISPATCH_AUDIENCE,sentAt:Date.now(),nonce,job:accepted,profile});
  if(encoder.encode(body).length>131072)throw Error('dispatch-outcome-unknown');
  const signature=b64(await crypto.subtle.sign('HMAC',key,encoder.encode(body)));
  // The URL remains an approved request address; only the fixed private binding can
  // deliver it. Missing or failed bindings must never fall back to the network.
  const response=await env.PROVISIONER_EXECUTOR.fetch(endpoint,{method:'POST',headers:{'content-type':'application/json','x-provisioner-signature':signature},body,redirect:'manual',signal:AbortSignal.timeout(20000)});
  const bytes=await readBytes(response,16384),proof=response.headers.get('x-provisioner-signature');
  if(!response.ok||!/^[A-Za-z0-9_-]{43}$/.test(proof??'')||!await crypto.subtle.verify('HMAC',key,unb64(proof),bytes))throw Error('dispatch-outcome-unknown');
  const result=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
  if(result.jobId!==job.id||result.requestNonce!==nonce||!states.has(result.state))throw Error('dispatch-outcome-unknown');
  // Only fixed nonsecret reference fields cross into the owner-visible record.
  const receipt={};
  if(result.receipt){
    for(const name of ['itemId','vaultId'])if(typeof result.receipt[name]==='string'&&/^[a-z0-9]{26}$/.test(result.receipt[name]))receipt[name]=result.receipt[name];
    for(const name of ['recoveryId','kvId'])if(typeof result.receipt[name]==='string'&&/^[A-Za-z0-9:/_.-]{1,512}$/.test(result.receipt[name]))receipt[name]=result.receipt[name];
  }
  if(result.state==='succeeded'&&(!receipt.itemId||!receipt.vaultId))throw Error('dispatch-outcome-unknown');
  return {state:result.state,...(Object.keys(receipt).length?{receipt}:{})};
}

export async function drainProvisionerOutbox(c){
  const cursor=await c.storage.get('provisioner:dispatch-cursor');
  const entries=await c.storage.list({prefix:'provisioner:outbox:',limit:20,...(cursor?{startAfter:cursor}:{})});
  let pending=false;
  for(const [outboxKey,outbox] of entries){
    if(outbox.state!=='pending'){await c.storage.delete(outboxKey);continue;}
    const jobKey='provisioner:job:'+outbox.jobId,job=await c.storage.get(jobKey);if(!job)continue;
    const profile=configuredProfiles(c.env).find(p=>p.id===job.context?.profileId);
    let result;
    if(!profile||profile.manifest?.qualified!==true||await profileDigest(profile)!==job.context.profileDigest)result={state:'blocked',error:'approved-profile-unavailable'};
    else {
      try{result=await dispatchAcceptedJob(c.env,job,profile);}
      catch{result={state:'uncertain',error:'dispatch-outcome-unknown'};}
    }
    await c.storage.transaction(async tx=>{
      const current=await tx.get(outboxKey);if(current?.state!=='pending')return;
      const latest=await tx.get(jobKey);
      await tx.put(jobKey,{...latest,...result,updatedAt:Math.floor(Date.now()/1000)});
      if(terminal.has(result.state))await tx.delete(outboxKey);
      else await tx.put(outboxKey,{...current,state:'pending',attempts:(current.attempts??0)+1});
    });
    pending||=!terminal.has(result.state);
  }
  if(entries.size===20)await c.storage.put('provisioner:dispatch-cursor',[...entries.keys()].at(-1));
  else await c.storage.delete('provisioner:dispatch-cursor');
  if(pending||entries.size===20||cursor)await c.storage.setAlarm(Date.now()+30000);
}
