import {jobStackPolicy} from './job-stack/authority.mjs';
// Project only the documented public status fields. RPC errors and extra fields
// may contain provider data and must never become owner-facing diagnostics.
const object=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const identifier=value=>typeof value==='string'&&/^[A-Za-z0-9_.:/-]{1,200}$/.test(value)?value:null;
const count=value=>Number.isSafeInteger(value)&&value>=0?value:null;

export function caretakerStatus(value){
  if(!object(value)||!['empty','created','exchanging','quarantined','installed','installation-review-required'].includes(value.phase))throw Error('invalid-capability-status');
  const result={phase:value.phase};
  for(const key of ['app_id','installation_id']){
    const id=typeof value[key]==='number'?String(value[key]):value[key];
    if(typeof id==='string'&&/^[1-9][0-9]{0,19}$/.test(id))result[key]=id;
  }
  if(typeof value.slug==='string'&&/^[A-Za-z0-9-]{1,100}$/.test(value.slug))result.slug=value.slug;
  if(object(value.webhook)){
    const receipt=value=>object(value)&&identifier(value.id)&&identifier(value.event)?{
      id:identifier(value.id),event:identifier(value.event),action:identifier(value.action),
      repository:identifier(value.repository),received_at:identifier(value.received_at),
    }:null;
    result.webhook={configured:value.webhook.configured===true,accepted_count:count(value.webhook.accepted_count),
      last_delivery:receipt(value.webhook.last_delivery),recent:Array.isArray(value.webhook.recent)?value.webhook.recent.slice(0,20).map(receipt).filter(Boolean):[]};
  }
  return result;
}

export function backupStatus(value){
  if(!object(value)||value.service!=='backup-control'||typeof value.dispatch_enabled!=='boolean')throw Error('invalid-capability-status');
  return {service:'backup-control',webhook_configured:value.webhook_configured===true,
    app_configured:value.app_configured===true,installation_configured:value.installation_configured===true,
    dispatch_enabled:value.dispatch_enabled,dispatch_state:identifier(value.dispatch_state),
    outbox:{counts:Array.isArray(value.outbox?.counts)?value.outbox.counts.slice(0,10).filter(row=>object(row)&&['pending','complete','failed'].includes(row.status)&&count(row.count)!==null).map(row=>({status:row.status,count:row.count})):[]},
    capture_evidence:'Inspect retained manifests and restoration evidence; connection status does not prove a successful backup.'};
}

export async function readCapabilityStatus(binding,project,{timeoutMs=3000}={}){
  if(!binding||typeof binding.status!=='function')return {state:'unavailable',reason:'capability-binding-unavailable'};
  let timer;
  try{
    const result=await Promise.race([Promise.resolve().then(()=>binding.status()),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('capability-status-timeout')),timeoutMs);})]);
    return {state:'reachable',evidence:project(result)};
  }catch{return {state:'unavailable',reason:'capability-status-unavailable'};}
  finally{clearTimeout(timer);}
}

export function prosrusStatus(env){
  // A service declaration is not a selected workspace grant. No broad profile
  // session is sent to Product and no substitute authority is minted here.
  const bound=typeof env.JOB_STACK?.invokeCore==='function'&&typeof env.JOB_STACK?.ownerAsset==='function';
  let configured=false;try{jobStackPolicy(env);configured=true;}catch{}
  return {state:configured?'configured':'unavailable',private_product_binding:bound,
    reason:configured?'owner-workspace-selection-required':'qualified-owner-policy-or-product-binding-unavailable',
    required_contract:'job-stack.shared-auth.v1',grant_contract:'selected-v2',
    owner_path:'/owner/job-stack'};
}

export async function capabilityStatuses(env){
  const [caretaker,backups]=await Promise.all([
    readCapabilityStatus(env.CARETAKER,caretakerStatus),
    readCapabilityStatus(env.BACKUP,backupStatus),
  ]);
  return {caretaker,backups,prosrus:prosrusStatus(env)};
}
