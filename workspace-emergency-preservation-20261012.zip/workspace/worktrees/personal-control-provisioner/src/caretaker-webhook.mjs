import {json} from './security.mjs';

export async function caretakerWebhook(request,env){
  if(request.method!=='POST')return json({error:'method-not-allowed'},405,{allow:'POST'});
  if(typeof env.CARETAKER?.webhook!=='function')return json({error:'caretaker-webhook-unavailable'},503);
  const headers=new Headers();
  for(const name of ['content-type','content-length','content-encoding','x-github-delivery','x-github-event','x-hub-signature-256']){
    const value=request.headers.get(name);if(value!==null)headers.set(name,value);
  }
  // No owner assertion or browser credentials cross this machine-identity path.
  // Preserve the signed raw body; the capability owns HMAC and identity checks.
  const forwarded=new Request(env.ORIGIN+'/webhooks/github/caretaker',{method:'POST',headers,body:request.body,duplex:'half'});
  try{return await env.CARETAKER.webhook(forwarded);}
  catch{return json({error:'caretaker-webhook-unavailable'},503);}
}
