import {uiSession} from './owner-session.mjs';
import {caretakerPanel} from './capability-panes/caretaker.mjs';
import {backupSetupPanel} from './capability-panes/backup-setup.mjs';
import {provisionerPanel} from './capability-panes/provisioner.mjs';
import {prosrusPanel} from './capability-panes/prosrus.mjs';
import {capabilityStatuses,readCapabilityStatus,backupStatus} from './capability-status.mjs';
import {capabilities,capabilityForPath} from './capabilities.mjs';
import {profiles,profileScopes,alive} from './policy.mjs';
import {toolList,callTool,publicSession} from './tools.mjs';
import {panel,outcome,toolForm,argumentsFrom} from './ui.mjs';
import {escape,hash,scrub,json} from './security.mjs';
import {form,resource} from './oauth.mjs';
import {inventory} from './inventory.mjs';

export async function panes(c,request,email){
  const u=new URL(request.url),cap=capabilityForPath(u.pathname);
  if(u.pathname==='/owner'||u.pathname==='/owner/'){
    const statuses=await Promise.all(profiles.filter(p=>p!=='caretaker').map(async profile=>({profile,...await c.status(profile)})));
    return panel(`<h2>Infrastructure overview</h2><p>One owner login. Focused capabilities with shared inspection, approval and audit controls.</p><div class="grid">${capabilities.map(c=>`<section><h3><a href="/owner/apps/${c.id}">${c.title}</a></h3><p>${c.description}</p></section>`).join('')}</div>${outcome({capabilities:await capabilityStatuses(c.env),connections:statuses,monitor:await c.storage.get('monitor:last')||null})}`,'',email);
  }
  if(!cap)return null;
  if(cap.id==='provisioner')return provisionerPanel(c,request,email,cap);
  const route='/owner/apps/'+cap.id;let body=`<h2>${cap.title}</h2><p>${cap.description}</p>`;
  if(cap.id==='caretaker')return caretakerPanel(c,request,email,cap);
  if(cap.id==='prosrus')return prosrusPanel(c,request,email,cap);
  if(cap.id==='backups'&&u.pathname.startsWith(route+'/setup'))return backupSetupPanel(c,request,email,cap);
  if(cap.id==='connections'||cap.id==='credentials'){
    for(const p of profiles.filter(p=>p!=='caretaker'))body+=`<section><h3>${p}</h3>${outcome(await c.status(p))}<a href="/owner/github/start?profile=${p}">Connect or resume GitHub</a><p>MCP endpoint: <code>${resource(c.env,p)}</code></p></section>`;
    body+='<p><a href="/owner/apps/caretaker">Caretaker installation</a> &middot; <a href="/owner/apps/backups/setup/start">Backup installation</a></p>';
  }
  if(cap.id==='sessions'){
    const sessions=[...await c.storage.list({prefix:'session:',limit:100})].map(([,s])=>s).filter(s=>s.owner===email);
    body+=sessions.map(s=>`<section><a href="/owner/session?id=${escape(s.id)}">Inspect or revoke ${escape(s.profile)} session</a>${outcome(publicSession(s))}</section>`).join('')||'<p>No sessions.</p>';
    body+=`<form method="post" action="/owner/revoke-all"><input type="hidden" name="nonce" value="${await c.oauth.nonce(email,'revoke-all')}"><button>Revoke all my sessions</button></form>`;
  }
  if(cap.id==='credentials'){
    body+='<p>Provider credentials stay in their private vaults. Cloudflare profile provisioning still requires account token-management authority.</p>';
    for(const p of profiles.filter(p=>p!=='caretaker'))body+=`<form method="post" action="/owner/rotate-webhook"><input type="hidden" name="profile" value="${p}"><input type="hidden" name="nonce" value="${await c.oauth.nonce(email,'rotate-webhook:'+p)}"><button>Rotate ${p} webhook secret</button></form>`;
  }
  if(cap.id==='pipelines')body+=outcome(inventory);
  if(cap.id==='backups'){
    body+='<p><a href="/owner/apps/backups/setup/status">Installation status</a> &middot; <a href="/owner/apps/backups/setup/start">Connect or resume backup App</a></p>';
    body+=outcome(await readCapabilityStatus(c.env.BACKUP,backupStatus));
    body+=outcome({monitor:await c.storage.get('monitor:last')||null});
  }
  const profile=cap.id==='changes'?'write':'super',session=await uiSession(c,email,profile);
  const tools=toolList(session).filter(t=>cap.tools?.includes(t.name));
  if(request.method==='POST'){
    const f=await form(request);await c.oauth.consumeNonce(f.get('nonce'),email,'pane:'+cap.id);
    const tool=tools.find(t=>t.name===f.get('tool'));if(!tool)throw Error('tool-not-granted');
    const value=await callTool(c,session,tool.name,argumentsFrom(f,tool.inputSchema));await c.audit('owner.capability',{owner:email,capability:cap.id,tool:tool.name});
    body+=outcome(scrub(value));if(value.approval_url?.startsWith(c.env.ORIGIN+'/owner/approve?'))body+=`<p><a href="${escape(value.approval_url)}">Review this exact change</a></p>`;
  }
  const nonce=await c.oauth.nonce(email,'pane:'+cap.id);body+=tools.map(t=>toolForm(t,nonce,route)).join('');
  return panel(body,cap.id,email);
}
