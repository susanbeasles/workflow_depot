export const capabilities=Object.freeze([
  {id:'connections',title:'Connections',description:'Provider readiness, owner consent and MCP endpoints.',tools:['connection_status','current_session']},
  {id:'workers',title:'Workers',description:'Deployments, configuration, logs and Cloudflare jobs.',tools:['workers_list','worker_settings','worker_logs','cloudflare_jobs','cloudflare_read','cloudflare_graphql','api_catalog']},
  {id:'github',title:'GitHub',description:'Repositories, workflow runs, jobs, logs and artifacts.',tools:['github_repositories','github_actions_runs','github_actions_jobs','github_job_log','github_artifacts','github_read','github_graphql']},
  {id:'caretaker',title:'Caretaker',description:'Focused GitHub reading and explicit issue or review collaboration.',binding:'CARETAKER'},
  {id:'prosrus',title:'ProsRUs',description:'Job Stack workspace access and integration readiness.',binding:'JOB_STACK'},
  {id:'backups',title:'Backups',description:'App installation, retained deliveries, manifests and restoration evidence.',tools:['webhook_deliveries','webhook_delivery','backup_catalog','backup_manifest']},
  {id:'audit',title:'Audit',description:'Immutable records of reads, failures, grants and changes.',tools:['audit_entries','audit_entry']},
  {id:'changes',title:'Changes',description:'Plan an exact scoped change, approve it, then execute once.',tools:['write_plan','write_plan_status','write_execute']},
  {id:'sessions',title:'Sessions',description:'Inspect expiry, resource grants and revocation.',tools:['current_session']},
  {id:'credentials',title:'Credentials',description:'Provider installation and credential lifecycle controls.'},
  {id:'provisioner',title:'Provision',description:'Hardware-approved credential generation with a disposable B2 runner.'},
  {id:'pipelines',title:'Pipelines',description:'Source, deployment paths, schedules and operational evidence.'},
]);
export function capabilityForPath(path){return capabilities.find(c=>path==='/owner/apps/'+c.id||path.startsWith('/owner/apps/'+c.id+'/'));}
export function ownerPath(path){return path==='/owner'||path==='/owner/'||!!capabilityForPath(path)||path==='/owner/job-stack'||path==='/owner/job-stack/'||/^\/owner\/(?:consent|session|approve|revoke-all|rotate-webhook|github\/(?:start|callback|installed|resume))$/.test(path);}
