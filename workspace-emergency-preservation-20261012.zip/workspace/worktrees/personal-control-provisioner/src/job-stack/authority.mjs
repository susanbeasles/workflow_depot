import {CONTRACT,LIMITS,canonicalJson,detachedJson,validateWorkspaceGrant,validateCapability,validateInvocation,validateCoreInput,validateCoreOutput,validateRpc,operationByName} from './shared-contract.mjs';
import {hash,unb64,random} from '../security.mjs';

const fail=()=>{throw Error('job-stack-authority-unavailable');};
const ownerRoot='/owner/job-stack';
export const READ_NAMES=Object.freeze(['job_stack_session','job_stack_pipeline_page','job_stack_records','job_stack_version','job_stack_versions','job_stack_request','job_stack_protection']);
const exact=(value,keys)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===keys.length&&keys.every(key=>Object.hasOwn(value,key));
const hex=async value=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value)))].map(x=>x.toString(16).padStart(2,'0')).join('');
export const inputDigest=(operationId,input)=>hex(CONTRACT+'\0invocation-input\0'+canonicalJson({operationId,input}));

export function jobStackPolicy(env){
  let value;try{const raw=env.JOB_STACK_POLICY_JSON;if(typeof raw!=='string'||raw.length>2048)fail();value=JSON.parse(raw);}catch{fail();}
  if(!exact(value,['contract','enabled','qualificationDigest','maxLeaseMs'])||value.contract!=='job-stack.owner-policy.v1'||value.enabled!==true||!/^[a-f0-9]{64}$/.test(value.qualificationDigest)||!Number.isSafeInteger(value.maxLeaseMs)||value.maxLeaseMs<1000||value.maxLeaseMs>LIMITS.accessMs)fail();
  if(typeof env.JOB_STACK?.invokeCore!=='function'||typeof env.JOB_STACK?.ownerAsset!=='function')fail();
  return value;
}

// Invoke only after the existing ownerGate has verified this exact request's
// Access signature, issuer, audience and allowlist. Qualification is explicit;
// an ordinary signed identity is not silently treated as a hardware assertion.
export async function jobStackOwnerProof(request,email,env,now=Date.now()){
  const policy=jobStackPolicy(env),jwt=request.headers.get('cf-access-jwt-assertion');
  if(typeof jwt!=='string'||jwt.length>16384)fail();
  let claims;try{claims=JSON.parse(new TextDecoder().decode(unb64(jwt.split('.')[1])));}catch{fail();}
  if(claims.email?.toLowerCase()!==email||typeof claims.sub!=='string'||!claims.sub||!Array.isArray(claims.amr)||!claims.amr.includes('hwk')||!claims.amr.includes('mfa')||!Number.isSafeInteger(claims.auth_time)||claims.auth_time*1000>now||!Number.isSafeInteger(claims.exp)||claims.exp*1000<=now||claims.auth_time*1000+LIMITS.accessMs<=now)fail();
  const principal='access-owner:'+email,contextExpiresAtMs=claims.auth_time*1000+LIMITS.accessMs;
  // Token refresh can alter iat/exp/jti/signature without new hardware proof.
  // Keep one terminal lease context for that qualified authentication event.
  const context=await hash(canonicalJson({issuer:claims.iss,audience:env.ACCESS_AUD,subject:claims.sub,principal,authenticatedAtSeconds:claims.auth_time,assurance:['hwk','mfa'],qualificationDigest:policy.qualificationDigest}));
  return {principal,context,contextExpiresAtMs,expiresAtMs:Math.min(claims.exp*1000,contextExpiresAtMs),policyDigest:await hash(canonicalJson(policy))};
}

function selectedCurrent(grant,cap,principal,env,now){
  grant=validateWorkspaceGrant(grant);cap=validateCapability(cap);
  if(grant.issuer!==env.ORIGIN||grant.issuerPrincipalId!==principal||cap.issuerPrincipalId!==principal||grant.createdAtMs>now||grant.expiresAtMs<=now||grant.revokedAtMs!==null||cap.runtime!=='production'||cap.state!=='active'||grant.capabilityId!==cap.id||grant.capabilityRevision!==cap.revision||grant.resources[0].id!==cap.workspace.workspaceId||grant.resources[0].ownerId!==cap.workspace.ownerId)fail();
  return {grant,cap};
}
export function parseOwnerRead(target,workspaceId){
  if(typeof target!=='string'||target.length>4096||!target.startsWith(ownerRoot+'/api/operations/')||/[#\\\x00-\x20]/.test(target))fail();
  const u=new URL(target,'https://owner.invalid');if(u.origin!=='https://owner.invalid')fail();
  const name=u.pathname.slice((ownerRoot+'/api/operations/').length);if(!READ_NAMES.includes(name))fail();
  const operation=operationByName(name);if(!operation||operation.effect!=='read')fail();
  const fields=[...u.searchParams.keys()];if(new Set(fields).size!==fields.length||fields.some(key=>['grant','workspaceId'].includes(key)))fail();
  const input={workspaceId,...Object.fromEntries(u.searchParams)};
  if(['job_stack_records','job_stack_versions','job_stack_pipeline_page'].includes(name)&&!Object.hasOwn(input,'entityId'))input.cursor??=null;
  const validated=validateCoreInput(operation.id,input);u.searchParams.sort();
  return {operation,input:validated,target:u.pathname+u.search};
}

export function createJobStackAuthority(c,{clock=Date.now}={}){
  const current=async(grantId,principal,store=c.storage)=>{
    if(typeof grantId!=='string'||!grantId||grantId.length>256||grantId.trim()!==grantId)fail();
    const grant=await store.get('job-stack:grant:'+grantId);if(!grant||grant.id!==grantId)fail();
    const cap=await store.get('job-stack:capability:'+grant.capabilityId);if(!cap)fail();
    return selectedCurrent(grant,cap,principal,c.env,clock());
  };
  const leaseKey=async(grantId,proof)=>'job-stack:lease:'+await hash(canonicalJson({grantId,owner:proof.principal,context:proof.context}));
  const leaseCurrent=async(grantId,proof,store=c.storage)=>{
    const policy=jobStackPolicy(c.env),policyDigest=await hash(canonicalJson(policy));
    const pair=await current(grantId,proof.principal,store),key=await leaseKey(grantId,proof),lease=await store.get(key);
    if(!lease||lease.revoked||lease.expiresAtMs<=clock()||proof.expiresAtMs<=clock()||lease.context!==proof.context||lease.principal!==proof.principal||lease.policyDigest!==policyDigest||proof.policyDigest!==policyDigest||lease.grantDigest!==await hash(canonicalJson(pair.grant))||lease.capabilityDigest!==await hash(canonicalJson(pair.cap)))fail();
    return {...pair,lease,key};
  };
  async function nonce(grantId,proof,action,target){
    let lease=null;
    if(action==='read'){lease=(await leaseCurrent(grantId,proof)).lease;parseOwnerRead(target,(await current(grantId,proof.principal)).cap.workspace.workspaceId);}
    else if(!['establish','revoke'].includes(action)||target!==ownerRoot+'/session/'+action)fail();
    const {grant,cap}=await current(grantId,proof.principal),value=random(),key='job-stack:nonce:'+await hash(value);
    await c.storage.put(key,{grantId,principal:proof.principal,context:proof.context,policyDigest:proof.policyDigest,grantDigest:await hash(canonicalJson(grant)),capabilityDigest:await hash(canonicalJson(cap)),action,target,leaseId:lease?.id??null,expiresAtMs:Math.min(clock()+60000,proof.expiresAtMs,grant.expiresAtMs,lease?.expiresAtMs??Infinity)});
    return value;
  }
  async function burn(value,grantId,proof,action,target){
    if(typeof value!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(value))fail();
    const key='job-stack:nonce:'+await hash(value);
    // Burn commits even when later binding checks fail. Concurrent consumers can
    // never both use one nonce, including when reads bypass Control's old queue.
    const record=await c.storage.transaction(async tx=>{const row=await tx.get(key);await tx.delete(key);return row;});
    const {grant,cap}=await current(grantId,proof.principal);
    if(!record||record.grantId!==grantId||record.principal!==proof.principal||record.context!==proof.context||record.policyDigest!==proof.policyDigest||record.action!==action||record.target!==target||record.expiresAtMs<=clock()||record.grantDigest!==await hash(canonicalJson(grant))||record.capabilityDigest!==await hash(canonicalJson(cap)))fail();
    return record;
  }
  return {
    current,nonce,
    async list(principal){jobStackPolicy(c.env);const records=await c.storage.list({prefix:'job-stack:grant:',limit:100}),result=[];for(const [,value]of records){try{const {grant,cap}=await current(value.id,principal);result.push({id:grant.id,workspace:cap.workspace,expiresAtMs:grant.expiresAtMs});}catch{}}return result;},
    async establish(grantId,proof,value){
      const policy=jobStackPolicy(c.env);if(proof.policyDigest!==await hash(canonicalJson(policy))||proof.expiresAtMs<=clock())fail();
      await burn(value,grantId,proof,'establish',ownerRoot+'/session/establish');
      const key=await leaseKey(grantId,proof);
      return c.storage.transaction(async tx=>{
        const {grant,cap}=await current(grantId,proof.principal,tx),old=await tx.get(key);
        if(old){if(old.revoked||old.expiresAtMs<=clock())fail();return (await leaseCurrent(grantId,proof,tx)).lease;}
        const lease={id:crypto.randomUUID(),principal:proof.principal,context:proof.context,policyDigest:proof.policyDigest,grantDigest:await hash(canonicalJson(grant)),capabilityDigest:await hash(canonicalJson(cap)),createdAtMs:clock(),expiresAtMs:Math.min(clock()+policy.maxLeaseMs,proof.expiresAtMs,grant.expiresAtMs),proofExpiresAtMs:proof.contextExpiresAtMs,revoked:false};
        await tx.put(key,lease);return lease;
      });
    },
    async revoke(grantId,proof,value){await burn(value,grantId,proof,'revoke',ownerRoot+'/session/revoke');const key=await leaseKey(grantId,proof);await c.storage.transaction(async tx=>{const lease=await tx.get(key);await tx.put(key,{...lease,principal:proof.principal,context:proof.context,proofExpiresAtMs:proof.contextExpiresAtMs,revoked:true});});return {revoked:true};},
    leaseCurrent,
    async invoke(grantId,proof,target,value){
      const initial=await leaseCurrent(grantId,proof),read=parseOwnerRead(target,initial.cap.workspace.workspaceId);
      const consumed=await burn(value,grantId,proof,'read',read.target),fresh=await leaseCurrent(grantId,proof);
      if(consumed.leaseId!==fresh.lease.id)fail();
      const {grant,cap,lease}=fresh,operation=read.operation;
      if(!grant.scopes.includes(operation.scope)||!cap.scopes.includes(operation.scope))fail();
      const now=clock(),id=crypto.randomUUID(),expiresAtMs=Math.min(now+30000,lease.expiresAtMs,grant.expiresAtMs,proof.expiresAtMs);
      const invocation=validateInvocation({contract:CONTRACT,invocationId:id,entrypoint:'owner',verifiedOwnerPrincipalId:proof.principal,grant,capability:cap,
        access:{kind:'canonical',grantId:grant.id,grantRevision:grant.revision,principalId:grant.principalId,clientId:grant.clientId,issuer:grant.issuer,audience:grant.audience,expiresAtMs},
        operation:{id:operation.id,version:operation.version,scope:operation.scope,effect:operation.effect,inputDigest:await inputDigest(operation.id,read.input)},authorizedAtMs:now,expiresAtMs});
      const record={invocation,proof,leaseId:lease.id};await c.storage.put('job-stack:invocation:'+id,record);
      try{
        let result;
        if(operation.name==='job_stack_session')result={grantId:grant.id,grantRevision:grant.revision,principalId:grant.principalId,clientId:grant.clientId,issuer:grant.issuer,audience:grant.audience,capabilityId:cap.id,capabilityRevision:cap.revision,scopes:grant.scopes.filter(scope=>cap.scopes.includes(scope)&&READ_NAMES.some(name=>operationByName(name)?.scope===scope)),resources:grant.resources,createdAtMs:lease.createdAtMs,expiresAtMs:lease.expiresAtMs};
        else {let timer;try{result=await Promise.race([c.env.JOB_STACK.invokeCore({contract:CONTRACT,invocationId:id,operationId:operation.id,input:read.input}),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('job-stack-read-timeout')),Math.max(1,expiresAtMs-clock()));})]);}finally{clearTimeout(timer);}}
        await this.revalidate({contract:CONTRACT,invocationId:id,operationId:operation.id,inputDigest:invocation.operation.inputDigest,stage:'before-ack'});
        return validateCoreOutput(operation.id,rpcValue(result),{grantId});
      }finally{await c.storage.delete('job-stack:invocation:'+id);}
    },
    async revalidate(value){
      const request=validateRpc('revalidate',value);if(!['read','before-ack'].includes(request.stage))fail();
      const record=await c.storage.get('job-stack:invocation:'+request.invocationId);if(!record)fail();
      const invocation=validateInvocation(record.invocation);if(invocation.entrypoint!=='owner'||invocation.operation.effect!=='read'||invocation.operation.id!==request.operationId||invocation.operation.inputDigest!==request.inputDigest||invocation.expiresAtMs<=clock())fail();
      const fresh=await leaseCurrent(invocation.grant.id,record.proof);
      if(fresh.lease.id!==record.leaseId||canonicalJson(fresh.grant)!==canonicalJson(invocation.grant)||canonicalJson(fresh.cap)!==canonicalJson(invocation.capability))fail();
      return {invocation,now:clock(),expiresAtMs:Math.min(invocation.expiresAtMs,fresh.lease.expiresAtMs)};
    },
  };
}

export async function cleanupJobStack(storage,now=Date.now()){
  for(const prefix of ['job-stack:nonce:','job-stack:invocation:','job-stack:lease:']){
    const rows=await storage.list({prefix,limit:1000});
    for(const [key,value]of rows){const expiry=prefix==='job-stack:lease:'?value.proofExpiresAtMs:prefix==='job-stack:invocation:'?value.invocation?.expiresAtMs:value.expiresAtMs;if(Number.isSafeInteger(expiry)&&expiry<=now)await storage.delete(key);}
  }
}
export async function revokeJobStackSessions(storage,email){
  let revoked=0;for(const [key,lease]of await storage.list({prefix:'job-stack:lease:',limit:10000})){
    if(lease.principal==='access-owner:'+email&&!lease.revoked){await storage.put(key,{...lease,revoked:true});revoked++;}
  }return revoked;
}

// Workerd adds a non-enumerable disposal hook to RPC results. Never accept it
// from public JSON, invoke getters or weaken the shared closed-value validator.
function rpcValue(value){
  if(value===null||typeof value!=='object')return detachedJson(value);
  const marker=Object.getOwnPropertyDescriptor(value,Symbol.dispose);if(!marker)return detachedJson(value,{maxBytes:LIMITS.privateComposite});
  if(marker.enumerable||typeof marker.value!=='function')fail();
  const copy=Object.create(Object.getPrototypeOf(value));for(const key of Reflect.ownKeys(value))if(key!==Symbol.dispose)Object.defineProperty(copy,key,Object.getOwnPropertyDescriptor(value,key));
  try{return detachedJson(copy,{maxBytes:LIMITS.privateComposite});}finally{marker.value.call(value);}
}
