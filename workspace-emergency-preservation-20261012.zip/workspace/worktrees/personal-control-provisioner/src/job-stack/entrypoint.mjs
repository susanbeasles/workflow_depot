import {WorkerEntrypoint} from 'cloudflare:workers';
import {validateRpc} from './shared-contract.mjs';

export class JobStackAuthority extends WorkerEntrypoint {
  async fetch(){return new Response(null,{status:404});}
  async revalidate(value){
    const request=validateRpc('revalidate',value);
    const response=await this.env.CONTROL.get(this.env.CONTROL.idFromName('owner')).fetch(new Request(this.env.ORIGIN+'/internal/job-stack/revalidate',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(request)}));
    if(!response.ok)throw Error('job-stack-authority-unavailable');
    return response.json();
  }
}
