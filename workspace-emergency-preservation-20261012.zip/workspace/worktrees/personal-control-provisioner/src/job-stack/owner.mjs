import {createJobStackAuthority,jobStackOwnerProof,jobStackPolicy,parseOwnerRead} from './authority.mjs';
import {panel,outcome} from '../ui.mjs';
import {escape,json} from '../security.mjs';
import {form} from '../oauth.mjs';
const ROOT='/owner/job-stack';
const unavailable=()=>json({error:'job-stack-authority-unavailable'},503);
function oneQuery(url,allowed){const keys=[...url.searchParams.keys()];if(new Set(keys).size!==keys.length||keys.some(key=>!allowed.includes(key)))throw Error('job-stack-invalid-selection');}

export async function jobStackOwner(c,request,email){
  const u=new URL(request.url),path=u.pathname;
  if(path!==ROOT&&!path.startsWith(ROOT+'/'))return null;
  if(!['GET','POST'].includes(request.method))return json({error:'method-not-allowed'},405);
  try{
    jobStackPolicy(c.env);
    const proof=await jobStackOwnerProof(request,email,c.env),authority=createJobStackAuthority(c);
    if(request.headers.has('origin')&&request.headers.get('origin')!==c.env.ORIGIN)throw Error('job-stack-origin-invalid');
    if(path.includes('/api/')&&request.headers.get('sec-fetch-site')==='cross-site')throw Error('job-stack-origin-invalid');
    if([ROOT,ROOT+'/'].includes(path)&&request.method==='GET'){
      // Product owns its presentation query. The gateway reads only the exact
      // selected grant and never forwards any query/header to the asset binding.
      if(u.searchParams.getAll('grant').length>1)throw Error('job-stack-invalid-selection');
      const grantId=u.searchParams.get('grant');
      if(grantId){try{await authority.leaseCurrent(grantId,proof);return await ownerAsset(c,request);}catch{}}
      const grants=await authority.list(proof.principal);let body='<h2>ProsRUs workspace</h2><p>Select an existing workspace grant to start a bounded hardware-assured session.</p>';
      for(const grant of grants){const nonce=await authority.nonce(grant.id,proof,'establish',ROOT+'/session/establish');body+=`<section><h3>${escape(grant.workspace.workspaceId)}</h3>${outcome(grant)}<form method="post" action="${ROOT}/session/establish"><input type="hidden" name="grant" value="${escape(grant.id)}"><input type="hidden" name="nonce" value="${nonce}"><button>Open workspace</button></form></section>`;}
      if(!grants.length)body+='<p>No current workspace grant is available for this owner.</p>';
      return panel(body,'prosrus',email);
    }
    if(/^\/owner\/job-stack\/assets\/[A-Za-z0-9_.-]+$/.test(path)&&request.method==='GET'){oneQuery(u,[]);return await ownerAsset(c,request);}
    if([ROOT+'/session/establish',ROOT+'/session/revoke'].includes(path)&&request.method==='POST'){
      if(request.headers.get('origin')!==c.env.ORIGIN)throw Error('job-stack-origin-invalid');
      oneQuery(u,[]);const fields=await form(request);if([...fields.keys()].some(key=>!['grant','nonce'].includes(key))||fields.getAll('grant').length!==1||fields.getAll('nonce').length!==1)throw Error('job-stack-invalid-selection');
      const grantId=fields.get('grant');
      if(path.endsWith('/establish'))await authority.establish(grantId,proof,fields.get('nonce'));
      else await authority.revoke(grantId,proof,fields.get('nonce'));
      return Response.redirect(c.env.ORIGIN+ROOT+(path.endsWith('/establish')?'?grant='+encodeURIComponent(grantId):''),303);
    }
    if(path===ROOT+'/api/nonce'&&request.method==='GET'){
      oneQuery(u,['grant','target']);const grantId=u.searchParams.get('grant'),rawTarget=u.searchParams.get('target');
      if(rawTarget===ROOT+'/session/revoke')return json({nonce:await authority.nonce(grantId,proof,'revoke',rawTarget)});
      const {cap}=await authority.current(grantId,proof.principal),read=parseOwnerRead(rawTarget,cap.workspace.workspaceId);
      return json({nonce:await authority.nonce(grantId,proof,'read',read.target)});
    }
    if(path.startsWith(ROOT+'/api/operations/')&&request.method==='GET'){
      const grantId=u.searchParams.get('grant');if(u.searchParams.getAll('grant').length!==1)throw Error('job-stack-invalid-selection');
      u.searchParams.delete('grant');u.searchParams.sort();
      return json(await authority.invoke(grantId,proof,u.pathname+u.search,request.headers.get('x-owner-nonce')));
    }
    return json({error:'not-found'},404);
  }catch{return unavailable();}
}

async function ownerAsset(c,request){
  const u=new URL(request.url);u.search='';u.hash='';
  const response=await c.env.JOB_STACK.ownerAsset(new Request(u,{method:'GET'}));
  if(response.status!==200)return new Response(null,{status:404});
  const headers=new Headers();for(const name of ['content-type','content-security-policy']){const value=response.headers.get(name);if(value)headers.set(name,value);}
  headers.set('cache-control','no-store');headers.set('referrer-policy','no-referrer');headers.set('x-content-type-options','nosniff');
  return new Response(response.body,{status:200,headers});
}
