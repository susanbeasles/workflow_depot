import {WorkerEntrypoint} from 'cloudflare:workers';
import {privateOrigin} from './provisioner.mjs';
import {json} from './security.mjs';

// Only a separately governed private ingress service receives this named binding.
// The default public Worker never forwards provisioning admissions.
export class ProvisionerAdmission extends WorkerEntrypoint {
  async fetch(request){
    const url=new URL(request.url),origin=privateOrigin(this.env);
    const allowed=['/owner/apps/provisioner/challenge','/owner/apps/provisioner/submit'];
    if(!origin||url.origin!==origin||!allowed.includes(url.pathname)||request.headers.get('origin')!==this.env.ORIGIN)return json({error:'not-found'},404);
    const cors={'access-control-allow-origin':this.env.ORIGIN,'access-control-allow-credentials':'true','vary':'Origin'};
    if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{...cors,'access-control-allow-methods':'POST','access-control-allow-headers':'content-type,x-provisioner-nonce,x-provisioner-signature','access-control-max-age':'0'}});
    if(request.method!=='POST')return json({error:'method-not-allowed'},405);
    const internal=new URL('/internal/provisioner/'+url.pathname.split('/').at(-1),this.env.ORIGIN);
    const response=await this.env.CONTROL.get(this.env.CONTROL.idFromName('owner')).fetch(new Request(internal,request));
    const headers=new Headers(response.headers);for(const [key,value] of Object.entries(cors))headers.set(key,value);
    return new Response(response.body,{status:response.status,headers});
  }
}
