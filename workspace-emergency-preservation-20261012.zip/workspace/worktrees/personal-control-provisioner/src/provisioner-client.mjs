// This module is also emitted as a same-origin, owner-authenticated browser script.
// Keep emitted functions self-contained; no secrets or key material live here.
export function provisionerPrivateOrigin(value){
  if(typeof value!=='string')return null;
  try{
    const url=new URL(value);
    if(url.protocol!=='https:'||url.username||url.password||url.port||url.pathname!=='/'||url.search||url.hash)return null;
    if(!['.vespoli.me','.anthonyvespoli.com'].some(suffix=>url.hostname.endsWith(suffix)))return null;
    return url.origin;
  }catch{return null;}
}

// The only production browser signer transport. Chrome authenticates the extension
// channel; its service worker pins the page origin before opening the native host.
export async function createNativeProvisionerSigner({chrome,config,origin,crypto,setTimer=setTimeout,clearTimer=clearTimeout,requestTimeoutMs=120000,onDisconnect=()=>{}}){
  const error=code=>Object.assign(new Error(code),{code});
  if(typeof config?.signerExtensionId!=='string'||!/^[a-p]{32}$/.test(config.signerExtensionId))throw error('signer-extension-not-configured');
  if(typeof chrome?.runtime?.connect!=='function')throw error('signer-extension-unavailable');
  if(!provisionerPrivateOrigin(origin)||new URL(origin).origin!==origin)throw error('origin-denied');
  if(!/^[a-f0-9]{64}$/.test(config.keyId??''))throw error('key-mismatch');
  const extensionId=config.signerExtensionId,keyId=config.keyId,runtime=chrome.runtime,encoder=new TextEncoder();
  const exact=(value,keys)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).sort().join(',')===keys.slice().sort().join(',');
  const encoded=bytes=>btoa(String.fromCharCode(...bytes)).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
  const decode=value=>{
    if(typeof value!=='string'||value.length>2731||!/^[A-Za-z0-9_-]+$/.test(value))return null;
    try{const bytes=Uint8Array.from(atob(value.replace(/-/g,'+').replace(/_/g,'/')),character=>character.charCodeAt(0));return encoded(bytes)===value?bytes:null;}catch{return null;}
  };
  const codes=new Set(['invalid-request','origin-denied','key-mismatch','signer-unavailable','signer-declined','invalid-signer-response','approval-order-invalid','approval-expired','signer-timeout','native-disconnected']);
  let port,pending,closed=false,phase='hello';
  const close=(code='native-disconnected',notify=false)=>{
    if(closed)return;closed=true;phase='closed';
    if(pending){clearTimer(pending.timer);pending.reject(error(code));pending=null;}
    try{port?.disconnect();}catch{}if(notify)onDisconnect(code);
  };
  try{port=runtime.connect(extensionId,{name:'provisioner-v1'});}catch{throw error('signer-extension-unavailable');}
  port.onDisconnect.addListener(()=>{void runtime.lastError;close('native-disconnected',true);});
  port.onMessage.addListener(response=>{
    if(closed)return;
    let bounded=false;try{bounded=encoder.encode(JSON.stringify(response)).length<=4096;}catch{}
    if(!pending||!bounded||response.version!==1||response.id!==pending.id||typeof response.ok!=='boolean'){close('invalid-signer-response');return;}
    if(response.ok===false){close(exact(response,['version','id','ok','error'])&&codes.has(response.error)?response.error:'invalid-signer-response');return;}
    const signing=pending.action==='sign',bytes=signing?decode(response.signature):null;
    if(!exact(response,signing?['version','id','ok','keyId','signature']:['version','id','ok','keyId'])||response.keyId!==keyId||signing&&bytes?.length!==64){close('invalid-signer-response');return;}
    const request=pending;pending=null;clearTimer(request.timer);phase=request.next;request.resolve(response);
  });
  const request=(action,extra,next)=>new Promise((resolve,reject)=>{
    if(closed){reject(error('native-disconnected'));return;}
    if(pending){reject(error('request-in-progress'));return;}
    const id=crypto.randomUUID(),timer=setTimer(()=>close('signer-timeout'),action==='hello'?10000:requestTimeoutMs);
    pending={id,action,next,resolve,reject,timer};
    try{port.postMessage({version:1,id,action,origin,keyId,...extra});}catch{close('native-disconnected');}
  });
  await request('hello',{},'ready');
  return Object.freeze({
    get state(){return phase;},
    close:()=>close(),
    async sign(input){
      if(!exact(input,['purpose','bytes','keyId']))throw error('invalid-request');
      if(input.keyId!==keyId)throw error('key-mismatch');
      const bytes=decode(input.bytes);let next;
      if(input.purpose==='provisioner.auth-request.v1'){
        if(phase!=='ready')throw error('approval-order-invalid');
        if(!bytes||bytes.length>2048)throw error('invalid-request');next='awaiting-nonce';
      }else if(input.purpose==='provisioner.nonce.v1'){
        if(phase!=='awaiting-nonce')throw error('approval-order-invalid');
        if(bytes?.length!==43||decode(String.fromCharCode(...bytes))?.length!==32)throw error('invalid-request');next='complete';
      }else throw error('invalid-request');
      return (await request('sign',{purpose:input.purpose,bytes:input.bytes},next)).signature;
    },
  });
}

export function createProvisionerClient({fetch,crypto,signer,now=()=>Date.now(),uuid=()=>crypto.randomUUID(),onProgress=()=>{},onJob=()=>{}}){
  const encoder=new TextEncoder();
  const base64url=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/=/g,'').replace(/\+/g,'-').replace(/\//g,'_');
  const error=code=>Object.assign(new Error(code),{code});
  const identifier=value=>typeof value==='string'&&/^[A-Za-z0-9_.-]{1,128}$/.test(value);
  const canonicalBytes=(value,length)=>{
    if(typeof value!=='string'||!/^[A-Za-z0-9_-]+$/.test(value)||value.length>128)return false;
    try{const bytes=Uint8Array.from(atob(value.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));return bytes.length===length&&base64url(bytes)===value;}catch{return false;}
  };
  const fields=['operation','secretUrl','1passwordRecordUrl','generatedCredentialType','uDomId','pwdDomId','otpDomId','loginUrl','recordType','generatedCredentialName','duration','KV','toVault','permissions'];
  const validatePayload=payload=>{
    if(!payload||Object.getPrototypeOf(payload)!==Object.prototype||Object.keys(payload).some(key=>!fields.includes(key)))throw error('invalid-payload');
    if(payload.operation!=='generate-api-key')throw error('operation-not-enabled');
    if(typeof payload.generatedCredentialType!=='string'||!/^[a-z][a-z0-9-]{0,63}$/.test(payload.generatedCredentialType))throw error('invalid-payload');
    for(const key of ['secretUrl','1passwordRecordUrl'])if(typeof payload[key]!=='string'||!payload[key])throw error('invalid-payload');
    for(const key of ['uDomId','pwdDomId','otpDomId','loginUrl','recordType','generatedCredentialName','toVault'])if(payload[key]!==undefined&&typeof payload[key]!=='string')throw error('invalid-payload');
    if(payload.duration!==undefined&&(!Number.isSafeInteger(payload.duration)||payload.duration<=0))throw error('invalid-payload');
    if(typeof payload.KV!=='boolean'||!Array.isArray(payload.permissions)||payload.permissions.length>32)throw error('invalid-payload');
    for(const permission of payload.permissions){
      if(!permission||Object.keys(permission).sort().join(',')!=='fieldDomId,value'||typeof permission.fieldDomId!=='string'||!permission.fieldDomId||!['string','number','boolean'].includes(typeof permission.value)||typeof permission.value==='number'&&!Number.isFinite(permission.value))throw error('invalid-permissions');
    }
  };
  const signed=async(purpose,bytes,keyId)=>{
    let signature;
    try{signature=await signer.sign({purpose,bytes:base64url(bytes),keyId});}catch(failure){throw error(['native-disconnected','signer-timeout','key-mismatch','origin-denied','approval-order-invalid','approval-expired','invalid-signer-response','signer-unavailable'].includes(failure?.code)?failure.code:'signer-declined');}
    if(!canonicalBytes(signature,64))throw error('invalid-signer-response');
    return signature;
  };
  const read=async(response,ambiguous=false)=>{
    let body;try{body=await response.json();}catch{throw error(ambiguous?'submission-unknown':'invalid-server-response');}
    if(!response.ok){
      if(ambiguous&&response.status>=500)throw error('submission-unknown');
      const failure=error('request-rejected');
      const codes=['required','invalid-json','invalid-utf8','object-required','unknown-field','not-enabled','not-approved','invalid-name','boolean-required','encrypted-destination-required','array-required','invalid-permission','scope-mismatch','profile-incomplete'];
      failure.fields=Array.isArray(body?.fields)?body.fields.filter(item=>item&&(fields.includes(item.field)||item.field==='$'||/^permissions\[(?:[0-9]|[12][0-9]|3[01])\]$/.test(item.field))&&codes.includes(item.code)).slice(0,48).map(({field,code})=>({field,code})):[];
      throw failure;
    }
    return body;
  };
  let inFlight=false;
  return Object.freeze({
    async submit({config,profileId,payload}){
      if(inFlight)throw error('request-in-progress');
      if(!config||config.ready!==true||!provisionerPrivateOrigin(config.privateOrigin))throw error('setup-required');
      const profile=config.profiles?.find(item=>item.id===profileId);
      if(!profile||!identifier(profile.id)||typeof profile.digest!=='string'||!/^[A-Za-z0-9_-]{43,128}$/.test(profile.digest))throw error('profile-unavailable');
      if(typeof config.keyId!=='string'||!/^[a-f0-9]{64}$/.test(config.keyId)||typeof config.audience!=='string'||!config.audience||config.audience.length>512)throw error('setup-required');
      if(typeof signer?.sign!=='function')throw error('signer-unavailable');
      validatePayload(payload);
      // Capture every approval input synchronously before either hardware ceremony.
      const raw=encoder.encode(JSON.stringify(payload));
      if(raw.byteLength>32768)throw error('payload-too-large');
      const privateOrigin=provisionerPrivateOrigin(config.privateOrigin),keyId=config.keyId,audience=config.audience,profileDigest=profile.digest,selectedProfileId=profile.id;
      inFlight=true;
      try{
        const payloadHash=base64url(await crypto.subtle.digest('SHA-256',raw)),requestId=uuid(),issuedAt=Math.floor(now()/1000);
        onProgress('request-signature');
        const input=encoder.encode(JSON.stringify(['provisioner.auth-request.v1',requestId,issuedAt,audience,keyId,profileDigest,payloadHash]));
        const signature=await signed('provisioner.auth-request.v1',input,keyId);
        onProgress('challenge');
        let response;
        try{response=await fetch(privateOrigin+'/owner/apps/provisioner/challenge',{method:'POST',credentials:'include',redirect:'error',cache:'no-store',headers:{'content-type':'application/json'},body:JSON.stringify({keyId,requestId,issuedAt,profileId:selectedProfileId,payloadHash,signature})});}catch{throw error('private-ingress-unavailable');}
        const challenge=await read(response);
        if(!canonicalBytes(challenge?.nonce,32)||!identifier(challenge?.jobId)||!Number.isSafeInteger(challenge?.expiresAt)||challenge.expiresAt<=Math.floor(now()/1000))throw error('invalid-server-response');
        const nonce=challenge.nonce,jobId=challenge.jobId,expiresAt=challenge.expiresAt;
        onJob(jobId);onProgress('nonce-signature');
        // Protocol requirement: sign the UTF8 bytes of the ASCII nonce string only.
        const finalSignature=await signed('provisioner.nonce.v1',encoder.encode(nonce),keyId);
        if(expiresAt<=Math.floor(now()/1000))throw error('challenge-expired');
        onProgress('submitting');
        try{response=await fetch(privateOrigin+'/owner/apps/provisioner/submit',{method:'POST',credentials:'include',redirect:'error',cache:'no-store',headers:{'x-provisioner-nonce':nonce,'x-provisioner-signature':finalSignature},body:raw});}catch{throw error('submission-unknown');}
        const job=await read(response,true);
        if(job?.id!==jobId||typeof job.state!=='string')throw error('submission-unknown');
        return {id:job.id,state:job.state,provider:job.provider,operation:job.operation};
      }finally{inFlight=false;}
    },
    async status(id){
      if(!identifier(id))throw error('invalid-job-reference');
      let response;try{response=await fetch('/owner/apps/provisioner/jobs/'+encodeURIComponent(id),{method:'GET',credentials:'same-origin',cache:'no-store',redirect:'error'});}catch{throw error('status-unavailable');}
      const job=await read(response);
      if(job?.id!==id||typeof job.state!=='string')throw error('invalid-server-response');
      return {id:job.id,state:job.state,provider:job.provider,operation:job.operation};
    },
  });
}

export async function provisionerBrowser(){
  const byId=id=>document.getElementById(id),form=byId('provision-form'),submit=byId('provision-submit'),status=byId('provision-status'),profileSelect=byId('provision-profile'),permissions=byId('provision-permissions'),refresh=byId('provision-refresh');
  const missingSigner='The signing extension is unavailable. Open this page in the configured Chrome browser with the Provisioner Signer extension installed.';
  const messages={
    'signer-unavailable':missingSigner,'signer-declined':'Hardware approval was declined or unavailable. No signed submission was sent.',
    'invalid-signer-response':'The signing extension or native host returned an invalid response. Check setup, then reload this page.',
    'signer-extension-unavailable':missingSigner,
    'signer-extension-not-configured':'The signing extension ID is not configured for this owner panel.',
    'native-disconnected':'The signing extension or native host disconnected. Check installation, then reload this page.',
    'signer-timeout':'The native signer timed out. Reload this page before a new approval.',
    'key-mismatch':'The configured signing key does not match the native host. Check the approved signer configuration.',
    'origin-denied':'This owner origin is not approved by the signing extension.',
    'approval-order-invalid':'This signing session cannot approve another request. Reload this page to start a new session.',
    'approval-expired':'The signing session expired. Reload this page before a new approval.',
    'setup-required':'Provisioning is blocked until the required setup is complete.',
    'profile-unavailable':'Select an approved runtime profile.',
    'private-ingress-unavailable':'The private admission service is unreachable. Check your private network connection and owner session.',
    'submission-unknown':'Submission result unknown. Refresh this job’s status before starting another request.',
    'challenge-expired':'Hardware approval took too long. The challenge expired; start a new approval.',
    'request-rejected':'The server rejected this request. Check the form against the approved profile.',
    'invalid-payload':'Check the required fields and use a positive whole number for duration.',
    'invalid-permissions':'Each permission needs a field DOM ID and a valid string, number or boolean value.',
    'payload-too-large':'The request exceeds the 32 KiB limit.',
    'operation-not-enabled':'Only API key generation is enabled for this operation.',
    'status-unavailable':'Job status is unavailable. Retry the status check before starting another job.',
    'invalid-server-response':'The server response could not be verified. Check setup before proceeding.',
  };
  const blockerMessages={
    'private-ingress-not-configured':'Private admission origin is not configured.',
    'owner-key-trust-not-configured':'The existing owner signing trust is not wired to this provisioner.',
    'hardware-verifier-not-configured':'Hardware signature verification is not configured.',
    'runner-not-configured':'The disposable runner is not configured.',
    'provider-profile-not-qualified':'A qualified provider runtime profile is not available.',
    'signer-extension-not-configured':'The signing extension ID is not configured.',
    'encrypted-kv-not-configured':'Encrypted KV delivery is not configured.',
  };
  const progress={
    'request-signature':'Confirm the request on your hardware signer.',
    challenge:'Requesting a one-use challenge from the private service…',
    'nonce-signature':'Confirm submission on your hardware signer.',
    submitting:'Submitting the exact approved request…',
  };
  let config,client,signer,jobId,busy=false,locked=false;
  const controls=()=>form.querySelectorAll('input, select, textarea, button');
  const report=(text,tone='neutral')=>{status.textContent=text;status.dataset.tone=tone;};
  const showFailure=failure=>{
    report(messages[failure?.code]||'Provisioning could not continue. Check setup and try again.','blocked');
    const list=byId('provision-errors');list.replaceChildren();
    for(const item of failure?.fields||[]){const row=document.createElement('li');row.textContent=item.field+': '+item.code.replaceAll('-',' ');list.append(row);}
  };
  const permissionRow=(permission={fieldDomId:'',value:''})=>{
    const row=document.createElement('div');row.className='permission-row';
    const fieldLabel=document.createElement('label');fieldLabel.textContent='Field DOM ID';
    const field=document.createElement('input');field.name='permissionField';field.autocomplete='off';field.value=permission.fieldDomId;field.required=true;fieldLabel.append(field);
    const typeLabel=document.createElement('label');typeLabel.textContent='Value type';
    const type=document.createElement('select');type.name='permissionType';
    for(const name of ['string','number','boolean']){const option=document.createElement('option');option.value=name;option.textContent=name;type.append(option);}
    type.value=typeof permission.value;typeLabel.append(type);
    const valueLabel=document.createElement('label');valueLabel.textContent='Approved value';
    const value=document.createElement('input');value.name='permissionValue';value.autocomplete='off';value.value=String(permission.value);valueLabel.append(value);
    const hint=()=>{value.placeholder=type.value==='boolean'?'true or false':type.value==='number'?'A finite number':'Exact approved text';};hint();type.addEventListener('change',hint);
    const remove=document.createElement('button');remove.type='button';remove.className='secondary';remove.textContent='Remove';remove.setAttribute('aria-label','Remove permission');remove.addEventListener('click',()=>row.remove());
    row.append(fieldLabel,typeLabel,valueLabel,remove);permissions.append(row);
  };
  const applyProfile=()=>{
    const profile=config?.profiles?.find(item=>item.id===profileSelect.value);if(!profile)return;
    const type=form.elements.namedItem('generatedCredentialType');
    type.replaceChildren();const choice=document.createElement('option');
    choice.value=typeof profile.defaults?.generatedCredentialType==='string'?profile.defaults.generatedCredentialType:'';
    choice.textContent=choice.value||'Credential type missing from profile';type.append(choice);
    for(const name of ['secretUrl','1passwordRecordUrl','generatedCredentialType','uDomId','pwdDomId','otpDomId','loginUrl','recordType','generatedCredentialName','duration','toVault']){
      const value=profile.defaults?.[name];form.elements.namedItem(name).value=typeof value==='string'||typeof value==='number'?String(value):'';
    }
    form.elements.namedItem('KV').checked=profile.defaults?.KV!==false;
    permissions.replaceChildren();for(const item of profile.defaults?.permissions||[])permissionRow(item);
    byId('provision-profile-summary').textContent=typeof profile.display==='string'?profile.display:JSON.stringify(profile.display||{},null,2);
    byId('provision-profile-digest').textContent=profile.digest;
  };
  const payloadFromForm=()=>{
    const value=name=>form.elements.namedItem(name).value;
    const payload={operation:value('operation'),secretUrl:value('secretUrl'),'1passwordRecordUrl':value('1passwordRecordUrl'),generatedCredentialType:value('generatedCredentialType'),KV:form.elements.namedItem('KV').checked,permissions:[]};
    for(const name of ['uDomId','pwdDomId','otpDomId','loginUrl','recordType','generatedCredentialName','toVault'])if(value(name)!=='')payload[name]=value(name);
    if(value('duration')!=='')payload.duration=Number(value('duration'));
    for(const row of permissions.children){
      const fieldDomId=row.querySelector('[name="permissionField"]').value,type=row.querySelector('[name="permissionType"]').value,input=row.querySelector('[name="permissionValue"]').value;
      if(type==='boolean'&&!['true','false'].includes(input)||type==='number'&&(!input.trim()||!Number.isFinite(Number(input))))throw {code:'invalid-permissions'};
      payload.permissions.push({fieldDomId,value:type==='boolean'?input==='true':type==='number'?Number(input):input});
    }
    return payload;
  };
  const showJob=job=>{
    const states={validating:'Validating',accepted:'Accepted for execution','dispatch-pending':'Waiting for runner',launching:'Launching runner',running:'Running',succeeded:'Succeeded',failed:'Failed',blocked:'Blocked',uncertain:'Outcome uncertain','recovery-required':'Recovery required',rejected:'Rejected'};
    byId('provision-job-state').textContent=states[job.state]||'Status received';
    report(job.state==='accepted'?'Job accepted. Credential generation and delivery are not yet confirmed.':'Job status updated. Review the delivery and cleanup evidence before using a credential.');
  };
  byId('provision-add-permission').addEventListener('click',()=>permissionRow());
  profileSelect.addEventListener('change',applyProfile);
  form.addEventListener('submit',async event=>{
    event.preventDefault();if(busy||locked||submit.disabled)return;
    let payload;try{payload=payloadFromForm();}catch(failure){showFailure(failure);return;}
    busy=true;byId('provision-errors').replaceChildren();for(const element of controls())element.disabled=true;
    try{const job=await client.submit({config,profileId:profileSelect.value,payload});locked=true;showJob(job);}
    catch(failure){locked=failure?.code==='submission-unknown'||signer.state!=='ready';showFailure(failure);if(locked&&failure?.code!=='submission-unknown')status.textContent+=' Reload this page before a new approval.';}
    finally{busy=false;if(locked)signer.close();else for(const element of controls())element.disabled=false;submit.disabled=locked;}
  });
  refresh.addEventListener('click',async()=>{
    if(!jobId||busy)return;refresh.disabled=true;
    try{showJob(await client.status(jobId));}catch(failure){showFailure(failure);}finally{refresh.disabled=false;}
  });
  try{
    const response=await fetch('/owner/apps/provisioner/config',{credentials:'same-origin',cache:'no-store',redirect:'error'});
    if(!response.ok)throw {code:'setup-required'};
    config=await response.json();
    const profiles=Array.isArray(config.profiles)?config.profiles:[];
    for(const profile of profiles){const option=document.createElement('option');option.value=profile.id;option.textContent=profile.title||profile.id;profileSelect.append(option);}
    if(profiles.length){profileSelect.value=profiles[0].id;applyProfile();}
    const blockers=byId('provision-blockers');blockers.replaceChildren();
    for(const code of Array.isArray(config.blockers)?config.blockers:[]){const item=document.createElement('li');item.textContent=blockerMessages[code]||'Provisioning is blocked by server setup policy.';blockers.append(item);}
    report('Checking the signing extension and native host. No signing approval is requested.');
    signer=await createNativeProvisionerSigner({chrome:window.chrome,config,origin:window.location?.origin,crypto,onDisconnect:code=>{submit.disabled=true;if(!busy&&!locked)report(messages[code]||messages['native-disconnected'],'blocked');}});
    window.addEventListener?.('pagehide',()=>signer.close(),{once:true});
    if(config.ready!==true||!profiles.length||!provisionerPrivateOrigin(config.privateOrigin)){signer.close();report(messages['setup-required'],'blocked');return;}
    client=createProvisionerClient({fetch,crypto,signer,onProgress:state=>report(progress[state]),onJob:id=>{jobId=id;byId('provision-job').hidden=false;byId('provision-job-id').textContent=id;byId('provision-job-state').textContent='Awaiting signed submission';refresh.hidden=false;refresh.disabled=false;}});
    submit.disabled=false;report('Ready for hardware approval. Review the exact values below.','ready');
  }catch(failure){signer?.close();report(messages[failure?.code]||'Setup could not be loaded. Refresh after checking your owner session and service configuration.','blocked');}
}

export function provisionerClientSource(){return `'use strict';\n${provisionerPrivateOrigin.toString()}\n${createNativeProvisionerSigner.toString()}\n${createProvisionerClient.toString()}\n(${provisionerBrowser.toString()})();\n`;}
export function provisionerClientResponse(){return new Response(provisionerClientSource(),{headers:{'content-type':'text/javascript; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'no-referrer'}});}
