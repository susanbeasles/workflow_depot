import {b64,unb64,json,random} from './security.mjs';

const encoder=new TextEncoder();
export const PAYLOAD_LIMIT=32768;
const digestPattern=/^[A-Za-z0-9_-]{43}$/;
const fields=new Set(['operation','uDomId','pwdDomId','otpDomId','loginUrl','secretUrl','1passwordRecordUrl','recordType','generatedCredentialName','generatedCredentialType','duration','KV','toVault','permissions']);
const fail=(message,details)=>Object.assign(Error(message),details);
export const canonical=value=>Array.isArray(value)?'['+value.map(canonical).join(',')+']':value&&typeof value==='object'?'{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k])).join(',')+'}':JSON.stringify(value);
export const digestBytes=async bytes=>b64(await crypto.subtle.digest('SHA-256',bytes));
export const profileDigest=async profile=>digestBytes(encoder.encode(canonical(profile)));

// Strict JSON accepts the user wire format without reserializing before hashing.
// Reject duplicate keys even when an escape produces the same decoded key.
export function strictJSON(text){
  let i=0;
  const invalid=()=>{throw fail('payload-invalid',{fields:[{field:'$',code:'invalid-json'}]});};
  const ws=()=>{while(/[\x20\t\r\n]/.test(text[i]??'x'))i++;};
  function string(){const start=i++;while(i<text.length){if(text[i]==='\\'){i+=2;continue;}if(text[i++]==='"'){try{return JSON.parse(text.slice(start,i));}catch{invalid();}}}invalid();}
  function value(depth=0){
    if(depth>5)invalid();ws();
    if(text[i]==='"')return string();
    if(text[i]==='{'){
      i++;ws();const result=Object.create(null),seen=new Set();if(text[i]==='}'){i++;return result;}
      while(i<text.length){ws();if(text[i]!=='"')invalid();const k=string();if(seen.has(k))invalid();seen.add(k);ws();if(text[i++]!==':')invalid();result[k]=value(depth+1);ws();const end=text[i++];if(end==='}')return result;if(end!==',')invalid();}invalid();
    }
    if(text[i]==='['){i++;ws();const result=[];if(text[i]===']'){i++;return result;}while(i<text.length){result.push(value(depth+1));if(result.length>64)invalid();ws();const end=text[i++];if(end===']')return result;if(end!==',')invalid();}invalid();}
    const m=/^(?:true|false|null|-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?)/.exec(text.slice(i));if(!m)invalid();i+=m[0].length;const result=JSON.parse(m[0]);if(typeof result==='number'&&!Number.isFinite(result))invalid();return result;
  }
  const result=value();ws();if(i!==text.length)invalid();return result;
}

export function validatePayload(payload,profile,jobId='00000000-0000-0000-0000-000000000000'){
  const errors=[],add=(field,code)=>errors.push({field,code});
  if(!payload||typeof payload!=='object'||Array.isArray(payload))throw fail('payload-invalid',{fields:[{field:'$',code:'object-required'}]});
  if(Object.keys(payload).some(k=>!fields.has(k)))throw fail('payload-invalid',{fields:[{field:'$',code:'unknown-field'}]});
  if(payload.operation!=='generate-api-key'||typeof profile.provider!=='string'||!/^[a-z0-9][a-z0-9-]{0,63}$/.test(profile.provider)||(profile.manifest?.version!==2&&profile.provider!=='b2')||profile.operation!==payload.operation)add('operation','not-enabled');
  for(const k of ['secretUrl','1passwordRecordUrl','generatedCredentialType'])if(typeof payload[k]!=='string'||!payload[k])add(k,'required');
  const constraints=profile.constraints??{};
  for(const k of ['uDomId','pwdDomId','otpDomId','loginUrl','secretUrl','1passwordRecordUrl','recordType','generatedCredentialType','toVault']){
    if(payload[k]!==undefined&&(typeof payload[k]!=='string'||payload[k].length>1024||payload[k]!==constraints[k]))add(k,'not-approved');
  }
  const credentialName=payload.generatedCredentialName??constraints.generatedCredentialName??'Provisioner secret #'+jobId;
  const names=profile.namePolicy??(profile.manifest?.version===1&&profile.provider==='b2'?{allowedCharacters:'alphanumeric-hyphen',maxLength:100}:null);
  if(!names||Object.keys(names).sort().join(',')!=='allowedCharacters,maxLength'||!['alphanumeric-hyphen','printable-ascii'].includes(names.allowedCharacters)||!Number.isSafeInteger(names.maxLength)||names.maxLength<1||names.maxLength>128)add('generatedCredentialName','invalid-name');
  else if(typeof credentialName!=='string'||credentialName.length>names.maxLength||!(names.allowedCharacters==='alphanumeric-hyphen'?/^[A-Za-z0-9-]+$/:/^[\x20-\x7e]+$/).test(credentialName)||payload.generatedCredentialName!==undefined&&constraints.generatedCredentialName!==undefined&&payload.generatedCredentialName!==constraints.generatedCredentialName)add('generatedCredentialName','invalid-name');
  if(constraints.duration!==undefined&&(!Number.isSafeInteger(constraints.duration)||constraints.duration<1)||payload.duration!==undefined&&(!Number.isSafeInteger(payload.duration)||payload.duration<1||payload.duration!==constraints.duration))add('duration','not-approved');
  if(payload.KV!==undefined&&typeof payload.KV!=='boolean')add('KV','boolean-required');
  const kv=payload.KV??true;
  if(kv&&(!profile.kv?.destination||!profile.kv?.encryptionKeyId))add('KV','encrypted-destination-required');
  if(!Array.isArray(payload.permissions)||payload.permissions.length>32)add('permissions','array-required');
  else {
    const ids=new Set();
    payload.permissions.forEach((permission,index)=>{
      const field='permissions['+index+']';
      if(!permission||typeof permission!=='object'||Array.isArray(permission)||Object.keys(permission).sort().join()!=='fieldDomId,value'||typeof permission.fieldDomId!=='string'||!['string','number','boolean'].includes(typeof permission.value)||typeof permission.value==='number'&&!Number.isFinite(permission.value)||ids.has(permission.fieldDomId)){add(field,'invalid-permission');return;}
      ids.add(permission.fieldDomId);
      if(!constraints.permissions?.some(p=>p.fieldDomId===permission.fieldDomId&&p.value===permission.value))add(field,'not-approved');
    });
    if(canonical(payload.permissions)!==canonical(constraints.permissions??[]))add('permissions','scope-mismatch');
  }
  if(!profile.sourceRecord||profile.sourceRecord!==constraints['1passwordRecordUrl']||!profile.outputVault||!profile.recovery?.destination||!profile.recovery?.encryptionKeyId)add('$','profile-incomplete');
  if(errors.length)throw fail('payload-invalid',{fields:errors});
  return {...payload,KV:kv};
}

export function createProvisioner({storage,trust,hardware,profiles,audience,clock=()=>Math.floor(Date.now()/1000)}){
  const getProfile=id=>profiles.find(p=>p.id===id);
  async function signer(owner,keyId){
    try{
      if(!/^[a-f0-9]{64}$/.test(keyId??''))throw Error();
      const key=await trust.current(keyId);
      if(key?.keyID!==keyId||key.ownerEmail!==owner||!Number.isSafeInteger(key.ownerID)||key.ownerID<1||key.revoked!==false||!key.purposes?.includes('credential-provisioning'))throw Error();
      const raw=Uint8Array.from(atob(key.publicKeyX963),c=>c.charCodeAt(0));
      const fingerprint=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',raw)),n=>n.toString(16).padStart(2,'0')).join('');
      if(fingerprint!==keyId)throw Error();
      const proof=await hardware.verify({keyID:keyId,ownerID:key.ownerID});
      if(proof?.keyID!==keyId||proof.hardwareVerified!==true||proof.revoked!==false||!/^[a-f0-9]{64}$/.test(proof.proofDigest??'')||!Number.isSafeInteger(proof.validUntil)||proof.validUntil<=clock())throw Error();
      return await crypto.subtle.importKey('raw',raw,{name:'ECDSA',namedCurve:'P-256'},false,['verify']);
    }catch{throw fail('authorization-invalid');}
  }
  async function verify(key,signature,message){
    try{if(!/^[A-Za-z0-9_-]{86}$/.test(signature??'')||!await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},key,unb64(signature),encoder.encode(message)))throw Error();}catch{throw fail('authorization-invalid');}
  }
  async function nonceRecord(nonce){
    if(!digestPattern.test(nonce??''))throw fail('nonce-unavailable');
    const key='provisioner:nonce:'+await digestBytes(encoder.encode(nonce)),record=await storage.get(key);
    if(!record||record.state!=='issued'||record.expiresAt<=clock())throw fail('nonce-unavailable');
    return {key,record};
  }
  return {
    async challenge(owner,input){
      if(!input||Object.keys(input).sort().join()!=='issuedAt,keyId,payloadHash,profileId,requestId,signature'||!Number.isSafeInteger(input.issuedAt)||Math.abs(clock()-input.issuedAt)>60||!digestPattern.test(input.payloadHash??'')||!/^[-_A-Za-z0-9]{16,128}$/.test(input.requestId??''))throw fail('authorization-invalid');
      const profile=getProfile(input.profileId);
      if(!profile||profile.manifest?.qualified!==true)throw fail('provider-profile-not-qualified');
      const digest=await profileDigest(profile),key=await signer(owner,input.keyId);
      await verify(key,input.signature,JSON.stringify(['provisioner.auth-request.v1',input.requestId,input.issuedAt,audience,input.keyId,digest,input.payloadHash]));
      const nonce=random(),jobId=crypto.randomUUID(),issuedAt=clock(),expiresAt=issuedAt+120;
      const context={profileId:profile.id,profileDigest:digest,codeDigest:profile.codeRevision,manifestDigest:await profileDigest(profile.manifest),policyRevision:profile.policyRevision,audience,ownerKeyId:input.keyId};
      const record={owner,jobId,payloadHash:input.payloadHash,context,issuedAt,expiresAt,state:'issued'};
      const nonceKey='provisioner:nonce:'+await digestBytes(encoder.encode(nonce));
      await storage.transaction(async tx=>{
        const replayKey='provisioner:request:'+owner+':'+input.requestId;
        if(await tx.get(replayKey))throw fail('request-replayed');
        const rateKey='provisioner:rate:'+owner,rate=await tx.get(rateKey),window=Math.floor(issuedAt/60),count=rate?.window===window?rate.count+1:1;
        if(count>10)throw fail('request-rate-limited');
        await tx.put(rateKey,{window,count});
        await tx.put(replayKey,{expiresAt:issuedAt+180});
        await tx.put(nonceKey,record);
      });
      return {nonce,expiresAt,jobId};
    },
    async submit(owner,nonce,signature,readPayload){
      const {key:nonceKey,record}=await nonceRecord(nonce);
      if(record.owner!==owner||record.context.audience!==audience)throw fail('authorization-invalid');
      const key=await signer(owner,record.context.ownerKeyId);
      // Purpose two: exactly the returned nonce string. The authenticated digest
      // and identity remain in immutable server state, never resent here.
      await verify(key,signature,nonce);
      const profile=getProfile(record.context.profileId);
      if(!profile||profile.manifest?.qualified!==true||await profileDigest(profile)!==record.context.profileDigest)throw fail('authorization-invalid');
      const jobKey='provisioner:job:'+record.jobId;
      await storage.transaction(async tx=>{
        const current=await tx.get(nonceKey);
        if(current?.state!=='issued'||current.expiresAt<=clock())throw fail('nonce-unavailable');
        await tx.put(nonceKey,{...current,state:'consumed',consumedAt:clock()});
        await tx.put(jobKey,{id:record.jobId,owner,state:'validating',createdAt:clock(),payloadHash:record.payloadHash,context:record.context,provider:profile.provider,operation:'generate-api-key'});
        await tx.put('provisioner:validating:'+record.jobId,{jobId:record.jobId,createdAt:clock()});
      });
      try{
        const bytes=await readPayload();
        if(!(bytes instanceof Uint8Array)||bytes.byteLength>PAYLOAD_LIMIT)throw fail('payload-too-large');
        if(await digestBytes(bytes)!==record.payloadHash)throw fail('payload-hash-mismatch');
        let rawPayload;try{rawPayload=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{throw fail('payload-invalid',{fields:[{field:'$',code:'invalid-utf8'}]});}
        const payload=strictJSON(rawPayload);validatePayload(payload,profile,record.jobId);
        await storage.transaction(async tx=>{
          const job=await tx.get(jobKey);if(job?.state!=='validating')throw fail('job-unavailable');
          await tx.put(jobKey,{...job,state:'accepted',rawPayload,payload,acceptedAt:clock()});
          await tx.put('provisioner:outbox:'+record.jobId,{jobId:record.jobId,state:'pending',createdAt:clock()});
          await tx.delete('provisioner:validating:'+record.jobId);
        });
      }catch(error){
        const permitted=['payload-too-large','payload-hash-mismatch','payload-invalid'];
        const reason=permitted.includes(error.message)?error.message:'admission-failed';
        await storage.transaction(async tx=>{const job=await tx.get(jobKey);if(job?.state==='validating')await tx.put(jobKey,{...job,state:'rejected',error:reason,fields:error.fields,finishedAt:clock()});await tx.delete('provisioner:validating:'+record.jobId);});
        throw fail(reason,error.fields?{fields:error.fields}:{});
      }
      return this.status(owner,record.jobId);
    },
    async status(owner,id){
      if(!/^[a-f0-9-]{36}$/.test(id??''))throw fail('job-not-found');
      const job=await storage.get('provisioner:job:'+id);
      if(!job||job.owner!==owner)throw fail('job-not-found');
      return {id:job.id,state:job.state,provider:job.provider,operation:job.operation,createdAt:job.createdAt,...(job.error?{error:job.error}:{}),...(job.fields?{fields:job.fields}:{}),...(job.receipt?{receipt:job.receipt}:{})};
    }
  };
}

export async function readBytes(request,limit=PAYLOAD_LIMIT,timeoutMs=10000){
  const reader=request.body?.getReader();if(!reader)return new Uint8Array();
  let size=0,timer;const chunks=[];
  const timeout=new Promise((_,reject)=>{timer=setTimeout(()=>{reject(fail('admission-failed'));void reader.cancel().catch(()=>{});},timeoutMs);});
  try{
    while(true){const {done,value}=await Promise.race([reader.read(),timeout]);if(done)break;size+=value.byteLength;if(size>limit){void reader.cancel().catch(()=>{});throw fail('payload-too-large');}chunks.push(value);}
    const out=new Uint8Array(size);let offset=0;for(const value of chunks){out.set(value,offset);offset+=value.byteLength;}return out;
  }finally{clearTimeout(timer);}
}

export async function cleanupProvisioner(storage,now=Math.floor(Date.now()/1000)){
  for(const prefix of ['provisioner:nonce:','provisioner:request:','provisioner:rate:']){
    const entries=await storage.list({prefix,limit:100});
    for(const [key,value] of entries)if(value.expiresAt!==undefined?value.expiresAt+60<now:value.window<Math.floor(now/60)-5)await storage.delete(key);
  }
  const jobs=await storage.list({prefix:'provisioner:validating:',limit:100});
  for(const [key,index] of jobs)if(index.createdAt+300<now)await storage.transaction(async tx=>{
    const jobKey='provisioner:job:'+index.jobId,value=await tx.get(jobKey);
    if(value?.state==='validating')await tx.put(jobKey,{...value,state:'rejected',error:'admission-interrupted',finishedAt:now});
    await tx.delete(key);
  });
}

export function configuredProfiles(env){
  try{const values=JSON.parse(env.PROVISIONER_PROFILES??'[]');return Array.isArray(values)?values:[];}catch{return [];}
}
export function enrollmentBindings(env){
  async function bound(binding,path,input){
    const response=await binding.fetch('https://internal'+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(input),redirect:'manual',signal:AbortSignal.timeout(10000)});
    if(!response.ok)throw fail('authorization-invalid');
    return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(await readBytes(response,8192)));
  }
  let mappings=[];try{mappings=JSON.parse(env.PROVISIONER_OWNER_BINDINGS??'[]');if(!Array.isArray(mappings))mappings=[];}catch{}
  const trust=env.PROVISIONER_TRUST??(env.ENROLLMENT_TRUST?{async current(keyID){
    const accepted=await bound(env.ENROLLMENT_TRUST,'/v1/enrollment/trust',{keyID});
    const mapping=mappings.find(m=>m.keyId===keyID&&m.ownerID===accepted.ownerID);
    if(!mapping||accepted.keyID!==keyID)return null;
    // Independent deployment mapping authorizes reuse of an already pinned key.
    // No new key, reenrollment, or caller-selected owner is accepted here.
    return {...accepted,ownerEmail:mapping.ownerEmail,purposes:['credential-provisioning']};
  }}:null);
  const hardware=env.PROVISIONER_HARDWARE??(env.ENROLLMENT_HARDWARE?{verify:input=>bound(env.ENROLLMENT_HARDWARE,'/v1/enrollment/verify',input)}:null);
  return {trust,hardware};
}
export function privateOrigin(env){
  try{const u=new URL(env.PROVISIONER_PRIVATE_ORIGIN);if(u.protocol==='https:'&&/^[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(vespoli\.me|anthonyvespoli\.com)$/.test(u.hostname)&&u.origin===env.PROVISIONER_PRIVATE_ORIGIN)return u.origin;}catch{}
  return null;
}
export async function provisionerPanelConfig(c,email){
  const profiles=configuredProfiles(c.env),origin=privateOrigin(c.env),blockers=[];
  const signerExtensionId=typeof c.env.PROVISIONER_SIGNER_EXTENSION_ID==='string'&&/^[a-p]{32}$/.test(c.env.PROVISIONER_SIGNER_EXTENSION_ID)?c.env.PROVISIONER_SIGNER_EXTENSION_ID:null;
  const {trust,hardware}=enrollmentBindings(c.env);
  if(!origin)blockers.push('private-ingress-not-configured');
  if(!signerExtensionId)blockers.push('signer-extension-not-configured');
  if(!trust||!c.env.PROVISIONER_OWNER_KEY_ID)blockers.push('owner-key-trust-not-configured');
  if(!hardware)blockers.push('hardware-verifier-not-configured');
  if(!c.env.PROVISIONER_DISPATCH_URL||!c.env.PROVISIONER_DISPATCH_KEY||!c.env.PROVISIONER_DISPATCH_AUDIENCE||typeof c.env.PROVISIONER_EXECUTOR?.fetch!=='function')blockers.push('runner-not-configured');
  const qualified=profiles.filter(p=>typeof p.provider==='string'&&/^[a-z0-9][a-z0-9-]{0,63}$/.test(p.provider)&&(p.manifest?.version===2||p.provider==='b2')&&p.operation==='generate-api-key'&&p.manifest?.qualified===true);
  if(!qualified.length)blockers.push('provider-profile-not-qualified');
  if(qualified.some(p=>!p.kv?.destination||!p.kv?.encryptionKeyId))blockers.push('encrypted-kv-not-configured');
  if(trust&&c.env.PROVISIONER_OWNER_KEY_ID){
    try{const key=await trust.current(c.env.PROVISIONER_OWNER_KEY_ID);if(key?.ownerEmail!==email||key.revoked!==false||!key.purposes?.includes('credential-provisioning'))blockers.push('owner-key-trust-not-configured');}catch{blockers.push('owner-key-trust-not-configured');}
  }
  return {ready:blockers.length===0,blockers:[...new Set(blockers)],privateOrigin:origin,audience:origin,keyId:c.env.PROVISIONER_OWNER_KEY_ID??null,signerExtensionId,profiles:await Promise.all(qualified.map(async p=>({id:p.id,title:p.title??'Backblaze B2',digest:await profileDigest(p),defaults:{operation:'generate-api-key',...p.constraints,KV:true},display:{provider:p.provider,outputVault:p.outputVault,itemTitle:p.itemTitle,kvDestination:p.kv?.destination,codeDigest:p.codeRevision,manifestDigest:p.manifestRevision,policyRevision:p.policyRevision}})))};
}

export function provisionerFor(c){return createProvisioner({storage:c.storage,...enrollmentBindings(c.env),profiles:configuredProfiles(c.env),audience:privateOrigin(c.env)});}

export async function provisionerAdmission(c,request,email){
  try{
    const config=await provisionerPanelConfig(c,email);
    if(!config.ready)return json({error:'provisioner-setup-required',blockers:config.blockers},503);
    const path=new URL(request.url).pathname,service=provisionerFor(c);
    if(path.endsWith('/challenge')){
      const input=strictJSON(new TextDecoder('utf-8',{fatal:true}).decode(await readBytes(request,4096)));
      return json(await service.challenge(email,input));
    }
    if(path.endsWith('/submit')){
      const result=await service.submit(email,request.headers.get('x-provisioner-nonce'),request.headers.get('x-provisioner-signature'),()=>readBytes(request));
      // Durable outbox already committed. Alarm scheduling failure must not turn
      // accepted work into a rejection or invite a second authorization.
      try{await c.storage.setAlarm(Date.now()+1000);}catch{}
      return json(result,202);
    }
    return json({error:'not-found'},404);
  }catch(error){
    const safe=new Set(['authorization-invalid','provider-profile-not-qualified','request-replayed','request-rate-limited','nonce-unavailable','payload-hash-mismatch','payload-too-large','payload-invalid','admission-failed']);
    const code=safe.has(error.message)?error.message:'admission-failed';
    return json({error:code,...(code==='payload-invalid'&&error.fields?{fields:error.fields}:{})},code==='authorization-invalid'?403:code==='request-replayed'||code==='nonce-unavailable'?409:400);
  }
}
