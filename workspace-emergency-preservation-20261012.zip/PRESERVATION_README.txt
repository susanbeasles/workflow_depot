Emergency preservation of /workspace

All preserved files are byte-for-byte copies. Original workspace was not modified.
Includes Git objects, refs, reflogs, indexes, worktree metadata, staged/unstaged and untracked source files.
Excluded credential locations/environment files, dependency caches, build output, logs, nested generated archives and runtime databases; see PRESERVATION_EXCLUSIONS.json.
No application tests, commits, deployments or development performed.
Git worktree pointer files retain original /workspace paths. If extracting elsewhere, run the optional relocate_worktrees.py in this archive ON THE EXTRACTED COPY to adjust those pointers.
Sensitivity checks are automated plus reviewed scanner findings; no known stored secrets or identifiable patient records were found in included content.
