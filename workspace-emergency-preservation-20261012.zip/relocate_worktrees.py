# Optional restoration helper: run only in the extracted archive directory.
from pathlib import Path
root=Path(__file__).resolve().parent/"workspace"
for p in root.rglob("*"):
 if p.is_file() and (p.name==".git" or (p.name in {"gitdir","commondir"} and ".git" in p.parts)):
  old=p.read_text(); new=old.replace("/workspace/",str(root)+"/")
  if new!=old:p.write_text(new)
print("Extracted-copy Git worktree pointers relocated.")
